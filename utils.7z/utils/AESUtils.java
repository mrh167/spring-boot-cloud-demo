package com.sinosoft.car.utils;

import cn.hutool.core.collection.CollectionUtil;
import com.google.common.hash.Hashing;
import org.apache.commons.codec.binary.Base64;
import org.apache.pdfbox.util.Charsets;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.crypto.*;
import javax.crypto.spec.SecretKeySpec;
import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Collections;
import java.util.List;

public class AESUtils {

    private static final Logger LOGGER = LoggerFactory.getLogger(AESUtils.class);

    private final static String CHARSET = "UTF-8";

    public static String encryptBase64(String seed, String content) {
        try {
            byte[] rawKey = getRawKey(seed.getBytes(CHARSET));
            byte[] encrypt = encrypt(rawKey, content.getBytes(CHARSET));
            return Base64.encodeBase64String(encrypt);
        } catch (Exception e) {
            LOGGER.error("AES加密Base64编码出错", e);
            throw new RuntimeException(e);
        }
    }

    public static String decryptBase64(String seed, String encrypted) {
        try {
            byte[] rawKey = getRawKey(seed.getBytes(CHARSET));
            byte[] enc = Base64.decodeBase64(encrypted);
            byte[] result = decrypt(rawKey, enc);
            return new String(result, CHARSET);
        } catch (Exception e) {
            LOGGER.error("AES解密Base64出错", e);
            throw new RuntimeException(e);
        }
    }

    public static String sign(List<String> value, String reqBody) {
        if(CollectionUtil.isEmpty(value)) {
            throw new RuntimeException("签名参数为空");
        }
        value.removeAll(Collections.singleton(null));
        value.add(reqBody);
        Collections.sort(value);
        StringBuilder sb = new StringBuilder();
        for (String s : value) {
            sb.append(s);
        }
        return Hashing.sha1().hashString(sb, Charsets.UTF_8).toString();
    }



    private static byte[] getRawKey(byte[] seed) throws NoSuchAlgorithmException {
        KeyGenerator kgen = KeyGenerator.getInstance("AES");
        SecureRandom sr = SecureRandom.getInstance("SHA1PRNG");
        sr.setSeed(seed);
        kgen.init(128, sr);
        SecretKey skey = kgen.generateKey();
        byte[] raw = skey.getEncoded();
        return raw;
    }

    /**
     * 加密
     * @param raw
     * @param clear
     * @return
     * @throws NoSuchPaddingException
     * @throws NoSuchAlgorithmException
     * @throws InvalidKeyException
     * @throws IllegalBlockSizeException
     * @throws BadPaddingException
     */
    private static byte[] encrypt(byte[] raw, byte[] clear) throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
        SecretKeySpec skeySpec = new SecretKeySpec(raw, "AES");
        Cipher cipher = Cipher.getInstance("AES");
        cipher.init(Cipher.ENCRYPT_MODE, skeySpec);
        byte[] bytes = cipher.doFinal(clear);
        return bytes;
    }

    /**
     * 解密
     * @param raw
     * @param encrypted
     * @return
     * @throws NoSuchPaddingException
     * @throws NoSuchAlgorithmException
     * @throws InvalidKeyException
     * @throws IllegalBlockSizeException
     * @throws BadPaddingException
     */
    private static byte[] decrypt(byte[] raw, byte[] encrypted) throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
        SecretKeySpec skeySpec = new SecretKeySpec(raw, "AES");
        Cipher cipher = Cipher.getInstance("AES");
        cipher.init(Cipher.DECRYPT_MODE, skeySpec);
        byte[] bytes = cipher.doFinal(encrypted);
        return bytes;
    }

    public static void main(String[] args) {
        String content = "9ntdNAXeWZWC6vL8UkXjgC1NptACa1YfLQ/+HctERFWyoW4rPMU9jbV4EXG60vedfccdzrABW3+K8oN0bSHh3EYinpKExCOSIwkdKzFQVyoftZIIy70b0cEBizYo/psggr5Snp75TkIzfd1kjNa7q0Zz7MTjvouhMWfywuH4yHhr0MxNsYjRjmIRnKvBihxWRac+f6hRDjkH9hzhpbsXMaejC5pjbpxoflJmvJFCVUX/uQcQWEyRH99xzMzla0N+N0X4c6KdLY3GN/f2Q6fW/drMN64ZeqeogWC0q0H6UwxzMriRzMb46H6PGU9tSIbbcVrkkl+J6ydNa6XwqNxrMjITgJWs2InRTtarkx9Y7ib8NxPCyTkVv1/szf99Rh40DInDp7mQ85htZWpPEVoeuHtXX9aTCAzvxI3wZWbwqZVNdoCj22fI0ZzQs8N0oXx325cAf0Gde41U0H4mbvRmsoMUyxRMsgTH6QGV/P1CptmCutp9EKfV1dCL0cLkAwS7nsSfNPDaLmyOtEoEmuVxZeZfltwEzGlC4LA06+Qg/EQm57ksFqzv6jz2oB9UioBrh3HvJjE4M2bPMm7H7zQ==";
        String s = decryptBase64("0123456789ABCDEF", content);
        System.out.println(s);
    }
}
