package com.sinosoft.car.utils;

import com.alibaba.fastjson.JSON;
import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.Velocity;
import org.apache.velocity.app.VelocityEngine;

import java.io.IOException;
import java.io.StringWriter;
import java.lang.reflect.Field;
import java.util.*;

/**
 * 末班引擎工具类
 *
 * @ClassName: CarInfo
 * @Description:TODO
 * @author: Wangly
 * @date 2020-11-30 18:11:57
 */
public class TemplateUtil {


    public static String builder(Object o, String vmUrl, String vmName, String encoding) throws IllegalAccessException {

        initProp(vmUrl.replaceAll(vmName, ""));
        VelocityContext context = new VelocityContext(createVmMap(o.getClass(), o));
        Template tpl = Velocity.getTemplate(vmName, encoding);
        StringWriter sw = new StringWriter();
        tpl.merge(context, sw);
        return sw.toString();
    }

    private static void initProp(String filePath) {
//        Properties prop = new Properties();
//        prop.put("file.resource.loader.class", "org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader" );
//        Velocity.init(prop);
        Properties prop = new Properties();
        prop.setProperty(VelocityEngine.FILE_RESOURCE_LOADER_PATH, filePath);
        prop.setProperty(Velocity.ENCODING_DEFAULT, "UTF-8");
        prop.setProperty(Velocity.OUTPUT_ENCODING, "UTF-8");
        Velocity.init(prop);
    }

    /**
     * 封装模板数据并生成模板上下文
     * @param clazz
     * @param o
     * @return
     * @throws IllegalAccessException
     */
    private static Map<String, Object> createVmMap(Class clazz, Object o) throws IllegalAccessException {
        Field[] fields = clazz.getDeclaredFields();
        //封装模板数据
        Map<String, Object> map = new HashMap<>();
        for (Field field : fields) {
            field.setAccessible(true);
            if(field.getGenericType().toString().indexOf("com.sinosoft") != -1) {
                Object inO = field.get(o);
                map.putAll(createVmMap(inO.getClass(), inO));
            }
            if(field.get(o) != null) {
                map.put(field.getName(), field.get(o));
            }
        }
        return map;
    }

//    public static void main(String[] args) throws IllegalAccessException, IOException {
//        CusInfo cus = new CusInfo();
//        CarInfoVo carInfoVo = new CarInfoVo();
//        List<CusInfo> cues = new ArrayList<CusInfo>();
//        cues.add(cus);
//        cues.add(cus);
//        cues.add(cus);
//        InquireReq req = new InquireReq();
//        req.setCusInfo(cus);
//        req.setCarInfoVo(carInfoVo);
//        req.setCusInfos(cues);
//        String builder = builder(req, "/Users/hero/Documents/SourceCode/Work/CarDealer/vmFiles/", "CarInfo.json.vm", "UTF-8");
//        System.out.println(JSON.parse(builder));
//    }
}
