package com.sinosoft.car.utils;

import com.sinosoft.car.utils.contants.GPICConstants;

import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.Date;

/**
 * 日期时间工具类
 *
 * @author LiYanLong
 * @version 1.0
 * @date 2021/4/19 16:35
 * @since JDK1.8
 */
public class DateTimeUtils {

    /**
     * 国寿：通用时间格式化
     * pattern：格式可以参考 {@link GPICConstants.DateFormatPattern}
     * 使用 DateTimeFormatter，确保线程安全
     *
     * @param date 需要转换的日期
     * @param pattern 日期时间格式，如 "yyyy-MM-dd"
     * @return
     */
    public static String getGpicDateTime(Date date, String pattern) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(pattern);
        String format = formatter.format(date.toInstant().atOffset(ZoneOffset.of("+0800")));
        return format;
    }

}
