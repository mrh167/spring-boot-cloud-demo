package com.sinosoft.car.utils.cpic.support;

class Shared {
    static String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    static char pad = '=';

    Shared() {
    }
}
