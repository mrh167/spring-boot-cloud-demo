package com.sinosoft.car.utils.cpic;

import com.alibaba.fastjson.JSONObject;
import org.apache.commons.collections.map.LinkedMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

import javax.crypto.Cipher;
import java.io.ByteArrayOutputStream;
import java.security.*;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

@Component
public class SignatureUtils {


    //保险公司的公钥
    public static String publicKey;
    //保险公司的私钥
    public static String privateKey;
    //合作伙伴的公钥
    public static String thirdPublicKey;
    //合作伙伴的私钥
    public static String thirdPrivateKey;

    @Value("${rsa.insurer.cpicPublicKey}")
    public void setPublicKey(String publicKey) {
        this.publicKey = publicKey;
    }

    @Value("${rsa.insurer.cpicPrivateKey}")
    public void setrivateKey(String privateKey) {
        this.privateKey = privateKey;
    }

    @Value("${rsa.self.selfPublicKey}")
    public void setThirdPublicKey(String thirdPublicKey) {
        this.thirdPublicKey = thirdPublicKey;
    }

    @Value("${rsa.self.selfPrivateKey}")
    public void setThirdPrivateKey(String thirdPrivateKey) {
        this.thirdPrivateKey = thirdPrivateKey;
    }


    private static final Logger LOGGER = LoggerFactory.getLogger(SignatureUtils.class);


    /**
     * RSA最大加密明文大小
     */
    private static final int MAX_ENCRYPT_BLOCK = 117;

    /**
     * RSA最大解密密文大小
     */
    private static final int MAX_DECRYPT_BLOCK = 128;


    private SignatureUtils() {
    }

    /**
     * 验签并解密
     * <p>
     * 对于<b>合作伙伴</b>，publicKey是指保险公司的公钥，privateKey是指合作伙伴的私钥<br>
     * 对于<b>保险公司</b>，publicKey是指合作伙伴的公钥，privateKey是指保险公司自己的私钥<br>
     *
     * @param request     原始报文(JSON字符串)
     * @param publicKey   公钥
     * @param privateKey  私钥
     * @param isCheckSign 是否验签
     * @param isDecrypt   是否解密
     * @return 解密后的明文，验签失败则异常抛出
     * @throws Exception
     */
    public static String checkSignAndDecrypt(String request, String publicKey, String privateKey,
                                             boolean isCheckSign, boolean isDecrypt) throws Exception {
        boolean verifyResult = false;
        JSONObject requestJSONObject = JSONObject.parseObject(request);
        String sign = requestJSONObject.getString("signContent");//获取的签文
        String bizContent = requestJSONObject.getString("bizContent");//获取的业务数据密文
        requestJSONObject.remove("signContent");//要排序先去掉signContent（签文）
        String signContent = getSignContent(requestJSONObject);//所有key排序后放入LingkedMap后map.toString()
//        LOGGER.info("签名字符串为：" + signContent);
        if (isCheckSign) {
            verifyResult = verify(signContent, sign, publicKey);
        }
        if (isDecrypt && verifyResult) {
            return decryptByPrivateKey(bizContent, privateKey);
        }
        return null;
    }

//    public static void main(String[] args) {
//        String msg = "{\"timestamp\":\"20210309182937600\",\"thirdCode\":\"10067\",\"bizContent\":\"h8L0d0hecVlz8sw6/O0Qa2D22FXoxc83f30X0E/BIxuxxnH98eW9Dz5jjbrgUscGdbiUIhbvIS/L5W1jhlHMZrqRvo+i9sz/knkAtkxfGVyap5bmkyQcfVMAiIjkziszMx0KCpNkuAKrnEOCKfI76THC2yM4IMgBEMfctIDTf+aRl9XoMw6+YXVyvU8DrAJuZ5CkB6UFQ6M10YCG0HcThONIVQrH898+jR2NdvxTiSyK4yF09GcDzVdaGkSMtC31luLDJx6pV5KIXev+jcBjhaMhYFtsSds3AQgu0/tMSArEBJlPVAs41xt/OmzttEtxAE/7He4nXXNyt6iiDEKF3WWNTC4suCyu9IcBUqvVuL+wX7MPlCnithAEthoNA2QvuMFC1KetnGMYnwOriaY8iuPrGhj2wV8dLAZjCOQn/kFyIkqkeWSyTMK7axMwDUx+9D6MgxyoOgl8i8JPhq3kMB3H6T1RVTAJiEXNg7EXE8LavJVomfp0+eU9vPuPEA5bpZMCyStV91pmVnUeEWE5CCtWtfaUTWgWnvZD4GZso4LPsdbvTRegmMf5b7RGZoJBRDJ7iZVENKEdHw1t929Tw6T/SYdcFkkYWvof7b1gVHU3JoMwxJgfujwwJ9sce6+IkS0hew7eYfeRkOWi5g4m7RB+YuYhlOL+9WSrGdbLr2wfmf9oEuol8I3eYkkHJv2qDSRkJlkk1Aw0U5riRhWTYfT2v03M6jsCi5kuXnLWX2Ia99CLDUmQvVeSP7G19gLnW4RnULDSbCtgKAetOlV9xCBd4glg4dxjpCkN4Ss9n94p72XYz1ZZj/jDf0sQUfBw5iBuOMLT8Sm+lxJxAQAVJ6jFM//T1AyN823YmHIYd18sQm4IhmwRFA3tbrEoukcAFJQRu710iazIc/1ioZEuSes6kxUmGJncCvs7F3DKp+P2Wtsz3EQmSHI2+IxrKLfVqmx/iQj3e7ryKAzE6C2SbABxixGcTpASTT03H1udSZDcM6NRDcoN4hDmAl4QOgccO4JRkE7NZv65jHApJhLS28UguTZ288nysAJnWPMVXsMOkKameGzp6CkM/+eZXqFxrrdgJYgWDImf4SUNQebS2GbCx5BLNGjeO9qMd9GeckiVxUwptBwQFkC2wWWRcb06qfaNwkA7vYheh6C6Ay11vhn5xf+C1Nm1WvLtlAIHs+iYp5VXqJ8e8MwXGD8ZBLwC4LBPIASHgGQ3crOA+8K+HsYg865PbEvENMP5ZNIwwwbwiq7jR5NyWLx7YIdN2K8dJSy6sAXFTFI71q2KvwKdKiRJMJ1E9bA9wH9JojkADYKsgeQANHPxOVCb6OQ/8MU9Cracl7U6yZQ7GDBNABMtbnBFpWnsBSlG3o1OJecZU6JVGKMnELvWi6k6Cmj1luyVbtek8yYsW7bjwuV9r0I2a3AbPU5qS98R2Qh152VLBOM5ltruxh6TntUqPUmBsVYuQbFCzLkvrBa/m25nK5gdYc0G0hBSyZpj65ZILax40dP9AgYwC6PwtxWgpx/jkEAVRJbSMilIWaCDJwwn7sJr7U+LbdrjglY3MHiC1+JepmRTqeRsYVzUCM5HpVgDdG8tJ1eSzIYJK7Y0S5kCihqMWQqpdXpLiBfAOtRPLUlqo/RMS6dNkJKNDxHbpDacM6PBPOlhiX6/DPVX7OKpCa5xyEuNgPkXCUPduiYiuvPkrEhsY2ov0e69G1fbKEvgIy+J6Fx73IeqQEcjniwdME7q9BDFoNVBZ3UlRlNIqAA5os3w+IFglJT8bX9E9ivEhsj9L6kffrWXYREAwGXbUCch1RZvI2lq8t4mTJyuxb6L7WRKpG3cJaV4eWDUI7zMZUVLwUnkPMKMuFNAEtVIr6dfMJvizZZOWeEGNa1eARbb/I6vr2+MxPro7u/BNoRh5F93rVWqH3GW8lJMKhhH+WfnoubtRJt3lvY4fkY1EcCtR5r/vM4tg8UQzYmyMNw5B0urIIn2EspxUTVaylV7ptFd56c2sla7hnVeDG8+FXz9pA66vxT73oxVQC7x6w2f0Yp7CJwUx4jts1td7mRhQRjp9tfECkVqdqI/ju48JJwfl5XSM4iJrEihzdVx5xREI7AJFislBPiyE4gQZloHubsc7nZSlQWc6IWiF73PJGmsfrKjUZfSOoIT5PEkvo461IbKf0DwDOCoS3H2CiHL9QVFWEJG99FiEXlBldWv7bqhY9dFVUqPb40o2mg0lVW9a/6JMALO5NfqWbvDlmo9wjLaBn4YdNRlZFwXBAzmeuRMu1M3/LZxtR3gy7N6jELrr7IUr19thcReyGJKXE2Re6iTEHlrXtyDOBOBLbsLnCSF20SsKhICwdNslELZMaqHI6BIVN7dMd8LWjMfbtJpr7nYuB9wNNjwmEJSICpLpW0cm9chQ3YhOx34/ipise9aeC/R3yl+eauJo2ORMg5gauUznBc9QeY9dkEASzxiupbMfo9UbLLoP5gifVbx8dudwZoXkca3+I+AiIwAu0asRG1/acptjnlMHvI6VqOd80nm8QQJ5B6LIr5bXtgk7TcHdlgEqqalxGAR4t0/qkF26yUzAO+fi4MgvvdbkpLagQ8jp3+S8osooebLVGGuN1QDI4AXOr9K1gM1ZEGlgrJtC/vIu3EIQhk58iwCeLb+OkbRT9wQ8Ma4nrx/gFuyfZlv/CTpEbp5pcklyet4Hwf5v6ukQaplzJx39PX3M0ialkiUIV5+A/w8UGJyIGznol9r8geZDe4NCVY2TEkLZ9Oyffakuh9wGI7sKIY6KkNwO1bk+BaXx3k0f+/OmKNMP/AOMJiK8QnWNdxbIxohW0yhuECL4DnrOQn7MFwaxsKIRutty8ym+rIySeO+P2olTfOVyDDc4qTNsZxVGnSnyUCFC151spaS+8orQstmo4B3FfyVRlSLSvUpixsSZ48HXeFNYuDJR3n+gMXaxTp42k3EzWoByG7NLS/P7aPbNmG4rOKUihPvDqlERWvP4tQLd0j7p1FNbaK3SWLTdLsh5AIA/0MFzEYfmTlYpDsL/+PS67xijWveCQb1z+ozW/3p2qZaee5vJEywhtkDFE5dIrjWDGWRbCMicpRBvDn5WrrHBRnP5yLWnt9b8Lw/k/kin8qx1bwwyGnU1NDiR8p5sJpch4vexk7uRLY/tY3fBblD+ldjhNowPldf8rgihc4fsFaflHHdWUbOn04fjl495fCwqFGKZnLEN9mOXCkPmIdS1ZkplpAn3PT1OgxGUn04xEgv0VXDM2m/tBN6OvXhrSuzaDn+Pz6conH9VNJRhppbKJl+494oNRFVlQTFzSzSeZADTWt4SVzQJ0rEAPcE04q+2wA9VLYxtR7U7w4qNCuizqOhiObAq6k+4570hrwUj1EwjW6dTUitYL/i2tvQYKq4zYxYb3bRfh+zuEhvTJGzqXoxYHR+11GREP8dAU7xcq9eR1D9yPLJf3jSNoRJeYHDeTF7wj4g00SwZX7rSaY/rAvw6oZQ0ryupS6AH4nfeaX9NTAc7gR4prPMtw9R/9Yog8P0DF4CF6eTNVs8nMt0ct2dBR2XYzhCfxqa0pmf4NhDbh1uVAYG4fBZAPoVGNs4wRI98iCR9vGKemAmCIqVfn2tJQpMwfDr+RpIM98U/D2Roc1Ja0jl5CqNP5TWDhP/AWAPyaZ517AuPxWmPbUSOc10+ge50hL0sqYPXUZzTgmEWoxG2eUm9OzbqlTYxQCNWTceN1LZmHjO3BJkPt3weJT6nawU2Q7NMlnd4UR2aO5RREkqpkV+mdhd7He22t86MX8npchciFdM+qYYlVw3yAjjQeh/roHF9Wy+ND0xuxuSsmG22Sj77ytGy9uAigXFkFpVEUP2fP7nllCGVbrHFpPX9ILXTLIJspDc6mY7AWamQ9yOOw46w+qdmNljQjfVzBJyuqtFJa2/Sopq4CQBIi+9dDavh07oOMykCGGP8N92/LAgunc6dPcJiirK4Lgp5iwGhNvrkhLlNs+N78z/XGEZYsQUGJtE3WG0CSl6aq94SpfDQfkVgiZUs2jKh2W4wsp+Gl9nQJOFmbFHXoSgZ7s4OwTl/w72TBOhnW2F+bbEGmPTCu2xOYS++YcnFIFujNEErk1qu/7Gj4QPNLzoomdQnv4okc5Pn+6TVywwg4lyDmrNquqGm76RAoCFjwnJbLHtvb4pwn90+Vrh/FX9Pp21yXeY2C4zp0Mu8O9v8ihfK5cuQlW6jNaH5VfNmLCB02cwSBv87zOCAqGlujNzKW/rGSagA42K+vyZrzMOZ71q+njT0HsvycLMy+o4HMYPxTdta78Q1fuIju1fC9XXXJQPX1cFiIBqmyuZDmvYGjsVNaol2Tew4KDcgt9dM9wUwIkdlF0QZjCmwZexDUWv8eKxJN3/iT1rz6krNWJJGoWiNDxnB5Zz6Nj36AqcrWzNmZ2fpSs9Mby5scFFDasBK4NQNDm3XB9EDgsy1q//9l3L3faQnMVM96DaNt8JfitcZPDdrvHo7QirS2i2FmaNiCLMxjaYMvDLUTgAslmOo/ogevip+wFrQ3qfF+6d8MstnFHLz8My+wVev4IIH5ExXo25f/QncXp/RxyQI0oApeub6f1AkXzAII8tlvo2FzMV9i0TVt0S3eRVP6ys7U9bzGAkk/XXarDQcfQ/FaUfZrBccqJmIneXVNU/3OrxeYMIZasICXQxe8V9o9ECTPeCtHg9xF9QOkBx0ImZ4c8vAg0CdXtxzbm5aWn8AIwuY59fH2IpMadMig0ajNBGpqf3XmRX2kBWc5kkrNjFzZWBySpqGD/ZOjrBKLcRe3IJgh3EUpB5d2DDOwbhkiyaGHaly05Qwd8fW9B4i0sWkuFvkkZ9CXFVJEsM/SEDenn+6bD7MpfZWYuslzvLiO+ttmMoXTNa/xkXi23Po0Rv0hl9rNb413wJuOgDE+af4sYChuyzhmPI0w==\",\"signType\":\"RSA\",\"signContent\":\"1j5vjQ55BXJMCoe56oUCvHLardiLiJo1RmjR2vwBIfXnbQGjVsuwRdNxMLyy1Q7kHXoJ2wT54Z4SRVFRzBjjAvYFB0V0iupOKv5tNNt+8TNDBp22+pOlWNKQRh7VpYwXFyeIV7K4wGmWCBavvQ77UHHWPnLB+jAy8AVetTW2X8Q=\",\"serviceCode\":\"third.insurance.inquire\",\"charset\":\"UTF-8\",\"format\":\"json\"}";
//        String s = null;
//        try {
//            s = checkSignAndDecrypt(msg, publicKey, thirdPrivateKey, true, true);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        System.out.println(s);
//    }

    public static String checkSignAndDecrypt(String request, String publicKey, String privateKey,
                                             boolean isCheckSign, boolean isDecrypt, boolean diff) {
        boolean verifyResult = true;
        JSONObject requestJSONObject = JSONObject.parseObject(request);
        String sign = requestJSONObject.getString("sign");
        String content = requestJSONObject.getString("content");
        if (isCheckSign) {
            verifyResult = verify(content, sign, publicKey);
        }
        if (isDecrypt && verifyResult) {
            return decryptByPrivateKey(content, privateKey);
        }
        return null;
    }

    /**
     * @param publicKey
     * @param privateKey
     * @param content
     * @param isCheckSign
     * @param isEncrypt
     * @param diff
     * @return
     * @throws Exception
     */
    public static String encryptAndSign(String publicKey, String privateKey, String content, boolean isCheckSign, boolean isEncrypt, boolean diff) throws Exception {
        JSONObject jsonObject = new JSONObject();
        if (isEncrypt) {
            String encryptContent = encryptByPublicKey(content, publicKey);
            jsonObject.put("content", encryptContent);
            if (isCheckSign) {
                String sign = sign(encryptContent, privateKey);
                jsonObject.put("sign", sign);
            }
        } else if (isCheckSign) {
            String sign = sign(content, privateKey);
            jsonObject.put("sign", sign);
        }
        return jsonObject.toString();
    }

    /**
     * 加密并加签
     * @param args
     */
//    public static void main(String[] args) {
//        try {
//            String request = "18614075331";
//            String msg = encryptAndSign(thirdPublicKey, privateKey, request, true, true, true);
//            System.out.println(msg);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

    /**
     * 加密并签名
     * <p>
     * 对于<b>合作伙伴</b>，publicKey是指保险公司的公钥，privateKey是指合作伙伴的私钥<br>
     * 对于<b>保险公司</b>，publicKey是指合作伙伴的公钥，privateKey是指保险公司自己的私钥<br>
     *
     * @param publicKey       公钥
     * @param privateKey      私钥
     * @param responseContent 返回报文原文
     * @param isCheckSign     是否签名
     * @param isEncrypt       是否加密
     * @return 加密加签后的返回报文
     * @throws Exception
     */
    public static String encryptAndSign(String publicKey, String privateKey, String responseContent,
                                        boolean isCheckSign, boolean isEncrypt) throws Exception {
        JSONObject responseJSONObject = JSONObject.parseObject(responseContent);
        String bizContent = responseJSONObject.getString("bizContent");
        responseJSONObject.remove("signContent");//去掉signContent,之后加签添加
        if (isEncrypt) {
            String encryptBizContent = encryptByPublicKey(bizContent, publicKey);
//            LOGGER.info("加密后业务数据：" + encryptBizContent);
            responseJSONObject.put("bizContent", encryptBizContent);
            if (isCheckSign) {
                String signContent = getSignContent(responseJSONObject);//所有key排序后放入LingkedMap后map.toString()
//                LOGGER.info("待签名字符串为：" + signContent);
                String sign = sign(signContent, privateKey);
                responseJSONObject.put("signContent", sign);
            }
        } else if (isCheckSign) {//只加签、不加密
            String signContent = getSignContent(responseJSONObject);//所有key排序后放入LingkedMap后map.toString()
//            LOGGER.info("待签名字符串为：" + signContent);
            String sign = sign(signContent, privateKey);
            responseJSONObject.put("signContent", sign);
        }
        return responseJSONObject.toJSONString();
    }

    /**
     * 封装待验签的内容
     *
     * @param sortedParam
     * @return
     */
    public static String getSignContent(Map<String, Object> sortedParam) {
        LinkedMap map = new LinkedMap();
        List<String> keys = new ArrayList<>(sortedParam.keySet());
        Collections.sort(keys);
        for (int i = 0; i < keys.size(); i++) {
            String key = keys.get(i);
            String value = sortedParam.get(key).toString();
            map.put(key, value);
        }
//        LOGGER.info("map = "+map.toString());
        return map.toString();
    }

    /**
     * 验签
     *
     * @param request
     * @param sign
     * @param publicKey
     * @return
     */
    public static boolean verify(String request, String sign, String publicKey) {
        try {
            return SignatureUtils.verify(request.getBytes(CharsetEnum.UTF_8.code), publicKey, sign);
        } catch (Exception e) {
            LOGGER.error(ExceptionUtil.getErrorMsg(e), e);
            throw new RuntimeException(e);
        }
    }

    /**
     * <p>
     * 校验数字签名
     * </p>
     *
     * @param data      已加密数据
     * @param publicKey 公钥(BASE64编码)
     * @param sign      数字签名
     * @return
     * @throws Exception
     */
    public static boolean verify(byte[] data, String publicKey, String sign)
            throws Exception {
        byte[] keyBytes = Base64Utils.decode(publicKey);
        X509EncodedKeySpec keySpec = new X509EncodedKeySpec(keyBytes);
        KeyFactory keyFactory = KeyFactory.getInstance(SignEnum.SIGN_TYPE_RSA.code);
        PublicKey publicK = keyFactory.generatePublic(keySpec);
        Signature signature = Signature.getInstance(SignEnum.SIGNATURE_ALGORITHM.code);
        signature.initVerify(publicK);
        signature.update(data);
        return signature.verify(Base64Utils.decode(sign));
    }

    /**
     * 私钥对数据进行解密
     *
     * @param bizContent
     * @param privateKey
     * @return
     */
    public static String decryptByPrivateKey(String bizContent, String privateKey) {
        try {
            return new String(SignatureUtils.decryptByPrivateKey(com.sinosoft.car.utils.cpic.support.Base64.decode(bizContent.getBytes()), privateKey), CharsetEnum.UTF_8.code);
        } catch (Exception e) {
            LOGGER.error(ExceptionUtil.getErrorMsg(e), e);
            throw new RuntimeException(e);
        }
    }

    /**
     * <P>
     * 私钥解密
     * </p>
     *
     * @param encryptedData 已加密数据
     * @param privateKey    私钥(BASE64编码)
     * @return
     * @throws Exception
     */
    public static byte[] decryptByPrivateKey(byte[] encryptedData, String privateKey)
            throws Exception {
        byte[] keyBytes = Base64Utils.decode(privateKey);
        PKCS8EncodedKeySpec pkcs8KeySpec = new PKCS8EncodedKeySpec(keyBytes);
        KeyFactory keyFactory = KeyFactory.getInstance(SignEnum.SIGN_TYPE_RSA.code);
        Key privateK = keyFactory.generatePrivate(pkcs8KeySpec);
        Cipher cipher = Cipher.getInstance(keyFactory.getAlgorithm());
        cipher.init(Cipher.DECRYPT_MODE, privateK);
        int inputLen = encryptedData.length;
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        int offSet = 0;
        byte[] cache = null;
        int i = 0;
        // 对数据分段解密
        while (inputLen - offSet > 0) {
            if (inputLen - offSet > MAX_DECRYPT_BLOCK) {
                cache = cipher.doFinal(encryptedData, offSet, MAX_DECRYPT_BLOCK);
            } else {
                cache = cipher.doFinal(encryptedData, offSet, inputLen - offSet);
            }
            out.write(cache, 0, cache.length);
            i++;
            offSet = i * MAX_DECRYPT_BLOCK;
        }
        byte[] decryptedData = out.toByteArray();
        out.close();
        return decryptedData;
    }


    /**
     * 公钥加密
     *
     * @param request
     * @param publicKey
     * @return
     */
    public static String encryptByPublicKey(String request, String publicKey) throws Exception {
        return Base64Utils.encode(SignatureUtils.encryptByPublicKey(request.getBytes(CharsetEnum.UTF_8.code), publicKey));
    }

    /**
     * <p>
     * 公钥加密
     * </p>
     *
     * @param data      源数据
     * @param publicKey 公钥(BASE64编码)
     * @return
     * @throws Exception
     */
    public static byte[] encryptByPublicKey(byte[] data, String publicKey)
            throws Exception {
        byte[] keyBytes = Base64Utils.decode(publicKey);
        X509EncodedKeySpec x509KeySpec = new X509EncodedKeySpec(keyBytes);
        KeyFactory keyFactory = KeyFactory.getInstance(SignEnum.SIGN_TYPE_RSA.code);
        Key publicK = keyFactory.generatePublic(x509KeySpec);
        // 对数据加密
        Cipher cipher = Cipher.getInstance(keyFactory.getAlgorithm());
        cipher.init(Cipher.ENCRYPT_MODE, publicK);
        int inputLen = data.length;
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        int offSet = 0;
        byte[] cache;
        int i = 0;
        // 对数据分段加密
        while (inputLen - offSet > 0) {
            if (inputLen - offSet > MAX_ENCRYPT_BLOCK) {
                cache = cipher.doFinal(data, offSet, MAX_ENCRYPT_BLOCK);
            } else {
                cache = cipher.doFinal(data, offSet, inputLen - offSet);
            }
            out.write(cache, 0, cache.length);
            i++;
            offSet = i * MAX_ENCRYPT_BLOCK;
        }
        byte[] encryptedData = out.toByteArray();
        out.close();
        return encryptedData;
    }

    /**
     * 加签
     *
     * @param request
     * @param privateKey
     * @return
     */
    public static String sign(String request, String privateKey) {
        try {
            return SignatureUtils.sign(request.getBytes(CharsetEnum.UTF_8.code), privateKey);
        } catch (Exception e) {
            LOGGER.error(ExceptionUtil.getErrorMsg(e), e);
            throw new RuntimeException(e);
        }
    }

    /**
     * <p>
     * 用私钥对信息生成数字签名
     * </p>
     *
     * @param data       已加密数据
     * @param privateKey 私钥(BASE64编码)
     * @return
     * @throws Exception
     */
    public static String sign(byte[] data, String privateKey) throws Exception {
        byte[] keyBytes = Base64Utils.decode(privateKey);
        PKCS8EncodedKeySpec pkcs8KeySpec = new PKCS8EncodedKeySpec(keyBytes);
        KeyFactory keyFactory = KeyFactory.getInstance(SignEnum.SIGN_TYPE_RSA.code);
        PrivateKey privateK = keyFactory.generatePrivate(pkcs8KeySpec);
        Signature signature = Signature.getInstance(SignEnum.SIGNATURE_ALGORITHM.code);
        signature.initSign(privateK);
        signature.update(data);
        return Base64Utils.encode(signature.sign());
    }
}
