package com.sinosoft.car.utils.ygbx;

import java.net.URI;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.apache.http.Header;
import org.apache.http.NameValuePair;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.utils.URIUtils;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicHeader;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.HttpParams;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.cloud.fast.exceptions.BusinessException;
import com.cloud.fast.utils.HttpClientUtils;
import com.cloud.fast.utils.RedisUtils;
import com.cloud.fast.utils.StringUtils;
import com.cloud.fast.utils.jwt.JwtTokenUtil;
import com.sinosoft.car.utils.contants.YGBXConstants;
import com.sinosoft.car.vo.ygbx.carquery.response.CarQueryResRoot;
import com.sinosoft.car.vo.ygbx.submit.response.SubmitResRoot;

/**
 * 阳光接口，报文服务工具类
 *
 * @author
 * @version 1.0
 * @date 2021/4/21 18:22
 * @since JDK1.8
 */
@Configuration
@Service("ygbxMessageUtils")
public class MessageUtils {

    private static final Logger LOGGER = LoggerFactory.getLogger(MessageUtils.class);
    
    @Autowired
    RedisUtils redisUtils;

    /**
     * 发送请求数据给保司接口
     *
     * @param jsonMsg
     * @return
     */
    public static String sendPost(JSONObject jsonMsg) {
        String requestUrl = YGBXConstants.InterfaceUrl.YGBX_URL;
        LOGGER.info("请求URL：" + requestUrl);
        //todo 需要加签调试
        LOGGER.info("加密前：" + JSON.toJSONString(jsonMsg));
        String strJson = JSON.toJSONString(jsonMsg);
        try {
            strJson = new String(JSON.toJSONString(jsonMsg).getBytes(), "utf-8");
        }catch (Exception e){
            e.printStackTrace();
        }
        String encrypt = SignatureUtil.authcodeEncode(strJson, YGBXConstants.InterfaceUrl.YGBX_KEY);
        LOGGER.info("加密后：" + encrypt);
        Map<String, String> headers = new HashMap<>();
        headers.put("content-type", "application/json");
        return HttpClientUtils.sendPost(requestUrl, headers, encrypt);
    }


    /**
     * 解密报文
     *
     * @param resultJson
     * @return
     */
    public static JSONObject decrypt(String resultJson) {
        String decrypt = null;
        try {
            LOGGER.info("响应密文: {}", resultJson);
            decrypt = SignatureUtil.authcodeDecode(resultJson, YGBXConstants.InterfaceUrl.YGBX_KEY);
            LOGGER.info("响应明文: {}", decrypt);
        } catch (Exception e) {
            e.printStackTrace();
            throw new BusinessException("响应内容解密失败！");
        }
        return JSONObject.parseObject(decrypt);
    }

    public static Boolean isSuccess(CarQueryResRoot response) {
        return isSuccess(response.getErrorCode());
    }
    
    public static Boolean isSuccess(SubmitResRoot response) {
        return isSuccess(response.getErrorCode());
    }

    private static Boolean isSuccess(String responseCode) {
        return YGBXConstants.ResponseCode.SUCCESS.equals(responseCode);
    }
    
    public static String getInfotransNoKey(String vinNo) {
        String key = "ygbx_infotrans_no_" + JwtTokenUtil.getTenant() + "_" + JwtTokenUtil.getUserId() + "_" + vinNo;
        LOGGER.info("ygbx_infotrans_no_  {}", key);
        return key;
    }
    
    public void setInfotransNo(String infotransNo, String vinNo) {
        LOGGER.info("保存阳光 InfotransNo...{}", infotransNo);
        redisUtils.set(MessageUtils.getInfotransNoKey(vinNo), infotransNo, 60*60*24*3, TimeUnit.SECONDS);
    }
    
    public String getInfotransNo(String vinNo) {
        String infotransNo = (String) redisUtils.get(MessageUtils.getInfotransNoKey(vinNo));
        LOGGER.info("获取阳光 InfotransNo...{}", infotransNo);
        if (StringUtils.isEmpty(infotransNo)) {
            throw new BusinessException("阳光：投保流程超时，请重新进行车型查询后，再进行操作!");
        }
        return infotransNo;
    }
 
    /**
     * 阳光影像上传：把加密报文拼到url地址后面再进行post请求
	 * 	
	 * @param requestUrl	请求地址
	 * @param paramName	参数名称(例如：req,具体请参数接口定义)
	 * @param json			请求报文
	 * @param Referer		请求头Referer
	 * @return
	 * @throws Exception
	 */
	public static String httpPost(String requestUrl, String paramName, String json, String Referer) {
		String result = "";
		Map<String, String> headers = new HashMap<>();
        headers.put("Referer", Referer);
		result = sendPost(requestUrl, headers, json,"UTF-8");
		return result;
	}
	
	/**
	 * 发送 post 请求，字符串类型数据
	 *
	 * @param url      请求地址
	 * @param headers  请求头
	 * @param data     请求数据，字符串类型
	 * @param encoding 字符编码
	 * @return
	 * @author LiYanLong
	 * @date 2021-05-06
	 */
	public static String sendPost(String url, Map<String, String> headers, String data, String encoding) {

		// 创建Client
		CloseableHttpClient client = HttpClients.createDefault();
		// 创建HttpPost对象
		HttpPost httpPost = new HttpPost();
		try {
			List<NameValuePair> qparams = new ArrayList<NameValuePair>();
			qparams.add(new BasicNameValuePair("req", data));
			// 设置请求地址
			URI urld= URIUtils.createURI("http", "unifiedimage.sinosig.com:8082", -1, "AutoImagePlatform/third/upload",
                     URLEncodedUtils.format(qparams, "UTF-8"), null);
			httpPost.setURI(urld);
			// 设置请求头
			if (headers != null) {
				Header[] allHeader = new BasicHeader[headers.size()];
				int i = 0;
				for (Map.Entry<String, String> entry : headers.entrySet()) {
					allHeader[i] = new BasicHeader(entry.getKey(), entry.getValue());
					i++;
				}
				httpPost.setHeaders(allHeader);
			}
			// 设置实体
			StringEntity stringEntity = new StringEntity(data, encoding);
			stringEntity.setContentType("application/json");
			stringEntity.setContentEncoding("UTF-8");
			httpPost.setEntity(stringEntity);
			
			// 发送请求,返回响应对象
			CloseableHttpResponse response = client.execute(httpPost);
			return HttpClientUtils.parseData(response);

		} catch (Exception e) {
			
		} finally {
			httpPost.releaseConnection();
		}
		return null;
	}
}
