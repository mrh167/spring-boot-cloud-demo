package com.sinosoft.car.utils;


import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.Velocity;
import org.apache.velocity.app.VelocityEngine;

import java.io.*;
import java.lang.reflect.Field;
import java.util.*;

/**
 * 末班引擎工具类
 *
 * @ClassName: CarInfo
 * @Description:TODO
 * @author: Wangly
 * @date 2020-11-30 18:11:57
 */
public class TemplateUtilbak {

    public static String createMsgByTemplate(Object o, String vm) throws IOException, IllegalAccessException {
        //封装模板数据并返回模板上下文
        Map<String, Object> map = TemplateUtilbak.createVmMap(o.getClass(), o);
        VelocityContext context = new VelocityContext(map);
        //创建模板临时文件并写入模板模板规则
        File f = TemplateUtilbak.createTempFile(vm);
        //初始化模板引擎并返回模板实例
        TemplateUtilbak.initProp(f);
        //根据模板临时文件获取模板实例
        Template template = Velocity.getTemplate(f.getName());
        //创建字符流
        StringWriter sw = new StringWriter();
        //将数据和模板合并
        template.merge(context, sw);
        return sw.toString();
    }

    /**
     * 初始化模板引擎并返回模板实例
     * @param f
     * @return
     * @throws IOException
     */
    private static void initProp(File f) throws IOException {
        Properties prop = new Properties();
        prop.setProperty(VelocityEngine.FILE_RESOURCE_LOADER_PATH, f.getCanonicalPath().replaceAll(f.getName(), ""));
        prop.setProperty(Velocity.ENCODING_DEFAULT, "UTF-8");
        prop.setProperty(Velocity.OUTPUT_ENCODING, "UTF-8");
        Velocity.init(prop);
    }

    /**
     * 封装模板数据并生成模板上下文
     * @param clazz
     * @param o
     * @return
     * @throws IllegalAccessException
     */
    private static Map<String, Object> createVmMap(Class clazz, Object o) throws IllegalAccessException {
        Field[] fields = clazz.getDeclaredFields();
        //封装模板数据
        Map<String, Object> map = new HashMap<>();
        for (Field field : fields) {
            field.setAccessible(true);
            if(field.getGenericType().toString().indexOf("com.sinosoft") != -1) {
                System.out.println(field.getGenericType());
                Object inO = field.get(o);
                map.putAll(createVmMap(inO.getClass(), inO));
            }
            if(field.get(o) != null) {
                if(field.getGenericType().toString().equals("class java.lang.String")) {
                    map.put(field.getName(), "\"" + field.get(o) + "\"");
                }else {
                    map.put(field.getName(), field.get(o));
                }
            }
        }
        System.out.println(map);
        return map;
    }

    /**
     * 创建模板临时文件并写入模板模板规则
     * @param vm
     * @return
     */
    private static File createTempFile(String vm) throws IOException {
        //创建临时文件
        File f = File.createTempFile("carInfo", ".json.vm");
        //创建输出流
        FileOutputStream fileOutputStream = new FileOutputStream(f);
        //将vm内容写入文件
        fileOutputStream.write(vm.getBytes());
        //以下为测试方法
        //获取输入流
        FileInputStream fis = new FileInputStream(f);
        //创建byte对象
        byte[] b = new byte[(int)f.length()];
        //循环读入
        while (fis.read(b) != -1){}
        
        return f;
    }

}
