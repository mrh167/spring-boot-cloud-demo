package com.sinosoft.car.utils.picc;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.ResourceBundle;
import java.util.UUID;

import com.sinosoft.car.vo.picc.common.request.RequestHead;

/** 
 * @desc 车商平台：人保---请求head生成工厂
 * @author 作者 ：liuxiaoyu
 * @date 创建时间：2021-7-8 19:48:09 
 */
public class RequestHeadFactory {
    private static final ResourceBundle resources = ResourceBundle.getBundle("picc/requestHead");
    
    public static RequestHead createRequestHead(String requestType) {
        RequestHead requestHead = new RequestHead();
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        try {
        String areaCode = resources.getString("areacode");
            String sender = resources.getString("sender");
            String chnlNo = resources.getString("ChnlNo");
            String user = resources.getString(requestType + ".user");
            String password = resources.getString(requestType + ".password");
            requestHead.setAreacode(areaCode);
            requestHead.setChnlNo(chnlNo);
            requestHead.setFlowintime(format.format(new Date()) + " CST");
            requestHead.setPassword(password);
            requestHead.setRequest_type(requestType);
            requestHead.setSender(sender);
            requestHead.setServer_version("00000000");
            requestHead.setUser(user);
            requestHead.setUuid(UUID.randomUUID().toString());
        } catch (Exception e) {
            System.out.println("生成requestHead异常！");
            e.printStackTrace();
        }
        
        return requestHead;
        
    }
}
