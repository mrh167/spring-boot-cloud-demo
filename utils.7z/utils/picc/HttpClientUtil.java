package com.sinosoft.car.utils.picc;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cloud.fast.exceptions.BusinessException;
import com.sinosoft.car.utils.contants.PICCConstants;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustStrategy;
import org.apache.http.conn.ssl.X509HostnameVerifier;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.ssl.SSLContextBuilder;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLException;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocket;
import java.io.*;
import java.security.GeneralSecurityException;
import java.security.cert.X509Certificate;

/**
 * 人保 - 接口调用工具类
 * 
 * @author zhaoxiaojie
 *
 */
public class HttpClientUtil {

	private static final Logger LOGGER = LoggerFactory.getLogger(HttpClientUtil.class);
	private static HttpClient client = null;
	static {
		PoolingHttpClientConnectionManager cm = new PoolingHttpClientConnectionManager();
		cm.setMaxTotal(1);
		cm.setDefaultMaxPerRoute(1);
		client = HttpClients.custom().setConnectionManager(cm).build();
	}

	/**
	 * 人保-发送请求数据给保司接口
	 * 
	 * @param textXml
	 * @param api
	 * @return
	 */
	public static String sendPost(String textXml, String api) {
		String rsp = null;
		try {
			/* 交互 */
			LOGGER.debug("发送报文：{}", textXml);
			rsp = sendPostForXml(textXml, api);
			LOGGER.debug("返回报文：{}", rsp);
		} catch (Exception e) {
			throw new BusinessException(e.getMessage());
		}
		return rsp;
	}

	/**
	 * XML方式发送报文
	 * 
	 * @param reqXml
	 * @param url
	 * @return
	 * @throws Exception
	 */
	public static String sendPostForXml(String reqXml, String url) throws Exception {
		HttpClient client = null;
		String respXml = null;
		HttpPost post = new HttpPost(url);
		try {
			if (StringUtils.isNotBlank(reqXml)) {
				HttpEntity entity = new StringEntity(reqXml,
						ContentType.create(PICCConstants.REQUEST_CONTENTTYPE, PICCConstants.REQUEST_CHARSET));
				post.setEntity(entity);
			}
			RequestConfig.Builder customReqConf = RequestConfig.custom();
			customReqConf.setConnectTimeout(PICCConstants.REQUEST_CONNTIMEOUT);
			customReqConf.setSocketTimeout(PICCConstants.REQUEST_READTIMEOUT);
			post.setConfig(customReqConf.build());
			HttpResponse res = null;
			if (url.startsWith(PICCConstants.REQUEST_PROTOCOL_HTTPS)) {
				// 执行 Https 请求.
				client = createSSLInsecureClient();
				res = client.execute(post);
			} else {
				// 执行 Http 请求.
				client = HttpClientUtil.client;
				res = client.execute(post);
			}
			respXml = IOUtils.toString(res.getEntity().getContent(), PICCConstants.REQUEST_CHARSET);
		} finally {
			post.releaseConnection();
			if (url.startsWith("https") && client != null && client instanceof CloseableHttpClient) {
				((CloseableHttpClient) client).close();
			}
		}
		return respXml;
	}

	/**
	 * 人保 : 创建 SSL连接
	 *
	 * @Author XieMengTao
	 * @Date 12:28 2021/6/11
	 * @Param []
	 * @return org.apache.http.impl.client.CloseableHttpClient
	 **/
	private static CloseableHttpClient createSSLInsecureClient() throws GeneralSecurityException {
		try {
			SSLContext sslContext = new SSLContextBuilder().loadTrustMaterial(null, new TrustStrategy() {
				public boolean isTrusted(X509Certificate[] chain, String authType) {
					return true;
				}
			}).build();

			SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(sslContext, new X509HostnameVerifier() {

				@Override
				public boolean verify(String arg0, SSLSession arg1) {
					return true;
				}

				@Override
				public void verify(String host, SSLSocket ssl) throws IOException {
				}

				@Override
				public void verify(String host, X509Certificate cert) throws SSLException {
				}

				@Override
				public void verify(String host, String[] cns, String[] subjectAlts) throws SSLException {
				}
			});
			return HttpClients.custom().setSSLSocketFactory(sslsf).build();
		} catch (GeneralSecurityException e) {
			throw e;
		}
	}

	public static void main(String[] args) {
		String request = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\">\n"
				+ "    <soap:Header xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">\n"
				+ "        <nshead:requesthead xmlns:nshead=\"http://pub.webservice.cmp.com\">\n"
				+ "            <nshead:request_type>04200276</nshead:request_type>\n"
				+ "            <nshead:uuid>QDCH210617000020120210617201648565</nshead:uuid>\n"
				+ "            <nshead:sender>0598</nshead:sender>\n"
				+ "            <nshead:server_version>00000000</nshead:server_version>\n"
				+ "            <nshead:user>0598</nshead:user>\n"
				+ "            <nshead:password>2A252F333EA918B4D5A33454C933C416</nshead:password>\n"
				+ "            <nshead:areacode>44030000</nshead:areacode>\n"
				+ "            <nshead:ChnlNo>dachanghang</nshead:ChnlNo>\n"
				+ "            <nshead:flowintime>2021-06-17 20:16:48</nshead:flowintime>\n"
				+ "        </nshead:requesthead>\n" + "    </soap:Header>\n" + "    <soapenv:Body>\n"
				+ "        <pan:NOTICEGENERATIONPAYMENTREQ xmlns:pan=\"http://pan.prpall.webservice.cmp.com\">\n"
				+ "            <pan:BIZ_ENTITY>\n" + "                <keyinfo>\n"
				+ "                    <opcode>11098696</opcode>\n" + "                    <paytype>03</paytype>\n"
				+ "                    <sumfee>5206.33</sumfee>\n" + "                    <currency>CNY</currency>\n"
				+ "                    <signmode>02</signmode>\n" + "                </keyinfo>\n"
				+ "                <busdocinfolist>\n" + "                    <busdocinfo>\n"
				+ "                        <documentno>TDAA202144030000010219</documentno>\n"
				+ "                    </busdocinfo>\n" + "                    <busdocinfo>\n"
				+ "                        <documentno>TDZA202144030000010169</documentno>\n"
				+ "                    </busdocinfo>\n" + "                    <busdocinfo>\n"
				+ "                        <documentno>TEBS202144039001000019</documentno>\n"
				+ "                    </busdocinfo>\n" + "                </busdocinfolist>\n"
				+ "            </pan:BIZ_ENTITY>\n" + "        </pan:NOTICEGENERATIONPAYMENTREQ>\n"
				+ "    </soapenv:Body>\n" + "</soapenv:Envelope>\n";
		String url = "https://esb.epicc.com.cn/InterfaceProxy/cmp/ProxyService";
		try {
			sendPost(request, url);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
