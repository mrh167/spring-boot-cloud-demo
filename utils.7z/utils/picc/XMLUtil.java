package com.sinosoft.car.utils.picc;

import java.io.ByteArrayInputStream;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import org.apache.logging.log4j.Logger;
import org.aspectj.weaver.patterns.ThisOrTargetAnnotationPointcut;
import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

import com.wutka.jox.JOXBeanInputStream;

import cn.hutool.core.util.XmlUtil;
/**
 * 
 * 人保：XML转对象工具类
 * @author zhaoxiaojie
 *
 */
public class XMLUtil {
	
	/**
	 * 
	 * @param xml
	 * @return
	 * @throws UnsupportedEncodingException
	 */
	public static JOXBeanInputStream generateJox(String xml) throws UnsupportedEncodingException {
		return new JOXBeanInputStream(new ByteArrayInputStream(xml.getBytes("GBK")));
	}

	/**
	 * Xml转换对象
	 * 
	 * @param xml
	 * @param object
	 * @return
	 * @throws Exception
	 */
	public static Object xmlToObj(String xml, Object object) throws Exception {
		if (xml == null || "".equals(xml)) {
			throw new Exception("xml数据异常");
		}
		Object obj = generateJox(xml).readObject(object.getClass());
		return obj;
	}

	 /**
     * 将对象直接转换成String类型的 XML输出
     * 注意该方法取自公共的xmlutils 但不会生成xml头标签
     * 部分情况下需要注解配合使用
     * @param obj
     * @return
     */
    public static String convertToXml(Object obj) {
        // 创建输出流
        StringWriter sw = new StringWriter();
        try {
            // 利用jdk中自带的转换类实现
            JAXBContext context = JAXBContext.newInstance(obj.getClass());
            Marshaller marshaller = context.createMarshaller();
            // 格式化xml输出的格式
            marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT,
                    Boolean.TRUE);
            //去掉生成xml的默认报文头
            marshaller.setProperty(Marshaller.JAXB_FRAGMENT, true);
            // 将对象转换成输出流形式的xml
            marshaller.marshal(obj, sw);
        } catch (JAXBException e) {
            e.printStackTrace();
        }
        return sw.toString();
    }
    
    /**
     * 将String类型的xml转换成对象
     *   注意该方法取自公共的xmlutils
     *   部分情况下需要注解配合使用
     */
    public static Object convertXmlStrToObject(Class clazz, String xmlStr) {
        Object xmlObject = null;
        try {
            JAXBContext context = JAXBContext.newInstance(clazz);
            // 进行将Xml转成对象的核心接口
            Unmarshaller unmarshaller = context.createUnmarshaller();
            StringReader sr = new StringReader(xmlStr);
            xmlObject = unmarshaller.unmarshal(sr);
        } catch (JAXBException e) {
            e.printStackTrace();
        }
        return xmlObject;
    }
	
	
	
}
