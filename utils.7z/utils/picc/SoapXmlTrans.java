package com.sinosoft.car.utils.picc;

import java.util.Date;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
/**
 * 人保 SOAP和XML 转换工具类
 */
public class SoapXmlTrans {

	/**
	 * xml请求报文转换成soap
	 * @param xml
	 * @return
	 */
    public static String xmlToSoap(String xml){
    	String soapStr = "";
    	String request_typeStr = SoapXmlTrans.getSubUtilSimple(xml, "<request_type>(\\w+)</request_type>");
    	String uuid = SoapXmlTrans.getSubUtilSimple(xml, "<uuid>(.*?)</uuid>");
    	String sender = SoapXmlTrans.getSubUtilSimple(xml, "<sender>(\\w+)</sender>");
    	String user = SoapXmlTrans.getSubUtilSimple(xml, "<user>(\\w+)</user>");
    	String password = SoapXmlTrans.getSubUtilSimple(xml, "<password>(.*?)</password>");
    	String ChnlNo=SoapXmlTrans.getSubUtilSimple(xml, "<ChnlNo>(\\w+)</ChnlNo>");
    	String flowintime = SoapXmlTrans.getSubUtilSimple(xml, "<flowintime>(.*?)</flowintime>");
    	String areacode = SoapXmlTrans.getSubUtilSimple(xml, "<areacode>(\\w+)</areacode>");
    	String MAKECOME = SoapXmlTrans.getSubUtilSimple(xml, "<zoneNo>(\\w+)</zoneNo>");
    	String server_version = SoapXmlTrans.getSubUtilSimple(xml, "<server_version>(\\w+)</server_version>");
    	if(server_version==null||server_version==""){
    		server_version="00000000";
    	}
    	String body = "";
    	if(xml.indexOf("<Body>")!=-1){
    		int beginIndex = xml.indexOf("<Body>");
    		int endIndex = xml.indexOf("</Body>");
    		body=xml.substring(beginIndex+6, endIndex);
    	}
    	if(xml.indexOf("<BODY>")!=-1){
    		int beginIndex = xml.indexOf("<BODY>");
    		int endIndex = xml.indexOf("</BODY>");
    		body=xml.substring(beginIndex+6, endIndex);
    	}
    	if(xml.indexOf("<requestbody>")!=-1){
    		int beginIndex = xml.indexOf("<requestbody>");
    		int endIndex = xml.indexOf("</requestbody>");
    		body=xml.substring(beginIndex+"</requestbody>".length()-1, endIndex);
    	}
    	//转投保接口Q04
    	if("Q04".equals(request_typeStr)){
    		int beginIndex = xml.indexOf("<CarQuoteTransProposalReqList>");
    		int endIndex = xml.indexOf("</CarQuoteTransProposalReqList>");
    		body=xml.substring(beginIndex, endIndex+"</CarQuoteTransProposalReqList>".length());
    	}
    	/*
    	 * <request_type>03790029</request_type>       报价接口Q012
			<request_type>03790030</request_type>       转投保接口Q04
			<request_type>03790022</request_type>       核保口Q19
			<request_type>03790020</request_type>       投保单查询接口Q12
			<request_type>03790021</request_type>       投保单查询接口Q13
			<request_type>03790026</request_type>       续保查询接口Q101
			<request_type>03790024</request_type>       续保报价接口Q013
			<request_type>Q45</request_type>       续保报价接口Q45
    	 * */
    	String methodName="";
    	String request_type ="";
    	if(request_typeStr!=null&&request_typeStr!=""){//03790018为车险服务平台代码
    		if("Q012".equals(request_typeStr)){//报价接口Q012
    			methodName="TEMPSTORAGEREQ";
    			request_type ="Q012";
    		}else if("Q04".equals(request_typeStr)){//转投保接口Q04
    			methodName="TRANSTEMP2POLICYREQ ";
    			request_type ="Q04";
    		}else if("Q19".equals(request_typeStr)){//核保口Q19
    			methodName="COMMITUDWRTREQ ";
    			request_type ="Q19";
    		}else if("Q12".equals(request_typeStr)){//投保单查询接口Q12 概要信息
    			methodName="GETPOLICYCONDITIONREQ";
    			request_type ="Q12";
    		}else if("Q13".equals(request_typeStr)){//投保单查询接口Q13 详细信息
    			methodName="GETPOLICYDETAILCONDITIONREQ ";
    			request_type ="Q13";
    		}else if("Q101".equals(request_typeStr)){//续保查询接口Q101
    			methodName="GETORIGINPOLICYREQ ";
    			request_type ="Q101";
    		}else if("Q013".equals(request_typeStr)){//续保报价接口Q013
    			methodName="RENEWALTEMPREQ ";
    			request_type ="Q013";
    		}else if("Q23".equals(request_typeStr)){//送缴费 Q23
    			methodName="TOPAYMENTINFOEMATIONREQ ";
    			request_type ="Q23";
    		}else if("01190077".equals(request_typeStr)){//支付号申请接口(01190077)  --生成缴费通知单
    			methodName="PAYNUMBERAPPREQ ";
    			request_type ="01190077";
    		}else if("01190078".equals(request_typeStr)){//支付号状态查询接口（01190078）
    			methodName="GETPAYCONDITIONREQ ";
    			request_type ="01190078";
    		}else if("01190079".equals(request_typeStr)){//支付号注销接口（01190079）
    			methodName="CANCELPAYNOTICEREQ ";
    			request_type ="01190079";
    		}else if("Q45".equals(request_typeStr)){//vin查车接口Q45
    			methodName="QUERYVEHICLEMODLEVINREQ";
    			request_type ="Q45";
    		}else if("Q21".equals(request_typeStr)){//交管车辆查询校验03790017
    			methodName="CHECKCARREQ";
    			request_type ="Q21";
    		}else if("Q22".equals(request_typeStr)){//交管车辆查询确认03790018
    			methodName="GETCARINFOREQ";
    			request_type ="Q22";
    		}else if("Q27".equals(request_typeStr)){//北京新车备案（Q27）
    			request_type ="Q27";
    			methodName="NEWVEHICLERECORDREQ";
    		}else if("Q28".equals(request_typeStr)){//上海车型查询平台（Q28）
    			request_type ="Q28";
    			methodName="QUERYVEHICLEMODELSHREQ";
    		}else if("Q29".equals(request_typeStr)){//北京车型查询平台（Q29）
    			request_type ="Q29";
    			methodName="QUERYVEHICLEMODELBJREQ";
    		}else if("Q30".equals(request_typeStr)){//身份证采集（Q30）
    			request_type ="Q30";
    			methodName="IDCARDCHECKINFOREQ";
    		}else if("Q31".equals(request_typeStr)){//身份证采集回写验证（Q31）
    			request_type ="Q31";
    			methodName="IDCARDCHECKCODEREQ";
    		}else if("Q44".equals(request_typeStr)){//身份证采集回写验证（Q44）
    			request_type ="Q44";
    			methodName="GENERATESMSCODEREQ";
    		}else if("Q201".equals(request_typeStr)){//打印（Q201）
    			request_type ="Q201";
    			methodName="POLICYPRINTREQ";
    		}
    	}
    	String beforeSoap = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\">  \n" +
                "  <soap:Header xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">  \n" +
                "    <nshead:requesthead xmlns:nshead=\"http://pub.webservice.cmp.com\">  \n" +
                "      <nshead:request_type>"+ request_type +"</nshead:request_type>  \n" +
                "      <nshead:uuid>"+uuid+"</nshead:uuid>  \n" +
                "      <nshead:sender>"+ sender +"</nshead:sender>  \n" +
                "      <nshead:user>"+ user +"</nshead:user>  \n" +
                "      <nshead:password>" + password + "</nshead:password>  \n" +
                "      <nshead:ChnlNo>"+ChnlNo+"</nshead:ChnlNo>  \n" +
                "      <nshead:areacode>"+ areacode +"</nshead:areacode>  \n" +
                "      <nshead:flowintime>"+ flowintime +"</nshead:flowintime> \n" +
                "      <nshead:server_version>"+ server_version +"</nshead:server_version> \n" +
                "    </nshead:requesthead> \n" +
                "  </soap:Header>  \n" +
                "  <soapenv:Body> \n" +
                "    <pan:"+ methodName +" xmlns:pan=\"http://pan.prpall.webservice.cmp.com\">  \n" +
                "      <pan:BIZ_ENTITY> \n" ;
    	String afterSoap = "  </pan:BIZ_ENTITY>  \n" +
                "      <pan:APP_INFO> \n" +
                "        <pan:MAKECOME>"+ MAKECOME +"</pan:MAKECOME>  \n" +
                "        <pan:REQMOD></pan:REQMOD> \n" +
                "      </pan:APP_INFO> \n" +
                "    </pan:"+ methodName +"> \n" +
                "  </soapenv:Body> \n" +
                "</soapenv:Envelope>" ;
    	String afterSoap1 = "  </pan:BIZ_ENTITY> \n" +
				"      <pan:EXTEND> \n" +
				"        <pan:PARAM></pan:PARAM> \n" +
				"	   </pan:EXTEND> \n" +
				"	 </pan:"+ methodName +"> \n" +
				"  </soapenv:Body> \n" +
				"</soapenv:Envelope>";
    	if(request_typeStr!=null&&request_typeStr!=""&&("Q04".equals(request_typeStr)||"Q12".equals(request_typeStr)||"Q13".equals(request_typeStr)||"Q201".equals(request_typeStr))){//转投保接口Q04
    		soapStr = beforeSoap+body+afterSoap1;
		}else if(request_typeStr!=null&&request_typeStr!=""&&"Q45".equals(request_typeStr)||"01190077".equals(request_typeStr)
                || "01190078".equals(request_typeStr) || "Q31".equals(request_typeStr) || "Q30".equals(request_typeStr)) {
			soapStr = beforeSoap+body+"</pan:BIZ_ENTITY></pan:"+methodName+"></soapenv:Body></soapenv:Envelope>";
		}else{
			soapStr = beforeSoap+body+afterSoap;
		}
      return soapStr;
    }
    /**
     * soap转换成xml
     * @param soapXml
     * @return
     */
    public static String soapToXml(String soapXml){
    	String xmlStr = "";
    	String request_typeStr = SoapXmlTrans.getSubUtilSimple(soapXml, "<pub:request_type>(\\w+)</pub:request_type>");
    	String uuid = SoapXmlTrans.getSubUtilSimple(soapXml, "<pub:uuid>(.*?)</pub:uuid>");
    	String sender = SoapXmlTrans.getSubUtilSimple(soapXml, "<pub:sender>(\\w+)</pub:sender>");
    	//String user = SoapXmlTrans.getSubUtilSimple(soapXml, "<user>(\\w+)</user>");
    	//String password = SoapXmlTrans.getSubUtilSimple(soapXml, "<password>(.*?)</password>");
    	String response_code=SoapXmlTrans.getSubUtilSimple(soapXml, "<pub:response_code>(\\w+)</pub:response_code>");
    	String flowintime = SoapXmlTrans.getSubUtilSimple(soapXml, "<pub:flowintime>(.*?)</pub:flowintime>");
    	String error_message = SoapXmlTrans.getSubUtilSimple(soapXml, "<pub:error_message>(\\w+)</pub:error_message>");
    	if((error_message==null||error_message=="")&&soapXml.indexOf("<pub:error_message>")!=-1){
    		int beginIndex = soapXml.indexOf("<pub:error_message>");
    		int endIndex = soapXml.indexOf("</pub:error_message>");
    		error_message=soapXml.substring(beginIndex+19, endIndex);
    	}
    	//String MAKECOME = SoapXmlTrans.getSubUtilSimple(soapXml, "<zoneNo>(\\w+)</zoneNo>");
    	String body = SoapXmlTrans.getSubUtilSimple(soapXml, "<pan:BIZ_ENTITY>(.*?)</pan:BIZ_ENTITY>");
    	if((body==null||body=="")&&soapXml.indexOf("<pan:BIZ_ENTITY>")!=-1){
    		int beginIndex = soapXml.indexOf("<pan:BIZ_ENTITY>");
    		int endIndex = soapXml.indexOf("</pan:BIZ_ENTITY>");
    		// 之前切割为6  实际效果为会切割成IZ_ENTITY>
    		body=soapXml.substring(beginIndex+16, endIndex);
    	}
    	String request_type ="";
    	request_type = request_typeStr;
    	/*if(request_typeStr!=null&&request_typeStr!=""){
    		if("Q012".equals(request_typeStr)){//报价接口Q012
    			request_type ="03790029";
    		}else if("Q04".equals(request_typeStr)){//转投保接口Q04
    			request_type ="03790030";
    		}else if("Q19".equals(request_typeStr)){//核保口Q19
    			request_type ="03790022";
    		}else if("Q12".equals(request_typeStr)){//投保单查询接口Q12 概要信息
    			request_type ="03790020";
    		}else if("Q13".equals(request_typeStr)){//投保单查询接口Q13 详细信息
    			request_type ="03790021";
    		}else if("Q101".equals(request_typeStr)){//续保查询接口Q101
    			request_type ="03790026";
    		}else if("Q013".equals(request_typeStr)){//续保报价接口Q013
    			request_type ="03790024";
    		}else if("Q23".equals(request_typeStr)){//送缴费 Q23
    			request_type ="01010186";
    		}else if("01190077".equals(request_typeStr)){//支付号申请接口(01190077)  --生成缴费通知单
    			request_type ="01190077";
    		}else if("01190078".equals(request_typeStr)){//支付号状态查询接口（01190078）
    			request_type ="01190078";
    		}else if("01190079".equals(request_typeStr)){//支付号注销接口（01190079）
    			request_type ="01190079";
    		}else if("Q45".equals(request_typeStr)){//支付号注销接口（01190079）
    			request_type ="Q45";
    		}
    	}*/
    	String successBeforeXml="";
    	String successAfterXml=" ";
    	String errorXml="";
    	//判断response_code是否成功 1 为查询成功
    	if(request_type!=null&&request_type!=""){
	    	if(("Q012,Q04,Q19,Q12,Q13,Q101,Q013,Q23,Q45,Q21,Q22,Q27,Q28,Q29,Q30,Q31,Q44,Q201").indexOf(request_type)!=-1){
	    		if(response_code!=null&&response_code!=""){
	    			if("1".equals(response_code)||"2".equals(response_code)){
	    				successBeforeXml="<?xml version=\"1.0\" encoding=\"GBK\"?>\n"+
	    						"<Packet>\n"+
	    						"<responsehead>\n"+
	    						"	<server_version>00000000</server_version>\n"+
	    						"	<uuid>"+uuid+"</uuid>\n"+
	    						"	<response_code>"+response_code+"</response_code>\n"+
	    						"	<error_message>"+error_message+"</error_message>\n"+
	    						"	<timestamp>"+flowintime+"</timestamp>\n"+
	    						"	<request_type>"+request_type+"</request_type>\n"+
	    						"	<sender>"+sender+"</sender>\n"+
	    						"</responsehead>\n"+
	    						"<Body>\n";
	    				successAfterXml=" </Body>\n</Packet>";
	    				xmlStr = successBeforeXml + body +successAfterXml;
	    			}else if("0".equals(response_code)){
	    				errorXml="<?xml version=\"1.0\" encoding=\"GBK\"?>\n"+
	    						"<Packet>\n"+
	    						"<responsehead>\n"+
	    						"	<server_version>00000000</server_version>\n"+
	    						"	<uuid>"+uuid+"</uuid>\n"+
	    						"	<response_code>"+response_code+"</response_code>\n"+
	    						"	<error_message>"+error_message+"</error_message>\n"+
	    						"	<timestamp>"+flowintime+"</timestamp>\n"+
	    						"	<request_type>"+request_type+"</request_type>\n"+
	    						"	<sender>"+sender+"</sender>\n"+
	    						"</responsehead>\n"+
	    						"</Packet>";
	    				xmlStr = errorXml;
	    			}
	    		}
	    	}else  if(("01190077,01190078,01190079").indexOf(request_type)!=-1){
	    		String timestamp = SoapXmlTrans.getSubUtilSimple(soapXml, "<pub:timestamp>(.*?)</pub:timestamp>");
		    		if(response_code!=null&&response_code!=""){
		    			if("0000".equals(response_code)){
		    				successBeforeXml="<?xml version=\"1.0\" encoding=\"GBK\"?>\n"+
		    						"<PACKET type=\"RESPONSE\" version=\"1.0\">\n"+
		    						"<responsehead>\n"+
		    						"	<server_version>00000000</server_version>\n"+
		    						"	<uuid>"+uuid+"</uuid>\n"+
		    						"	<response_code>"+response_code+"</response_code>\n"+
		    						"	<error_message>"+error_message+"</error_message>\n"+
		    						"	<timestamp>"+timestamp+"</timestamp>\n"+
		    						"	<request_type>"+request_type+"</request_type>\n"+
		    						"	<sender>"+sender+"</sender>\n"+
		    						"</responsehead>\n"+
		    						"<BODY>";
		    				successAfterXml="</BODY>\n</PACKET>";
		    				xmlStr = successBeforeXml + body +successAfterXml;
		    			}else {
		    				errorXml="<?xml version=\"1.0\" encoding=\"GBK\"?>\n"+
		    						"<PACKET type=\"RESPONSE\" version=\"1.0\">\n"+
		    						"<responsehead>\n"+
		    						"	<server_version>00000000</server_version>\n"+
		    						"	<uuid>"+uuid+"</uuid>\n"+
		    						"	<response_code>"+response_code+"</response_code>\n"+
		    						"	<error_message>"+error_message+"</error_message>\n"+
		    						"	<timestamp>"+timestamp+"</timestamp>\n"+
		    						"	<request_type>"+request_type+"</request_type>\n"+
		    						"	<sender>"+sender+"</sender>\n"+
		    						"</responsehead>\n"+
		    						"</PACKET>";
		    				xmlStr = errorXml;
		    			}
		    		}
		    	}
	    	
    	}
      return xmlStr;
    }
    
    public static String getSubUtilSimple(String str,String rgex){
    	if(str != null && str != "" && rgex != null && rgex != ""){
    		Pattern pattern = Pattern.compile(rgex);// 匹配的模式
    		Matcher m = pattern.matcher(str);
    		while(m.find()){
    			return m.group(1);
    		}
    	}
    	return "";
    }
    
    /**
     * xml请求报文转换成soap
     * @param xml
     * @param comCode
     * @return
     */
    public static String dmsXmlToSoap(String xml,String comCode){
    	String soapStr="";
    	String beforeSoap = "<soapenv:Envelope	xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\">"+
    		"<soap:Header	xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">"+
    			"<nshead:requesthead	xmlns:nshead=\"http://pub.webservice.cmp.com\">"+
    			"<nshead:request_type>dmsinterface</nshead:request_type>"+
    			"<nshead:uuid>9cacc039-5d1c-42bd-abca-e1818062537t</nshead:uuid>"+
    			"<nshead:sender>0578</nshead:sender>"+
    			"<nshead:server_version>00000000</nshead:server_version>"+
    			"<nshead:user>0578</nshead:user>"+
    			"<nshead:password>B6298F271E699D3987AAFB1471C70EF8</nshead:password>"+
    			"<nshead:ChnlNo>qingdaocarsales</nshead:ChnlNo>"+
    			"<nshead:areacode>"+comCode.substring(0,4)+"0000</nshead:areacode>"+
    			"<nshead:flowintime>2013-05-1000:01:38.653CST</nshead:flowintime>"+
    			"</nshead:requesthead>"+
    			"</soap:Header>"+
    			"<soapenv:Body>"+
    			"<pan:DMSINTERFACEREQ xmlns:pan=\"http://pan.prpall.webservice.cmp.com\">"+
    			"<pan:BIZ_ENTITY>";
    	String afterSoap = "</pan:BIZ_ENTITY>"+
    			"<pan:APP_INFO>"+
    			"<pan:MAKECOME></pan:MAKECOME>"+
    			"<pan:REQMOD></pan:REQMOD>"+
    			"</pan:APP_INFO>"+
    			"</pan:DMSINTERFACEREQ>"+
    			"</soapenv:Body>"+
    			"</soapenv:Envelope>";
		soapStr = beforeSoap+xml+afterSoap;
      return soapStr;
    }
  
    /**
     * soap转换成xml
     * @param soapXml
     * @return
     */
    public static String dmsSoapToXml(String soapXml){
    	String xmlStr="";
		int beginIndex = soapXml.indexOf("<pan:BIZ_ENTITY>");
		int endIndex = soapXml.indexOf("</pan:BIZ_ENTITY>");
		xmlStr=soapXml.substring(beginIndex+"<pan:BIZ_ENTITY>".length(), endIndex);
      return xmlStr;
    }
}