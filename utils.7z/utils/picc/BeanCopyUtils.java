package com.sinosoft.car.utils.picc;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class BeanCopyUtils {

    /**
     * 复制源对象和目标对象的属性值（可以忽略大小写）
     *
     */
    public static void copy(Object source, Object target) throws NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {

        Class sourceClass = source.getClass();//得到对象的Class
        Class targetClass = target.getClass();//得到对象的Class

        Field[] sourceFields = sourceClass.getDeclaredFields();//得到Class对象的所有属性
        Field[] targetFields = targetClass.getDeclaredFields();//得到Class对象的所有属性

        for(Field sourceField : sourceFields){
            String name = sourceField.getName();//属性名
            String lowNmae = name.toLowerCase();//转换小写用于赋值
            Class type = sourceField.getType();//属性类型
            String sourceMethodName = name.substring(0, 1).toUpperCase() + name.substring(1);
            //得到属性对应get方法
            Method getMethod = sourceClass.getMethod("get" + sourceMethodName);
            Object value = getMethod.invoke(source);//执行源对象的get方法得到属性值
            //如果为空则没必要进行赋值
            if (value != null){
                for(Field targetField : targetFields){
                    String targetName = targetField.getName();//目标对象的属性名
                    String lowTargetName = targetName.toLowerCase(); //转换小写用于赋值
                    if(lowTargetName.equals(lowNmae)){
                        String targetMethodName = targetName.substring(0, 1).toUpperCase() + targetName.substring(1);
                        Method setMethod = targetClass.getMethod("set" + targetMethodName, type);//属性对应的set方法

                        setMethod.invoke(target, value);//执行目标对象的set方法
                        break; //赋值完毕直接打断循环
                    }
                }
            }
        }
    }
}
