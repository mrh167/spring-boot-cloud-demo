package com.sinosoft.car.utils;

import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang3.StringUtils;

import java.io.UnsupportedEncodingException;

public class MD5Utils {

    public static final String key = "MIICeAIBADANBgkqhkiG9w0BAQEFAASCAmIwggJeAgEAAoGBANRxvMq8HizWHl45kBl1JnGw6r6r++3C4DjNAeOrAcQRFzGzrT3WIOFF6pkJYZl+zDn1Csymqe/rlImSH3Jh4I41APz09KBtlQkI6+qwK4LjJUWUaMcVJew9SfiTNVXERIt18C7RyX2MuAoNV8VGUgqf76ql20N/tfwU4OPSHw51AgMBAAECgYEAp1WTNEkqp3xcXTGQDE1XY7PLozZKcMPP402vUEmxUWN41oBFU/Cm42oz2CkohEP4zynxQLOCJWV1EUtUk77+pPQnGCEYmUZUTuDUeWwD3u9JsAS2v83QJWvAPkjf7mCk7dIzTORQxxuNHqyOYKNqn1P4fe4gbcvAdURoRoAZpF0CQQD758pcd1ZFUoM8asUW1fD7RBY39gCZZ9SNQSDKJnbxYJqRSe0QumNVHRkcVQ/L25jh0EPkUZ5u0u56cYnlRHXPAkEA1+W+i0EtVu7jqU6gQ0zbWd/KOcjXDeanIPFcXp4DG4lZPAuSw9Kqz8Xbb1Yqq7dkPFsIFNYAl6wf7F0Tte9MewJBALyQnBhvdHLb+0Ukn3gimgtcwk0NpxEuehtq30KzXGH/cHTFo+HbxDOYXo2o1vRA48ZVghzNRA2tc7rQduraPl0CQQDRJb9xJ7LEhKgHXCPlDo9wgVtmnym2TbuaLjdNccWQ532KrauACJVwsjvhn5e2wfJYhddOWAI67IQAdiqiFTABAkA8QuD9xf45GNarchjGibovlPgdf+ExQn3n5HbgkqpckBaqTvgZ3ofYKMNIDlVuiOF7cFASvn1mW03z+VsRySmm";


    /**
     * 带秘钥加密
     *
     * @param param      数据
     * @param privateKey 秘钥
     * @param charset    编码格式
     * @return 密文
     */
    public static String signMD5(String param, String privateKey, String charset) throws UnsupportedEncodingException {
        // 加密后的字符串
        String md5str = DigestUtils.md5Hex(getContentBytes(param + privateKey, charset));
        return md5str;
    }

    /**
     * 根据编码转换字符串为byte数组
     *
     * @param content 需要转换的字符串
     * @param charset 编码格式
     * @return byte[] 字节码数据
     */
    private static byte[] getContentBytes(String content, String charset) throws UnsupportedEncodingException {
        return content.getBytes(charset);
    }

    public static void main(String[] args) {
        String param = "{\"commonData\":{\"policySort\":\"EAV\",\"operator\":\"EAV_user\",\"operatorKey\":\"123456\",\"franchiserCode\":\"110000\",\"transactionTime\":\"2021-03-03T13:58:47.868+08:00\",\"transactionNo\":\"Tno-ebf37181-81ef-4e4f-8dbf-b174caa95c1e\",\"businessNumber\":\"Biz-67ed072a-2da7-4fac-af13-ae63b102ad4e\",\"ipAddress\":\"172.23.101.223\",\"transactionType\":\"G04\"},\"businessData\":{\"bzbusinessNo\":\"6105072021110102050105\",\"sybusinessNo\":\"\",\"plcCarowner\":{\"customerType\":\"1\",\"customerName\":\"王龙洋\",\"identifyType\":\"01\",\"identifyNumber\":\"410185199211060094\",\"plcCustomer\":{\"address\":\"北京市昌平区回龙观\",\"postalAddress\":\"北京市昌平区回龙观\",\"mobile\":\"18614075331\",\"sex\":\"1\"}},\"plcApplicant\":{\"customerType\":\"1\",\"customerName\":\"王龙洋\",\"identifyType\":\"01\",\"identifyNumber\":\"410185199211060094\",\"plcCustomer\":{\"address\":\"北京市昌平区回龙观\",\"postalAddress\":\"北京市昌平区回龙观\",\"mobile\":\"18614075331\",\"sex\":\"1\"}},\"plcPublicInsurant\":{\"customerType\":\"1\",\"customerName\":\"王龙洋\",\"identifyType\":\"01\",\"identifyNumber\":\"410185199211060094\",\"plcCustomer\":{\"address\":\"北京市昌平区回龙观\",\"postalAddress\":\"北京市昌平区回龙观\",\"mobile\":\"18614075331\",\"sex\":\"1\"},\"carInsureRelation\":\"1\"}}}";
        String s = null;
        try {
            s = signMD5(param, key, "UTF-8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }

        System.out.println(s);
    }
}