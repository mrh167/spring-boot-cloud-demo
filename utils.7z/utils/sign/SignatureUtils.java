package com.sinosoft.car.utils.sign;

import com.alibaba.fastjson.JSONObject;
import com.sinosoft.car.service.support.AESEncrypt;
import com.sinosoft.car.utils.cpic.support.Base64;
import org.apache.commons.collections.map.LinkedMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.crypto.Cipher;
import java.io.ByteArrayOutputStream;
import java.security.*;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
@Component("SignatureUtil")
public class SignatureUtils {
    //保险公司的公钥
    public static String publicKey;
    //保险公司的私钥
   // public static String privateKey;
    //合作伙伴的公钥
    public static String thirdPublicKey;
    //合作伙伴的私钥
    public static String thirdPrivateKey;

    // 华安保险公司公钥
    public static String haicCertiPublicKey;

    // 国寿保险公司公钥
    public static String gpicCertiPublicKey;

    @Value("${rsa.certi.certiPublicKey}")
    public void setPublicKey(String publicKey) {
        this.publicKey = publicKey;
    }
    @Value("${rsa.self.selfPublicKey}")
    public void setThirdPublicKey(String thirdPublicKey) {
        this.thirdPublicKey = thirdPublicKey;
    }
    @Value("${rsa.self.selfPrivateKey}")
    public void setThirdPrivateKey(String thirdPrivateKey) {
        this.thirdPrivateKey = thirdPrivateKey;
    }


    @Value("${rsa.certi.haicCertiPublicKey}")
    public void setHaicCertiPublicKey(String haicCertiPublicKey) {
        this.haicCertiPublicKey = haicCertiPublicKey;
    }

    //国寿保司
    @Value("${rsa.certi.gpicCertiPublicKey}")
    public void setGpicCertiPublicKey(String gpicCertiPublicKey) {
        this.gpicCertiPublicKey = gpicCertiPublicKey;
    }

    private static final Logger LOGGER = LoggerFactory.getLogger(SignatureUtils.class);

    /**
     * RSA最大加密明文大小
     */
    private static final int MAX_ENCRYPT_BLOCK = 117;

    /**
     * RSA最大解密密文大小
     */
    private static final int MAX_DECRYPT_BLOCK = 128;

    private SignatureUtils() {
    }

    /**
     * 解密并解签(若无法解签，请检查公钥私钥是否有效)
     * @param args
     */
//    public static void main(String[] args) throws Exception {
//        String msg = "{\"dateTime\":\"20210317133419\",\"charset\":\"UTF-8\",\"partnerCode\":\"QYC\",\"serviceCode\":\"A1001\",\"insurer\":\"000014\",\"format\":\"json\",\"sign\":\"X2VmzKF3t7zr+EGkRY16hWI4nVy0UBv2LcfufEUOLLshFB4BJ+BE/RxVBUtfGlzUqqXT4qxiuiy2egIzd8Y3t5t0j4nAO1GSJ6CVDglNQidqtFsnSPlzlrnFzxvXbykgt9tVFzeD5v2i3oJcIZTyHIcVSFsaC7W6JiakJlIA1zA=\",\"type\":\"RSA\",\"content\":\"IKxGKQxsA4IkUDc7GEuwY5U7xQZSstvWDNqtw4NlLjW3vPbBwD5xUnQKE8Vj51RVVZT5WZFAPaD29DGcuFBnvhDmxfIcjqPAQ+UZFRE9BhOa3dwhTab2bRpKKG8lf9yP8zp0CuNRQaHMk2q1FTN8K1GH2q1t6h6ZqkhyiNnF9UgTWwPiOeibrDJOdT/DjN8qAs/tU9KcSGj74dFR4vcWKzDKYP7q0vyDHSJT5wS9nztY7yi4sMMZC58qXLKPTKpgXwg1OzYZAkva3GaUN7qYL6vn+WnLquCMWq3QHFKJMXH15wTcv5meL3HKn9aRmoHrNRirBYpeJIc1MGm9e2EEtQ==\"}";
//        String s = checkSignAndDecrypt(msg, publicKey, thirdPrivateKey, true, true);
//        System.out.println(s);
//    }

    //保险公司加密
//    public static void main(String[] args) throws Exception {
//        String request = "{\"serviceCode\":\"A1001\",\"partnerCode\":\"QYC\",\"insurer\":\"000014\",\"charset\":\"UTF-8\",\"format\":\"json\",\"content\":{\"bodyData\":{\"policyList\":[{\"riskName\":\"交强险\",\"plateNo\":\"京A660H*\",\"agencyCreditCode\":\"913101017970918181\",\"signingDate\":\"20210202\",\"riskCode\":\"1\",\"certiType\":\"E-批单\",\"policyNo\":\"P3201202102020000001\",\"insurerCode\":\"000001\",\"insuranceEndDate\":\"20220203123023\",\"insurerName\":\"中国人民财产保险股份有限公司\",\"commRatio\":\"30.00\",\"agencyName\":\"天彩保险经纪有限公司\",\"premium\":\"888.88\",\"certiNo\":\"P3201220000001\",\"vin\":\"LB1**5884A8008781\",\"salesCertificateNo\":\"ES060000000\",\"salesPerson\":\"王可\",\"insuranceStartDate\":\"20210203123023\"}]},\"headData\":{\"passWord\":\"123456\",\"dateTime\":\"19000101235959\",\"user\":\"picc\",\"serialNo\":\"2021010119200900000001\"}},\"sign\":\"\",\"type\":\"RSA\",\"dateTime\":\"20210317094206\"}";
//        String msg = encryptAndSign(thirdPublicKey, privateKey, request, true, true);
//        System.out.println(msg);
//    }
    //全优车解密

    //全优车加密

    //保险公司解密
//    public static void main(String[] args) throws Exception {
//        String msg = "{\"dateTime\":\"20210317133935\",\"charset\":\"UTF-8\",\"partnerCode\":\"QYC\",\"serviceCode\":\"A1001\",\"insurer\":\"000014\",\"format\":\"json\",\"sign\":\"KKWPKHD3U2iAhkYjQOhTgxajtpQQ9/etgAMJxzXj8K8I/zeq5M0n1COVm04qI1L2MIsx4/Q3OdVHx2HvaW9RaqSspjX02ZH0+4U2j1Y1q38gWse3H+zkaeP09u7gHug4xX2mFRKdHOmLjK+rtdHsQhimR1W7F2y3KnhP3er5BL0=\",\"type\":\"RSA\",\"content\":\"Ez3vpuxMqMwDguYzGN5HG1vWYiQryoE12dfvw5DUqcOAkphA7bvRY+hK20vyCFhJNJ/4p0q+b3mmtyVMTY0WEmXbq88WMxJVcUas/3EUcyxh/SzvQ3PEb9nCDwGruajs1vTS7aRBr/WUToBNlv+HZxiIcuN1pByo4z3vmcv1PluLgJVp1tGFMjlztsfGFpsONhbemL4huk/v/3qCVTWuZogSwQCPMzhbZvkBkMIRhV4ySm/DlJwtoNmpXOGlIitEDEDsIOkJRFr0eXq7D5lwiPIo3wRM7reIZQr2v7qep30+byD5gv9LrmaW/3m6jh8nDjpjRDoSeEKCy9+aCN+viA==\"}";
//        String s = checkSignAndDecrypt(msg, publicKey, thirdPrivateKey, true, true);
//        System.out.println(s);
//    }

    /**
     * 验签并解密
     * <p>
     * 对于<b>合作伙伴</b>，publicKey是指保险公司的公钥，privateKey是指合作伙伴的私钥<br>
     * 对于<b>保险公司</b>，publicKey是指合作伙伴的公钥，privateKey是指保险公司自己的私钥<br>
     *
     * @param request     原始报文(JSON字符串)
     * @param publicKey   公钥
     * @param privateKey  私钥
     * @param isCheckSign 是否验签
     * @param isDecrypt   是否解密
     * @return 解密后的明文，验签失败则异常抛出
     * @throws Exception
     */
//    public static String checkSignAndDecrypt(String request,String publicKey, String privateKey,
//                                             boolean isCheckSign, boolean isDecrypt) {
//        boolean verifyResult = true;
//        JSONObject requestJSONObject = JSONObject.parseObject(request);
//        String sign = requestJSONObject.getString("sign");
//        String content = requestJSONObject.getString("content");
//        if(isCheckSign){
//            verifyResult = verify(content, sign, publicKey);
//        }
//        if(isDecrypt && verifyResult){
//            return decryptByPrivateKey(content, privateKey);
//        }
//        return null;
//    }
    public static String checkSignAndDecrypt(String request, String publicKey, String privateKey,
                                             boolean isCheckSign, boolean isDecrypt) throws Exception {
        boolean verifyResult = false;
        System.out.println("request:" + request);
        LOGGER.info("request:" + request);
        JSONObject requestJSONObject = JSONObject.parseObject(request);
        String sign = requestJSONObject.getString("sign");//获取的签文
        LOGGER.info("sign:" + sign);
//        System.out.println("sign:"+sign);
        String content = requestJSONObject.getString("content");//获取的业务数据密文
        requestJSONObject.remove("sign");//要排序先去掉sign（签文）
        String signContent = getSignContent(requestJSONObject);//所有key排序后放入LingkedMap后map.toString()
//        LOGGER.info("签名字符串为：" + signContent);
        if (isCheckSign) {
            verifyResult = verify(signContent, sign, publicKey);
        }
        System.out.println("================"+verifyResult);
        System.out.println("00001");
        if (isDecrypt && verifyResult) {
            return decryptByPrivateKey(content, privateKey);
        }

        return null;
    }

    /**
     * 加密并签名
     * <p>
     * 对于<b>合作伙伴</b>，publicKey是指保险公司的公钥，privateKey是指合作伙伴的私钥<br>
     * 对于<b>保险公司</b>，publicKey是指合作伙伴的公钥，privateKey是指保险公司自己的私钥<br>
     *
     * @param publicKey       公钥
     * @param privateKey      私钥
     * @param responseContent 返回报文原文
     * @param isCheckSign     是否签名
     * @param isEncrypt       是否加密
     * @return 加密加签后的返回报文
     * @throws Exception
     */
//    public static String encryptAndSign(String publicKey, String privateKey, String content, boolean isCheckSign, boolean isEncrypt) throws Exception {
//        JSONObject jsonObject = new JSONObject();
//        JSONObject responseJSONObject = JSONObject.parseObject(content);
//        if(isEncrypt) {
//            String encryptContent = encryptByPublicKey(content, publicKey);
//            jsonObject.put("content", encryptContent);
//            if(isCheckSign) {
//                String sign = getSignContent(responseJSONObject);
//                jsonObject.put("sign", sign);
//            }
//        } else if(isCheckSign) {
//            String sign = sign(content, privateKey);
//            jsonObject.put("sign", sign);
//        }
//        return jsonObject.toString();
//    }
    public static String encryptAndSign(String publicKey, String privateKey, String responseContent,
                                        boolean isCheckSign, boolean isEncrypt) throws Exception {
        JSONObject responseJSONObject = JSONObject.parseObject(responseContent);
        String content = responseJSONObject.getString("content");
        responseJSONObject.remove("sign");//去掉sign,之后加签添加
        if (isEncrypt) {
            String encryptContent = encryptByPublicKey(content, publicKey);
//            LOGGER.info("加密后业务数据：" + encryptContent);
            responseJSONObject.put("content", encryptContent);
            if (isCheckSign) {
                String signContent = getSignContent(responseJSONObject);//所有key排序后放入LingkedMap后map.toString()
//                LOGGER.info("待签名字符串为：" + sign);
                String sign = sign(signContent, privateKey);
                responseJSONObject.put("sign", sign);
            }
        } else if (isCheckSign) {//只加签、不加密
            String signContent = getSignContent(responseJSONObject);//所有key排序后放入LingkedMap后map.toString()
//            LOGGER.info("待签名字符串为：" + sign);
            String sign = sign(signContent, privateKey);
            responseJSONObject.put("sign", sign);
        }
        return responseJSONObject.toJSONString();
    }

    /**
     * 封装待验签的内容
     *
     * @param sortedParam
     * @return
     */
    public static String getSignContent(Map<String, Object> sortedParam) {
        LinkedMap map = new LinkedMap();
        List<String> keys = new ArrayList<>(sortedParam.keySet());
        Collections.sort(keys);
        for (int i = 0; i < keys.size(); i++) {
            String key = keys.get(i);
            String value = sortedParam.get(key).toString();
            map.put(key, value);
        }
//        LOGGER.info("map = "+map.toString());
        return map.toString();
    }

    /**
     * 验签
     *
     * @param request
     * @param sign
     * @param publicKey
     * @return
     */
    public static boolean verify(String request, String sign, String publicKey) {
        try {
            return SignatureUtils.verify(request.getBytes(CharsetEnum.UTF_8.code), publicKey, sign);
        } catch (Exception e) {
            LOGGER.error(ExceptionUtil.getErrorMsg(e), e);
            throw new RuntimeException(e);
        }
    }

    /**
     * <p>
     * 校验数字签名
     * </p>
     *
     * @param data      已加密数据
     * @param publicKey 公钥(BASE64编码)
     * @param sign      数字签名
     * @return
     * @throws Exception
     */
    public static boolean verify(byte[] data, String publicKey, String sign)
            throws Exception {
        byte[] keyBytes = Base64Utils.decode(publicKey);
        X509EncodedKeySpec keySpec = new X509EncodedKeySpec(keyBytes);
        KeyFactory keyFactory = KeyFactory.getInstance(SignEnum.SIGN_TYPE_RSA.code);
        PublicKey publicK = keyFactory.generatePublic(keySpec);
        //modify by 君君 调试不通，临时修改
        //Signature signature = Signature.getInstance(SignEnum.SIGNATURE_ALGORITHM.code);
        Signature signature = Signature.getInstance(SignEnum.SIGNATURE_ALGORITHM.code);
        signature.initVerify(publicK);
        signature.update(data);
        return signature.verify(Base64Utils.decode(sign));
    }

    /**
     * 私钥对数据进行解密
     *
     * @param bizContent
     * @param privateKey
     * @return
     */
    public static String decryptByPrivateKey(String bizContent, String privateKey) {
        try {
            return new String(SignatureUtils.decryptByPrivateKey(Base64.decode(bizContent.getBytes()), privateKey), CharsetEnum.UTF_8.code);
        } catch (Exception e) {
            LOGGER.error(ExceptionUtil.getErrorMsg(e), e);
            throw new RuntimeException(e);
        }
    }

    /**
     * <P>
     * 私钥解密
     * </p>
     *
     * @param encryptedData 已加密数据
     * @param privateKey    私钥(BASE64编码)
     * @return
     * @throws Exception
     */
    public static byte[] decryptByPrivateKey(byte[] encryptedData, String privateKey)
            throws Exception {
        byte[] keyBytes = Base64Utils.decode(privateKey);
        PKCS8EncodedKeySpec pkcs8KeySpec = new PKCS8EncodedKeySpec(keyBytes);
        KeyFactory keyFactory = KeyFactory.getInstance(SignEnum.SIGN_TYPE_RSA.code);
        Key privateK = keyFactory.generatePrivate(pkcs8KeySpec);
        Cipher cipher = Cipher.getInstance(keyFactory.getAlgorithm());
        cipher.init(Cipher.DECRYPT_MODE, privateK);
        int inputLen = encryptedData.length;
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        int offSet = 0;
        byte[] cache = null;
        int i = 0;
        // 对数据分段解密
        while (inputLen - offSet > 0) {
            if (inputLen - offSet > MAX_DECRYPT_BLOCK) {
                cache = cipher.doFinal(encryptedData, offSet, MAX_DECRYPT_BLOCK);
            } else {
                cache = cipher.doFinal(encryptedData, offSet, inputLen - offSet);
            }
            out.write(cache, 0, cache.length);
            i++;
            offSet = i * MAX_DECRYPT_BLOCK;
        }
        byte[] decryptedData = out.toByteArray();
        out.close();
        return decryptedData;
    }


    /**
     * 公钥加密
     *
     * @param request
     * @param publicKey
     * @return
     */
    public static String encryptByPublicKey(String request, String publicKey) throws Exception {
        return Base64Utils.encode(SignatureUtils.encryptByPublicKey(request.getBytes(CharsetEnum.UTF_8.code), publicKey));
    }

    /**
     * <p>
     * 公钥加密
     * </p>
     *
     * @param data      源数据
     * @param publicKey 公钥(BASE64编码)
     * @return
     * @throws Exception
     */
    public static byte[] encryptByPublicKey(byte[] data, String publicKey)
            throws Exception {
        byte[] keyBytes = Base64Utils.decode(publicKey);
        X509EncodedKeySpec x509KeySpec = new X509EncodedKeySpec(keyBytes);
        KeyFactory keyFactory = KeyFactory.getInstance(SignEnum.SIGN_TYPE_RSA.code);
        Key publicK = keyFactory.generatePublic(x509KeySpec);
        // 对数据加密
        Cipher cipher = Cipher.getInstance(keyFactory.getAlgorithm());
        cipher.init(Cipher.ENCRYPT_MODE, publicK);
        int inputLen = data.length;
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        int offSet = 0;
        byte[] cache;
        int i = 0;
        // 对数据分段加密
        while (inputLen - offSet > 0) {
            if (inputLen - offSet > MAX_ENCRYPT_BLOCK) {
                cache = cipher.doFinal(data, offSet, MAX_ENCRYPT_BLOCK);
            } else {
                cache = cipher.doFinal(data, offSet, inputLen - offSet);
            }
            out.write(cache, 0, cache.length);
            i++;
            offSet = i * MAX_ENCRYPT_BLOCK;
        }
        byte[] encryptedData = out.toByteArray();
        out.close();
        return encryptedData;
    }

    /**
     * 加签
     *
     * @param request
     * @param privateKey
     * @return
     */
    public static String sign(String request, String privateKey) {
        try {
            return SignatureUtils.sign(request.getBytes(CharsetEnum.UTF_8.code), privateKey);
        } catch (Exception e) {
            LOGGER.error(ExceptionUtil.getErrorMsg(e), e);
            throw new RuntimeException(e);
        }
    }

    /**
     * <p>
     * 用私钥对信息生成数字签名
     * </p>
     *
     * @param data       已加密数据
     * @param privateKey 私钥(BASE64编码)
     * @return
     * @throws Exception
     */
    public static String sign(byte[] data, String privateKey) throws Exception {
        byte[] keyBytes = Base64Utils.decode(privateKey);
        PKCS8EncodedKeySpec pkcs8KeySpec = new PKCS8EncodedKeySpec(keyBytes);
        KeyFactory keyFactory = KeyFactory.getInstance(SignEnum.SIGN_TYPE_RSA.code);
        PrivateKey privateK = keyFactory.generatePrivate(pkcs8KeySpec);
        Signature signature = Signature.getInstance(SignEnum.SIGNATURE_ALGORITHM.code);
        signature.initSign(privateK);
        signature.update(data);
        return Base64Utils.encode(signature.sign());
    }

    // 人保的AES密钥
    public static String piccAesPrivateKey;
    @Value("${picc.aes.private.key}")
    public void setPiccAesPrivateKey(String piccAesPrivateKey) {
        this.piccAesPrivateKey = piccAesPrivateKey;
    }
    public static String checkSignAndDecryptPicc(String request, String publicKey, String privateKey,
                                             boolean isCheckSign, boolean isDecrypt) throws Exception {
        boolean verifyResult = false;
        System.out.println("request:" + request);
        LOGGER.info("request:" + request);
        JSONObject requestJSONObject = JSONObject.parseObject(request);
        String sign = JSONObject.parseObject(requestJSONObject.getString("head")).getString("sign");//获取的签文
        LOGGER.info("sign:" + sign);
        String content = requestJSONObject.getString("body");//获取的业务数据密文
//        JSONObject moveSignObject = JSONObject.parseObject(requestJSONObject.getString("head"));//要排序先去掉sign（签文）
//        moveSignObject.remove("sign");
//        requestJSONObject.put("head", moveSignObject);
        String partnerNo = JSONObject.parseObject(requestJSONObject.getString("head")).getString("partnerNo");//获取的签文
        String requestId = JSONObject.parseObject(requestJSONObject.getString("head")).getString("requestId");//获取的签文
        String version = JSONObject.parseObject(requestJSONObject.getString("head")).getString("version");//获取的签文
        String timestamp = JSONObject.parseObject(requestJSONObject.getString("head")).getString("timestamp");//获取的签文
        String srcData = partnerNo + requestId + timestamp + version + "123456" + content;

//        Signature signature = Signature.getInstance(SignEnum.SIGN_ALGORITHMS.code);
//        byte[] keyBytes = Base64Utils.decode(publicKey);
//        X509EncodedKeySpec keySpec = new X509EncodedKeySpec(keyBytes);
//        KeyFactory keyFactory = KeyFactory.getInstance(SignEnum.SIGN_ALGORITHMS.code);
//        PublicKey key = keyFactory.generatePublic(keySpec);
//        signature.initVerify(key);
//        signature.update(srcData.getBytes("UTF-8"));
//        isCheckSign = signature.verify(Base64.decode(sign).getBytes(StandardCharsets.UTF_8));

//        String signContent = getSignContent(requestJSONObject);//所有key排序后放入LingkedMap后map.toString()
//        LOGGER.info("签名字符串为：" + signContent);
        if (isCheckSign) { //按测试文档没有测通，与调通的其他公司沟通都没做验签，暂时放开
//            verifyResult = verify(srcData, sign, "123456");
            verifyResult = true;
        }
        if (isDecrypt && verifyResult) {
            return decryptByPrivateKeyPicc(content, piccAesPrivateKey);
        }
        return null;
    }

    private static String decryptByPrivateKeyPicc(String content, String privateKey){
        try {
            return AESEncrypt.decryptPicc(content, privateKey);
        } catch (Exception e) {
            LOGGER.error(ExceptionUtil.getErrorMsg(e), e);
            throw new RuntimeException(e);
        }
    }
}
