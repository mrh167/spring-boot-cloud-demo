package com.sinosoft.car.utils.sign.paic;
import com.alibaba.fastjson.JSONObject;
import com.cloud.fast.exceptions.BusinessException;
import org.apache.log4j.lf5.util.StreamUtils;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang.StringUtils;

import javax.crypto.Cipher;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.security.*;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.*;

/**
 * 加解密工具类
 */
public class SignatureUtils {

    //私钥
    public static final String privateKey = "MIIEvwIBADANBgkqhkiG9w0BAQEFAASCBKkwggSlAgEAAoIBAQC503CHzgYT3QA8CveG5jXCgKCqzj5lcoDiZPkK6q+GvxPIXZFgi48YlGnWSLNRmrqhlif8PKn+/2x2QXkeVbesjxkVoLNjLgr66Y7Iy8zqxbWJz5X0jh6bZz0zwdhyD4jdlfUGl5r9mvWtPnZeM8UNkkV6V0oHKYAomfaqYhwoYPV6N4fDxc6jJM8CoSXtz7diTafZHm0dAR+/uOBXe+lktZGqQCxviRI7oYTFcTmaiKlqNk9T8Dr+NVXlHeWJpz/5y8LiRfmrF7noaCQ3oti3nOxWDd2VkiX+sP7Qjf+yB0w91DdlM7GWmiX+VmHpNMNguH4fKg3DbHFyPggNpY8dAgMBAAECggEAE/YioHQBMyEKZWjILjWMkNhAahi9mygxsCAooIOVV2QvO9bRRw220W0f8WTd3mZAphr7MJ1TpZDKlelymU+b621zxF7+5iiMBWgRboB2AsI6PhOOiDa8EvWEHYs1NQt2KFdzesHOZG/A9FtBW90zzcFotTurOBm9Kp9fX+4qGCwjBpSUfwhAwSmFrKlPyhF63PaKqPhh4eUbUyw66+uGsfbNHjpIdnFj2frpO399Iib1CfvifgSsvmvQDGFdNRs3HI3eWkcBVVjPw1tkeeKulfQA3RgJGWpxrJvwIcwk5Qqi3pHmq13Wpao3RBFJVRh1Mgv2+a46n7WegzhvtxeCAQKBgQD0yC49j5/rkMG3/F7KIAWo5YI5ANBUKsJ+vFokwCXCLUAcjd6zTkuJGLq5AGxQpxh70pS3fL+Nk6uJjjNEHYAqRFROTdK5rFrvce494L2TkYAvc75fKqotzlzGnhYY7nqWnC8XUJgE6I0maOsCGMT/0jz+RRYwiexN5zAsxXJp1wKBgQDCV5PxDd2/0gNsU62Kzughvn0xMKF8ED665Nc9Ck1UsJFrCX5SHyL6wl1evI58rE7AwhIDHelN4qnalkiJVSfN3Nli1EFfi8AYkNWKzVOB7P/7GUJ39v7WxMeJu+mxxnnNu6dDFsV+Ac0cJ7oDp6TqvPxVwXO1J3SRL3S7TJd4KwKBgQDM6whK4QGv4u9JZyyzaTtTuU7bCaNd0q4gCu4r9e+mLtuNC/dzhAgYLWujlIcYvcnxXsjBEt4JV6Yy8ahZTZkNyUYKh3vxlChMa8RWaN5Lu3LkRrEIWl89GZTxcUZueLaHfxitG/snoMcJcKvMhY/l2crV0mBRIiWA0hmyYVj24QKBgQCcJF8xyrFCgArOC0EgiHLLQdA2KFtmYWr1IA2q9k8BX0fG1v7OHkQtcuIvzpEwrAQuLP7p0Ct1r0pG3H31ER0E8o8aL21CxfaWBi/78FJKzk8wwK+90Q4ZIksrZ3YwpkWQvVd6uJ3+SpYwK97xNs1y6FpY0DAV+VhXmehQ4A3GtwKBgQDj+MWs7r5For62CkU4GrReR+32nt65nFcBOJLqWAxijcIZdjarn1VfrjN9Al51X/4jH8/GytAI2i7CCeDRrOYv7BGvOzOrBY0xZbNUNpuR5PrLu2r50/TdjMJDqcCTlmGe7r9geUHwHTi1KedJ9gSFcX+uIohYdP0YjkQXSFhFPw==";
    //公钥
    public static final String publicKey = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAudNwh84GE90APAr3huY1woCgqs4+ZXKA4mT5Cuqvhr8TyF2RYIuPGJRp1kizUZq6oZYn/Dyp/v9sdkF5HlW3rI8ZFaCzYy4K+umOyMvM6sW1ic+V9I4em2c9M8HYcg+I3ZX1Bpea/Zr1rT52XjPFDZJFeldKBymAKJn2qmIcKGD1ejeHw8XOoyTPAqEl7c+3Yk2n2R5tHQEfv7jgV3vpZLWRqkAsb4kSO6GExXE5moipajZPU/A6/jVV5R3liac/+cvC4kX5qxe56GgkN6LYt5zsVg3dlZIl/rD+0I3/sgdMPdQ3ZTOxlpol/lZh6TTDYLh+HyoNw2xxcj4IDaWPHQIDAQAB";


    public static void main(String[] args) {

        try {
            //密文
            String businessContent = "EZ0BAX7DTyqQCUPLE590132Tq0CKoK5mHuQup2B53A/3dTADBSnz9KHzl9mstt1uwfimnAsYcp5WMsl+eHH0CSLghkzAD/1d2KtZZwWB+MTzDdTcXlpoRp5NiuPu2MRZFW55GZ1ust0d74MThAOOaqTiy01F1EPmoKyie0MF5Qa6jORHyJ/gvr5ZOnM83OX4/YaleFIN1Z/yRs69fEQA+vo/9w0bux2Iuld4P8jeQLTgkcgcSivPmvbs5K9GEMhw8fYN0wQeLl6PFUK/LXSjEZAL+92kSnBXWa5GUQEfErV/HlMQ+8p3OpC3JE/pDr5naDOJ620h9kjrUYVDDnmLaJwxiubiB08ehvh8V0of+hKtv6CNREhX8cj28XGZUWknZrdUpeqqi21jlUeYTid0fy4Obwx3evOT7cgr6VHaJtz7LqpbCthS5zmbDBIDwYfbm3/GAqg3wwFezYMwQzq9NfmmQB2YEbsSfG58p9w2ER+2XnVTYh8fA5QfymnacvD0LaULl8Bkp4mxTtmAvtJmBcJEqmtQwCY376w2R9DGqDNvHCF6emLm+Yd9NXP0FTeOrHULUatNwjP2osHQ2ZHE2pk5FMZByjrTPBRGgiNwDQGH/U3v5kQg73S/E9hMMalUKwnPpPBO/KQqqVwyr5tYRIkLj8e2HMbkVL4ox8Bh9slPCSvqkfxQ7WXw6Trib5SDiAGMOWcUGYj4eVE5Iq/pU1twXYbYR7QC/Lx9mRLJ4imEDFcBc67ro5SBqfYkiIFhxqXuO+ZDLwQEyZ9cmaDy7KRaa6I56LQXcJRi9XXzYmxTjaR13l10YldzJPxckRaIRvtbf4F2/WUXUNUZnVtENrsBGvMvQuV1XVANrKezoNcaBCp2AqhCNdeKgQUihYzvwuLIQ6fki1N8Nlo1S9XZ4xwGY7JLJAZAO3u/bBVT2JkOYVItF3cWYO8S+oYMoHwhOV/bj34AWIltqUiEVDf7gtqT022kpH8HZP533GLvebG2igbXH+4F3j5DmfBq/9H7fTOntp5Sp6jARP8c0S7hK+XPJU8X70fpX/Fn+s5zg53YvzYUwu6TP9Q58evK4httGXraG3Yi5etQGqmzjFcvFmnGhPaMyorFQS848/uC1MWjQSS63vx64x+PlPMyP6FpaNBOroqjgxfx8MG02vH1UuFZdlNeyTvLuVtlTqsZTOi08fsNS93lxYFERuO+9sutJ+3sXRsH+xyuzZoE4UtrzSoW/21WFq16vyu6qydYma0v9l3VPuhTLAegGd38vfD7pvUFMITpq9qNyJljJl+R/Btnz+veK+CDZMDZD2v4o3wh1bDscoRg/+DyL/+JjtbGtHQ8+MNHQcvcoSzsfnaYdQ==";
            //签名
            String sign = "NodJuttCFpxqfn7k605y1gs30ojZStlHyUfOxIXqwBoBvqNsl2fdCd9tJVgW93nojXNNLhgeZa6G2chddlMQ1NTxYBdQAK2wkst9BtBqOinHnR1a6SiKhltt6D3G2VKAudSB8ju6hWOax9bhlhCj7pI61WsZuU14ycIwJ9FgercIJMYp5Z9kGs0gj8gNSCJyuDwJRtmxuIzhaZ02YvO1WqC5N3Xim5mgytV0OM8/0uHdEiqRWAkaxWBcXnR0amuv4WxlytU7RmvPLkJzWA1J6HrGIU7KYU90JAuS+h0lldpOLT55D4i04GQahRrGXXCivI3w4z2CqUVU7D6KA5mx6w==";
            //解密报文
            String Data = SignatureUtils.rsaDecrypt(businessContent, privateKey, "UTF-8", "RSA2048");
            System.out.println("解密后待业务处理明文:" + Data);
            //验签
            SignatureUtils.checkRSASign(sign, Data, publicKey, "UTF-8");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 解密并验签
     * @param requestJson
     * @return
     */
    public static String checkSignAndDecrypt(JSONObject requestJson) {
        if(!Objects.isNull(requestJson)) {
            String bizContent = requestJson.getString("content");
            String sign = requestJson.getString("sign");
            try {
                String data = SignatureUtils.rsaDecrypt(bizContent, privateKey, "UTF-8", "RSA2048");
                SignatureUtils.checkRSASign(sign, data, publicKey, "UTF-8");
                return data;
            } catch (Exception e) {
                e.printStackTrace();
                throw new BusinessException("解密失败");
            }
        }else {
            throw new BusinessException("requestJson cant be null");
        }
    }

    public static String encryptAndSign(String params, boolean isEncrypt, boolean isSign) throws Exception {
        JSONObject jsonObject = JSONObject.parseObject(params);
        String bizContent = jsonObject.getString("content");
        if(isEncrypt) {
            String encrypted = rsaEncrypt(bizContent);
            jsonObject.put("content", encrypted);
            if(isSign) {
                String sign = rsaSign(bizContent);
                jsonObject.put("sign", sign);
            }
        }else if(isSign) {
            String sign = rsaSign(bizContent);
            jsonObject.put("sign", sign);
        }
        return jsonObject.toJSONString();
    }

    /**
     * 加密加签
     *
     * @param map        要加密的map
     * @param publicKey  公钥
     * @param privateKey 私钥
     * @param charset    字符编码
     * @param isEncrypt  是否要加密
     * @param isSign     是否要加签
     * @return 加密后的密文和签名
     * @throws Exception
     */
    public static Map<String, Object> encryptAndSign2(Map<String, Object> map,
                                                      String publicKey, String privateKey, String charset,
                                                      boolean isEncrypt, boolean isSign) throws Exception {
        Set<String> keySet = map.keySet();
        Map<String, Object> businessParamMap = new HashMap();
        Map<String, Object> newMap = new HashMap();
        List<String> codeList = SystemParameterEnum.getCodeList();
        for (String key : keySet) {
            if (!codeList.contains(key)) {
                businessParamMap.put(key, map.get(key));
            } else {
                newMap.put(key, map.get(key));
            }
        }
        if (StringUtils.isEmpty(charset)) {
            charset = "UTF-8";
        }
        if (isEncrypt) {
            String encrypted = rsaEncrypt(businessParamMap, publicKey, charset);
            newMap.put(SystemParameterEnum.BIZ_CONTENT.getCode(), encrypted);
            if (isSign) {//明文加签
                String sign = rsaSign(businessParamMap, privateKey, charset);
                newMap.put(SystemParameterEnum.SIGN.getCode(), sign);
            }
        } else if (isSign) {
            newMap.put(SystemParameterEnum.BIZ_CONTENT.getCode(),
                    getSignContent(businessParamMap));
            String sign = rsaSign(newMap, privateKey, charset);
            newMap.put(SystemParameterEnum.SIGN.getCode(), sign);
        }
        return newMap;
    }

    /**
     * rsa加密
     *
     * @param map       要加密的map
     * @param publicKey 公钥
     * @param charset   字符编码
     * @return 密文
     * @throws Exception
     */
    public static String rsaEncrypt(Map<String, Object> map, String publicKey,
                                    String charset) throws Exception {
        String businessContent = getSignContent(map);
        return rsaEncrypt(businessContent, publicKey, charset);
    }

    public static String rsaEncrypt(String bizContent) throws Exception {
        return rsaEncrypt(bizContent, publicKey, "UTF-8");
    }

    /**
     * 加签
     *
     * @param sortedParams 排序后的参数
     * @return 签名
     */
    public static String getSignContent(Map<String, Object> sortedParams) {
        JSONObject js = new JSONObject();
        List<String> keys = new ArrayList(sortedParams.keySet());
        Collections.sort(keys);
        for (int i = 0; i < keys.size(); i++) {
            String key = (String) keys.get(i);
            Object value = sortedParams.get(key);
            js.put(key, value);
        }
        return js.toJSONString();
    }

    /**
     * rsa加密
     *
     * @param content   明文
     * @param publicKey 公钥
     * @param charset   字符编码
     * @return 密文
     * @throws Exception
     */
    public static String rsaEncrypt(String content, String publicKey,
                                    String charset) throws Exception {
        PublicKey pubKey = getPublicKeyFromX509("RSA",
                new ByteArrayInputStream(publicKey.getBytes()));
        Cipher cipher = Cipher.getInstance("RSA");
        cipher.init(1, pubKey);
        byte[] data = StringUtils.isEmpty(charset) ? content.getBytes()
                : content.getBytes(charset);
        int inputLen = data.length;
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        int offSet = 0;
        int i = 0;
        while (inputLen - offSet > 0) {
            byte[] cache;
            if (inputLen - offSet > 117) {
                cache = cipher.doFinal(data, offSet, 117);
            } else {
                cache = cipher.doFinal(data, offSet, inputLen - offSet);
            }
            out.write(cache, 0, cache.length);
            i++;
            offSet = i * 117;
        }
        byte[] encryptedData = Base64.encodeBase64(out.toByteArray());
        out.close();
        return StringUtils.isEmpty(charset) ? new String(encryptedData) : new String(encryptedData, charset);
    }

    public static PublicKey getPublicKeyFromX509(String algorithm,
                                                 InputStream ins) throws Exception {
        KeyFactory keyFactory = KeyFactory.getInstance(algorithm);
        byte[] encodedKey = StreamUtils.getBytes(ins);
        encodedKey = Base64.decodeBase64(encodedKey);
        return keyFactory.generatePublic(new X509EncodedKeySpec(encodedKey));
    }

    /**
     * rsa签名
     *
     * @param params     明文map
     * @param privateKey 私钥
     * @param charset    字符编码
     * @return 签名
     * @throws Exception
     */
    public static String rsaSign(Map<String, Object> params, String privateKey,
                                 String charset) throws Exception {
        String content = getSignContent(params);
        return rsaSign(content, privateKey, charset);
    }

    public static String rsaSign(String bizContent) throws Exception {
        return rsaSign(bizContent, privateKey, "UTF-8");
    }

    /**
     * rsa加密
     *
     * @param content    明文String
     * @param privateKey 私钥
     * @param charset    字符编码
     * @return 签名
     * @throws Exception
     */
    public static String rsaSign(String content, String privateKey,
                                 String charset) throws Exception {
        try {
            PrivateKey priKey = getPrivateKeyFromPKCS8("RSA",
                    new ByteArrayInputStream(privateKey.getBytes()));
            Signature signature = Signature.getInstance("SHA1WithRSA");
            signature.initSign(priKey);
            if (StringUtils.isEmpty(charset)) {
                signature.update(content.getBytes());
            } else {
                signature.update(content.getBytes(charset));
            }
            byte[] signed = signature.sign();
            return new String(Base64.encodeBase64(signed));
        } catch (Exception e) {
            throw new Exception("RSAcontent = " + content + "; charset = " + charset, e);
        }
    }

    public static PrivateKey getPrivateKeyFromPKCS8(String algorithm,
                                                    InputStream ins) throws Exception {
        if ((ins == null) || (StringUtils.isEmpty(algorithm))) {
            return null;
        }
        KeyFactory keyFactory = KeyFactory.getInstance(algorithm);
        byte[] encodedKey = StreamUtils.getBytes(ins);
        encodedKey = Base64.decodeBase64(encodedKey);
        return keyFactory.generatePrivate(new PKCS8EncodedKeySpec(encodedKey));
    }

    /**
     * rsa解密
     *
     * @param content    密文
     * @param privateKey 私钥
     * @param charset    字符编码
     * @return 明文字符串
     * @throws Exception
     */
    public static String rsaDecrypt(String content, String privateKey,
                                    String charset) throws Exception {
        return rsaDecrypt(content, privateKey, charset, null);
    }

    /**
     * rsa解密
     *
     * @param content    密文
     * @param privateKey 私钥
     * @param charset    字符编码
     * @param signType   签名类型
     * @return 明文字符串
     * @throws Exception
     */
    public static String rsaDecrypt(String content, String privateKey,
                                    String charset, String signType) throws Exception {
        int maxDecryptBlock = 128;
        if ("RSA2048".equalsIgnoreCase(signType)) {
            maxDecryptBlock = 256;
        }
        try {
            PrivateKey priKey = getPrivateKeyFromPKCS8("RSA",
                    new ByteArrayInputStream(privateKey.getBytes()));
            Cipher cipher = Cipher.getInstance("RSA");
            cipher.init(2, priKey);
            byte[] encryptedData = StringUtils.isEmpty(charset) ? Base64
                    .decodeBase64(content.getBytes()) : Base64
                    .decodeBase64(content.getBytes(charset));
            int inputLen = encryptedData.length;
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            int offSet = 0;
            int i = 0;
            while (inputLen - offSet > 0) {
                byte[] cache;
                if (inputLen - offSet > maxDecryptBlock) {
                    cache = cipher.doFinal(encryptedData, offSet,
                            maxDecryptBlock);
                } else {
                    cache = cipher.doFinal(encryptedData, offSet, inputLen
                            - offSet);
                }
                out.write(cache, 0, cache.length);
                i++;
                offSet = i * maxDecryptBlock;
            }
            byte[] decryptedData = out.toByteArray();
            out.close();

            return StringUtils.isEmpty(charset) ? new String(decryptedData)
                    : new String(decryptedData, charset);
        } catch (Exception e) {
            throw new Exception("RSA解密失败. EncodeContent = " + content + ",charset = " + charset, e);
        }
    }

    /**
     * 检查验签结果，验签失败抛异常
     *
     * @param sign      签名
     * @param content   明文
     * @param publicKey 公钥
     * @param charset   字符编码
     * @throws Exception
     */
    public static void checkRSASign(String sign, String content,
                                    String publicKey, String charset) throws Exception {
        if (!rsaCheckContent(content, sign, publicKey, charset)) {
            throw new Exception("RSA签名校验出错: sign=" + sign + ", content="
                    + content + ", charset=" + charset);
        }
    }

    /**
     * 验签
     *
     * @param content   明文
     * @param sign      签名
     * @param publicKey 公钥
     * @param charset   字符编码
     * @return 验签结果
     * @throws Exception
     */
    public static boolean rsaCheckContent(String content, String sign,
                                          String publicKey, String charset) throws Exception {
        try {
            PublicKey pubKey = getPublicKeyFromX509("RSA",
                    new ByteArrayInputStream(publicKey.getBytes()));
            Signature signature = Signature.getInstance("SHA1WithRSA");
            signature.initVerify(pubKey);
            if (StringUtils.isEmpty(charset)) {
                signature.update(content.getBytes());
            } else {
                signature.update(content.getBytes(charset));
            }
            boolean verify = signature.verify(Base64.decodeBase64(sign.getBytes()));
            System.out.println("验签结果：" + verify);
            return verify;
        } catch (Exception e) {
            throw new Exception("RSAcontent=" + content + ",sign=" + sign + ",charset=" + charset, e);
        }
    }

    public enum SystemParameterEnum {
        APP_KEY("clientId", "Y", "", "应用接入唯一key"),
        BIZ_CONTENT("businessContent", "Y", "", "业务级参数，需加密"),
        TIME_STAMP("timestamp", "Y", "", "时间戳"),
        FUNCTION("function", "Y", "", "服务名"),
        FORMAT("format", "N", "json", "响应格式"),
        SIGN_TYPE("signType", "Y", "RSA", "签名类型"),
        CHARSET("charset", "N", "UTF-8", "字符集"),
        SIGN("sign", "Y", "", "签名"),
        VERSION("version", "N", "", "版本");

        private String code;
        private String isMandotary;
        private String defaultValue;
        private String description;

        private SystemParameterEnum(String code, String isMandotary, String defaultValue, String description) {
            this.code = code;
            this.isMandotary = isMandotary;
            this.defaultValue = defaultValue;
            this.description = description;
        }

        public static boolean containCode(String code) {
            for (SystemParameterEnum an : values()) {
                if ((code != null) && (code.equals(an.getCode()))) {
                    return true;
                }
            }
            return false;
        }

        public static SystemParameterEnum getSystemParameterEnum(String code) {
            for (SystemParameterEnum an : values()) {
                if ((code != null) && (code.equals(an.getCode()))) {
                    return an;
                }
            }
            return null;
        }

        public static List<Map<String, String>> getListForMap() {
            List<Map<String, String>> mapList = new ArrayList();
            for (SystemParameterEnum an : values()) {
                Map<String, String> map = new HashMap();
                map.put("code", an.getCode());
                map.put("isMandotary", an.getIsMandotary());
                map.put("defaultValue", an.getDefaultValue());
                map.put("description", an.getDescription());
                mapList.add(map);
            }
            return mapList;
        }

        public static List<String> getCodeList() {
            List<String> codeList = new ArrayList();
            for (SystemParameterEnum spe : values()) {
                codeList.add(spe.getCode());
            }
            return codeList;
        }

        public String getCode() {
            return this.code;
        }

        public String getIsMandotary() {
            return this.isMandotary;
        }

        public String getDefaultValue() {
            return this.defaultValue;
        }

        public String getDescription() {
            return this.description;
        }
    }
}