package com.sinosoft.car.utils.cic;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Properties;
import java.util.Vector;

import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;
import com.sinosoft.car.utils.contants.CICConstants;

@Service
public class SFTPClient {

	private static final Logger LOGGER = LoggerFactory.getLogger(SFTPClient.class);

	private String host = "61.138.246.86";// 服务器ip地址
	private String username = "lnchedai"; // 账号
	private String password = "KoCZpX3E";// 密码
	private int port = 20;// 端口号


	private Session session;
	private ChannelSftp sftp;

	/**
	 * 将文件转为Base64上传到sftp作为文件
	 * 
	 * @param directory
	 * @param sftpFileName
	 * @param base64
	 * @throws SftpException
	 */
	public void upload(String directory, String sftpFileName, String base64) throws SftpException {
		login();
		try {
			sftp.cd(directory);
		} catch (SftpException e) {
			LOGGER.info(e.getMessage());
			sftp.mkdir(directory);
			sftp.cd(directory);
			logout();
		} catch (Exception e) {
			LOGGER.info(e.getMessage());
		}
		sftp.put(base64, sftpFileName);
		logout();
	}

	/**
	 * 将输入流的数据上传到sftp作为文件
	 * 
	 * @param directory    上传到该目录
	 * @param sftpFileName sftp端文件名
	 * @param in           输入流
	 * @throws SftpException
	 * @throws Exception
	 */
	public String upload(String directory, String sftpFileName, InputStream input) throws SftpException {
		login();
		try {
			sftp.cd(CICConstants.LNCHEDAI_QYC);
			sftp.cd(directory);
		} catch (SftpException e) {
			sftp.cd(CICConstants.LNCHEDAI_QYC);
			sftp.mkdir(directory);
			sftp.cd(directory);
		}
		sftp.put(input, sftpFileName);
		logout();
		return CICConstants.LNCHEDAI_QYC+"/"+directory+"/"+sftpFileName;
	}

	/**
	 * 连接sftp服务器
	 * 
	 * @throws Exception
	 */
	public void login() {
		try {
			JSch jsch = new JSch();

//			if (privateKey != null) {
//				jsch.addIdentity(getKey());// 设置私钥
//				LOGGER.info("sftp connect,path of private key file：{}", privateKey);
//			}
			session = jsch.getSession(username, host, port);
			LOGGER.info("Session is build");
			if (password != null) {
				session.setPassword(password);
			}
			Properties config = new Properties();
			config.put("StrictHostKeyChecking", "no");

			session.setConfig(config);
			session.connect(1500);
			LOGGER.info("Session is connected");

			Channel channel = session.openChannel("sftp");
			channel.connect();
			LOGGER.info("channel is connected");

			sftp = (ChannelSftp) channel;
			LOGGER.info(String.format("sftp server host:[%s] port:[%s] is connect successfull", host, port));
		} catch (JSchException e) {
			LOGGER.error("Cannot connect to specified sftp server : {}:{} \n Exception message is: {}",
					new Object[] { host, port, e.getMessage() });
		}
	}

	/**
	 * 关闭连接 server
	 */
	public void logout() {
		if (sftp != null) {
			if (sftp.isConnected()) {
				sftp.disconnect();
				LOGGER.info("sftp is closed already");
			}
		}
		if (session != null) {
			if (session.isConnected()) {
				session.disconnect();
				LOGGER.info("sshSession is closed already");
			}
		}
	}

	public String getKey() {
		String key = "";
		try {
			KeyGenerator kg = KeyGenerator.getInstance("AES");
			kg.init(128);
			SecretKey sk = kg.generateKey();
			byte[] b = sk.getEncoded();
			key = byteToHexString(b);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return key;
	}

	/**
	 * byte数组转化为16进制字符串
	 * 
	 * @param bytes
	 * @return
	 */
	public static String byteToHexString(byte[] bytes) {
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < bytes.length; i++) {
			String strHex = Integer.toHexString(bytes[i]);
			if (strHex.length() > 3) {
				sb.append(strHex.substring(6));
			} else {
				if (strHex.length() < 2) {
					sb.append("0" + strHex);
				} else {
					sb.append(strHex);
				}
			}
		}
		return sb.toString();
	}

	/**
	 * MultipartFile 转 File
	 *
	 * @param file
	 * @throws Exception
	 */
	public static File multipartFileToFile(MultipartFile file) throws Exception {

		File toFile = null;
		if (file.equals("") || file.getSize() <= 0) {
			file = null;
		} else {
			InputStream ins = null;
			ins = file.getInputStream();
			toFile = new File(file.getOriginalFilename());
			inputStreamToFile(ins, toFile);
			ins.close();
		}
		return toFile;
	}

	// 获取流文件
	private static void inputStreamToFile(InputStream ins, File file) {
		try {
			OutputStream os = new FileOutputStream(file);
			int bytesRead = 0;
			byte[] buffer = new byte[8192];
			while ((bytesRead = ins.read(buffer, 0, 8192)) != -1) {
				os.write(buffer, 0, bytesRead);
			}
			os.close();
			ins.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
