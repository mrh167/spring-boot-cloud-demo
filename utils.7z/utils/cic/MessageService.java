package com.sinosoft.car.utils.cic;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.cloud.fast.exceptions.BusinessException;
import com.cloud.fast.utils.HttpClientUtils;
import com.sinosoft.car.utils.contants.CICConstants;

/**
 * 中华联合，报文服务工具类
 *
 * @author
 * @version 1.0
 * @date 2021/6/30
 * @since JDK1.8
 */

@Service
public class MessageService {
	private static final Logger logger = LoggerFactory.getLogger(MessageService.class);
	@Autowired
	private CicCipher cipher;

	/**
	 * 发送请求数据给保司接口
	 * 
	 * @param serviceCode 调用服务编码
	 * @param chSubCode   子渠道编码
	 * @param jsonMsg     发送消息内容
	 * @return
	 */
	public String sendPost(String serviceCode, String chSubCode, JSONObject jsonMsg) {
		String requestUrl = cipher.getCicUrl();
		// 加密业务数据 公钥 私钥
		Map<String, String> encry = null;
		logger.debug("发送明文json：{}", JSON.toJSONString(jsonMsg));
		try {
			encry = RSAUtils.encryptAndSign(JSON.toJSONString(jsonMsg), cipher.getPublicKey(),
					cipher.getThirdPrivateKey(), SignConstants.CHARSET_UTF_8, true, true);
		} catch (Exception e) {
			logger.error("发送数据至中华联合加密加签异常！");
			throw new BusinessException("发送数据至中华联合加密加签异常！");
		}
		String content = encry.get("CONTENT");
		String sign = encry.get("GW_CH_SIGN");

		logger.debug("发送密文：{}", content);
		logger.debug("发送使用的签名：{}", sign);

		// 请求头信息
		Map<String, String> headers = new HashMap<>();
		headers.put(CICConstants.HEADER_TRADE_CODE, serviceCode);
		headers.put(CICConstants.HEADER_CH_CODE, cipher.getCicCode());
		headers.put(CICConstants.HEADER_TRADE_USR, cipher.getCicUser());
		headers.put(CICConstants.HEADER_TRADE_PWD, cipher.getCicPwd());
		headers.put(CICConstants.HEADER_TRADE_SIGN, sign);
		headers.put(CICConstants.HEADER_SUB_CODE, chSubCode);
		headers.put(CICConstants.HEADER_CONTENT_TYPE, "application/json; charset=UTF-8");

		HashMap<String, String> datas = HttpClientUtils.sendPost4Hash(requestUrl, headers, content);
		String decry = null;
		try {
			decry = RSAUtils.checkSignAndDecrypt(datas.get("data"), datas.get(CICConstants.HEADER_TRADE_SIGN), cipher.getPublicKey(),
					cipher.getThirdPrivateKey(), SignConstants.CHARSET_UTF_8, true, true);
		} catch (Exception e) {
			logger.error("发送数据至中华联合返回结果验签解密异常！");
			throw new BusinessException(e.getMessage());
		}

		logger.debug("返回明文：{}", decry);
		return decry;
	}

}
