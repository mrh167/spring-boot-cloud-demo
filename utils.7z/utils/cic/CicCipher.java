package com.sinosoft.car.utils.cic;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import lombok.Data;

@Data
@Configuration
public class CicCipher {
	@Value("${cicUrl}")
	private String cicUrl;
	/** 全优车渠道代码 */
	@Value("${cicCode}")
	private String cicCode;
	/** 全优车用户名 */
	@Value("${cicUser}")
	private String cicUser;
	/** 全优车口令 */
	@Value("${cicPwd}")
	private String cicPwd;
	/** 保险公司的公钥 */
	@Value("${rsa.insurer.cicPublicKey}")
	private String publicKey;
	/** 合作伙伴的公钥 */
	@Value("${rsa.self.selfPublicKey}")
	public String thirdPublicKey;
//	/** 合作伙伴的私钥 */
//	@Value("${rsa.self.selfPrivateKey}")
//	private String thirdPrivateKey;

	/** 合作伙伴的私钥 */
	@Value("${rsa.self.cicSelfPrivateKey}")
	private String thirdPrivateKey;
}
