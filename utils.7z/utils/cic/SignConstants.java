package com.sinosoft.car.utils.cic;

public interface SignConstants {

	String SIGN_ALGORITHMS = "SHA1WithRSA";

	String CONTENT = "CONTENT";

	String GW_CH_SIGN = "GW_CH_SIGN";

	String SIGN_TYPE_RSA = "RSA";

	String CHARSET_UTF_8 = "UTF-8";

	String CHARSET_GBK = "GBK";

	int MAX_ENCRYPT_BLOCK = 117;

	int MAX_DECRYPT_BLOCK = 128;
}
