package com.sinosoft.car.utils.cic;

import java.util.Map;

public class RSATest {

	// 测试中华私钥
	static String privateKey = "MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBAIbDhcA8eL4r78XXJvik/cxNI66sBaxX6jZvN5Utoj4vgBh5daExJn8vnIRfU6+lkqQFEPop4jMMWqU/7BneqC3ifwyhp4Dj/9mPhNJdvJdU+0UC2l5OJ13uhYElZzJ2+G1xZeuEFGH3ASthnr6ELCHXQkFaZJtNwObSpjw/Kq6xAgMBAAECgYB2odAwNgukfVEJvCjWYYf6PT3YGh60ZIANg0JO1GkqjO4anXFrgLT+6Y7DCJfG296G/N7BGfXCMnHpXqgc7eDlmSy2JVfKzvptgKJBLktP7Yfajg3oY9S8parSK+iyHT6qYqQv6wBmQ3Q9smOp/TM2ndBMDXu9MjoTkNJhrfMDsQJBANbWHciQhazb3Y2DY42hW/zBf7rmmJFrw7aOrEjzw5E+SnGs/vcr3LUWBbSRTYHcoJ+V/kudfwRMlz0SLkfMAvMCQQCglcjNRx35Zw6vNKHE4vTN/ny2gukjvtkzXpPeTUfblrXjK3w3x9aWBZ/MUiphVe5NB8CAtlfYZMo4UG+WMEjLAkA4yHsyydArMinK/5FOm/meQt6p3c0xkpQ2KlurJJLqTtaKWTlCx1scmeeEJGuiCViDFbgS8FvkHQJUZ/vHikq1AkAHbUX/MHXTbg/AzKdaqsB1snpkGoPb0lzLQmmGU36qSjsZSY6SKdzjzVjJo1cwbz/5Mg2WJljDuk2b8yRmBs+nAkEAzoEZmM031u/0KBpukSbqef8JgJOZ0Do9KDbf2P6YuBal6drUeNYVhImKBxQAbjETp9m5TxxW/dkKmHCnc3zqsA==";
	// 测试中华公钥
	static String publicKey = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCGw4XAPHi+K+/F1yb4pP3MTSOurAWsV+o2bzeVLaI+L4AYeXWhMSZ/L5yEX1OvpZKkBRD6KeIzDFqlP+wZ3qgt4n8MoaeA4//Zj4TSXbyXVPtFAtpeTidd7oWBJWcydvhtcWXrhBRh9wErYZ6+hCwh10JBWmSbTcDm0qY8PyqusQIDAQAB";
	// 测试合作方私钥
	static String ex_privateKey = "MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBAIgLfCAl37ta57rdCN2Hf+6xxBIp5zab2Bp4KrTTuSMSJIURLlN/HvlU9LFGPqqTpc3i6Yc6wdj5b2OS/4KPj7Pdek+jOxF2iPbWjE/Hx88nOlV5pQesSRm2P1i+j8qEHIErmxGMqaUQ1dUXfBdV8CDjwllHZdTJRwF1mFH1oeGhAgMBAAECgYAkBJ5lSIG2cbfeUjzRodkuEeRuRqfPXm1VfLEZ1OA0N85xaH4SXxqNOn/aG1XmBVclbkkTo2vFDSz/eOCq6WVK/4oMJTliS8fJr5r0Ty5Xw0WZFc6CDR0g/0Zp+m4k1yGtLkVlma98RgHI1E4tQeD0At+doy3EWZoQVZu9fmIi3QJBAMSDTbKXEHEMatHnfsyKc9KIP5avByTqHdcb4oUfrP/zx1bWQjpWyUPLgj5c6iuednyMbot6EU38pmgh77FWoE8CQQCxOjt6M2/DlAsibE8c7bqtmV3wqKmlnU3Pem8dehmSo9wbG7bE9mUJhFQWDndkkMGVpcaTFxL4xM05scSaBXMPAkEAi17UbCTXdFXqLJSSSV6oZlhbQPNBjdy87SLJtMCSYbTzW5L5xYZnl71t0ezz55urTQoMHL+mJjlZi+EFrjBR4QJAfvuXVBZ4tOxlEfQCt1qKUAo8acufSf+smcVCyh8LJatscKvpx7Q3bps22FrjJtYlLkEKR6fXuxDfbsA1epn+9wJAX7/1TLtV/eyDC8P6iu2CH36dqCxlh4LCXu4ukv96Rs+7yu8UadnNjkjXg7Nh0gqqW37hzKVAT7kO/sZr+IjIgQ==";
	// 测试合作方公钥
	static String ex_publicKey = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCIC3wgJd+7Wue63Qjdh3/uscQSKec2m9gaeCq007kjEiSFES5Tfx75VPSxRj6qk6XN4umHOsHY+W9jkv+Cj4+z3XpPozsRdoj21oxPx8fPJzpVeaUHrEkZtj9Yvo/KhByBK5sRjKmlENXVF3wXVfAg48JZR2XUyUcBdZhR9aHhoQIDAQAB";

	// 测试方法主入口
	public static void main(String[] args) throws Exception {
		String paramJsonStr = "{\n" + "    \"head\": {\n" + "          \"GW_CH_TX\": \"B104\",\n"
				+ "          \"GW_CH_CODE\": \"test\",\n" + "          \"GW_CH_SUBCODE\": \"test01\",\n"
				+ "          \"GW_CH_TRANSTIME\": \"2017-04-01 12:09:23\",\n" + "          \"GW_CH_USER\": \"cic\"\n"
				+ "          \"GW_CH_PWD\": \"cic\",\n" + "          \"TRANSRNO\": \"0000000001\"\n"
				+ "          \"SESSIONID\": \"S1234567\",\n" + "        },\n" + "    \"body\": {}\n" + "}\n";

		// 加密业务数据 公钥 私钥
		Map<String, String> encry = RSAUtils.encryptAndSign(paramJsonStr, ex_publicKey, privateKey, "UTF-8", true,
				true);

		String content = encry.get("CONTENT");
		String sign = encry.get("GW_CH_SIGN");

		System.out.println("加签串" + sign);
		System.out.println("请求报文：" + content);

		// 需要解密的json串 公钥 私钥
		String decry = RSAUtils.checkSignAndDecrypt(content, sign, publicKey, ex_privateKey, "UTF-8", true, true);
		System.out.println("验签解密串" + decry);
	}
}
