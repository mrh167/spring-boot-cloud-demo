package com.sinosoft.car.utils.contants;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

/**
 * 中华联合常量池
 */
@Component
@Configuration
public class CICConstants {
	@Value("${cicUrl}")
	public String cicUrl;
	public static String INTERFACE_URL;

	/** 保险公司编码 */
	public static final String INSURER_CODE = "000012";
	/** 保险公司名称 */
	public static final String INSURER_NAME = "中华联合保险";

	/** 交互请求头参数-交易码 */
	public static final String HEADER_TRADE_CODE = "GW_CH_TX";
	/** 交互请求头参数-合作伙伴代码 */
	public static final String HEADER_CH_CODE = "GW_CH_CODE";
	/** 交互请求头参数-合作伙伴子机构代码 */
	public static final String HEADER_SUB_CODE = "GW_CH_SUBCODE";
	/** 交互请求头参数-用户名 */
	public static final String HEADER_TRADE_USR = "GW_CH_USER";
	/** 交互请求头参数-密码 */
	public static final String HEADER_TRADE_PWD = "GW_CH_PWD";
	/** 交互请求头参数-加签串 */
	public static final String HEADER_TRADE_SIGN = "GW_CH_SIGN";
	/** 交互请求头参数-交易码 */
	public static final String HEADER_CONTENT_TYPE = "Content-Type";

	/** 车型查询代码 */
	public static final String SERVICE_CODE_VEHICLE_MODEL_QUERY = "B104";
	/** 车辆查询 */
	public static final String SERVICE_CODE_VEHICLE_QUERY = "B102";
	/** 北京新车备案 */
	public static final String SERVICE_CODE_BJCARRECORD = "B101";
	/** 报价 */
	public static final String SERVICE_CODE_ENQUIRY = "B201";
	/** 交管车辆查询 */
	public static final String SERVIVE_CODE_TRAFFIC_QUERY = "B601";
	/** 交管车辆确认 */
	public static final String SERVIVE_CODE_TRAFFIC_CONF = "B602";
	/** 实际价值计算 */
	public static final String SERVICE_CODE_CARACTUALPRICE = "H001";
	/** 确认投保 */
	public static final String SERVICE_CODE_ENSURE = "V7203";
	/** 身份证采集上传 */
	public static final String SERVICE_CODE_IDCOLLECT = "V7625";
	/** 生成短信验证码 */
	public static final String SERVICE_CODE_SEND_SMS = "V7844";
	/** 北京预确认 */
	public static final String SERVICE_CODE_BJPREVALID = "V7628";
	/** 在线支付申请 */
	public static final String SERVICE_CODE_PAYAPPLY = "P001";
	/** 支付结果查询 */
	public static final String SERVICE_CODE_PAYMENTSTATUS = "P002";
	/** 文件上传 */
	public static final String SERVICE_CODE_UPLOAD = "ECM0029";
	public static final String OSS_VIDEO_UPLOAD_DIR = "客户影像资料/videoUpload/000012/";//影像上传OSS的地址
	/** 意健险方案查询 */
	public static final String OPINION_PLAN_INQUIRY = "C001";

	/** 商业险 */
	public static final String PRO_NO_BI = "newcar_0059";
	/** 交强险 */
	public static final String PRO_NO_CI = "newcar_0060";
	/** 访问保司成功 */
	public static final String SUCCESS_CODE = "0000";

	/** : 系统拟合计算 */
	public static final String CALCULATION_SYS = "A01";
	/** 人工修改系数模式 */
	public static final String CALCULATION_USER = "A04";

	/** 通过中华收银台网页版支付 */
	public static final String PAY_BY_PC = "pc";
	/** 移动端网页支付 */
	public static final String PAY_BY_WAP = "wap";

	/** 支付成功状态 */
	public static final String PAY_SUCCESS = "true";
	/** 支付失败状态 */
	public static final String PAY_FAIL = "false";
	/** 测试用的身份证采集器设备编号 */
	public static final String DEBUT_ID_DEVICE = "5-3-20150914-4161071";
	
	/** 影像上传的根路径 */
	public static final String LNCHEDAI_QYC = "/lnchedai/qyc";

	@PostConstruct
	public void init() {
		INTERFACE_URL = this.cicUrl;
	}

	/**
	 * 保司接口地址 使用
	 */
	public static class InterfaceUrl {
		/** 配置文件中的地址 */
		//public static String CIC_URL = "http://61.138.246.87:6001/CommNewCarServiceUat";
		public static String CIC_URL;
	}

	/**
	 * 转码工具，平台类型转为保司类型
	 */
	public static class Transcode {
		/**
		 * 中华 -> 车商平台 将保司订单状态映射为车商系统的订单状态 中华状态：0 下发修改;1 自核通过;2 转人工;
		 * 车商订单状态：1-核保中；2-已发送；3-验证失败；4-待支付；5-支付失败；6-已承保；7-核保失败；0-关闭
		 */
		public static Map<String, String> ORDER_STATUS_TO_STANDARD = new HashMap<String, String>() {
			private static final long serialVersionUID = 7749702451441593276L;

			{
				put("0", "7");//下发修改=》核保失败【在系统原型先落地订单数据改造之前不会走到这种情况】
				put("1", "4");//
				put("2", "1");//
			}
		};

		/**
		 * 车商平台 -> 中华 将车商平台的车主证件类型映射为保司车主证件类型（中华只支持身份证） 中华证件类型：01：居民身份证 02：组织机构代码证
		 * 03：税务登记证 04：营业执照 05:其他证件
		 * 证件类型：111-居民身份证;113-户口簿;114-中国人民解放军军官证;335-机动车驾驶证;414-普通护照
		 */
		public static Map<String, String> CAR_OWNER_IDENTIFY_TYPE = new HashMap<String, String>() {
			{
				put("111", "01");
				put("113", "05");
				put("114", "05");
				put("335", "05");
				put("414", "05");
			}
		};

		/**
		 * 车商平台 -> 中华 将车商平台的车主证件类型映射为保司车主证件类型（中华只支持身份证） 中华证件类型：464001：居民身份证
		 * 464004：组织机构代码证 464020：税务登记证 464021：营业执照 464003:其他证件
		 * 证件类型：111-居民身份证;113-户口簿;114-中国人民解放军军官证;335-机动车驾驶证;414-普通护照
		 */
		public static Map<String, String> RECORD_CAR_OWNER_IDENTIFY_TYPE = new HashMap<String, String>() {
			{
				put("111", "464001");
				put("113", "464003");
				put("114", "464003");
				put("335", "464003");
				put("414", "464003");
			}
		};

		/**
		 * 车商平台 -> 中华 将车商平台的交管能源种类映射为保司燃料种类
		 */
		public static Map<String, String> POWER_TYPE = new HashMap<String, String>() {
			{
				put("A", "0"); // 汽油 - 汽油
				put("B", "1"); // 柴油 - 柴油
				put("C", "3"); // 电 - 电力
				put("D", "14"); // 混合油 - 混合油
				put("E", "4"); // 天然气 - 天燃气
				put("F", "5"); // 液化石油气 - 液化石油气
				put("L", "6"); // 甲醇 - 甲醇
				put("M", "7"); // 乙醇 - 乙醇
				put("N", "8"); // 太阳能 - 太阳能
				put("O", "9"); // 混合动力 - 混合动力
				put("P", "11"); // 氢-其他
				put("Q", "12"); // 生物燃料-燃料电池
				put("Y", "10"); // 无 - 无
				put("Z", "11"); // 其他 - 其他
			}
		};

		/**
		 * 中华 -> 车商平台 将保司燃料种类映射为车商平台的交管能源种类
		 */
		public static Map<String, String> POWER_TYPE_REVERSE = new HashMap<String, String>() {
			{
				put("0", "A"); // 汽油 - 汽油
				put("1", "B"); // 柴油 - 柴油
				put("3", "C"); // 电力 - 电
				put("14", "D"); // 混合油 - 混合油
				put("4", "E"); // 天燃气 - 天然气
				put("5", "F"); // 液化石油气 - 液化石油气
				put("6", "L"); // 甲醇 - 甲醇
				put("7", "M"); // 乙醇 - 乙醇
				put("8", "N"); // 太阳能 - 太阳能
				put("9", "O"); // 混合动力 - 混合动力
				put("", "P"); // TODO 待确认 ？ - 氢，其他转码为氢？还是说有其他转换或不用转？
				put("12", "Q"); // 燃料电池 - 生物燃料
				put("10", "Y"); // 无 - 无
				put("11", "Z"); // 其他 - 其他
			}
		};

		/**
		 * 车商平台 -> 中华 将车商平台的车辆来历凭证种类映射为保司车辆来历凭证种类 车商平台车辆来历凭证种类：01:销售发票; 02:法院调解书;
		 * 03:法院裁定书; 04:法院判决书; 05:仲裁裁决书; 06:相关文书; 07:批准文件; 08:调拨证明; 09:修理发票
		 * 中华车辆来历凭证种类：同上
		 */
//		public static Map<String, String> CERTIFY_CATE_TYPE = new HashMap<String, String>() {
//			{
//				put("01", "01"); // 销售发票 -
//				put("02", "02"); // 法院调解书 -
//				put("03", "03"); // 法院裁定书 -
//				put("04", "04"); // 法院判决书 -
//				put("05", "05"); // 仲裁裁决书 -
//				put("06", "06"); // 相关文书 -
//				put("07", "07"); // 批准文件 -
//				put("08", "08"); // 调拨证明 -
//				put("09", "09"); // 修理发票 -
//			}
//		};

		/**
		 * 车商平台 -> 中华 将车商平台的投保人类型转换为中华的投保人类型 车商投保人类型：0：非自然人 1：自然人 中华投保人类型：1-个人 2-组织 3-机关
		 */
		public static Map<String, String> CUSTOMER_TYPE = new HashMap<String, String>() {
			{
				put("0", "2"); // 非自然人 - 组织
				put("1", "1"); // 自然人 - 个人
			}
		};

		/**
		 * 车商平台 -> 中华 将车商平台经办人证件类型转换为中华的经办人证件类型 中华经办人证件类型：01：居民身份证 02：组织机构代码证 03：税务登记证
		 * 04：营业执照 车商平台经办人证件类型：111-居民身份证;113-户口簿;114-中国人民解放军军官证;335-机动车驾驶证;414-普通护照 TODO
		 * 除居民身份证外的转换待保司确认，暂时先转换为01
		 */
		public static Map<String, String> CUSTOMER_TRANSACTOR_CERTIFY_TYPE = new HashMap<String, String>() {
			{
				put("111", "01"); // 居民身份证 - 居民身份证
				put("113", "01"); // 户口簿 - ？
				put("114", "01"); // 中国人民解放军军官证 - ？
				put("335", "01"); // 机动车驾驶证 - ？
				put("414", "01"); // 普通护照 - ？
			}
		};

		/**
		 * 车商平台 -> 中华 将车商平台车辆使用性质转换为中华的车辆使用性质 中华车辆使用性质：309001:家庭自用车 309002:机关、事业单位用车
		 * 309004:企业非营业车 309005：特种车 309012：城市公交营业客车 309014：非营业货车 309015：营业货车
		 * 309016：出租、租赁营业车 309017：营业公路客车 309041：特种车挂车 车商平台车辆使用性质：8A-家庭自用
		 */
		public static Map<String, String> CAR_USER_NATURE_CODE = new HashMap<String, String>() {
			{
				put("8A", "309001"); // - 家庭自用车
//				put("", "309002"); //  - 机关、事业单位用车
//				put("", "309004"); //  - 企业非营业车
//				put("", "309005"); //  - 特种车
//				put("", "309012"); //  - 城市公交营业客车
//				put("", "309014"); //  - 非营业货车
//				put("", "309015"); //  - 营业货车
//				put("", "309016"); //  - 出租、租赁营业车
//				put("", "309017"); //  - 营业公路客车
//				put("", "309041"); //  - 特种车挂车
			}
		};

		/**
		 * 车商平台 -> 中华 将车商平台性别转换为中华的车主性别代码 车商：1.男、0.女 中华：男传M，女传F
		 */
		public static Map<String, String> SEX_CODE = new HashMap<String, String>() {
			{
				put("0", "F"); // 女 - 女
				put("1", "M"); // 男 - 男
			}
		};

		/**
		 * 车商平台 -> 中华 将车商平台车牌颜色转换为中华的车牌颜色 车商：1:蓝; 2:黑; 3:白; 4:黄; 5:白蓝; 6:渐变绿; 7:黄绿双拼;
		 * 99:其他 中华：6-渐变绿; 7-黄绿双拼 TODO: 其余颜色没有对应，对应颜色代码无变化，是否转码？其余如何转码？
		 */
		public static Map<String, String> PLATE_COLOR = new HashMap<String, String>() {
			{
				put("1", ""); // 蓝 - ？
				put("2", ""); // 黑 - ？
				put("3", ""); // 白 - ？
				put("4", ""); // 黄 - ？
				put("5", ""); // 白蓝 - ？
				put("6", "6"); // 渐变绿 - 渐变绿
				put("7", "7"); // 黄绿双拼 - 黄绿双拼
				put("99", ""); // 其他 - ？
			}
		};

		/**
		 * 车商平台 -> 中华 将车商平台号牌种类转换为中华的号牌种类 车商：TODO 缺少车商的号牌种类，待补充 中华：02-小型汽车号牌; 52-小型新能源汽车
		 */
		public static Map<String, String> PLATE_TYPE = new HashMap<String, String>() {
			{
				put("", "02"); // ？ - 小型汽车号牌
				put("", "52"); // ？ - 小型新能源汽车
			}
		};

		/**
		 * 中华 -> 车商平台 将中华的号牌种类代码转换为车商平台的号牌种类代码 TODO 缺少车商的号牌种类代码，待补充
		 */
		public static Map<String, String> VEHICLE_TYPE = new HashMap<String, String>() {
			{
				put("02", ""); // 小型汽车号牌 - ?
				put("52", ""); // 小型新能源汽车 - ?
			}
		};

		/**
		 * 中华 -> 车商 将中华的车型种类转换为车商的车型种类 车商： 中华：国产/进口/合资 TODO 车商缺少字段，待转码
		 */
		public static Map<String, String> PRODUCING_AREA = new HashMap<String, String>() {
			{
				put("国产", ""); // 国产 - ？
				put("进口", ""); // 进口 - ？
				put("合资", ""); // 合资 - ？
			}
		};

		/**
		 * 中华 -> 车商 争议处理转换 车商：暂无 中华：007001-诉讼;007002-仲裁
		 */
		public static Map<String, String> DISP_STTL_CODE = new HashMap<String, String>() {
			{
				put("007001", ""); // 诉讼 - ？
				put("007002", ""); // 仲裁 - ？
			}
		};

		/**
		 * 车商 -> 中华 争议处理转换 车商：暂无 中华：007001-诉讼;007002-仲裁
		 */
		public static Map<String, String> DISP_STTL_CODE_REVERSE = new HashMap<String, String>() {
			{
				put("", "007001"); // ？ - 诉讼
				put("", "007002"); // ？ - 仲裁
			}
		};

		/**
		 * 中华 -> 车商 车主性质 车商：暂无 中华：1-个人;2-机关;3-企业
		 */
		public static Map<String, String> OWNER_TYPE = new HashMap<String, String>() {
			{
				put("1", ""); // 个人 - ？
				put("2", ""); // 机关 - ？
				put("3", ""); // 企业 - ？
			}
		};

		/**
		 * 车商 -> 中华 车主性质转码 车商：暂无 中华：1-个人;2-机关;3-企业
		 */
		public static Map<String, String> OWNER_TYPE_REVERSE = new HashMap<String, String>() {
			{
				put("", "1"); // ？ - 个人
				put("", "2"); // ？ - 机关
				put("", "3"); // ？ - 企业
			}
		};

		/**
		 * 车商 -> 中华 民族代码转码 TODO 除了未知，其余代码都一样，推荐使用判断，除了特定其余不转码
		 */
		public static Map<String, String> NATION_CODE = new HashMap<String, String>() {
			{
				put("00", "0");
			}
		};

		/**
		 * 中华 -> 车商 民族代码转码 TODO 除了未知，其余代码都一样，推荐使用判断，除了特定其余不转码
		 */
		public static Map<String, String> NATION_CODE_REVERSE = new HashMap<String, String>() {
			{
				put("0", "00");
			}
		};

		/**
		 * 中华 -> 车商 险别代码转码
		 */
		public static Map<String, String> COVERAGE_CODE = new HashMap<String, String>() {
			{
				// 主险
				put("037001", "0301200"); // 机动车损失保险
				put("037002", "0301600"); // 机动车第三者责任保险
				put("037003", "0301701"); // 机动车车上人员责任保险（司机）
				put("037004", "0301702"); // 机动车车上人员责任保险（乘客）
				// 附加险
				put("037009", "0301210"); // 附加车身划痕损失险
				put("037010", "0301230"); // 附加修理期间费用补偿险
				put("037008", "0301260"); // 附加新增加设备损失险
				put("037007", "0301232"); // 附加车轮单独损失险
				put("0", "0301601"); // 附加车上货物责任险 TODO 中华对应没找到 - 暂用0替代
				put("037011", "0301202"); // 附加发动机进水损坏除外特约条款
				put("037013", "0301610"); // 附加精神损害抚慰金责任险（机动车第三者责任保险）
				put("037031", "0301611"); // 附加精神损害抚慰金责任险（机动车车上人员责任保险（司机））
				put("037032", "0301612"); // 附加精神损害抚慰金责任险（机动车车上人员责任保险（乘客））
				put("037014", "0301604"); // 附加法定节假日限额翻倍险
				put("037015", "0301002"); // 附加医保外医疗费用责任险（机动车第三者责任保险）
				put("037029", "0301011"); // 附加医保外医疗费用责任险（机动车车上人员责任保险（司机））
				put("037030", "0301012"); // 附加医保外医疗费用责任险（机动车车上人员责任保险（乘客））
				put("037018", "0301003"); // 道路救援服务特约条款
				put("037019", "0301004"); // 车辆安全检测特约条款
				put("037020", "0301005"); // 代为驾驶服务特约条款
				put("037021", "0301006"); // 代为送检服务特约条款
				put("037024", "0301007"); // 附加绝对免赔率特约条款（机动车损失保险）
				put("037025", "0301008"); // 附加绝对免赔率特约条款（机动车第三者责任保险）
				put("037026", "0301009"); // 附加绝对免赔率特约条款（机动车车上人员责任保险（司机））
				put("037027", "0301010"); // 附加绝对免赔率特约条款（机动车车上人员责任保险（乘客））

				// TODO 暂没找到对应转换代码
				put("037005", ""); // 全车盗抢保险
				put("037016", ""); // 起重、装卸、挖掘车辆损失扩展条款
				put("037017", ""); // 特种车辆固定设备、仪器损坏扩展条款
				put("037006", ""); // 驾乘人员意外伤害保险
				put("037022", ""); // 住院津贴保险
				put("037023", ""); // 医保外医疗费用补偿险
			}
		};

		/**
		 * 车商 -> 中华 险别代码转码
		 */
		public static Map<String, String> COVERAGE_CODEE_REVERSE = new HashMap<String, String>() {
			{
				// 主险
				put("0301200", "037001"); // 机动车损失保险
				put("0301600", "037002"); // 机动车第三者责任保险
				put("0301701", "037003"); // 机动车车上人员责任保险（司机）
				put("0301702", "037004"); // 机动车车上人员责任保险（乘客）
				// 附加险
				put("0301210", "037009"); // 附加车身划痕损失险
				put("0301230", "037010"); // 附加修理期间费用补偿险
				put("0301260", "037008"); // 附加新增加设备损失险
				put("0301232", "037007"); // 附加车轮单独损失险
				put("0301601", ""); // 附加车上货物责任险 TODO 中华对应没找到
				put("0301610", "037013"); // 附加精神损害抚慰金责任险（机动车第三者责任保险）
				put("0301611", "037031"); // 附加精神损害抚慰金责任险（机动车车上人员责任保险（司机））
				put("0301612", "037032"); // 附加精神损害抚慰金责任险（机动车车上人员责任保险（乘客））
				put("0301202", "037011"); // 附加发动机进水损坏除外特约条款
				put("0301604", "037014"); // 附加法定节假日限额翻倍险
				put("0301002", "037015"); // 附加医保外医疗费用责任险（机动车第三者责任保险）
				put("0301011", "037029"); // 附加医保外医疗费用责任险（机动车车上人员责任保险（司机））
				put("0301012", "037030"); // 附加医保外医疗费用责任险（机动车车上人员责任保险（乘客））
				put("0301003", "037018"); // 道路救援服务特约条款
				put("0301004", "037019"); // 车辆安全检测特约条款
				put("0301005", "037020"); // 代为驾驶服务特约条款
				put("0301006", "037021"); // 代为送检服务特约条款
				put("0301007", "037024"); // 附加绝对免赔率特约条款（机动车损失保险）
				put("0301008", "037025"); // 附加绝对免赔率特约条款（机动车第三者责任保险）
				put("0301009", "037026"); // 附加绝对免赔率特约条款（机动车车上人员责任保险（司机））
				put("0301010", "037027"); // 附加绝对免赔率特约条款（机动车车上人员责任保险（乘客））
			}
		};

		/**
		 * 车商 -> 中华 手机实际持有人类型
		 * 车商：TODO 待确认
		 * 中华：00-投保人；01-被保人；02-企业业务经办人
		 */
		public static Map<String, String> APP_PHONE_HOLDER_TYPE = new HashMap<String, String>() {
			{
				put("", "00"); // ？ -> 投保人
				put("", "01"); // ？ -> 被保人
				put("", "02"); // ？ -> 企业业务经办人
			}
		};
	}
}
