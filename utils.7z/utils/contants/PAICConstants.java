package com.sinosoft.car.utils.contants;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.HashMap;
import java.util.Map;

/**
 * 平安常量池
 *
 * @author LiYanLong
 * @version 1.0
 * @date 2021/5/20 3:55
 * @since JDK1.8
 */
@Component
@Configuration
public class PAICConstants {

    /** 保险公司编码 */
    public static final String INSURER_CODE  = "000017";
    /** 保险公司简称 */
    public static final String INSURER_NAME  = "中国平安";
    
    public static final String YES  = "1";
    public static final String NO  = "0";

    /*
     * 可用的录单账号及车商编码/合作网点编
     * 1. 201机构--北京：
     *  "inputBy": "BEIJING-00005","saleCode": "201387602001"
     *  "inputBy": "BJDG-00001",    "saleCode": "201998531263"
     *  "inputBy": "BJJYLH-00001",    "saleCode": "201377418001"，采集器编码：05-03-20140910-0002510448
     *  20119
     *      "inputBy": "BJRJQC-00002",
     *      "saleCode": "201998540202"
     *  20121
     *      "inputBy": "BEIJING-00005",
     *      "saleCode": "201211502146"
     *   
     *      "inputBy": "BJDG-00001",
     *      "saleCode": "201998531263"
     */
    /** 平安好伙伴外网录单账号 */
//    public static final String INPUT_BY = "CGHJB-91372"; // 北京北方福瑞汽车销售服务有限公司
//    public static final String INPUT_BY = "BJJYLH-00001";
//    public static final String INPUT_BY = "BJDG-00001";
//    public static final String INPUT_BY = "FHFID-76160";
    /** 车商编码/合作网点编码 */
//    public static final String SALE_CODE = "201210912006"; // 北京北方福瑞汽车销售服务有限公司
//    public static final String SALE_CODE = "201377418001";
//    public static final String SALE_CODE = "201998531263";
//    public static final String SALE_CODE = "201210912044";

    /** 配置文件中的 url 地址，根据生产环境或者测试环境配置 */
    @Value("${paicTokenUrl}")
    public String paicTokenUrl;
    @Value("${paicUrl}")
    public String paicUrl;

    // 私钥
    public static String privateKey;
    // 公钥
    public static String publicKey;

    @Value("${rsa.insurer.paicPublicKey}")
    public void setPublicKey(String paicPublicKey) {
        this.publicKey = paicPublicKey;
    }

    @Value("${rsa.insurer.paicPrivateKey}")
    public void setPrivateKey(String paicPrivateKey) {
        this.privateKey = paicPrivateKey;
    }

    @PostConstruct
    public void init() {
        PAICConstants.InterfaceUrl.PAIC_TOKEN_URL = this.paicTokenUrl;
        PAICConstants.InterfaceUrl.PAIC_URL = this.paicUrl;
    }

    /**
     * 保司接口地址
     */
    public static class InterfaceUrl {
        /** 配置文件中的地址 */
        public static String PAIC_TOKEN_URL;
        public static String PAIC_URL;
        /*
         * 测试环境
         * 令牌地址：https://test-api.pingan.com.cn:20443/oauth/oauth2/access_token
         * 接口地址：https://test-api.pingan.com.cn:20443/open/appsvr
         * 生产环境
         * 令牌地址：https://api.pingan.com.cn/oauth/oauth2/access_token
         * 接口地址：https://api.pingan.com.cn/open/appsvr
         */
        /** 测试环境：令牌地址 */
        public static final String TEST_TOKEN_URL = "https://test-api.pingan.com.cn:20443/oauth/oauth2/access_token";
        /** 测试环境：接口地址 */
        public static final String TEST_URL = "https://test-api.pingan.com.cn:20443/open/appsvr";
        /** 生产环境：令牌地址 */
        public static final String PRODUCT_TOKEN_URL = "https://api.pingan.com.cn/oauth/oauth2/access_token";
        /** 生产环境：接口地址 */
        public static final String PRODUCT_URL = "https://api.pingan.com.cn/open/appsvr";
    }

    /** 请求服务名称 */
    public static class ServiceName {
        /** 标的检查接口 */
        public static final String INSURE_INDEX = "/property/chexian/insure/index";
        /** 车辆信息确认接口 */
        public static final String INSURE_CAR_CONFIRM = "/property/chexian/insure/carConfirm";

        /** 平安车型搜索接口 */
        public static final String QUERY_SEARCHPAVEHICLELIST = "/property/chexian/query/searchPAVehicleList";
        
        /** 保费计算接口 */
        public static final String INSURE_QUOTE = "/property/chexian/insure/quote";

        /** 补充信息并核保接口 */
        public static final String INSURE_SUBMIT_APPLY = "/property/chexian/insure/submitApply";

        /** 北京身份信息采集接口 */
        public static final String BEIJING_IDACQUISITION = "/property/chexian/insure/beiJingIdAcquisition";

        /** 投保短信发送 (获取验证码)接口 */
        public static final String GET_APPLY_VERIFY_CODE = "/property/chexian/insure/getApplyVerifyCode";

        /** 短信验证码回收及“阅读状态回收”接口 */
        public static final String RECOVER_APPLY_VERIFY_CODE = "/property/chexian/insure/recoverApplyVerifyCode";

        /** 江苏、北京交管车辆验证码接口 */
        public static final String GET_DMVEHICLE_INFO= "/property/chexian/insure/getDmvehicleInfo";

        /** 生成支付通知单号接口 */
        public static final String INSURE_NOTICEDO= "/property/chexian/insure/noticeDo";

        /** 平安新CPC收银台 */
        public static final String CHEXIAN_STANDARD_PREPAYMNT= "/property/chexian/insure/chexianStandardPrePayment";

        /** 单证状态查询 */
        public static final String CHEXIAN_INSURE_DOCUMENT_STATUS_LIST = "/property/chexian/insure/getDocumentStatusList";

        /** 平安承保接口 */
        public static final String INSURE_ACCEPT ="/property/chexian/insure/accept";

        /** 平安电子保单下载接口 */
        public static final String QUERY_GETPOLICYPDF = "/property/chexian/query/getPolicyPdf";

        /** 资料上传*/
        public static final String INSURE_UPLOADFILES = "/property/chexian/insure/uploadFiles";
        public static final String OSS_VIDEO_UPLOAD_DIR = "客户影像资料/videoUpload/000017/";//影像上传OSS的地址

        /** 查询事后未上传资料清单*/
            public static final String QUERY_SUPPLEMENT_MATERIAL = "/appsvr/property/chexian/insure/querySupplementMaterial";

        /** 获取财意险险种套餐列表接口 */
        public static final String INSURE_UNAUTOPRODUCTLIST = "/property/chexian/insure/getUnAutoProductList";
        /** 获取财意险险种套餐责任信息接口 */
        public static final String INSURE_UNAUTOPRODUCTDETAIL = "/property/chexian/insure/getUnAutoProductDetail";
    }

    /**
     * 转码工具，平台类型转为保司类型
     */
    public static class Transcode {
        /**
         * 车商平台 - 平安 证件类型映射
         *
         * 太保代码	说明	备注<br>
         * 1	身份证	车主性质只能为个人
         * 2	护照	车主性质只能为个人
         * 3	军官证	车主性质只能为个人
         * 4	社保证	车主性质只能为个人
         * 5	团体其他	车主性质只能为企业或机关
         * 6	组织机构代码	车主性质只能为企业或机关
         * 7	个人其他	车主性质只能为个人
         * 8	税务登记证	车主性质只能为企业或机关
         * 9	企业代码	车主性质只能为企业或机关
         * 10	法人证书	车主性质只能为企业或机关
         * 11	营业执照	车主性质只能为企业或机关
         * 12	离休证	车主性质只能为个人
         * 13	台湾居民来往大陆通行证	车主性质只能为个人
         * 14	内部编码	车主性质只能为企业或机关
         * 15	港澳居民来往内地通行证	车主性质只能为个人
         * 16	外国人永久居留证	车主性质只能为个人
         * 17	港澳台居民居住证	车主性质只能为个人
         */
        public static Map<String, String> CERTI_TYPE = new HashMap<String, String>() {
            {// 北京只有01、02、03、06四种证件
                put("111", "01"); // 居民身份证
                put("414", "02"); // 护照
                put("114", "03"); // 军官证
                put("516", "06"); // 港澳回乡证或台胞证
            }
        };

        /** 车商平台 - 平安 性别类型映射 */
        public static Map<String, String> SEX_TYPE = new HashMap<String, String>() {
            {
                put("0", "F"); // 女 - 女
                put("1", "M"); // 男 - 男
            }
        };

        /** 车商平台 - 平安 燃料类型映射 **/
        public static Map<String, String> ENERGY_TYPES = new HashMap<String, String>() {
            {
//                //非北京  后期需要S需要改
//                put("S", "0"); // 汽油
//                put("S", "1"); // 汽油
//                put("S", "2"); // 汽油
//                put("S", "3"); // 汽油
//                put("S", "4"); // 汽油
                //北京
                put("A", "A"); // 汽油
                put("B", "B"); // 柴油
                put("C", "C"); // 电
                put("D", "D"); // 混合油
                put("E", "E"); // 天然气
                put("F", "F"); // 液化石油气
                put("L", "L"); // 甲醇
                put("M", "M"); // 乙醇O
                put("N", "N"); // 太阳能
                put("O", "O"); // 混合动力
                put("Y", "Y"); // 无
                put("Z", "Z"); // 其他
            }
        };
        /** 精友类型 - 平安 燃料类型映射 **/
        public static Map<String, String> JY_ENERGY_TYPES = new HashMap<String, String>() {
            {
                /**
                 * 精友类型
                 * D1	汽油
                 * D2	柴油
                 * D3	天然气(NG/CNG/LNG)
                 * D4	液化石油气(LPG)
                 * D5	混合动力
                 * D6	电动
                 * D7	两用燃料
                 * D8	燃料电池
                 * D9	甲醇
                 * D10	乙醇
                 * D11	其它
                 * D12	插电式混合动力
                 * D13	混合油
                 * D14	太阳能
                 * D15	无
                 */
                put("D1", "A"); // 汽油
                put("D2", "B"); // 柴油
                put("D6", "C"); // 电
                put("D13", "D"); // 混合油
                put("D3", "E"); // 天然气
                put("D4", "F"); // 液化石油气
                put("D9", "L"); // 甲醇
                put("D10", "M"); // 乙醇O
                put("D14", "N"); // 太阳能
                put("D5", "O"); // 混合动力
                put("D15", "Y"); // 无
                put("D7", "Z"); // 其他
                put("D8", "Z"); // 其他
                put("D11", "Z"); // 其他
                put("D12", "Z"); // 其他
            }
        };

        /**
         * 平安 -> 车商平台
         * 将保司订单状态映射为车商系统的订单状态
         * 平安状态：BE-待审批，B1-待审核，BH-待验车，B2-待缴费，B3-待承保，B5-已承保，B6-AI审核，B4-待修改，B9-拒保，B0-承保失败，99-已失效，BZ-系统异常，BT-已退费
         * 车商订单状态：1-核保中；2-已发送；3-验证失败；4-待支付；5-支付失败；6-已承保；7-核保失败；0-关闭
         */
        public static Map<String, String> ORDER_STATUS_TO_STANDARD = new HashMap<String, String>() {
            {
                put("BE","1"); // 待审批--核保中
                put("B1","1"); // 待审核--核保中
                put("B2","4"); // 待缴费--待支付
                put("B3","4"); // 待承保--待支付
                put("BT","5"); // 已退费--支付失败
                put("B5","6"); // 已承保--已承保
                put("B4","7"); // 待修改--核保失败
                put("B9","7"); // 拒保--核保失败
                put("B0","7"); // 承保失败--核保失败
                put("BZ","7"); // 系统异常--核保失败
                put("BH","7"); // 待验车--验证失败
                put("99","0"); // 已失效--关闭            TODO 待确认
                put("B6","0"); // AI审核--已发送          TODO 待确认
            }
        };


    }

    /** 返回信息码表 后台接口执行编码*/
    public static class ResultCode {
        /** 成功 */
        public static final String SUCCESS = "0";
        /** 异常 */
        public static final String EXCEPTION = "1";
    }
}
