package com.sinosoft.car.utils.contants;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.HashMap;
import java.util.Map;

/**
 * 华安常量池
 */
@Component
@Configuration
public class HAICConstants {

    /** 保险公司编码 */
    public static final String INSURER_CODE  = "000024";
    /** 保险公司简称 */
    public static final String INSURER_NAME  = "华安保险";

    /*
     * 保险公司分配给渠道商的数据：
     * channelCode：QYC_C
     * secretToken：5cf3fef1fce61621af83d5ad3ba1fc78
     */
    /** 保险公司分配：渠道编码 */
    public static final String CHANNEL_CODE = "QYC_C";
    /** 保险公司分配：secretToken */
    public static final String SECRET_TOKEN = "5cf3fef1fce61621af83d5ad3ba1fc78";


    /** 配置文件中的 url 地址，根据生产环境或者测试环境配置 */
    @Value("${haicUrl}")
    public String haicUrl;

    @PostConstruct
    public void init() {
        InterfaceUrl.HAIC_URL = this.haicUrl;
    }

    /**
     * 保司接口地址
     * 使用
     */
    public static class InterfaceUrl {
        /** 配置文件中的地址 */
        public static String HAIC_URL;
        /** 车险接口测试环境地址 */
//        public static final String TEST_URL_OLD = " http://agenttest.sinosafe.com.cn/eauto_open";
        /** 车险接口生产环境地址 */
//        public static final String PRODUCT_URL_OLD = " http://agent.sinosafe.com.cn/eauto_open";

        // 使用新接口地址需要加密加签，请华安参考最新接口文档
        /** 【最新】车险接口测试环境地址： */
//        public static final String TEST_URL = "https://agenttest.sinosafe.com.cn/carinsure/open/v1";
        /** 【最新】车险接口生产环境地址： */
//        public static final String PRODUCT_URL = "https://agent.sinosafe.com.cn/carinsure/open/v1";
        public static final String OSS_VIDEO_UPLOAD_DIR = "客户影像资料/videoUpload/000024/";
    }

    public static class ServiceName {
        /** 精友车型查询 */
        public static String CAR_MODEL = "carmodel";
        /** 车险保费计算 */
        public static String PREMIUM = "premium";
        /** 车险提交核保 */
        public static String UNDERWRITE = "underwrite";
        /** 车险投保状态查询 */
        public static String POLICY_STATUS = "policystatus";
        /** 支付申请 */
        public static String PAYMENT = "payment";
        /**
         * 虚拟确认
         * 说明：仅限走非华安支付渠道使用
         */
        public static String DUMMY_COMFIRM = "dummyConfirm";
        /** 见费出单 */
        public static String CONFIRM = "confrim";
        /** 撤单接口 */
        public static String CANCLE = "cancle";
        /** 配送接口 */
        public static String DISTRIBUTE = "distribute";
        /**
         * 影像上传接口
         * 说明：报价或者提核后均可上传
         */
        public static String UPLOAD_IMAGE = "uploadimage";
        /**
         * 人工核保回调接口
         * 说明：外部渠道提供给华安使用，同步接口人工核保结果
         */
//        public static String aaa = "";
        /**
         * 支付回调接口
         * 说明：外部渠道提供给华安使用，同步投保单对应保单信息
         */
//        public static String aaa = "";
        /**
         * 续保查询
         * 说明：续保查询
         */
        public static String QUERY_RENEW_INFO = "queryRenewInfo";
        /**
         * 获取FlowId接口
         * 说明：获取新flowId（退回修改流程超时后可通过此接口创建新流程）
         */
        public static String GET_FLOW_ID = "getFlowId";
        /**
         * 验车码
         * 说明：获取验车码
         */
        public static String CAR_CHECK_CODE = "carCheckCode";
        /**
         * 获取认证短信
         * 说明：实名缴费验证短信触发短信
         */
        public static String GET_AUTH_SMS = "getAuthSms";
        /**
         * 非车产品查询
         * 说明：获取非车产品
         */
        public static String QUERY_NO_CAR_PRODUCT = "queryNoCarProduct";
    }


    /** 保司接口响应代码 */
    public static class ResponseCode {
        /** 成功返回 */
        public static final String SUCCESS = "C00000000";
        /** 失败 */
        public static final String FAIL = "C99999999";
        /** 异常 */
        public static final String EXCEPTION = "E00000000";
        /** 重复投保 */
        public static final String DOUBLE_INSURANCE = "C001";
        /** 建议车型 */
        public static final String SUGGEST_MODEL = "C002";
    }

    /**
     * 转码工具，平台类型转为保司类型
     */
    public static class Transcode {
        /** 车商平台 -> 华安 身份证件类型映射 */
        public static Map<String, String> CERTI_TYPE = new HashMap<String, String>() {
            {
                put("111", "01"); // 居民身份证         - 身份证
                put("113", "99"); // 户口簿             - 其他
                put("114", "03"); // 中国人民解放军军官证 - 军人证
                put("335", "99"); // 机动车驾驶证        - 其他
                put("414", "02"); // 普通护照           - 护照
            }
        };

        /** 车商平台 -> 华安 性别类型映射 */
        public static Map<String, String> SEX_TYPE = new HashMap<String, String>() {
            {
                put("0", "02"); // 女 - 女
                put("1", "01"); // 男 - 男
            }
        };
        /** 华安 -> 车商平台 划痕，三者 保险金额 代码->值，映射 */
        public static Map<String, String> AMT_CODE_TO_VALUE = new HashMap<String, String>() {
            {
                //划痕险
                put("HH01","2000.00");
                put("HH02","5000.00");
                put("HH03","10000.00");
                put("HH04","20000.00");

                //三者险
                put("SZ01","100000");
                put("SZ02","150000");
                put("SZ03","200000");
                put("SZ04","300000");
                put("SZ05","500000");
                put("SZ06","1000000");
                put("SZ07","1500000");
                put("SZ08","2000000");
                put("SZ09","2500000");
                put("SZ10","3000000");
                put("SZ11","3500000");
                put("SZ12","4000000");
                put("SZ13","4500000");
                put("SZ14","5000000");
                put("SZ15","10000000");
            }
            /**
             * //划痕险
             * ("HH01",2000.00D);
             * ("HH02",5000.00D);
             * ("HH03",10000.00D);
             * ("HH04",20000.00D);
             *
             * //三者险
             * ("SZ01",100000D);
             * ("SZ02",150000D);
             * ("SZ03",200000D);
             * ("SZ04",300000D);
             * ("SZ05",500000D);
             * ("SZ06",1000000D)
             * ("SZ07",1500000D)
             * ("SZ08",2000000D)
             * ("SZ09",2500000D)
             * ("SZ10",3000000D)
             * ("SZ11",3500000D)
             * ("SZ12",4000000D)
             * ("SZ13",4500000D)
             * ("SZ14",5000000D)
             * ("SZ15",10000000D)
             *
             * 附加发动机进水损坏除外特约条款（030138） 不展示保额
             * 附加车轮单独损失险（030139）  1000/2000/3000/5000/10000
             * 精神损害抚慰金责任险（三者）（030144） 手动填写（整数且大于0）
             * 精神损害抚慰金责任险（司机）（030145） 手动填写（整数且大于0）
             *
             * 精神损害抚慰金责任险（乘客）（030146）乘客单位保额手动录入*座位数 手动填写（整数且大于0）
             * 附加医保外用药责任险（三者/司机/乘客/车上人员）(030140/030141/030142/030143) 手动输入(必须是整数)
             */
        };
        /** 车商平台 -> 华安 划痕，三者 保险金额 值->代码，映射 */
        public static Map<String, String> AMT_VALUE_TO_CODE_SZ = new HashMap<String, String>() {
            {
                //三者险
                put("100000","SZ01");
                put("150000","SZ02");
                put("200000","SZ03");
                put("300000","SZ04");
                put("500000","SZ05");
                put("1000000","SZ06");
                put("1500000","SZ07");
                put("2000000","SZ08");
                put("2500000","SZ09");
                put("3000000","SZ10");
                put("3500000","SZ11");
                put("4000000","SZ12");
                put("4500000","SZ13");
                put("5000000","SZ14");
                put("10000000","SZ15");
            }
        };
        /** 车商平台 -> 华安 划痕，三者 保险金额 值->代码，映射 */
        public static Map<String, String> AMT_VALUE_TO_CODE_HH = new HashMap<String, String>() {
            {
                //划痕险
                put("2000.00","HH01");
                put("5000.00","HH02");
                put("10000.00","HH03");
                put("20000.00","HH04");
            }
        };

        /**
         * 华安 -> 车商平台
         * 将保司订单状态映射为车商系统的订单状态
         * 华安状态：0 转人工核保;3 打回修改;4 拒保;7 核保通过
         * 车商订单状态：1-核保中；2-已发送；3-验证失败；4-待支付；5-支付失败；6-已承保；7-核保失败；0-关闭
         */
        public static Map<String, String> ORDER_STATUS_TO_STANDARD = new HashMap<String, String>() {
            {
                put("0","1");
                put("3","7");
                put("4","0");// TODO 待确认
                put("7","4");
            }
        };



    }

}
