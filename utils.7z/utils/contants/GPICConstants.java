package com.sinosoft.car.utils.contants;

import com.cloud.fast.exceptions.BusinessException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.HashMap;
import java.util.Map;

/**
 * 国寿常量池
 */
@Component
@Configuration
public class GPICConstants {
    /**
     * 保险公司编码
     */
    public static final String INSURER_CODE  = "000108";

    public static final String INSURER_NAME = "中国人寿";

    /**
     * 险种编码
     */
    /** 商业险编码 */
    public static final String BUSINESS_RISK = "0521";
    /** 交强险编码 */
    public static final String INSURANCE = "0507";

    /**
     * 国寿通用时间格式化式样
     */
    public static class DateFormatPattern {
        public static final String YEAR_TO_DATE = "yyyy-MM-dd";
        public static final String YEAR_TO_MILLISECOND_TIMEZONE = "yyyy-MM-dd'T'HH:mm:ss.SSSZ";
    }

    /** 配置文件中的 url 地址，根据生产环境或者测试环境配置 */
    @Value("${gpicUrl}")
    public String gpicUrl;
    @Value("${gpicPayUrl}")
    public String gpicPayUrl;
    @Value("${gpicCallUrl}")
    public String gpicCallUrl;

    @Value("${gpicKey}")//支付key
    public String gpicKey;
    /** CommonData配置 */
    @Value("${gpicPolicySort}")
    public String gpicPolicySort;
    @Value("${gpicOperator}")
    public String gpicOperator;
    @Value("${gpicOperatorKey}")
    public String gpicOperatorKey;

    @PostConstruct
    public void init() {
        InterfaceUrl.ROUTE_UAT = this.gpicUrl;
        InterfaceUrl.TEST_ORDER_PAYMENT_WEB_VERSION = this.gpicPayUrl;
        InterfaceUrl.KEY = this.gpicKey;
        InterfaceUrl.PAY_BACK_ADDRESS = this.gpicCallUrl;



        /** CommonData配置 */
        CommonData.POLICY_SORT = this.gpicPolicySort;
        CommonData.OPERATOR = this.gpicOperator;
        CommonData.OPERATOR_KEY = this.gpicOperatorKey;
    }
    public static class CommonData {
        /** CommonData配置 */
        public static String POLICY_SORT;
        public static String OPERATOR;
        public static String OPERATOR_KEY;
    }

    /** 保险公司接口 */
    public static class InterfaceUrl {
        /** 标准对接公共接口-UAT */
        public static String ROUTE_UAT;
        //public static final String ROUTE_UAT = "http://esbtest.chinalife-p.com.cn:9088/ESB/P020T/RouteSit/B103";//最新测试地址
        //public static final String ROUTE_UAT = "http://esbtest.chinalife-p.com.cn:9088/ESB/P020T/RouteUat/B103";//测试

        //public static final String ROUTE_UAT = "https://esb.chinalife-p.com.cn:8443/ESB/P246T/Route/B103";//生产最新
        //public static final String ROUTE_UAT = "https://esb.chinalife-p.com.cn:8443/ESB/P221T/Route/B103";//生产

        /** 保险公司投保单商业接口-UAT */
        /**  车型查询服务 */
        public static final String CAR_QUERY = "http://esbtest.chinalife-p.com.cn:9088/ESB/P020T/SIT_CarQueryService";
        /**  车辆实际价值计算服务 */
        public static final String CAR_ACTUAL_PRICE_QUERY = "http://esbtest.chinalife-p.com.cn:9088/ESB/P020T/SIT_CarActualPriceQueryService";
        /**  保费计算服务 */
        public static final String PREMIUM_CACULATE = "http://esbtest.chinalife-p.com.cn:9088/ESB/P020T/SIT_PremiumCaculateService";
        /**  投保单保存服务 */
        public static final String PROPOSAL_SAVE = "http://esbtest.chinalife-p.com.cn:9088/ESB/P020T/SIT_ProposalSaveService";
        /**  短信验证码获取及回填服务 */
        public static final String RECEIVER_CUSTOMER_ID_CARD_INFO = "http://esbtest.chinalife-p.com.cn:9088/ESB/P020T/SIT_ReceiverCustomerIDCardInfoService";
        /**  业务状态查询服务 */
        public static final String PROVISONAL_STATUS_QUERY = "http://esbtest.chinalife-p.com.cn:9088/ESB/P020T/SIT_ProvisonalStatusQueryService";
        /**  业务详细信息查询服务 */
        public static final String POLICY_QUERY_DETAIL = "http://esbtest.chinalife-p.com.cn:9088/ESB/P020T/SIT_PolicyQueryDetailService";
        /**  投保单撤单服务 */
        public static final String PROPOSAL_CANCEL = "http://esbtest.chinalife-p.com.cn:9088/ESB/P020T/SIT_ProposalCancelService";
        /**  影像上传服务 */
        public static final String AUTO_AUDIT_UPLOAD = "http://esbtest.chinalife-p.com.cn:9088/ESB/P020T/SIT_AutoAuditUploadService";
        public static final String OSS_VIDEO_UPLOAD_DIR = "客户影像资料/videoUpload/000108/";//影像上传OSS的地址
        /**  电子保单下载服务 */
        public static final String ELEC_POLICY_SHOW_LINK = "http://esbtest.chinalife-p.com.cn:9088/ESB/P020T/SIT_ElecPolicyShowLinkService";
        /**  投保单下发修改信息查询服务 */
        public static final String DOWN_REASON = "http://esbtest.chinalife-p.com.cn:9088/ESB/P020T/SIT_DownReasonService";
        /**  业务员查询接口服务（多业务场景使用） */
        public static final String BUS_PERSON_QUERY = "http://esbtest.chinalife-p.com.cn:9088/ESB/P020T/SIT_BusPersonQueryService";
        /**  平台信息获取接口服务（暂不开放） */
        public static final String PLT_INFO_QUERY = "http://esbtest.chinalife-p.com.cn:9088/ESB/P020T/SIT_PltInfoQueryService";
        /**  上海、北京平台车型查询接口 */
        public static final String SH_CAR_QUERY = "http://esbtest.chinalife-p.com.cn:9088/ESB/P020T/SIT_SHCarQueryService";

        /**  下单支付接口  支付接口服务地址 */
        /**  测试URL地址*/
        public static String TEST_ORDER_PAYMENT_WEB_VERSION;//移动版 或者 生产
        /**  移动版 */
        //public static final String TEST_ORDER_PAYMENT_WEB_VERSION = "http://106.37.195.142:5120/clppay/_cdMAction.do?cmd=toMCD&f=1&sys=1&req=";
        /**  网页版 */
        public static final String TEST_ORDER_PAYMENT_MOBILE_VERSION = "http://106.37.195.142:5120/clppay/_cdMAction.do?cmd=toWCD&f=1&sys=1&req=";

        /**  生产URL地址 */
        /**  移动版 */
        public static final String ORDER_PAYMENT_WEB_VERSION = "https://gpicpay.chinalife-p.com.cn/clppay/_cdMAction.do?cmd=toMCD&f=1&sys=1&req=";
        /**  网页版 */
        public static final String ORDER_PAYMENT_MOBILE_VERSION = "https://gpicpay.chinalife-p.com.cn/clppay/_cdMAction.do?cmd=toWCD&f=1&sys=1&req=";

        /**  支付成功跳转地址 测试 */
        //public static final String  PAY_BACK_ADDRESS = "https://bxgj.qyccar.com/success";
        //public static final String  PAY_BACK_ADDRESS = "https://testbxgj.qyccar.com/success";
        public static String  PAY_BACK_ADDRESS;
//        public static final String  PAY_BACK_ADDRESS = "https://testbxgj.qyccar.com/success";
        //public static final String   KEY = "123456";//测试
        //public static final String   KEY = "frjt123456";//生产
        /**  支付后调回地址 生产 */
        public static String   KEY;

        /**  下单支付接口 100（100接口）301（301接口） 支付结果通知接口204（204接口）支付结果通知接口 **/
        public static final String  PAYMENT_APPLICATION = "100";
        public static final String   PAY_RESULTS = "301";
        public static final String   PAYMENT_STATUS = "204";

    }

    /***
     *  订单状态 (1.核保中：2.已发送：3.验证失败：4.待支付：5.支付失败：6.已承保：7.核保失败：0.关闭)
     **/

    public static final String ORDER_STATUS_UNDERWRITE = "1";

    public static final String ORDER_STATUS_SEND = "2";

    public static final String ORDER_STATUS_VERIFY_FAILURE = "3";

    public static final String ORDER_STATUS_PENDING_PAYMENT = "4";

    public static final String ORDER_STATUS_PAYMENT_FAILURE = "5";

    public static final String ORDER_STATUS_INSURED = "6";

    public static final String ORDER_STATUS_UNDERWRITE_FAILURE = "7";

    public static final String ORDER_STATUS_CLOSE = "7";

    /**
     *  0-失败 1-成功
     */
    public static final String INSURED_STATUS_PASS = "1";

    public static final String INSURED_STATUS_REPEAT = "0";

    /** 请求服务名称 */
    public static class ServiceName {
        /** 标准对接公共接口 */
        public static final String COMMON_SERVICE_ROUTE = "commonService/route";
        /**  车型查询服务 */
        public static final String CAR_QUERY_SERVICE = "carQueryService";
        /**  车辆实际价值计算服务 */
        public static final String CAR_ACTUAL_PRICE_QUERY_SERVICE = "carActualPriceQueryService";
        /**  保费计算服务 */
        public static final String PREMIUM_CACULATE_SERVICE = "premiumCaculateService";
        /**  投保单保存服务 */
        public static final String PROPOSAL_SAVE_SERVICE = "proposalSaveService";
        /**  短信验证码获取及回填服务 */
        public static final String RECEIVER_CUSTOMER_ID_CARD_INFO_SERVICE = "receiverCustomerIDCardInfoService";
        /**  业务状态查询服务 */
        public static final String PROVISONAL_STATUS_QUERY_SERVICE = "provisonalStatusQueryService";
        /**  业务详细信息查询服务 */
        public static final String POLICY_QUERY_DETAIL_SERVICE = "policyQueryDetailService";
        /**  投保单撤单服务 */
        public static final String PROPOSAL_CANCEL_SERVICE = "proposalCancelService";
        /**  影像上传服务 */
        public static final String AUTO_AUDIT_UPLOAD_SERVICE = "autoAuditUploadService";
        /**  电子保单下载服务 */
        public static final String ELEC_POLICY_SHOW_LINK_SERVICE = "elecPolicyShowLinkService";
        /**  投保单下发修改信息查询服务 */
        public static final String DOWN_REASON_SERVICE = "downReasonService";
        /**  业务员查询接口服务（多业务场景使用） */
        public static final String BUS_PERSON_QUERY_SERVICE = "busPersonQueryService";
        /**  平台信息获取接口服务（暂不开放） */
        public static final String PLT_INFO_QUERY_SERVICE = "PltInfoQueryService";
        /**  上海、北京平台车型查询接口 */
        public static final String SH_CAR_QUERY = "shCarQuery";
        /** 北京新车备案接口 */
        public static final String BJ_CAR_RECORD = "bjCarRecord";
        /** 全国平台车型查询预填接口 */
        public static final String PURE_CAR_QUERY = "pureCarQuery";
        /** 电子投保信息推送接口 */
        public static final String ELEC_MESSAGE_PUSH = "elecMessagePush";
        /** 保单清单查询接口 */
        public static final String POLICY_QUERY_LIST = "policyQueryList";
        /** 联保协议详细信息查询接口 */
        public static final String QUERY_AGREEMENT_DETAIL = "queryAgreementDetail";
        /** 基础信息查询接口【内部渠道使用】 */
        public static final String FIND_CODE_DETAILS = "findCodeDetails";
    }

    /** 4.1.    返回信息码表 */
    public static class ResultCode {
        /** 交易成功 */
        public static final String SUCCESS = "0000";
        /** 数据校验失败(返回校验失败原因) */
        public static final String VERIFY_FAILED = "0001";
        /** 服务异常-系统异常 */
        public static final String SERVICE_EXCEPTION = "0002";
        /** 业务交互处理成功，但有相应软提示信息 */
        public static final String SUCCESS_PROMPT_INFO = "0003";
        /** 当平台返回的行业车型【】与本单录入行业车型【】不一致异常 */
        public static final String DISSIMILAR = "0004";
        /** 需补充传入（B类、C类）自动特约异常 */
        public static final String ISSUED_BY_REASON = "0005";
        /** 其它异常 */
        public static final String OTHER_EXCEPTION = "9999";
    }

    /** 4.4.	号牌种类编码 */
    public static class LicenseType {
        // 代码	名称
        /** 01 大型汽车号牌 */
        public static final String LARGE_CAR = "01";
        /** 02 小型汽车号牌 */
        public static final String SMALL_CAR = "02";
        /** 03 使馆汽车号牌 */
        public static final String EMBASSY_CAR = "03";
        /** 04 领馆汽车号牌 */
        public static final String CONSULATE_CAR = "04";
        /** 05 境外汽车号牌 */
        public static final String OVERSEAS_CAR = "05";
        /** 06 外籍汽车号牌 */
        public static final String FOREIGN_CAR = "06";
        /** 14 拖拉机号牌 */
        public static final String TRACTOR = "14";
        /** 15 挂车号牌 */
        public static final String TRAILER_CAR = "15";
        /** 16 教练车号牌 */
        public static final String COACH_CAR = "16";
        /** 18 试验汽车号牌 */
        public static final String TEST_CAR = "18";
        /** 20 临时入境汽车号牌 */
        public static final String TEMPORARY_ENTRY_CAR = "20";
        /** 22 临时行驶车号牌 */
        public static final String TEMPORARY_DRIVING_CAR = "22";
        /** 23 公安警车号牌 */
        public static final String POLICE_CAR = "23";
        /** 24 公安民用号牌 */
        public static final String CIVIL_CAR = "24";
        /** 25 其他 */
        public static final String OTHER_CAR = "25";
        /** 31 武警号牌 */
        public static final String ARMED_POLICE_CAR = "31";
        /** 32 军队号牌 */
        public static final String ARMY_CAR = "32";
        /** 51 大型新能源汽车 */
        public static final String LARGE_NEW_ENERGY_CAR = "51";
        /** 52 小型新能源汽车 */
        public static final String SMALL_NEW_ENERGY_CAR = "52";
    }

    /** 4.6.	车辆种类编码 */
    public static class CarKindCode {
        //  代码	名称
        /** A0 客车 */
        public static final String PASSENGER_CAR = "A0";
        /** G0 挂车 */
        public static final String TRAILER_CAR = "G0";
        /** H0 货车 */
        public static final String TRUCK = "H0";
        /** H1 低速载货汽车 */
        public static final String LOW_SPEED_TRUCK = "H1";
    }

    /** 4.7.	车辆使用性质编码 */
    public static class CarUserNatureCode {
        // 代码	名称
        /** 8A	家庭自用 */
        public static final String HOME_USE = "8A";
        /** 8B	非营业企业 */
        public static final String NON_BUSINESS_ENTERPRISE = "8B";
        /** 8C	非营业党政机关，事业团体 */
        public static final String NON_BUSINESS_PARTY_GOV = "8C";
        /** 8D	非营业个人 */
        public static final String NON_BUSINESS_PERSONAL = "8D";
        /** 9A	营业出租租赁 */
        public static final String LEASING = "9A";
        /** 9B	营业城市公交 */
        public static final String BUS = "9B";
        /** 9C	营业公路客运 */
        public static final String HIGHWAY_PASSENGER = "9C";
        /** 9D	营业货运 */
        public static final String FREIGHT_TRANSPORT = "9D";
    }

    /** 4.48.	核保状态代码 */
    public static class UnderWriteFlag {
        // 代码	描述
        /** 0	初始值 */
        public static final String INITIAL_VALUE = "0";
        /** 1	核保通过生成保单 */
        public static final String PASS = "1";
        /** 2	不通过 */
        public static final String NO_PASS = "2";
        /** 3	自动核保核保通过生成保单 */
        public static final String AUTO_PASS = "3";
        /** 4	主动回撤 */
        public static final String ACTIVE_WITHDRAWAL = "4";
        /** 5	人工预核保通过 */
        public static final String MANUAL_PRE_PASS = "5";
        /** 6	自动预核保通过 */
        public static final String AUTO_PRE_PASS = "6";
        /** 9	待核保 */
        public static final String WAITING = "9";
    }

    /** 4.52.	交易类型（接口类型） */
    public static class TransactionType {
        // 代码	名称	说明
        /** G01	车型查询服务 */
        public static final String CAR_QUERY = "G01";
        /** G02	车辆实际价值计算服务 */
        public static final String CAR_ACTUAL_PRICE_QUERY = "G02";
        /** G03	保费计算服务 */
        public static final String PREMIUM_CACULATE = "G03";
        /** G04	投保单保存服务 */
        public static final String PROPOSAL_SAVE = "G04";
        /** G05	短信验证码获取及回填服务 */
        public static final String RECEIVER_CUSTOMER_ID_CARD_INFO = "G05";
        /** G06	业务状态查询服务 */
        public static final String PROVISONAL_STATUS_QUERY = "G06";
        /** G07	业务详细信息查询服务 */
        public static final String POLICY_QUERY_DETAIL = "G07";
        /** G08	投保单撤单服务 */
        public static final String PROPOSAL_CANCEL = "G08";
        /** G09	影像上传服务 */
        public static final String AUTO_AUDIT_UPLOAD = "G09";
        /** G10	电子保单下载服务 */
        public static final String ELEC_POLICY_SHOW_LINK = "G10";
        /** G11	投保单下发修改信息查询服务 */
        public static final String DOWN_REASON = "G11";
        /** G12	业务员查询接口服务（多业务场景使用） */
        public static final String BUS_PERSON_QUERY = "G12";
        /** G13	平台信息获取接口服务（暂不开放） */
        public static final String PLT_INFO_QUERY = "G13";
        /** G14	上海、北京平台车型查询接口 */
        public static final String SH_CAR_QUERY = "G14";
        /** G15	北京新车备案接口 */
        public static final String BJ_CAR_RECORD = "G15";
        /** G16	全国平台车型查询预填接口 */
        public static final String PURE_CAR_QUERY = "G16";
        /** G17	电子投保信息推送接口 */
        public static final String ELEC_MESSAGE_PUSH = "G17";
        /** G18	保单清单查询接口 */
        public static final String POLICY_QUERY_LIST = "G18";
        /** G19	联保协议详细信息查询接口 */
        public static final String QUERY_AGREEMENT_DETAIL = "G19";
        /** G20	基础信息查询接口【内部渠道使用】 */
        public static final String FIND_CODE_DETAILS = "G20";
        /** G20	电子发票下载接口【内部渠道使用】 */
        public static final String ELECTRONIC_INVOICE_DOWNLOAD = "G21";
        /** G20	北京交管所查询接口 */
        public static final String TRAFFIC_CONTROL_INQUIRY = "G22";
    }
    /**
     * 转码工具，平台类型转为保司类型
     */
    public static class Transcode {
        /** 车商平台 - 国寿 身份证件类型映射 */
        public static Map<String, String> CERTI_TYPE = new HashMap<String, String>() {
            {
                put("111", "01"); // 居民身份证         - 身份证
                put("113", "02"); // 户口簿             - 其他
                put("114", "04"); // 中国人民解放军军官证 - 军人证
                put("335", "05"); // 机动车驾驶证        - 其他
                put("414", "18"); // 普通护照           - 护照
            }
        };
        /** 车商平台 精友车型查询类型 - 国寿 燃料类型映射 **/
        public static Map<String, String> ENERGY_TYPES = new HashMap<String, String>() {
            {
                //非北京  后期需要S需要改
                //put("D1", "0"); // 燃油
                //put("D2", "0"); // 燃油
                //put("D6", "1"); // 纯电动
                //put("D8", "2"); // 燃料电池
                //put("D12", "3"); // 插电式混合动力
                //put("D5", "4"); // 其他混合动力
                //北京
                put("D1", "A"); // 汽油
                put("D2", "B"); // 柴油
                put("D6", "C"); // 电
                put("D13", "D"); // 混合油
                put("D3", "E"); // 天然气
                put("D4", "F"); // 液化石油气
                put("D9", "L"); // 甲醇
                put("D10", "M"); // 乙醇
                put("D14", "N"); // 太阳能
                //put("D5", "该能源类型国寿目前不支持"); // 混合动力
                //put("P", "该能源类型国寿目前不支持"); // 氢
                //put("Q", "该能源类型国寿目前不支持"); // 生物燃料
                put("D15", "Y"); // 无
                put("D11", "Z"); // 其他
            }
        };
        /** 车商平台 - 国寿 产地种类映射 **/
        public static Map<String, String> PLACE_OF_ORIGIN = new HashMap<String, String>() {
            {
                put("0", "B"); // 国产
                put("1", "A"); // 进口
                put("2", "C"); // 合资
            }
        };
        /** 车商平台 - 国寿 车辆种类码 **/
        public static Map<String, String> VEHICL_CLASS_CODE = new HashMap<String, String>() {
            {
                put("1", "A0"); // 客车
                put("2", "H0"); // 货车
            }
        };
        /** 车商平台 - 国寿 性别类型映射 **/
        public static Map<String, String> SEX_TYPE = new HashMap<String, String>() {
            {
                put("0", "1"); // 女 - 女
                put("1", "2"); // 男 - 男
            }
        };
        /** 车商平台 - 国寿 （燃料类型）校验 **/
        public static void nationalLifeCodeCheck(String code){
            if(code.equals("D5")||code.equals("D7")||code.equals("D8")||code.equals("D12")) {throw new BusinessException("该能源类型国寿目前不支持");}
        }

        //以下是映射到数据库
        /** 国寿 - 车商平台 身份证件类型映射到数据库 */
        public static Map<String, String> IDENTIF_TYPE = new HashMap<String, String>() {
            {
                put("01", "1"); // 居民身份证         - 身份证
                put("02", "2"); // 户口簿             - 其他
                put("04", "3"); // 中国人民解放军军官证 - 军人证
                put("05", "4"); // 机动车驾驶证        - 其他
                put("18", "5"); // 普通护照           - 护照
            }
        };

    }

}
