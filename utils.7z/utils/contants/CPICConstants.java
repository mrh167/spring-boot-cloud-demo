package com.sinosoft.car.utils.contants;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.HashMap;
import java.util.Map;

/**
 * 太保常量池
 */
@Component
@Configuration
public class CPICConstants {
    /**
     * 保险公司编码
     */
    public static final String INSURER_CODE  = "000014";

    public static final String INSURER_NAME = "太平洋保险";
    @Value("${cpicUrl}")
    public String cpicUrl;

    public static  String INTERFACE_URL;

    public static final String MACHINE_CODE = "05-03-20150316-0003065167";

    public static final String TERMINAL_NO = "QYC_1010100";

    public static final String SERVICE_CODE_THIRD_INSURANCE_VEHICLE_MODEL_QUERY = "third.insurance.vehicleModelQuery";

    public static final String SERVICE_CODE_THIRD_INSURANCE_INQUIRE = "third.insurance.inquire";

    public static final String SERVICE_CODE_THIRD_INSURANCE_COM_UNDER_WRITING = "third.insurance.comUnderWriting";

    public static final String SERVICE_CODE_THIRD_INSURANCE_POST_BJ_CERTIFICATE_INFO = "third.insurance.postBJCertificateInfo";

    public static final String SERVICE_CODE_THIRD_INSURANCE_BJ_IDENTIFY_CODE = "third.insurance.bjidentifycode";

    public static final String SERVICE_CODE_THIRD_INSURANCE_APPLY_PAY_NO = "third.insurance.applyPayNo";

    public static final String SERVICE_CODE_THIRD_INSURANCE_HAND_UNDER_WRITING = "third.insurance.handUnderWriting";

    public static final String SERVICE_CODE_THIRD_INSURANCE_REGISTER_NEW_VEHICLE = "third.insurance.registerNewVehicle";

    public static final String SERVICE_CODE_THIRD_INSURANCE_ELECTRONIC_MSG_CONFIRM= "third.insurance.electronicMsgConfirm";

    public static final String SERVICE_CODE_THIRD_INSURANCE_QUERY_VEHICLE= "third.insurance.queryVehicle";

    public static final String SERVICE_CODE_THIRD_INSURANCE_QUERY_AUAPPOLICYSTATUS = "third.insurance.queryAuapPolicyStatus";
    /**实际价值计算*/
    public static final String SERVICE_CODE_THIRD_CURRENT_VALUE ="third.insurance.getCurrentValue";
    //生产
//    public static final String CHANNEL_POLICY_URL = "https://jttp.cpic.com.cn:8443/jttpitx/externalpartner/un/cblc_CB";
    //测试
    public static final String CHANNEL_POLICY_URL = "https://jttpitxsit.cpic.com.cn/jttpitx/externalpartner/un/cblc_CB";

    public static final String SUCCESS_CODE = "0000";

    //精友码车型查询失败代码
    public static final String FAIL_CARESSENTIAL_CODE = "E9999_0001";

    public static final String ORDER_STATUS_UNDERWRITE = "1";

    public static final String ORDER_STATUS_SEND = "2";

    public static final String ORDER_STATUS_VERIFY_FAILURE = "3";

    public static final String ORDER_STATUS_PENDING_PAYMENT = "4";

    public static final String ORDER_STATUS_PAYMENT_FAILURE = "5";

    public static final String ORDER_STATUS_INSURED = "6";

    public static final String ORDER_STATUS_UNDERWRITE_FAILURE = "7";

    public static final String ORDER_STATUS_CLOSE = "7";

    //生产
    //public static final String GET_POLICY_PDF_URL = "https://service-sit.cpic.com.cn/ePolicy/ePolicyInit";

    //测试
    public static final String GET_POLICY_PDF_URL = "https://service.cpic.com.cn/ePolicy/ePolicyInit";

    /** 资料上传*/
    public static final String OSS_VIDEO_UPLOAD_DIR = "客户影像资料/videoUpload/000014/";//影像上传OSS的地址
    public static final String OSS_VIDEO_UPLOAD_VIDEO = "http://pt16auap-sit.cpic.com.cn/auap-esb/externalServices/trandition/uploadVideo.json";


    /**
     * 0000	标件核保通过
     * 4001	发生重复投保
     * 4002	拒保不可申诉
     * 4003	拒保可申诉
     * 4004	非标件(待人工审核)
     * 4006	核保失败
     */
    public static final String INSURED_STATUS_PASS = "0000";

    public static final String INSURED_STATUS_REPEAT = "4001";

    public static final String INSURED_STATUS_REFUSE_FOREVER = "4002";

    public static final String INSURED_STATUS_REFUSE_TEMP = "4003";

    public static final String INSURED_STATUS_ARTIFICIAL = "4004";

    public static final String INSURED_STATUS_UNDERWRITE_FAILURE = "4006";

    @PostConstruct
    public void init() {
        INTERFACE_URL = this.cpicUrl;
    }



    /**
     * 转码工具，平台类型转为保司类型
     */
    public static class Transcode {
        /**
         * 车商平台 - 太保 身份证件类型映射<br>
         * <br>
         * 太保代码	说明	备注<br>
         * 1	身份证	车主性质只能为个人
         * 2	护照	车主性质只能为个人
         * 3	军官证	车主性质只能为个人
         * 4	社保证	车主性质只能为个人
         * 5	团体其他	车主性质只能为企业或机关
         * 6	组织机构代码	车主性质只能为企业或机关
         * 7	个人其他	车主性质只能为个人
         * 8	税务登记证	车主性质只能为企业或机关
         * 9	企业代码	车主性质只能为企业或机关
         * 10	法人证书	车主性质只能为企业或机关
         * 11	营业执照	车主性质只能为企业或机关
         * 12	离休证	车主性质只能为个人
         * 13	台湾居民来往大陆通行证	车主性质只能为个人
         * 14	内部编码	车主性质只能为企业或机关
         * 15	港澳居民来往内地通行证	车主性质只能为个人
         * 16	外国人永久居留证	车主性质只能为个人
         * 17	港澳台居民居住证	车主性质只能为个人
         */
        public static Map<String, String> CERTI_TYPE = new HashMap<String, String>() {
            {// 目前车商平台只支持五种类型，后面根据情况添加
                put("111", "1"); // 居民身份证          - 身份证
                put("113", "7"); // 户口簿             - 个人其他
                put("114", "3"); // 中国人民解放军军官证  - 军官证
                put("335", "7"); // 机动车驾驶证        - 个人其他
                put("414", "2"); // 普通护照            - 护照
            }
        };
        /**
         * 车商平台 - 太保 身份证件类型映射<br>
         * <br>
         * 太保代码	说明	备注<br>
         *  1       男      对应太保的代码转换是 1
         *  0       女      对应的太保转换代码是 2
         */
        public static Map<String,String> SEX_TYPE = new HashMap<String,String >(){
            {
                put("1","1");
                put("0","2");
            }
        };



    }
}
