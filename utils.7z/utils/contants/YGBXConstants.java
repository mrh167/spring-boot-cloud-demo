package com.sinosoft.car.utils.contants;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.HashMap;
import java.util.Map;

/**
 * 阳光常量池
 */
@Component
@Configuration
public class YGBXConstants {

    /** 保险公司编码 */
    public static final String INSURER_CODE  = "000093";
    /** 保险公司简称 */
    public static final String INSURER_NAME  = "阳光保险";

    /** 配置文件中的 url 地址，根据生产环境或者测试环境配置 */
    @Value("${ygbxUrl}")
    public String ygbxUrl;
    
    @Value("${ygbxKey}")
    public String ygbxKey;

    @PostConstruct
    public void init() {
        InterfaceUrl.YGBX_URL = this.ygbxUrl;
        InterfaceUrl.YGBX_KEY = this.ygbxKey;
    }

    /** 影像上传测试外网地址：注：生产需要配置生产影像上传地址 */
    public static final String UPLOAD_URL = "http://unifiedimage.sinosig.com:8082/AutoImagePlatform/third/upload";
    /** 影像上传参数名称 */
    public static final String PARAM_NAME = "req";
    /** 影像上传请求头Referer */
    public static final String REFERER = "ygcbl";
    /** 影像上传加密秘钥 */
    public static final String YGBX_SECRET_KEY = "GUDzk55WzY71W4ZtjTLUwQLK";
    
    /**
     * 保司接口地址
     */
    public static class InterfaceUrl {
        /** 配置文件中的地址 */
        public static String YGBX_URL;
        /** 密钥 **/
        public static String YGBX_KEY;
   }

    public static class ServiceName {
        /** 车型查询（精友） */
        public static String CAR_MODEL = "ccsiQueryVehicleModel";
        /** 精准报价 */
        public static String ENQUIRY = "accuracyCalculate";
        /** 车险提交核保 */
        public static String SUBMIT = "submit";
        /** 车险投保状态查询 */
        public static String POLICY_STATUS = "policystatus";
        /** 支付申请 */
        public static String PAYMENT = "payment";
        /**
         * 虚拟确认
         * 说明：仅限走非阳光支付渠道使用
         */
        public static String DUMMY_COMFIRM = "dummyConfirm";
        /** 见费出单 */
        public static String CONFIRM = "confrim";
        /** 撤单接口 */
        public static String CANCLE = "cancle";
        /** 配送接口 */
        public static String DISTRIBUTE = "distribute";
        /**
         * 影像上传接口
         * 说明：报价或者提核后均可上传
         */
        public static String UPLOAD_IMAGE = "uploadimage";
        public static final String OSS_VIDEO_UPLOAD_DIR = "客户影像资料/videoUpload/000093/";//影像上传OSS的地址
        /**
         * 续保查询
         * 说明：续保查询
         */
        public static String QUERY_RENEW_INFO = "queryRenewInfo";
        /**
         * 获取FlowId接口
         * 说明：获取新flowId（退回修改流程超时后可通过此接口创建新流程）
         */
        public static String GET_FLOW_ID = "getFlowId";
        /**
         * 验车码
         * 说明：获取验车码
         */
        public static String CAR_CHECK_CODE = "carCheckCode";
        /**
         * 获取认证短信
         * 说明：实名缴费验证短信触发短信
         */
        public static String GET_AUTH_SMS = "getAuthSms";
        /**
         * 非车产品查询
         * 说明：获取非车产品
         */
        public static String QUERY_NO_CAR_PRODUCT = "queryNoCarProduct";
        /**
         *  北京客户信息采集
         */
        public static String CUSTOMER_COLLECT = "customerCollect";
        /**
         *  北京信息采集验证码回收
         */
        public static String CUSTOMER_INSERT = "customerInsert";
        /**
         *  新车备案
         */
        public static String NEW_CAR_RECORD = "newCarRecord";
        /**
         *  保单生效通知
         */
        public static String PAYMENT_CALLBACK = "paymentcallback";
        /**
         *  获取电子保单下载地址
         */
        public static String GET_POLICY_PDF_URL = "getEpolicyPDFURL";

        /**
         * 交管车辆查询校验
         */
        public static String JS_QUERY_CAR = "jsQueryCar";

        /**
         * 交管车辆查询确认
         */
        public static String JS_CONFIRM_CAR = "jsConfirmCar";
        
        /**
         * 意健险套餐查询
         */
        public static String GET_NON_VEHICLE_PRODUCTS="getNonVehicleProducts";
    }


    /** 保司接口响应代码 */
    public static class ResponseCode {
        /** 成功返回 */
        public static final String SUCCESS = "0";
        /** 失败 */
        public static final String FAIL = "C99999999";
        /** 异常 */
        public static final String EXCEPTION = "E00000000";
        /** 重复投保 */
        public static final String DOUBLE_INSURANCE = "C001";
        /** 建议车型 */
        public static final String SUGGEST_MODEL = "C002";
    }

    /**
     * 转码工具，平台类型转为保司类型
     */
    public static class Transcode {
        /** 车商平台 -> 阳光 身份证件类型映射 */
        public static Map<String, String> CERTI_TYPE = new HashMap<String, String>() {
            {
                put("111", "01"); // 居民身份证         - 身份证
                put("113", "99"); // 户口簿             - 其他
                put("114", "04"); // 中国人民解放军军官证 - 军人证
                put("335", "99"); // 机动车驾驶证        - 其他
                put("414", "03"); // 普通护照           - 护照
                put("511", "42"); // 台湾居民来往大陆通行证
                put("553", "47"); // 外国人永久居留身份证
            }
        };

        /** 车商平台 -> 阳光 性别类型映射 */
        public static Map<String, String> SEX_TYPE = new HashMap<String, String>() {
            {
                put("0", "2"); // 女 - 女
                put("1", "1"); // 男 - 男
            }
        };
        /** 阳光 -> 车商平台 划痕，三者 保险金额 代码->值，映射 */
        public static Map<String, String> AMT_CODE_TO_VALUE = new HashMap<String, String>() {
            {
                //划痕险
                put("HH01","2000.00");
                put("HH02","5000.00");
                put("HH03","10000.00");
                put("HH04","20000.00");

                //三者险
                put("SZ01","100000");
                put("SZ02","150000");
                put("SZ03","200000");
                put("SZ04","300000");
                put("SZ05","500000");
                put("SZ06","1000000");
                put("SZ07","1500000");
                put("SZ08","2000000");
                put("SZ09","2500000");
                put("SZ10","3000000");
                put("SZ11","3500000");
                put("SZ12","4000000");
                put("SZ13","4500000");
                put("SZ14","5000000");
                put("SZ15","10000000");
            }
        };
        /** 车商平台 -> 阳光 划痕，三者 保险金额 值->代码，映射 */
        public static Map<String, String> AMT_VALUE_TO_CODE_SZ = new HashMap<String, String>() {
            {
                //三者险
                put("100000","SZ01");
                put("150000","SZ02");
                put("200000","SZ03");
                put("300000","SZ04");
                put("500000","SZ05");
                put("1000000","SZ06");
                put("1500000","SZ07");
                put("2000000","SZ08");
                put("2500000","SZ09");
                put("3000000","SZ10");
                put("3500000","SZ11");
                put("4000000","SZ12");
                put("4500000","SZ13");
                put("5000000","SZ14");
                put("10000000","SZ15");
            }
        };
        /** 车商平台 -> 阳光 划痕，三者 保险金额 值->代码，映射 */
        public static Map<String, String> AMT_VALUE_TO_CODE_HH = new HashMap<String, String>() {
            {
                //划痕险
                put("2000.00","HH01");
                put("5000.00","HH02");
                put("10000.00","HH03");
                put("20000.00","HH04");
            }
        };

        /**
         * 阳光 -> 车商平台
         * 将保司订单状态映射为车商系统的订单状态
         * 阳光状态：0 转人工核保;3 打回修改;4 拒保;7 核保通过
         * 车商订单状态：1-核保中；2-已发送；3-验证失败；4-待支付；5-支付失败；6-已承保；7-核保失败；0-关闭
         */
        public static Map<String, String> ORDER_STATUS_TO_STANDARD = new HashMap<String, String>() {
            {
                put("0","1");
                put("3","7");
                put("4","0");// TODO 待确认
                put("7","4");
            }
        };

        /**
         * 车商平台 -> 阳光
         * 将车商平台的车辆来历凭证种类转换成阳光的车辆来历凭证种类
         * 车商凭证种类：01 销售发票;02 法院调解书;03 法院裁定书;04 法院判决书;05 仲裁裁决书;
         *            06 相关文书;07 批准文件;08 调拨证明;09:修理发票
         * 阳光凭证种类：01 销售发票;02 法院调解书;03 法院裁定书;04 法院判决书;05 仲裁裁决书;
         *            06 相关文书（继承、赠予、协议抵债）;07 批准文件;08 调拨证明
         */
        public static Map<String, String> CERTIFICATE_TYPE = new HashMap<String, String>() {
            {
                put("01", "01");
                put("02", "02");
                put("03", "03");
                put("04", "04");
                put("05", "05");
                put("06", "06");
                put("07", "07");
                put("08", "08");
                put("09","06"); // TODO 车商修理发票阳光无对应，暂用06替代
            }
        };


        /**
         * 请求 车商 -> 阳光
         * 将车商地区代码映射为保司系统地区代码
         * 车商地区代码：810000 香港特别行政区； 820000 澳门特别行政区； 710000 台湾省；
         */
        public static Map<String, String> AREA_CODE = new HashMap<String, String>(){
            {
                put("810000","");
                put("820000","");//TODO 待补充
                put("710000","");
            }
        };

        /**
         * 请求 车商 -> 阳光
         * 将车商保单类型/投保类型映射为保司系统保单类型/投保类型
         * 车商保单类型/投保类型：3 单保商业险； 2 单保交强险； 1 交商同保；
         * 阳光保单类型/投保类型：1 单保商业险； 2 单保交强险； 3 交商同保；
         */
        public static Map<String,String> POLICY_TYPE = new HashMap<String, String>(){
            {
                put("3","1"); //单保商业险
                put("2","2"); //单保交强险
                put("1","3"); //交商同保
            }
        };

        /**
         * 请求 车商 -> 阳光
         * 将车商号牌底色映射为阳光保司系统号牌底色
         * 车商号牌底色：1 蓝； 2 黑； 3 白； 4 黄； 5 白蓝； 6 渐变绿； 7 黄绿双拼； 99 其他；
         * 阳光号牌底色：01 蓝； 02 黑； 03 白； 04 黄； 05 白蓝； 06 渐变绿； 07 黄绿双拼； 99 其他；
         */
        public static Map<String,String> LICENSE_COLOR = new HashMap<String, String>(){
            {
                put("1","01"); //蓝
                put("2","02"); //黑
                put("3","03"); //白
                put("4","04"); //黄
                put("5","05"); //白蓝
                put("6","06"); //渐变绿  小型新能源汽车
                put("7","07"); //黄绿双拼  大型新能源汽车
            }
        };

        /**
         * 请求 车商 -> 阳光
         * 将车商车辆种类代码映射为保司系统车辆种类代码
         * 车商车辆种类代码：1 客车； 2 货车；
         * 阳光车辆种类代码：A0 客车； H0 载货机动车；
         */
        public static Map<String,String> VEHICLE_TYPE = new HashMap<String, String>(){
            {
                put("1","A0"); //客车  阳光：客车
                put("2","H0"); //货车  阳光：载货机动车
            }
        };

        /**
         * 请求 车商 -> 阳光
         * 将车商车辆类型描述映射为保司系统车辆类型描述
         * TODO: 待确定
         */
        public static Map<String,String> LICENSE_CATEGORY = new HashMap<String, String>(){
            {

            }
        };
    
        /**
         * 车商平台 -> 阳光
         * 将车商平台的能源/燃料种类转换成阳光的能源/燃料种类
         * 车商燃料种类：A 汽油；B 柴油；C 电；D 混合油；E 天然气；F 液化石油气；L 甲醇；
         *            M 乙醇；N 太阳能；O 混合动力；P 氢；Q 生物燃料；Y 无；Z 其他
         * 阳光燃料种类：0 燃油；1 纯电动；2 燃料电池；3 插电式混合动力；4 其他混合动力；A 汽油（北京专用）
         *            B 柴油（北京专用）；C 电（北京专用）；D 混合油（北京专用）；E 天然气（北京专用）；F 液化石油气（北京专用）
         *            L 甲醇（北京专用）；M 乙醇（北京专用）；N 太阳能（北京专用）；O 混合动力（北京专用）；Y 无（北京专用）；Z 其他（北京专用）
         */
        public static Map<String, String> FUEL_TYPE = new HashMap<String, String>() {
            {
                put("A", "0");
                put("B", "B");
                put("C", "1");
                put("D", "D");
                put("E", "E");
                put("F", "F");
                put("L", "L");
                put("M", "M");
                put("N", "N");
                put("O", "O");//　TODO　待确认　映射表中车商O对应阳光4、Ｏ
                put("P", "2");// TODO　待确认
                put("Q", "B");
                put("Y", "Y");
                put("Z", "Z");
            }
        };
    
        /**
         * 阳光 -> 车商
         * 将阳光车辆种类转换成车商车辆种类
         * 车商车辆种类：1 客车； 2 货车；
         * 阳光车辆种类：A0客车； H0 载货机动车；
         * TODO 待确认是否转码
         */
        public static Map<String, String> CAR_KIND = new HashMap<String, String>() {
            {
                put("A0","1"); //客车  阳光：客车
                put("H0","2"); //货车  阳光：载货机动车
            }
        };
    
        /**
         * 车商平台 -> 阳光
         * 将车商平台的关系人标志转换成阳光的关系人标志
         * 车商关系人标志：1-车主; 2-投保人; 3-被保险人
         * 阳光关系人标志：1-被保险人;2-投保人
         * TODO 需讨论，待确认
         */
        public static Map<String, String> INSURED_FLAG = new HashMap<String, String>() {
            {
                put("1", ""); // 车主 - ？
                put("2", "2"); // 投保人 - 投保人
                put("3", "1"); // 被保险人 - 被保险人
            }
        };
    
        /**
         * 阳光　->　车商平台
         * 将阳光的险种类型转换为车商平台的险种类型
         * 车商险种类型：1　交强险；2　商业险
         * 阳光险种类型：0507-交强；0528-商业
         */
        public static Map<String, String> RISK_CODE = new HashMap<String, String>() {
            {
                put("0507", "1"); // 交强 - 交强险
                put("0528", "2"); // 商业 - 商业险
            }
        };
    
        /**
         * 阳光　->　车商平台
         * 将阳光的核保结果转换为车商平台的核保结果
         * 车商核保结果：1 核保中; 4 待支付; 7 核保失败
         * 阳光核保结果：1	通过;2 失败;3 转人工核保（转人工判断由阳光规则系统处理）
         */
        public static Map<String, String> UNDER_WRITE_FLAG = new HashMap<String, String>() {
            {
                put("1", "4");// 通过 - 待支付
                put("2", "7");// 失败 - 核保失败
                put("3", "1");// 转人工核保 - 核保中
            }
        };
    
        /**
         * 阳光 -> 车商平台
         * 将阳光的保单即时生效标志转换为车商平台的保单即时生效标志
         * 车商保单即时生效标志：
         * 阳光保单即时生效标志：0-否；1-是
         * TODO 车商的正在商议，待补充
         */
        public static Map<String, String> IMMEVALID_FLAG = new HashMap<String, String>() {
            {
                put("0", "");// 否 - ？
                put("1", "");// 是 - ？
            }
        };
    
        /**
         * 车商平台 -> 阳光
         * 将车商平台险别代码转换为阳光险别代码2020版
         * 车商险别代码：100 机动车交通事故责任强制险； 0301200 机动车损失保险； 0301600 机动车第三者责任保险； 0301701 机动车车上人员责任保险（司机）
         *            0301702 机动车车上人员责任保险（乘客）； 0301260 附加新增加设备损失险； 0301230 附加修理期间费用补偿险；
         *            0301202 附加发动机进水损坏除外特约条款； 0301007 附加绝对免赔率特约条款（机动车损失保险）；
         *            0301008 附加绝对免赔率特约条款（机动车第三者责任保险）； 0301009 附加绝对免赔率特约条款（机动车车上人员责任保险（司机））；
         *            0301010 附加绝对免赔率特约条款（机动车车上人员责任保险（乘客））； 0301601 附加车上货物责任险；
         *            0301610 附加精神损害抚慰金责任险（机动车第三者责任保险）； 0301611 附加精神损害抚慰金责任险（机动车车上人员责任保险（司机））；
         *            0301612 附加精神损害抚慰金责任险（机动车车上人员责任保险（乘客））； 0301210 附加车身划痕损失险；
         *            0301232 附加车轮单独损失险； 0301604 附加法定节假日限额翻倍险； 0301002 附加医保外医疗费用责任险（机动车第三者责任保险）；
         *            0301011 附加医保外医疗费用责任险（机动车车上人员责任保险（司机））； 0301012 附加医保外医疗费用责任险（机动车车上人员责任保险（乘客））；
         *            0301003 道路救援服务特约条款； 0301004 车辆安全检测特约条款； 0301005 代为驾驶服务特约条款；
         *            0301006 代为送检服务特约条款；
         * 阳光险别代码：20A 机动车损失保险（2020条款）； 20B 第三者责任保险（2020条款）； 20C1 驾驶员车上人员责任保险（2020条款）；
         *            20C2 乘客车上人员责任保险（2020条款）； 20F1 新增加设备损失险（2020条款）；
         *            20F2 修理期间费用补偿险（2020条款）； 20FJ 附加发动机进水损坏除外特约条款（2020条款）；
         *            20FD 车损险事故免赔率特约条款 （2020条款）； 20FE 三者险事故免赔率特约条款 （2020条款）；
         *            20FF 司机车上人员事故免赔率特约条款 （2020条款）； 20FG 乘客车上人员事故免赔率特约条款 （2020条款）；
         *            20F5 车上货物责任险（2020条款）； 20F6 精神损害抚慰金责任险（2020条款） 附加三者精神损害抚慰金责任险（2020条款）
         *            20FS 附加司机车上人员精神损害抚慰金责任险（2020条款）； 20FT 附加乘客车上人员精神损害抚慰金责任险（2020条款）；
         *            20F7 车身划痕损失险（2020条款）； 20F8 轮胎单独破损险（2020条款）； 20FA 机动车第三者责任保险法定节假日限额翻倍险（2020条款）；
         *            20FH 附加三者医保外医疗费用责任险（2020条款）； 20FQ 附加司机车上人员医保外医疗费用责任险（2020条款）；
         *            20FR 附加乘客车上人员医保外医疗费用责任险（2020条款）； 20FI 附加机动车增值服务特约条款（2020条款）；
         *            20FK 附加道路救援服务特约条款（2020条款）； 20FL 附加车辆安全检测特约条款（2020条款）；
         *            20FM 附加代为驾驶服务特约条款（2020条款）； 20FN 附加代为送检服务特约条款（2020条款）；
         */
        public static Map<String, String> KIND_CODE = new HashMap<String, String>(){
            {
                put("100","20BZ");
                put("0301200","20A");
                put("0301600","20B");
                put("0301701","20C1");
                put("0301702","20C2");
                put("0301260","20F1");
                put("0301230","20F2");
                put("0301202","20FJ");
                put("0301007","20FD");
                put("0301008","20FE");
                put("0301009","20FF");
                put("0301010","20FG");
                put("0301601","20F5");
                put("0301610","20F6"); //TODO 20F6 待确定
                put("0301611","20FS");
                put("0301612","20FT");
                put("0301210","20F7");
                put("0301232","20F8");
                put("0301604","20FA");
                put("0301002","20FH");
                put("0301011","20FQ");
                put("0301012","20FR");
                put("","20FI");        //TODO 车商暂无
                put("0301003","20FK");
                put("0301004","20FL");
                put("0301005","20FM");
                put("0301006","20FN");
            }
        };
    }

}

