package com.sinosoft.car.utils.contants;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
public class TPICConstants {
    /**
     * 保险公司编码
     */
    public static final String INSURER_CODE = "000026";

    public static final String INSURER_NAME = "太平财险保险有限公司";

    public static String defaultCharset = "UTF-8";

    public static final String INSURER_RISK_CODE_CI = "BZ";

    public static final String INSURER_RISK_CODE_BI = "BS";//保司 -商业险险种代码
    
    /** 配置文件中的 url 地址，根据生产环境或者测试环境配置 */
    @Value("${tpicUrl}")
    public String tpicUrl ;
    
    @Value("${tpicKey}")
    public String tpicKey ;
    
    @Value("${tpicClientName}")
    public String tpicClientName;

    @PostConstruct
    public void init() {
        InterfaceUrl.TGBX_URL = this.tpicUrl;
        InterfaceUrl.TGBX_CLIENT_NAME = this.tpicClientName;
        InterfaceUrl.TGBX_KEY = this.tpicKey;
    }

    /**
     * 保司接口地址
     */
    public static class InterfaceUrl {
        /** 配置文件中的地址 */
        public static String TGBX_URL;
        /** 商户号 **/
        public static String TGBX_CLIENT_NAME;
        /** 加签 */
        public static String TGBX_KEY;
   }

    /**
     * 支付成功回调地址-(支付登记接口时使用)
     */
    public static final String payCall = "<![CDATA[https://testbxgj.qyccar.com/success]]>";

    /**
     * 车型查询接口地址名称
     */
    public static String carType = "carType";
    /**
     * 保存订单车辆信息接口地址名称
     */
    public static String saveOrderVehicle = "saveOrderVehicle";
    /**
     * 确认投保接口地址名称
     */
    public static String insConfirm = "insConfirm";
    /**
     * 支付登记接口地址名称
     */
    public static String paymentRegister = "paymentRegister";
    /**
     * 自选方案报价接口地址名称
     */
    public static String premiumCalculate = "premiumCalculate";
    /**
     * 北京验证码获取接口接口地址名称
     */
    public static String securityAcquire = "securityAcquire";
    /**
     * 北京验证码校验接口接口地址名称
     */
    public static String securityVerify = "securityVerify";
    /**
     * 北京新车备案接口接口地址名称
     */
    public static String bjNewCarRegister = "bjNewCarRegister";
    /**
     * 再次投保
     */
    public static String continueInsConfirm = "continueInsConfirm";
    /**
     * 上传影像接口
     */
    public static String uploadImg = "uploadImg";
    public static final String OSS_VIDEO_UPLOAD_DIR = "客户影像资料/videoUpload/000026/";//影像上传OSS的地址
    /**
     * 订单查询详情
     */
    public static String orderList = "orderList";

    /**
     * 电子保单下载
     */
    public static String downElecPolicy = "downElecPolicy";

    /**
     * 交互成功
     */
    public static String SUCCESS = "S";


    /**
     * 交管车辆类型
     *
     * @param key
     * @return
     */
    public static String getVehicleCategory(String key) {
        Map<String, String> map = new HashMap<String, String>();
        map.put("K11", "K11");
        map.put("K12", "K12");
        map.put("K13", "K13");
        map.put("K14", "K14");
        map.put("K15", "K15");
        map.put("K21", "K21");
        map.put("K22", "K22");
        map.put("K23", "K23");
        map.put("K24", "K24");
        map.put("K25", "K25");
        map.put("K31", "K31");
        map.put("K32", "K32");
        map.put("K33", "K33");
        map.put("K41", "K41");
        map.put("K42", "K42");
        map.put("K43", "K43");

        return map.get(key);
    }

    public static String getEnergyType(String key) {
        Map<String, String> map = new HashMap<String, String>();
        map.put("A", "A");
        map.put("B", "B");
        map.put("C", "C");
        map.put("D", "D");
        map.put("E", "E");
        map.put("F", "F");
        map.put("L", "L");
        map.put("M", "M");
        map.put("N", "N");
        map.put("O", "O");
        map.put("Y", "Y");
        map.put("Z", "Z");
        return map.get(key);
    }

    /**
     * 证件类型
     *
     * @param key
     * @return
     */
    public static String getIdentifyType(String key) {
        Map<String, String> map = new HashMap<String, String>();
        map.put("111", "01");
        map.put("114", "03");
        map.put("414", "07");

        return map.get(key);
    }

    /**
     * 险种代码【请求】
     * 车商->太平
     *
     * @param key
     * @return TODO 保司没有对应交商同保代码映射
     */
    public static String getRiskCode(String key) {
        Map<String, String> map = new HashMap<String, String>();
        map.put("2", "BZ");//交强险
        map.put("3", "BS");//商业险
        /**
         * 保司没有对应交商同保代码映射
         */
        //map.put("1", "");//交商同保

        return map.get(key);
    }

    /**
     * 险种代码【返回】
     * 太平->车商 将太平险种代码转为车商平台的险种代码
     *
     * @param key
     * @return TODO 保司没有对应交商同保代码映射
     */
    public static String getRiskCode2(String key) {
        Map<String, String> map = new HashMap<String, String>();
        map.put("BZ", "2");//交强险
        map.put("BS", "3");//商业险
        /**
         * 保司没有对应交商同保代码映射
         */
        //map.put("", "1");//交商同保
        return map.get(key);
    }

    /**
     * 险种代码：0801、0802【返回】
     * 【支付登记】
     * 太平->车商
     *
     * @param key
     * @return TODO 保司没有对应交商同保代码映射
     */
    public static String getRiskCode3(String key) {
        Map<String, String> map = new HashMap<String, String>();
        map.put("0801", "2");//交强险
        map.put("0802", "3");//商业险
        /**
         * 保司没有对应交商同保代码映射
         */
        //map.put("", "1");//交商同保

        return map.get(key);
    }

    /**
     * 险别代码【请求】
     * 车商->太平
     *
     * @param key
     * @return
     */
    public static String getKindCode(String key) {
        Map<String, String> map = new HashMap<String, String>();
        //主险
        map.put("100", "BZ");//机动车交通事故责任强制险
        map.put("0301200", "0301200");//机动车损失保险
        map.put("0301600", "0301600");//机动车第三者责任保险
        map.put("0301701", "0301701");//机动车车上人员责任保险（司机）
        map.put("0301702", "0301702");//机动车车上人员责任保险（乘客）
        //附加险
        map.put("0301210", "0301210");//附加车身划痕损失险
        map.put("0301230", "0301230");//附加修理期间费用补偿险
        map.put("0301202", "0301202");//附加发动机进水损坏除外特约条款
        map.put("0301232", "0301232");//车轮单独损失险
        map.put("0301610", "0301610");//精神抚慰金责任险（第三者）
        map.put("0301611", "0301611");//精神抚慰金责任险（司机）
        map.put("0301612", "0301612");//精神抚慰金责任险（乘客）
        map.put("0301604", "0301604");//附加法定节假日限额翻倍险
        map.put("0301002", "0301002");//医保外医疗费用责任险（第三者）
        map.put("0301011", "0301011");//医保外医疗费用责任险（司机）
        map.put("0301012", "0301012");//医保外医疗费用责任险（司机）
        map.put("0301003", "0301003");//道路救援服务特约险
        map.put("0301004", "0301004");//车辆安全检测特约险
        map.put("0301005", "0301005");//代为驾驶服务特约险
        map.put("0301007", "0301007");//绝对免赔率特约险（机动车损失保险）
        map.put("0301008", "0301008");//绝对免赔率特约险（机动车第三者责任保险）
        map.put("0301009", "0301009");//绝对免赔率特约险（机动车车上人员责任保险（司机））
        map.put("0301010", "0301010");//绝对免赔率特约险（机动车车上人员责任保险（乘客））
        /**
         * 保司代码待传
         */
        map.put("0301260", "");//附加新增加设备损失险
        map.put("0301601", "");//附加车上货物责任险

        return map.get(key);
    }

    /**
     * 险别代码【返回】
     * 太平->车商
     *
     * @param key
     * @return
     */
    public static String getKindCode2(String key) {
        Map<String, String> map = new HashMap<String, String>();
        //主险
        map.put("BZ", "100");//机动车交通事故责任强制险
        map.put("0301200", "0301200");//机动车损失保险
        map.put("0301600", "0301600");//机动车第三者责任保险
        map.put("0301701", "0301701");//机动车车上人员责任保险（司机）
        map.put("0301702", "0301702");//机动车车上人员责任保险（乘客）
        //附加险
        map.put("0301210", "0301210");//附加车身划痕损失险
        map.put("0301230", "0301230");//附加修理期间费用补偿险
        map.put("0301202", "0301202");//附加发动机进水损坏除外特约条款
        map.put("0301232", "0301232");//车轮单独损失险
        map.put("0301610", "0301610");//精神抚慰金责任险（第三者）
        map.put("0301611", "0301611");//精神抚慰金责任险（司机）
        map.put("0301612", "0301612");//精神抚慰金责任险（乘客）
        map.put("0301604", "0301604");//附加法定节假日限额翻倍险
        map.put("0301002", "0301002");//医保外医疗费用责任险（第三者）
        map.put("0301011", "0301011");//医保外医疗费用责任险（司机）
        map.put("0301012", "0301012");//医保外医疗费用责任险（司机）
        map.put("0301003", "0301003");//道路救援服务特约险
        map.put("0301004", "0301004");//车辆安全检测特约险
        map.put("0301005", "0301005");//代为驾驶服务特约险
        map.put("0301007", "0301007");//绝对免赔率特约险（机动车损失保险）
        map.put("0301008", "0301008");//绝对免赔率特约险（机动车第三者责任保险）
        map.put("0301009", "0301009");//绝对免赔率特约险（机动车车上人员责任保险（司机））
        map.put("0301010", "0301010");//绝对免赔率特约险（机动车车上人员责任保险（乘客））

        return map.get(key);
    }

    /**
     * 是否过户车【请求】
     * 太平->车商
     *
     * @param key
     * @return
     */
    public static String getChgOwnerFlag(String key) {
        Map<String, String> map = new HashMap<String, String>();
        map.put("0", "0");//非过户车
        map.put("1", "1");//投保过户

        return map.get(key);
    }

    /**
     * 是否过户车【返回】
     * 太平->车商
     * 注意：保司返回代码与请求代码不同，需注意
     *
     * @param key
     * @return
     */
    public static String getChgOwnerFlag2(String key) {
        Map<String, String> map = new HashMap<String, String>();
        map.put("0", "0");//非过户车
        map.put("01", "1");//投保过户

        return map.get(key);
    }

    /**
     * 商业过户车标识【请求】
     * 车商->太平
     *
     * @param key
     * @return
     */
    public static String getBsChgOwnerFlag(String key) {
        Map<String, String> map = new HashMap<String, String>();
        map.put("0", "0");//非过户车
        map.put("1", "1");//投保过户

        return map.get(key);
    }

    /**
     * 交强过户车标识【请求】
     * 车商->太平
     *
     * @param key
     * @return
     */
    public static String getBzChgOwnerFlag(String key) {
        Map<String, String> map = new HashMap<String, String>();
        map.put("0", "0");//非过户车
        map.put("1", "1");//投保过户

        return map.get(key);
    }

    /**
     * 是否贷款车【请求】
     * 车商->太平
     *
     * @param key
     * @return
     */
    public static String getLoanVehicleFlag(String key) {
        Map<String, String> map = new HashMap<String, String>();
        map.put("0", "0");//否
        map.put("1", "1");//是

        return map.get(key);
    }

    /**
     * 是否贷款车【返回】
     * 太平->车商
     *
     * @param key
     * @return
     */
    public static String getLoanVehicleFlag2(String key) {
        Map<String, String> map = new HashMap<String, String>();
        map.put("0", "0");//否
        map.put("1", "1");//是

        return map.get(key);
    }

    /**
     * 车辆种类【返回】
     * 太平->车商
     *
     * @param key
     * @return
     */
    public static String getCarKindCode2(String key) {
        Map<String, String> map = new HashMap<String, String>();
        map.put("100", "1");//客车
        map.put("200", "2");//货车

        return map.get(key);
    }

    /**
     * 车辆种类【请求】
     * 车商->太平
     *
     * @param key
     * @return
     */
    public static String getCarKindCode(String key) {
        Map<String, String> map = new HashMap<String, String>();
        map.put("1", "100");//客车
        map.put("2", "200");//货车

        return map.get(key);
    }

    /**
     * 性别【请求】
     * 车商->太平
     *
     * @param key
     * @return TODO 车商平台性别没有未知字段代码，待传
     */
    public static String getSex(String key) {
        Map<String, String> map = new HashMap<String, String>();
        map.put("1", "1");//男性
        map.put("0", "2");//女性
        //map.put("", "0");//？未知的性别

        return map.get(key);
    }

    /**
     * 性别【返回】
     * 太平->车商
     *
     * @param key
     * @return TODO 车商平台性别没有未知字段代码，待传
     */
    public static String getSex2(String key) {
        Map<String, String> map = new HashMap<String, String>();
        map.put("1", "1");//男性
        map.put("2", "0");//女性
//        map.put("0", "");//？未知的性别

        return map.get(key);
    }

    /**
     * 号牌颜色【返回】
     * 太平->车商
     *
     * @param key
     * @return TODO 车商平台绿色，待传
     */
    public static String getLicenseColorCode2(String key) {
        Map<String, String> map = new HashMap<String, String>();
        map.put("01", "1");//蓝色
        map.put("02", "4");//黄色
        map.put("03", "2");//黑色
        map.put("04", "3");//白色
        map.put("05", "");//绿色
        map.put("06", "5");//白蓝
        map.put("07", "6");//渐变绿
        map.put("08", "7");//黄绿双拼
        map.put("99", "99");//其他

        return map.get(key);
    }

    /**
     * 号牌颜色【请求】
     * 车商->太平
     *
     * @param key
     * @return TODO 车商平台绿色，待传
     */
    public static String getLicenseColorCode(String key) {
        Map<String, String> map = new HashMap<String, String>();
        map.put("1", "01");//蓝色
        map.put("4", "02");//黄色
        map.put("2", "03");//黑色
        map.put("3", "04");//白色
        map.put("", "05");//绿色
        map.put("5", "06");//白蓝
        map.put("6", "07");//渐变绿
        map.put("7", "08");//黄绿双拼
        map.put("99", "99");//其他

        return map.get(key);
    }

    /**
     * 能源种类【请求】
     * 车商->太平
     *
     * @param key
     * @return TODO
     */
    public static String getFuelType(String key) {
        Map<String, String> map = new HashMap<String, String>();
        map.put("A", "A");//汽油
        map.put("B", "B");//柴油
        map.put("C", "C");//电
        map.put("D", "D");//混合油
        map.put("E", "E");//天燃气
        map.put("F", "F");//液化石油气
        map.put("L", "L");//甲醇
        map.put("M", "M");//乙醇
        map.put("N", "N");//太阳能
        map.put("O", "O");//混合动力
        map.put("Y", "Y");//无
        map.put("Z", "Z");//其他
        map.put("P", "");//氢
        map.put("Q", "");//生物燃料

        return map.get(key);
    }

    /**
     * 能源种类【返回】
     * 太平->车商
     *
     * @param key
     * @return TODO
     */
    public static String getFuelType2(String key) {
        Map<String, String> map = new HashMap<String, String>();
        map.put("A", "A");//汽油
        map.put("B", "B");//柴油
        map.put("C", "C");//电
        map.put("D", "D");//混合油
        map.put("E", "E");//天燃气
        map.put("F", "F");//液化石油气
        map.put("L", "L");//甲醇
        map.put("M", "M");//乙醇
        map.put("N", "N");//太阳能
        map.put("O", "O");//混合动力
        map.put("Y", "Y");//无
        map.put("Z", "Z");//其他
        map.put("", "P");//氢
        map.put("", "Q");//生物燃料

        return map.get(key);
    }
    /**
     * 审核标志【返回】
     * 太平->车商
     *
     * @param key
     * @return TODO 车商平台审核标志，待传
     */
    public static String getUnderWriteInd(String key) {
        Map<String, String> map = new HashMap<String, String>();
        map.put("1", "");//双核审核通过
        map.put("2", "");//下发修改
        map.put("3", "");//双核审核自动通过
        map.put("4", "");//拒保
        map.put("5", "");//复核通过
        map.put("6", "");//承保成功
        map.put("7", "");//复核不通过
        map.put("8", "");//待复核
        map.put("9", "");//待双核审核

        return map.get(key);
    }

    /**
     * 实名认证模式【返回】
     * 太平->车商
     *
     * @param key
     * @return TODO 车商平台实名认证模式，待传
     */
    public static String getCheckInd(String key) {
        Map<String, String> map = new HashMap<String, String>();
        map.put("0", "");//不校验
        map.put("1", "");//商户校验
        map.put("2", "");//江苏平台实名校验
        map.put("3", "");//保信平台实名认证
        map.put("4", "");//深圳实名认证

        return map.get(key);
    }

    /**
     * 查询所有城市标识【请求】
     * 车商->太平
     *
     * @param key
     * @return TODO 车商平台查询所有城市标识，待传
     */
    public static String getAllCity(String key) {
        Map<String, String> map = new HashMap<String, String>();
        map.put("", "0");//否
        map.put("", "1");//是

        return map.get(key);
    }

    /**
     * 费改地区标识【返回】
     * 太平->车商
     *
     * @param key
     * @return TODO 车商平台费改地区标识，待传
     */
    public static String getFGInd(String key) {
        Map<String, String> map = new HashMap<String, String>();
        map.put("0", "");//否
        map.put("1", "");//是

        return map.get(key);
    }

    /**
     * 是否可以直接报价【返回】
     * 太平->车商
     *
     * @param key
     * @return TODO 车商平台是否可以直接报价，待传
     */
    public static String getStatus(String key) {
        Map<String, String> map = new HashMap<String, String>();
        map.put("0", "");//可以
        map.put("1", "");//不可以

        return map.get(key);
    }

    /**
     * 是否录入行驶证使用性质标志【返回】
     * 太平->车商
     *
     * @param key
     * @return TODO 车商平台是否录入行驶证使用性质标志，待传
     */
    public static String getUseTypeFlag(String key) {
        Map<String, String> map = new HashMap<String, String>();
        map.put("1", "");//是
        map.put("2", "");//否

        return map.get(key);
    }

    /**
     * 是否4S店销售
     * 【有问题，待议】
     *
     * @param key
     * @return TODO 是否4S店销售，待传
     */
    public static String getsale4SFlag(String key) {

        return null;
    }

    /**
     * 号牌种类【请求】
     *
     * 太平->车商
     *
     * @param key
     * @return TODO 车商平台号牌种类，待传
     */
    public static String getLicenseTypeCode(String key) {
        Map<String, String> map = new HashMap<String, String>();
        map.put("", "01");//大型汽车
        map.put("", "02");//小型汽车
        map.put("", "03");//使馆汽车
        map.put("", "04");//领馆汽车
        map.put("", "05");//境外汽车
        map.put("", "06");//外籍汽车
        map.put("", "07");//两、三轮汽车
        map.put("", "08");//轻便摩托车
        map.put("", "09");//使馆摩托车
        map.put("", "10");//领馆摩托车
        map.put("", "11");//境外摩托车
        map.put("", "12");//外籍摩托车
        map.put("", "13");//农用运输车
        map.put("", "14");//拖拉机
        map.put("", "15");//挂车
        map.put("", "17");//教练摩托车
        map.put("", "18");//实验汽车
        map.put("", "19");//实验摩托车
        map.put("", "20");//临时入境汽车
        map.put("", "21");//临时入境摩托车
        map.put("", "22");//临时行驶车
        map.put("", "31");//公安警用汽车
        map.put("", "32");//公安民用汽车
        map.put("", "33");//公安警用摩托车
        map.put("", "36");//武警车牌
        map.put("", "37");//军队号牌
        map.put("", "51");//大型新能源汽车
        map.put("", "52");//小型新能源汽车
        map.put("", "99");//其他
        map.put("", "24");//其他车型

        return map.get(key);
    }
    /**
     * 新旧车标志【返回】
     * 太平->车商
     *
     * @param key
     * @return TODO 车商平台新旧车标志，待传
     */
//    public static String getCarNewOldFlag(String key) {
//        Map<String, String> map = new HashMap<String, String>();
//        map.put("N", "");//新车
//        map.put("O", "");//旧车
//
//        return map.get(key);
//    }
    /**
     * 投保保险公司【返回】
     * 太平->车商
     *
     * @param key
     * @return TODO 黄河财产保险股份有限公司,融盛财产保险股份有限公司 待传
     */
    public static String getPayCompany(String key) {
        Map<String, String> map = new HashMap<String, String>();
        map.put("AAIC", "000064");//安信农业保险股份有限公司
        map.put("ABIC", "000159");//安邦财产保险股份有限公司
        map.put("ACIC", "000110");//安信农业保险股份有限公司
        map.put("AHIC", "000075");//安华农业保险股份有限公司
        map.put("AICS", "000068");//永诚财产保险股份有限公司
        map.put("BOCI", "000046");//中银保险有限公司
        map.put("BPIC", "000098");//渤海财产保险股份有限公司
        map.put("CAIC", "000112");//长安责任保险股份有限公司
        map.put("CCIC", "000010");//中国大地财产保险股份有限公司
        map.put("CICP", "000012");//中华联合财产保险股份有限公司
        map.put("CPIC", "000014");//中国太平洋财产保险股份有限公司
        map.put("DBIC", "000096");//都邦财产保险股份有限公司
        map.put("DICC", "000023");//史带财产保险股份有限公司
        map.put("GPIC", "000108");//中国人寿财产保险股份有限公司
        map.put("HNIC", "000101");//华农财产保险股份有限公司
        map.put("HTIC", "000154");//华泰财产保险有限公司
        map.put("MACN", "000038");//亚太财产保险有限公司
        map.put("PAIC", "000017");//中国平安财产保险股份有限公司
        map.put("PICC", "000002");//中国人民财产保险股份有限公司
        map.put("SMIC", "000094");//阳光农业相互保险公司
        map.put("TAIC", "000022");//天安财产保险股份有限公司
        map.put("TPBX", "000078");//安盛天平财产保险股份有限公司
        map.put("TPIC", "000026");//太平财产保险有限公司
        map.put("YAIC", "000025");//永安财产保险股份有限公司
        map.put("YGBX", "000093");//阳光财产保险股份有限公司
        map.put("ZSIC", "000140");//浙商财产保险股份有限公司
        map.put("ZKIC", "000137");//紫金财产保险股份有限公司
        map.put("JTIC", "000149");//锦泰财产保险股份有限公司
        map.put("AIGC", "000039");//美亚财产保险有限公司
        map.put("AMIC", "000067");//中航安盟财产保险有限公司
        map.put("AZCN", "000050");//安联财产保险（中国）有限公司
        map.put("CATH", "000133");//国泰财产保险有限责任公司
        map.put("CHAC", "000158");//诚泰财产保险股份有限公司
        map.put("CJCX", "000120");//长江财产保险股份有限公司
        map.put("DHIC", "000129");//鼎和财产保险股份有限公司
        map.put("FPIC", "000146");//富邦财产保险有限公司
        map.put("GYIC", "000126");//国元农业保险股份有限公司
        map.put("LIHI", "000060");//利宝保险有限公司
        map.put("SPIC", "000045");//三星财产保险（中国）有限公司
        map.put("TMNF", "000040");//东京海上日动火灾保险（中国）有限公司
        map.put("TSBX", "000148");//泰山财产保险股份有限公司
        map.put("UTIC", "0000151");//众诚汽车保险股份有限公司
        map.put("XDCX", "000142");//信达财产保险股份有限公司
        map.put("YDCX", "000121");//英大泰和财产保险股份有限公司
        map.put("ZMBX", "000132");//中煤财产保险股份有限公司
        map.put("ZYIC", "000117");//中意财产保险有限公司
        map.put("CRIC", "000163");//富德财产保险股份有限公司
        map.put("SJIC", "000053");//日本财产保险（中国）有限公司
        map.put("XAIC", "0000165");//鑫安汽车保险股份有限公司
        map.put("HYIC", "000111");//现代财产保险（中国）有限公司
        map.put("BGIC", "000173");//北部湾财产保险股份有限公司
        map.put("MSIC", "000044");//三井住友海上火灾保险（中国）有限公司
        map.put("HBIC", "000178");//恒邦财产保险股份有限公司
        map.put("HHBX", "000183");//华海财产保险股份有限公司
        map.put("YZIC", "000185");//燕赵财产保险股份有限公司
        map.put("ZYBX", "000195");//中原农业保险股份有限公司
        map.put("ZLIC", "000192");//中路财产保险股份有限公司
        map.put("JLIC", "000206");//久隆财产保险有限公司
        map.put("QHIC", "000208");//新疆前海联合财产保险股份有限公司
        map.put("ZFIC", "000209");//珠峰财产保险股份有限公司
        map.put("HGIC", "000210");//海峡金桥财产保险股份有限公司
        map.put("APIC", "000203");//安心财产保险有限责任公司
        map.put("ULIC", "000189");//合众财产保险股份有限公司
        map.put("CRCI", "000196");//中国铁路财产保险自保有限公司
        map.put("ZAPA", "000179");//众安在线财产保险股份有限公司
        map.put("TKIC", "000199");//泰康在线财产保险股份有限公司
        map.put("CCBP", "000207");//建信财产保险有限公司
        map.put("EAIC", "000205");//易安财产保险股份有限公司
        map.put("YPIC", "");//黄河财产保险股份有限公司
        map.put("MPIC", "");//融盛财产保险股份有限公司

        return map.get(key);
    }

    /**
     * 费率系数因子代码/系数因子名称【返回】
     * 【profitCode/profitName】
     * 太平->车商
     *
     * @param key
     * @return TODO 车商平台费率系数因子代码/系数因子名称，待传
     */
//    public static String getProfitCode(String key) {
//        Map<String, String> map = new HashMap<String, String>();
//        map.put("A", "");//违反交通信号灯等
//        map.put("B1", "");//超速10%以上但未达50%等
//        map.put("B2", "");//超速超过50%等
//        map.put("C", "");//载物超过核定载质量等
//        map.put("D", "");//不按规定安装机动车号牌等
//        map.put("E", "");//未取得驾驶证、被吊销、暂扣、丢失或者损毁期间驾驶机动车等
//        map.put("F1", "");//饮酒后驾驶机动车等
//        map.put("F2", "");//醉酒后驾驶机动车、毒驾等
//        map.put("G", "");//交通事故后逃逸等
//        map.put("H", "");//未按规定使用安全带、驾驶时拨打或接听电话、未参加定期安全技术检验、载人超过核定载人数、
//        // 违反交通标线或标志、违反规定停放车辆、逆向行驶等其他违法类型
//        map.put("O", "");//无违法信息
//        map.put("qt", "");//其他违法类型
//        map.put("Z", "");//不参与上浮的违法类型
//
//        return map.get(key);
//    }

    /**
     * 浮动调整系数【返回】
     * 太平->车商
     *
     * @param key
     * @return TODO 车商平台浮动调整系数，待传
     */
//    public static String getRate(String key) {
//        Map<String, String> map = new HashMap<String, String>();
//        map.put("A", "");//累计3次，浮动系数为5%
//        //累计4次，浮动系数为10%
//        //累计5次及以上，浮动系数为15%
//        map.put("B1", "");//累计3次，浮动系数为5%
//        //累计4次，浮动系数为10%
//        //累计5次及以上，浮动系数为15%
//        map.put("B2", "");//1次及以上的，浮动系数为15%
//        map.put("C", "");//1次及以上的，浮动系数为5%
//        map.put("D", "");//1次及以上的，浮动系数为30%
//        map.put("E", "");//1次及以上的，浮动系数为25%
//        map.put("F1", "");//1次及以上的，浮动系数为10%
//        map.put("F2", "");//1次及以上的，浮动系数为30%
//        map.put("G", "");//1次及以上的，浮动系数为25%
//        map.put("H", "");//累计10-19(含)次的，浮动系数为5%
//        //累计20-29(含)次的，浮动系数为10%
//        //累计30次及以上的，浮动系数为15%
//        map.put("O", "");//下浮10%
//        map.put("qt", "");//不参与浮动，有此类违法系数不下浮
//        map.put("Z", "");//不上浮
//
//        return map.get(key);
//    }

    /**
     * 短信类型【请求】
     * 车商->太平
     *
     * @param key
     * @return TODO 车商短信类型，待传
     */
//    public static String getSmsType(String key) {
//        Map<String, String> map = new HashMap<String, String>();
//        map.put("", "sl");//深圳双录短信
//        map.put("", "SMDX");//实名短信
//        map.put("", "DZTB");//电子投保单短信
//
//        return map.get(key);
//    }

    /**
     * 交易类型
     * 【实名认证接口】【支付回调】
     * 车商->太平 将车商平台的交易类型转为太平交易类型
     *
     * @param key
     * @return TODO 车商交易类型，待传
     */
//    public static String getTradeType(String key) {
//        Map<String, String> map = new HashMap<String, String>();
//        map.put("", "03");//银行卡
//        map.put("", "ZFB");//支付宝
//        map.put("", "WX");//微信支付
//
//        return map.get(key);
//    }

    /**
     * 撤销类型【请求】
     * 车商->太平
     *
     * @param key
     * @return TODO 车商撤销类型，待传
     */
//    public static String getCancelType(String key) {
//        Map<String, String> map = new HashMap<String, String>();
//        map.put("", "0");//撤销支付登记及投保
//        map.put("", "1");//撤销支付登记
//        map.put("", "2");//撤销投保
//
//        return map.get(key);
//    }

    /**
     * 车辆来历凭证种类【请求】
     * 车商->太平
     *
     * @param key
     * @return
     */
    public static String getCertificateType(String key) {
        Map<String, String> map = new HashMap<String, String>();
        map.put("01", "01");//销售发票
        map.put("02", "02");//法院调解书
        map.put("03", "03");//法院裁定书
        map.put("04", "04");//法院判定书
        map.put("05", "05");//仲裁裁决书
        map.put("06", "06");//相关文书（继承、赠予、协议抵债）
        map.put("07", "07");//批准文件
        map.put("08", "08");//调拨证明
        map.put("09", "09");//修理发票

        return map.get(key);
    }

    /**
     * 单证类型【返回】
     * 太平->车商
     *
     * @param key
     * @return TODO 车商平台单证类型，待传
     */
//    public static String getElectronInvoice(String key) {
//        Map<String, String> map = new HashMap<String, String>();
//        map.put("0", "");//电子保单
//        map.put("1", "");//电子发票
//
//        return map.get(key);
//    }

    /**
     * 即时生效类型【返回】
     * 太平->车商
     *
     * @param key
     * @return TODO 车商平台即时生效类型，待传
     */
//    public static String getImmEffectType(String key) {
//        Map<String, String> map = new HashMap<String, String>();
//        map.put("0", "");//不是
//        map.put("1", "");//是
//
//        return map.get(key);
//    }

    /**
     * 是否电子投保单【返回】
     * 太平->车商
     *
     * @param key
     * @return TODO 车商平台即时生效类型，待传
     */
//    public static String getIsElecInsurance(String key) {
//        Map<String, String> map = new HashMap<String, String>();
//        map.put("0", "");//否
//        map.put("1", "");//是
//
//        return map.get(key);
//    }

    /**
     * 电子投保单签字状态【返回】
     * 太平->车商
     *
     * @param key
     * @return TODO 车商平台即时生效类型，待传
     */
//    public static String getElecSignStatus(String key) {
//        Map<String, String> map = new HashMap<String, String>();
//        map.put("0", "");//否
//        map.put("1", "");//是
//
//        return map.get(key);
//    }

    /**
     * 是否允许补签【返回】
     * 太平->车商
     *
     * @param key
     * @return TODO 车商平台是否允许补签，待传
     */
//    public static String getIsCapableReplenishSign(String key) {
//        Map<String, String> map = new HashMap<String, String>();
//        map.put("0", "");//否
//        map.put("1", "");//是
//
//        return map.get(key);
//    }

    /**
     * 电子投保单短信是否已发送【返回】
     * 太平->车商
     *
     * @param key
     * @return TODO 车商平台电子投保单短信是否已发送，待传
     */
//    public static String getIsSend(String key) {
//        Map<String, String> map = new HashMap<String, String>();
//        map.put("0", "");//否
//        map.put("1", "");//是
//
//        return map.get(key);
//    }

    /**
     * 是否需要实名短信认证【返回】
     * 太平->车商
     *
     * @param key
     * @return TODO 车商平台是否需要实名短信认证，待传
     */
//    public static String getIsNeedSM(String key) {
//        Map<String, String> map = new HashMap<String, String>();
//        map.put("0", "");//否
//        map.put("1", "");//是
//
//        return map.get(key);
//    }

    /**
     * 是否已经完成实名信认证【返回】
     * 太平->车商
     *
     * @param key
     * @return TODO 车商平台是否已经完成实名信认证，待传
     */
//    public static String getIsFinishSM(String key) {
//        Map<String, String> map = new HashMap<String, String>();
//        map.put("0", "");//否
//        map.put("1", "");//是
//
//        return map.get(key);
//    }

    /**
     * 是否需要走北京身份证采集（验证码）流程【返回】
     * 太平->车商
     *
     * @param key
     * @return TODO 车商平台是否需要走北京身份证采集（验证码）流程，待传
     */
//    public static String getBjVerificationCodeFlag(String key) {
//        Map<String, String> map = new HashMap<String, String>();
//        map.put("0", "");//否
//        map.put("1", "");//是
//
//        return map.get(key);
//    }

    /**
     * 北京验证码是否已完成校验【返回】
     * 太平->车商
     *
     * @param key
     * @return TODO 车商平台北京验证码是否已完成校验，待传
     */
//    public static String getBjVerificationCodeIsSuss(String key) {
//        Map<String, String> map = new HashMap<String, String>();
//        map.put("0", "");//否
//        map.put("1", "");//是
//
//        return map.get(key);
//    }

    /**
     * 北京验证码是否已发送【返回】
     * 太平->车商
     *
     * @param key
     * @return TODO 车商平台北京验证码是否已发送，待传
     */
//    public static String getBjVerificationCodeIsSend(String key) {
//        Map<String, String> map = new HashMap<String, String>();
//        map.put("0", "");//否
//        map.put("1", "");//是
//
//        return map.get(key);
//    }

    /**
     * 客户是否确认投保告知单【返回】
     * 太平->车商
     *
     * @param key
     * @return TODO 车商平台客户是否确认投保告知单，待传
     */
//    public static String getIsReading(String key) {
//        Map<String, String> map = new HashMap<String, String>();
//        map.put("0", "");//否
//        map.put("1", "");//是
//
//        return map.get(key);
//    }

    /**
     * 未完成验证码原因代码【返回】
     * 太平->车商
     *
     * @param key
     * @return TODO 车商平台未完成验证码原因代码，待传
     */
//    public static String getMsgCode(String key) {
//        Map<String, String> map = new HashMap<String, String>();
//        map.put("0", "");//身份证采集未完成
//        map.put("1", "");//投保单和浮动告知单采集未完成
//        map.put("2", "");//短信发送未完成
//        map.put("3", "");//验证码保存未完成
//        map.put("4", "");//验证码已失效
//        map.put("5", "");//客户未确认投保告知单
//        map.put("6", "");//流程还未创建
//
//        return map.get(key);
//    }

    /**
     * 未完成验证码原因【返回】
     * 太平->车商
     *
     * @param key
     * @return TODO 车商平台未完成验证码原因，待传
     */
//    public static String getMsg(String key) {
//        Map<String, String> map = new HashMap<String, String>();
//        map.put("0", "");//身份证采集未完成
//        map.put("1", "");//投保单和浮动告知单采集未完成
//        map.put("2", "");//短信发送未完成
//        map.put("3", "");//验证码保存未完成
//        map.put("4", "");//验证码已失效
//        map.put("5", "");//客户未确认投保告知单
//        map.put("6", "");//流程还未创建
//
//        return map.get(key);
//    }

    /**
     * 是否需要双录【返回】
     * 太平->车商
     *
     * @param key
     * @return TODO 车商平台是否需要双录，待传
     */
//    public static String getSzDoubleRecordingFlag(String key) {
//        Map<String, String> map = new HashMap<String, String>();
//        map.put("0", "");//否
//        map.put("1", "");//是
//
//        return map.get(key);
//    }

    /**
     * 双录是否完成【返回】
     * 太平->车商
     *
     * @param key
     * @return TODO 车商平台双录是否完成，待传
     */
//    public static String getSzDoubleRecordingIsSuss(String key) {
//        Map<String, String> map = new HashMap<String, String>();
//        map.put("0", "");//否
//        map.put("1", "");//是
//
//        return map.get(key);
//    }

    /**
     * 双录短信是否发送【返回】
     * 太平->车商
     *
     * @param key
     * @return TODO 车商平台双录短信是否发送，待传
     */
//    public static String getSzDoubleRecordingDXIsSend(String key) {
//        Map<String, String> map = new HashMap<String, String>();
//        map.put("0", "");//否
//        map.put("1", "");//是
//
//        return map.get(key);
//    }
}
