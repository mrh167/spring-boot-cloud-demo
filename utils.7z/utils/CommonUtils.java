package com.sinosoft.car.utils;

import cn.hutool.core.util.BooleanUtil;
import cn.hutool.core.util.ObjectUtil;
import com.cloud.fast.exceptions.BusinessException;
import com.cloud.fast.utils.jwt.JwtTokenUtil;
import com.sinosoft.car.feign.CommonFeignClient;
import com.sinosoft.car.utils.contants.CICConstants;
import com.sinosoft.car.utils.contants.GPICConstants;
import com.sinosoft.car.utils.contants.PAICConstants;
import com.sinosoft.car.utils.contants.YGBXConstants;
import com.sinosoft.car.vo.CommonOrganConfigVo;
import com.sinosoft.car.vo.common.InsureModel;
import com.sinosoft.car.vo.common.enquiry.EnquiryModel;
import com.sinosoft.car.vo.common.enquiry.RiskInfo;
import com.sinosoft.car.vo.common.enquiry.SecurityDetect;
import io.jsonwebtoken.lang.Collections;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

/**
 * 处理公共代码块
 */
@Component
public class CommonUtils {

	@Autowired
	CommonFeignClient commonFeignClient;

	public static String getSearchKey(InsureModel insureModel) {
		return new StringBuffer("")
				.append(StringUtils.isNoneBlank(insureModel.getInsurerCode()) ? insureModel.getInsurerCode() : "")
				.append(StringUtils.isNoneBlank(insureModel.getTciEnquiryNo()) ? insureModel.getTciEnquiryNo() : "")
				.append(StringUtils.isNoneBlank(insureModel.getVciEnquiryNo()) ? insureModel.getVciEnquiryNo() : "")
				.toString();
	}

	/**
	 * LiYanLong-2021-5-5:取消 首次保费查询时，默认险种，附加车身划痕损失险 LiYanLong-2021-5-13:增加
	 * 首次保费查询时，默认险种，附加机动车增值服务特约条款（道路救援服务） 默认 7 次 2021/06/15 此方法废弃，使用下面的重载方法
	 */
	@Deprecated
	public static List<RiskInfo> setDefault(BigDecimal newCarPrice) {
		List<RiskInfo> result = new ArrayList<>();
		RiskInfo vo_100 = new RiskInfo();
		vo_100.setProductKindCode("100"); // 交强险
		RiskInfo vo_0301200 = new RiskInfo();
		vo_0301200.setProductKindCode("0301200"); // 车辆损失险
		vo_0301200.setSumAmount(newCarPrice);
		RiskInfo vo_0301600 = new RiskInfo();
		vo_0301600.setProductKindCode("0301600"); // 第三者责任险
		vo_0301600.setSumAmount(new BigDecimal("200000"));
//        RiskInfo vo_0301210 = new RiskInfo();
//        vo_0301210.setProductKindCode("0301210"); // 附加车身划痕损失险
//        vo_0301210.setSumAmount(new BigDecimal("2000"));

		// 前端已在 ext 扩展信息中 传了 rescueNum（道路救援次数，7次），这里只需定义好险种，然后在各个保司的特殊险种处理中获取 rescueNum
		// 值即可
		RiskInfo vo_0301003 = new RiskInfo();
		vo_0301003.setProductKindCode("0301003"); // 附加机动车增值服务特约条款（道路救援服务）

		result.add(vo_100);
		result.add(vo_0301200);
		result.add(vo_0301600);
		result.add(vo_0301003);
//        result.add(vo_0301210);
		return result;
	}

	/**
	 * 根据前端是否传交强和商业的时间来判断，是否投保交强和商业险，满足用户选择单较强或者单商业情况
	 *
	 * @param model 车商平台：询价接口入参对象
	 * @return List<RiskInfo> 首次查询时默认投保的险种列表
	 * @author LiYanLong
	 * @date 2021/06/15
	 */
	public static List<RiskInfo> setDefault(EnquiryModel model) {
		if (!Collections.isEmpty(model.getRiskList())) {
			return model.getRiskList();
		}
		List<RiskInfo> result = new ArrayList<>();
		// 车辆损失险总保额
		BigDecimal amt_0301200 = null;
		/*
		 * 不同保司，车辆损失险总保额-传对应值 平安：车辆实际价值 国寿：车辆实际价值 太保：新车购置价 华安：新车购置价 人保：
		 */
		if (model.getInsurerCodes().contains(PAICConstants.INSURER_CODE)
				|| model.getInsurerCodes().contains(GPICConstants.INSURER_CODE)
				|| model.getInsurerCodes().contains(CICConstants.INSURER_CODE)) {

			if (ObjectUtil.isNotEmpty(model.getCarInfo().getActualPrice())) {
				amt_0301200 = model.getCarInfo().getActualPrice();
			} else {
				throw new BusinessException("车辆实际价值 actualPrice 不能为空。");
			}
		} else {
			if (ObjectUtil.isNotEmpty(model.getCarInfo().getNewCarPrice())) {
				amt_0301200 = model.getCarInfo().getNewCarPrice();
			} else {
				throw new BusinessException("新车购置价 newCarPrice 不能为空。");
			}
		}

		// 判断是否投保交强险
//        if (ObjectUtil.isNotEmpty(model.getTciStartTime())) {
		if (BooleanUtil.isTrue(model.getJqFlag())) {
			RiskInfo vo_100 = new RiskInfo();
			vo_100.setProductKindCode("100"); // 交强险
			result.add(vo_100);
		}

		// 判断是否投保商业险
//        if (ObjectUtil.isNotEmpty(model.getVciStartTime())) {
		if (BooleanUtil.isTrue(model.getSyFlag())) {
			// 车辆损失险
			RiskInfo vo_0301200 = new RiskInfo();
			vo_0301200.setProductKindCode("0301200");
			vo_0301200.setSumAmount(amt_0301200);

			// 第三者责任险
			RiskInfo vo_0301600 = new RiskInfo();
			vo_0301600.setProductKindCode("0301600");
			if (model.getInsurerCodes().contains(CICConstants.INSURER_CODE)) {
				vo_0301600.setSumAmount(new BigDecimal("1000000"));
			} else {
				vo_0301600.setSumAmount(new BigDecimal("200000"));
			}

			// 附加机动车增值服务特约条款（道路救援服务）
			// 前端已在 ext 扩展信息中 传了 rescueNum（道路救援次数，7次），这里只需定义好险种，然后在各个保司的特殊险种处理中获取 rescueNum
			// 值即可
			RiskInfo vo_0301003 = new RiskInfo();
			vo_0301003.setProductKindCode("0301003");

			result.add(vo_0301200);
			result.add(vo_0301600);
			result.add(vo_0301003);

			List<String> insurerCodes = model.getInsurerCodes();
			for (String insurer : insurerCodes) {
				if (YGBXConstants.INSURER_CODE.equals(insurer)) {

					RiskInfo vo_0301004 = new RiskInfo();
					vo_0301004.setProductKindCode("0301004");

					RiskInfo vo_0301006 = new RiskInfo();
					vo_0301006.setProductKindCode("0301006");

					result.add(vo_0301004);
					result.add(vo_0301006);
					//北京-7座及以下家庭自用、非营业客车-附加道路救援服务次数必须为12次
					model.getExt().setRescueNum(12);
					model.getExt().setServiceType("1");
					List<SecurityDetect> securityDetects = new ArrayList<>();
					SecurityDetect securityDetect = new SecurityDetect();
					securityDetect.setCount("1");
					securityDetects.add(securityDetect);
					model.getExt().setSecurityDetects(securityDetects);
				}
			}
		}

		if (BooleanUtil.isFalse(model.getJqFlag()) && BooleanUtil.isFalse(model.getSyFlag())) {
			RiskInfo vo_100 = new RiskInfo();
			vo_100.setProductKindCode("100"); // 交强险
			result.add(vo_100);

			// 车辆损失险
			RiskInfo vo_0301200 = new RiskInfo();
			vo_0301200.setProductKindCode("0301200");
			vo_0301200.setSumAmount(amt_0301200);

			// 第三者责任险
			RiskInfo vo_0301600 = new RiskInfo();
			vo_0301600.setProductKindCode("0301600");
			vo_0301600.setSumAmount(new BigDecimal("200000"));

			// 附加机动车增值服务特约条款（道路救援服务）
			// 前端已在 ext 扩展信息中 传了 rescueNum（道路救援次数，7次），这里只需定义好险种，然后在各个保司的特殊险种处理中获取 rescueNum
			// 值即可
			RiskInfo vo_0301003 = new RiskInfo();
			vo_0301003.setProductKindCode("0301003");

			result.add(vo_0301200);
			result.add(vo_0301600);
			result.add(vo_0301003);
		}

		return result;
	}

	/**
	 * 国寿 : 国寿获取commonData内的信息
	 *
	 * @Author XieMengTao
	 * @Date 0:34 2021/6/5
	 * @Param []
	 * @return void
	 **/
	public static String getGpicKey() {
		Integer userId = JwtTokenUtil.getUserId();// 获取到当前用户ID
		String tenant = JwtTokenUtil.getTenant();
		return new StringBuffer("").append(userId).append(tenant).append(GPICConstants.INSURER_CODE).toString();
	}

	/**
	 * 根据初等日期判断新车标志 当前时间 - 初等日期 < 9个月，认为新车，否则认为是非新车
	 * 
	 * @param regestDate 初等日期
	 * @return
	 */
	public static String getIsNewFlag(Date regestDate) {
		if (regestDate == null) {
			throw new BusinessException("请填写车辆初次登记日期，不能为空！");
		}

		Calendar now = Calendar.getInstance();
		now.add(Calendar.MONTH, -9);
		return regestDate.after(now.getTime()) ? "1" : "0";
	}

	/**
	 * 根据保司代码和租户代码获取相关配置信息
	 * 
	 * @param insurerCode 保司代码
	 * @return
	 */
	public CommonOrganConfigVo findSellerCode(String insurerCode) {
		CommonOrganConfigVo sellerRelation = commonFeignClient.findSellerRelation(JwtTokenUtil.getUserId(),
				insurerCode);
		if (sellerRelation == null) {
			throw new BusinessException("数据库未查询到相关配置信息");
		}
		return sellerRelation;
	}

	/**
	 * 输出堆栈错误信息
	 */
	public static String printStackTraceToString(Throwable t) {
		StringWriter sw = new StringWriter();
		t.printStackTrace(new PrintWriter(sw, true));
		return sw.getBuffer().toString();
	}
}
