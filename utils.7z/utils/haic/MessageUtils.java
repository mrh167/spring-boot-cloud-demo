package com.sinosoft.car.utils.haic;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.cloud.fast.exceptions.BusinessException;
import com.cloud.fast.utils.HttpClientUtils;
import com.sinosoft.car.utils.contants.HAICConstants;
import com.sinosoft.car.vo.haic.car.response.CarCheckCodeResRoot;
import com.sinosoft.car.vo.haic.car.response.CarQueryResRoot;
import com.sinosoft.car.vo.haic.car.response.NewFlowIdResRoot;
import com.sinosoft.car.vo.haic.common.response.ResponseRoot;
import com.sinosoft.car.vo.haic.enquiry.response.EnquiryResRoot;
import com.sinosoft.car.vo.haic.underwrite.response.UnderwriteRes;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Configuration;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * 华安接口，报文服务工具类
 *
 * @author LiYanLong
 * @version 1.0
 * @date 2021/4/21 18:22
 * @since JDK1.8
 */
@Configuration
public class MessageUtils {

    private static final Logger LOGGER = LoggerFactory.getLogger(MessageUtils.class);

    /**
     * 发送请求数据给保司接口
     * @param serviceCode
     * @param jsonMsg
     * @return
     */
    public static String sendPost(String serviceCode, JSONObject jsonMsg) {
        String requestUrl = HAICConstants.InterfaceUrl.HAIC_URL + "/" + serviceCode; // 旧接口
//        String requestUrl = HAICConstants.InterfaceUrl.TEST_URL + "/" + serviceCode; // 新接口

        String nonce = UUID.randomUUID().toString().replaceAll("-", "");
        String timestamp = String.valueOf(new Date().getTime());
        String signature = SignatureUtil.sign(HAICConstants.SECRET_TOKEN, timestamp, nonce);

        // 请求头信息
        Map<String, String> headers = new HashMap<>();
        headers.put("content-type", "application/json");
        headers.put("ha-channel-code", HAICConstants.CHANNEL_CODE); // 保险公司分配给渠道的唯一编码，必传
        headers.put("ha-x-nonce", nonce);                           // 不长于 32 位的随机字符串，推荐使用字母和数字，必传
        headers.put("ha-x-signature", signature);                   // 签名字符串，必传
        headers.put("ha-x-timestamp", timestamp);                   // 调用的时间戳,每次调用时取当前时间的时间戳，必传

        // 加密报文消息
        String encrypt;
        try {
            LOGGER.info("请求明文: {}", jsonMsg);
            encrypt = AES.encrypt(JSON.toJSONString(jsonMsg), HAICConstants.SECRET_TOKEN);
            LOGGER.info("请求密文: {}", encrypt);
        } catch (Exception e) {
            e.printStackTrace();
            throw new BusinessException("请求内容加密失败！");
        }
        return HttpClientUtils.sendPost(requestUrl, headers, encrypt);
    }


    /**
     * 解密报文
     *
     * @param resultJson
     * @return
     */
    public static JSONObject decrypt(String resultJson) {
        String decrypt = null;
        try {
            LOGGER.info("响应密文: {}", resultJson);
            decrypt = AES.decrypt(resultJson, HAICConstants.SECRET_TOKEN);
            LOGGER.info("响应明文: {}", decrypt);
        } catch (Exception e) {
            e.printStackTrace();
            throw new BusinessException("响应内容解密失败！");
        }
        return JSONObject.parseObject(decrypt);
    }
    /**
     * 判断当前响应是否成功
     */
    public static Boolean isSuccess(CarQueryResRoot response) {
        return isSuccess(response.getHead().getResponseCode());
    }
    /**
     * 判断当前响应是否成功
     */
    public static Boolean isSuccess(UnderwriteRes response) {
        return isSuccess(response.getHead().getResponseCode());
    }

    /**
     * 判断当前响应是否成功
     */
    public static Boolean isSuccess(EnquiryResRoot response) {
        return isSuccess(response.getHead().getResponseCode());
    }


    /**
     * 判断当前响应是否成功
     */
    public static Boolean isSuccess(NewFlowIdResRoot response) {
        return isSuccess(response.getHead().getResponseCode());
    }
    /**
     * 判断当前响应是否成功
     */
    public static Boolean isSuccess(CarCheckCodeResRoot response) {
        return isSuccess(response.getHead().getResponseCode());
    }
    /**
     * 判断当前响应是否成功
     */
    public static Boolean isSuccess(ResponseRoot response) {
        return isSuccess(response.getHead().getResponseCode());
    }

    private static Boolean isSuccess(String responseCode) {
        return HAICConstants.ResponseCode.SUCCESS.equals(responseCode);
    }

}
