package com.sinosoft.car.utils.haic;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.Date;

/**
 * 华安保险：新接口的加密、验签工具类
 *
 * @author LiYanLong
 * @date 2021-05-06
 */
public class SignatureUtil {

    private static final Logger log = LoggerFactory.getLogger(SignatureUtil.class);

    private static final String SHA_ALG = "SHA-1";
    private static final long DURATION = 1000 * 60 * 5; //5 分钟

    /**
     * 验证签名
     *
     * @param token     保险公司分配给渠道商
     * @param signature 加密签名
     * @param timestamp 时间戳
     * @param nonce     随机数
     */
    public static boolean checkSign(String token, String signature, String timestamp, String nonce) {

        log.info("req signature: " + signature);
        log.info("req timestamp: " + timestamp);
        log.info("req nonce: " + nonce);
        //验证时间是否在有效区间
        if (!isDuration(timestamp)) {
            return false;
        }
        String tmpStr = sign(token, timestamp, nonce);
        log.info("correct sign: " + tmpStr);
        // 将 sha1 加密后的字符串可与 signature 对比
        return tmpStr != null && tmpStr.equals(signature.toUpperCase());
    }

    /**
     * 签名
     *
     * @param token
     * @param timestamp
     * @param nonce     * @return sign string
     */
    public static String sign(String token, String timestamp, String nonce) {
        String[] arr = new String[]{token, timestamp, nonce};
        // 将 token、timestamp、nonce、三个参数进行字典序排序
        Arrays.sort(arr);
        StringBuilder content = new StringBuilder();
        for (String anArr : arr) {
            content.append(anArr);
        }
        MessageDigest md = null;
        String signature = null;
        try {
            md = MessageDigest.getInstance(SHA_ALG);
            // 将三个参数字符串拼接成一个字符串进行 sha1 加密
            byte[] digest = md.digest(content.toString().getBytes());
            signature = byteToStr(digest);
        } catch (NoSuchAlgorithmException e) {
            log.error(e.getMessage());
        }
        return signature;
    }

    /**
     * 将字节数组转换为十六进制字符串
     *
     * @param byteArray * @return
     */
    private static String byteToStr(byte[] byteArray) {
        String strDigest = "";
        for (int i = 0; i < byteArray.length; i++) {
            strDigest += byteToHexStr(byteArray[i]);
        }
        return strDigest;
    }

    /**
     * 将字节转换为十六进制字符串
     *
     * @param mByte * @return
     */
    private static String byteToHexStr(byte mByte) {
        char[] Digit = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'};
        char[] tempArr = new char[2];
        tempArr[0] = Digit[(mByte >>> 4) & 0X0F];
        tempArr[1] = Digit[mByte & 0X0F];
        String s = new String(tempArr);
        return s;
    }

    /**
     * 验证时间戳是否在有效区间* @param timestamp
     *
     * @return
     */
    private static boolean isDuration(String timestamp) {
        try {
            long currentStamp = new Date().getTime();
            log.info("currentStamp: " + currentStamp);
            return Math.abs(currentStamp - Long.valueOf(timestamp)) < DURATION;
        } catch (Exception e) {
            return false;
        }
    }
}