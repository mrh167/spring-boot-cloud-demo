package com.sinosoft.car.utils.haic;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * 华安保险：新接口的报文加密工具类
 *
 * @author LiYanLong
 * @date 2021-05-06
 */
public class AES {
    /**
     * 加密
     *
     * @param content 待加密内容
     * @param key     加密的密钥
     * @return 加密后的报文
     */
    public static String encrypt(String content, String key) throws
            NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
        SecretKeySpec secretKeySpec = new SecretKeySpec(generateSecretKey(key), "AES");
        Cipher cipher = Cipher.getInstance("AES");
        byte[] byteContent = content.getBytes(StandardCharsets.UTF_8);
        cipher.init(Cipher.ENCRYPT_MODE, secretKeySpec);
        byte[] byteRresult = cipher.doFinal(byteContent);
        StringBuffer sb = new StringBuffer();
        StringBuffer hex = new StringBuffer();
        for (byte aByteRresult : byteRresult) {
            hex.setLength(0);
            hex.append(Integer.toHexString(aByteRresult & 0xFF));
            if (hex.length() == 1) {
                hex.insert(0, '0');
            }
            sb.append(hex);
        }
        return sb.toString().toUpperCase();
    }

    /**
     * 解密
     *
     * @param content 待解密内容
     * @param key     解密的密钥
     * @return 解密后的报文
     */
    public static String decrypt(String content, String key) throws
            NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
        if (content.length() < 1)
            return null;
        byte[] byteResult = new byte[content.length() / 2];
        for (int i = 0; i < content.length() / 2; i++) {
            int high = Integer.parseInt(content.substring(i * 2, i * 2 + 1), 16);
            int low = Integer.parseInt(content.substring(i * 2 + 1, i * 2 + 2), 16);
            byteResult[i] = (byte) (high * 16 + low);
        }
        SecretKeySpec secretKeySpec = new SecretKeySpec(generateSecretKey(key), "AES");
        Cipher cipher = Cipher.getInstance("AES");//修改这里
        cipher.init(Cipher.DECRYPT_MODE, secretKeySpec);
        byte[] result = cipher.doFinal(byteResult);
        return new String(result, StandardCharsets.UTF_8);
    }

    private static byte[] generateSecretKey(String key) throws NoSuchAlgorithmException {
        MessageDigest digest = MessageDigest.getInstance("MD5");
        digest.update(key.getBytes(StandardCharsets.UTF_8));
        return digest.digest();
    }
}