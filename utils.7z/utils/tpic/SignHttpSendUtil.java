package com.sinosoft.car.utils.tpic;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.StringWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.GeneralSecurityException;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.Signature;
import java.security.spec.PKCS8EncodedKeySpec;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cloud.fast.exceptions.BusinessException;
import com.sinosoft.car.utils.contants.TPICConstants;
import com.sinosoft.car.utils.sign.SignatureUtils;

import cn.hutool.core.codec.Base64;

/**
 * 太平云-报文签名加密
 *
 */
public class SignHttpSendUtil {

	private static final Logger LOGGER = LoggerFactory.getLogger(SignHttpSendUtil.class);

	
	/**
	 * 太平云平台-发送请求数据给保司接口
	 * 
	 * @param textXml
	 * @param api
	 * @return
	 */
	public static String sendPost(String textXml,String api) {
		String rsp = null;
		try {
			/* 加签 */
			String respSign = sign(textXml);
			/* 交互 */
			rsp = sendPost(textXml, api, respSign);
		} catch (Exception e) {
			throw new BusinessException(e.getMessage());
		}
		
		return rsp;
	}
	
	/**
	 * 报文签名加密
	 * 
	 * @param text
	 * @return
	 * @throws Exception
	 */
	public static String sign(String textXml) throws Exception {
		// 对报文进行加签
		byte[] signBytes;
		String respEncode = Base64.encode(textXml.getBytes("UTF-8"));
//		LOGGER.info("TPICConstants.InterfaceUrl.TGBX_KEY: "+TPICConstants.InterfaceUrl.TGBX_KEY);
//		LOGGER.info("TPICConstants.InterfaceUrl.TGBX_Name: "+TPICConstants.InterfaceUrl.TGBX_CLIENT_NAME);
//		LOGGER.info("TPICConstants.InterfaceUrl.TGBX_Url: "+TPICConstants.InterfaceUrl.TGBX_URL);
		signBytes = sign(respEncode.replace("\n", "").getBytes(), Base64.decode(SignatureUtils.thirdPrivateKey), TPICConstants.InterfaceUrl.TGBX_KEY);
		String respSign = Base64.encode(signBytes);
		LOGGER.info("请求明文加签后: {}", respSign);
		return respSign;
	}

	/**
	 * 交互
	 * 
	 * @param textXml
	 * @param api
	 * 			接口名称
	 * @return	
	 * @throws Exception
	 */
	public static String sendPost(String textXml,String api,String respSign) throws Exception {

		// 构建地址并打开请求
		URL url = new URL(String.format("%s/%s/%s", TPICConstants.InterfaceUrl.TGBX_URL, TPICConstants.InterfaceUrl.TGBX_CLIENT_NAME, api));
	    HttpsURLConnection conn = (HttpsURLConnection) url.openConnection();
		conn.setHostnameVerifier(new HostnameVerifier() {
			@Override
			public boolean verify(String arg0, SSLSession arg1) {
				return true;
			}
		});

		// 加签且发送请求并获取结果
		conn.setRequestProperty("TP-SIGN", respSign);
		conn.setRequestMethod("POST");
		conn.setDoInput(true);
		conn.setDoOutput(true);
		String rsp;
		OutputStream out = null;
		try {
			LOGGER.info("post请求: {}", TPICConstants.InterfaceUrl.TGBX_URL+"/"+TPICConstants.InterfaceUrl.TGBX_CLIENT_NAME+"/"+api);
			out = conn.getOutputStream();
			out.write(textXml.getBytes());
			rsp = getResponseAsString(conn);
			LOGGER.info("返回报文: {}", rsp);
		} catch (IOException e) {
			throw new BusinessException(e.getMessage());
		}

		return rsp;
	}
	
    
    protected static String getResponseAsString(HttpURLConnection conn) throws IOException {
		return getStreamAsString(conn.getInputStream(), TPICConstants.defaultCharset);
	}

	private static String getStreamAsString(InputStream stream, String charset) throws IOException {
		try {
			BufferedReader reader = new BufferedReader(new InputStreamReader(stream, charset));
			StringWriter writer = new StringWriter();

			char[] chars = new char[256];
			int count = 0;
			while ((count = reader.read(chars)) > 0) {
				writer.write(chars, 0, count);
			}

			return writer.toString();
		} finally {
			if (stream != null) {
				stream.close();
			}
		}
	}
	
	public static byte[] sign(final byte[] text, final byte[] privateKeyData, final String algorithm)
			throws GeneralSecurityException {
		PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(privateKeyData);
		KeyFactory keyFactory = KeyFactory.getInstance("RSA");
		PrivateKey privateKey = keyFactory.generatePrivate(keySpec);
		Signature signatureChecker = Signature.getInstance(algorithm);
		signatureChecker.initSign(privateKey);
		signatureChecker.update(text);
		return signatureChecker.sign();
	}


}
