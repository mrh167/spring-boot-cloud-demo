package com.sinosoft.car.utils.paic;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.lf5.util.StreamUtils;

import javax.crypto.Cipher;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.security.*;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.*;

public class RSA {
	private static String algorithm = "SHA256withRSA";

	/**
	 * 加签
	 * @param responseBody 排序后的请求数据
	 * @param inPrivateKey 私钥
	 * @return
	 * @throws Exception
	 */
	public static String sign(String responseBody, String inPrivateKey) throws Exception {
		byte[] dataEncode = Base64.encodeBase64(responseBody.getBytes("UTF-8"));
		PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(Base64.decodeBase64(inPrivateKey.getBytes()));
		KeyFactory keyFactory = KeyFactory.getInstance("RSA");
		PrivateKey privateKey = keyFactory.generatePrivate(keySpec);
		Signature signatureChecker;
		Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider());
		signatureChecker = Signature.getInstance(algorithm);
		signatureChecker.initSign(privateKey);
		signatureChecker.update(dataEncode);
		byte[] sign = signatureChecker.sign();
		return new String(Base64.encodeBase64(sign));
	}

	/**
	 * 验签
	 * @param param 业务数据
	 * @param signature 签名
	 * @param verifyKey 公钥
	 * @return
	 */
	public static Boolean verifySignRsa(Map param ,String signature, String verifyKey){
		if(!hasText(signature)){
			return false;
		}
		String wtsign ="";
		wtsign = sortParametersWithASCII(param);
		Boolean verifyresult =false;
		verifyresult = verify(wtsign, signature,verifyKey);
		//兼容partnerId不加密
		if(!verifyresult){
			param.remove("partnerId");
			wtsign = sortParametersWithASCII(param);
			verifyresult = verify(wtsign, signature,verifyKey);
		}
		return verifyresult;
	}
	
	/**验签
	 * @param businessdata 实际业务数据
	 * @param signedText   加密后待验证数据
	 * @return boolean
	 */
	public static boolean verify(String businessdata, String signedText, String verifyKey) {
		try {
			String dataEncode = new String(Base64.encodeBase64(businessdata.getBytes("UTF-8")));
			X509EncodedKeySpec keySpec = new X509EncodedKeySpec(Base64.decodeBase64(verifyKey.getBytes()));
			KeyFactory keyFactory = KeyFactory.getInstance("RSA");
			PublicKey publicKey = keyFactory.generatePublic(keySpec);
			Signature signatureChecker = null;
			Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider());
			signatureChecker = Signature.getInstance(algorithm);
			signatureChecker.initVerify(publicKey);
			signatureChecker.update(dataEncode.replace("\n", "").getBytes());
			byte[] signBytes = signedText.getBytes("UTF-8");
			byte[] sign = Base64.decodeBase64(signBytes);
			return signatureChecker.verify(sign);
		} catch (Exception e) {
		}
		return false;
	}

	/**
	 * 解密
	 *
	 * @param content 加密的数据
	 * @param privateKey 私钥
	 * @param charset 编码格式
	 * @return
	 * @throws Exception
	 */
	public static String rsaDecrypt(String content, String privateKey,
			String charset) throws Exception {
		return rsaDecrypt(content, privateKey, charset, null);
	}

	public static String rsaDecrypt(String content, String privateKey,
			String charset, String signType) throws Exception {
		int maxDecryptBlock = 256;
		try {
			PrivateKey priKey = getPrivateKeyFromPKCS8("RSA",
					new ByteArrayInputStream(privateKey.getBytes()));
			Cipher cipher = Cipher.getInstance("RSA");
			cipher.init(2, priKey);
			byte[] encryptedData = StringUtils.isEmpty(charset) ? Base64
					.decodeBase64(content.getBytes()) : Base64
					.decodeBase64(content.getBytes(charset));
			int inputLen = encryptedData.length;
			ByteArrayOutputStream out = new ByteArrayOutputStream();
			int offSet = 0;
			int i = 0;
			while (inputLen - offSet > 0) {
				byte[] cache;
				if (inputLen - offSet > maxDecryptBlock) {
					cache = cipher.doFinal(encryptedData, offSet,
							maxDecryptBlock);
				} else {
					cache = cipher.doFinal(encryptedData, offSet, inputLen
							- offSet);
				}
				out.write(cache, 0, cache.length);
				i++;
				offSet = i * maxDecryptBlock;
			}
			byte[] decryptedData = out.toByteArray();
			out.close();

			return StringUtils.isEmpty(charset) ? new String(decryptedData)
					: new String(decryptedData, charset);
		} catch (Exception e) {
			throw new Exception("RSA解密失败. EncodeContent = " + content + ",charset = " + charset, e);
		}
	}
	public static PrivateKey getPrivateKeyFromPKCS8(String algorithm,
			InputStream ins) throws Exception {
		if ((ins == null) || (StringUtils.isEmpty(algorithm))) {
			return null;
		}
		KeyFactory keyFactory = KeyFactory.getInstance(algorithm);
		byte[] encodedKey = StreamUtils.getBytes(ins);
		encodedKey = Base64.decodeBase64(encodedKey);
		return keyFactory.generatePrivate(new PKCS8EncodedKeySpec(encodedKey));
	}
	
	public static boolean hasText(String str) {
        if (!hasLength(str)) {
            return false;
        } else {
            int strLen = str.length();

            for(int i = 0; i < strLen; ++i) {
                if (!Character.isWhitespace(str.charAt(i))) {
                    return true;
                }
            }

            return false;
        }
    }
	
	public static boolean hasLength(String str) {
        return str != null && str.length() > 0;
    }

	/**
	 * 对数据进行排序
	 *
	 * @param param
	 * @return
	 */
	public static String sortParametersWithASCII(Map param){
		List sortList = new LinkedList<String>();
		Iterator listadd = param.keySet().iterator();
		while (listadd.hasNext()) {
			Object obj = listadd.next();
			sortList .add(obj.toString());
		}
		//参数排序
		Collections.sort(sortList);
		String sortStr ="";
		for(int i=0; i< sortList .size(); i++){
			String paramListStr="" ;
			//对List数据进行排序
			if(param.get(sortList .get(i)) instanceof List){
				List dataList = (List) param.get(sortList.get(i));
				if(null != dataList && dataList.size()>0){
					Collections.sort(dataList);
					for(int k = 0; k<dataList.size(); k++){
						paramListStr = paramListStr + dataList.get(k) + ",";
					}
					paramListStr = paramListStr.substring(0,paramListStr.length()-1);
					
				}
				sortStr = sortStr + sortList.get(i) + "=" + paramListStr + "&";
				
			}else{
				sortStr = sortStr + sortList.get(i) + "=" + param.get(sortList.get(i)) + "&";
				
			}
			
		}
		sortStr = sortStr.substring(0, sortStr.length()-1);
		return sortStr;
		
	}
}
