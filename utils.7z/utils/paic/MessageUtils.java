package com.sinosoft.car.utils.paic;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.cloud.fast.exceptions.BusinessException;
import com.cloud.fast.utils.HttpClientUtils;
import com.cloud.fast.utils.RedisUtils;
import com.cloud.fast.utils.StringUtils;
import com.cloud.fast.utils.jwt.JwtTokenUtil;
import com.sinosoft.car.utils.contants.PAICConstants;
import com.sinosoft.car.vo.paic.common.response.TokenRes;
import com.sinosoft.car.vo.paic.index.request.IndexReq;
import com.sinosoft.car.vo.paic.index.request.Vehicle;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

/**
 * 平安接口，报文服务工具类
 *
 * @author LiYanLong
 * @version 1.0
 * @date 2021/5/20 3:12
 * @since JDK1.8
 */
@Service("paciMessageUtils")
public class MessageUtils {

    private static final Logger LOGGER = LoggerFactory.getLogger(MessageUtils.class);

    @Autowired
    RedisUtils redisUtils;

    public static final String CLIENT_ID = "P_QYC_AUTO";
    public static final String CLIENT_SECRET_TEST = "K21zA8qJ"; // 测试环境
    public static final String CLIENT_SECRET = "e6dHXQ65";      // 生产环境

//    public static final String publicKeyTest = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAsq92diDWK5To/ysSEAdDAPUhRmCbuWcR9QYZbE5xIhngHNyaytdw8kMXpTrv2nZjQvm78nDOF1iUInSCEK3L79k/spq1pBspLLgrQgw58J9br47u7sqPKdxiGlT4aEBw+fEcCgUjI3zrO0EaXABHlt6ACZjJp3aHy31oX0CnwYx7Q/I7Qcc7PTKSpeNK4WmjcA/lLRqgPKyZo7Huiy9e+iLjLNRz8XjbmWADxKyXtMeScJZOnyO1mnfk5DeDo6amkcPDm9Z7vHx/OtHepuivHuUK7AxMKo14shEh0x2yGZEK1AgTnPLcmHyjPxz+rMsYIQypUVxEbkc1WOuZbU8JqQIDAQAB";
//    public static final String privateKeyTest = "MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCyr3Z2INYrlOj/KxIQB0MA9SFGYJu5ZxH1BhlsTnEiGeAc3JrK13DyQxelOu/admNC+bvycM4XWJQidIIQrcvv2T+ymrWkGyksuCtCDDnwn1uvju7uyo8p3GIaVPhoQHD58RwKBSMjfOs7QRpcAEeW3oAJmMmndofLfWhfQKfBjHtD8jtBxzs9MpKl40rhaaNwD+UtGqA8rJmjse6LL176IuMs1HPxeNuZYAPErJe0x5Jwlk6fI7Wad+TkN4OjpqaRw8Ob1nu8fH860d6m6K8e5QrsDEwqjXiyESHTHbIZkQrUCBOc8tyYfKM/HP6syxghDKlRXERuRzVY65ltTwmpAgMBAAECggEAENgdkLEzv1QASt2ijERC+rog8uN0ipu+w5xZlS4n2BEcYVwic3Cvwwa0Ge1eYve6D7w/DXG429aL0FuvTyczDF8sdAfFi7zLut15pnZEl/xNxlTxDS2nJUkTLmxIJnu8qrMh84fcciH6gtF2TKnyFbTP2RfAGrs/vd0Kk8AikEone7DWLgPakcLw8F7wwnC4jbnWTW8VvJfmsV+nm/Fk1CffddPn5+Nw1OIFvpmBsjGbxMYGjX9CbHyoAH8hnGLkOsgJrYxHKlQAZcgFcinLjuylhhndFM1IOvmKsLlbOve6YYnU1aY60Ok1Y+xbAQZI3KBhSB0aLaObqhCw/h5zAQKBgQDmz2BGhf4X4fdQ0BOW5K5I9pGWeJ/Tev5iMXgUJIkyoOtqqmhdfsx8MdEARhXrlMyGscpTtBBBiUfyhOaoTc3NWAyEnX+9hmW2KGfAaFWILN7pvrrnRczQrNWPnQhHKa0iKTS5Ay6OipLOHIlDjUao7w9tupjQWQSxp7da7jvEGQKBgQDGL8VX+26dXShqY7Kma+NscJwO6/LBAG6D+DhSFrdhE1MARUl1BDp5FRAbQPX3TgFDVqG98TdsnnGlarSiK/l5xG/fNR7wU0uhIqP/KKT7UtAo2nf2+V+ROCCRXxrOdMgXBk98GoKQ4xDv21C60Trt33o2Ln2+ZBUgwNpH/k+kEQKBgB2nXxMwe+jNm1zCnwGv98RgCWxvqvkcwDoVaPwNhaL/kb9ujWIVvGfobpW+a2qM/4n+paQDamNBJAFAmfHdrSdIvLL9GUBcWA0DO/E4dmS8fxdA7fpwuVPGINoGrt2VuSy+ZouuoPinTR02BVysdfuWW0EZzDBYf4XjqmcAXKVhAoGADuutyc/uJf7LeicDXjAlMRbRSPZOkmU77MeVRejb6X0Q9KZCv4KP/Gmvir27RuEiizVMfAZbC9xp5fBApSz2XUqCuaVALQu4V+tJuX4P3bQAY/L+sSNZJI+7M/abCAwWvFUHSuqcBdhyf/xc+ZOjAiGfC9E4OktCo/Kg/GaTDGECgYEAnz/9I0/iS10GBE/PzOYAiyA7Bj9tp+J/K1ZzJjhCjGGJOd6ih1IAhVdFQG+lH3UuGCYB237BGalvhLBsUeY/kcYAozO4DVEpPCFUoC3bWSZSCkotYPpeV6AuZ8IoKvbCelRvO5CJIzX/Ar5CE9d4Dyn0PPav9jtA3fWcZKFOeeE=";

    public static final String publicKey = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAsq92diDWK5To/ysSEAdDAPUhRmCbuWcR9QYZbE5xIhngHNyaytdw8kMXpTrv2nZjQvm78nDOF1iUInSCEK3L79k/spq1pBspLLgrQgw58J9br47u7sqPKdxiGlT4aEBw+fEcCgUjI3zrO0EaXABHlt6ACZjJp3aHy31oX0CnwYx7Q/I7Qcc7PTKSpeNK4WmjcA/lLRqgPKyZo7Huiy9e+iLjLNRz8XjbmWADxKyXtMeScJZOnyO1mnfk5DeDo6amkcPDm9Z7vHx/OtHepuivHuUK7AxMKo14shEh0x2yGZEK1AgTnPLcmHyjPxz+rMsYIQypUVxEbkc1WOuZbU8JqQIDAQAB";
    public static final String privateKey = "MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCyr3Z2INYrlOj/KxIQB0MA9SFGYJu5ZxH1BhlsTnEiGeAc3JrK13DyQxelOu/admNC+bvycM4XWJQidIIQrcvv2T+ymrWkGyksuCtCDDnwn1uvju7uyo8p3GIaVPhoQHD58RwKBSMjfOs7QRpcAEeW3oAJmMmndofLfWhfQKfBjHtD8jtBxzs9MpKl40rhaaNwD+UtGqA8rJmjse6LL176IuMs1HPxeNuZYAPErJe0x5Jwlk6fI7Wad+TkN4OjpqaRw8Ob1nu8fH860d6m6K8e5QrsDEwqjXiyESHTHbIZkQrUCBOc8tyYfKM/HP6syxghDKlRXERuRzVY65ltTwmpAgMBAAECggEAENgdkLEzv1QASt2ijERC+rog8uN0ipu+w5xZlS4n2BEcYVwic3Cvwwa0Ge1eYve6D7w/DXG429aL0FuvTyczDF8sdAfFi7zLut15pnZEl/xNxlTxDS2nJUkTLmxIJnu8qrMh84fcciH6gtF2TKnyFbTP2RfAGrs/vd0Kk8AikEone7DWLgPakcLw8F7wwnC4jbnWTW8VvJfmsV+nm/Fk1CffddPn5+Nw1OIFvpmBsjGbxMYGjX9CbHyoAH8hnGLkOsgJrYxHKlQAZcgFcinLjuylhhndFM1IOvmKsLlbOve6YYnU1aY60Ok1Y+xbAQZI3KBhSB0aLaObqhCw/h5zAQKBgQDmz2BGhf4X4fdQ0BOW5K5I9pGWeJ/Tev5iMXgUJIkyoOtqqmhdfsx8MdEARhXrlMyGscpTtBBBiUfyhOaoTc3NWAyEnX+9hmW2KGfAaFWILN7pvrrnRczQrNWPnQhHKa0iKTS5Ay6OipLOHIlDjUao7w9tupjQWQSxp7da7jvEGQKBgQDGL8VX+26dXShqY7Kma+NscJwO6/LBAG6D+DhSFrdhE1MARUl1BDp5FRAbQPX3TgFDVqG98TdsnnGlarSiK/l5xG/fNR7wU0uhIqP/KKT7UtAo2nf2+V+ROCCRXxrOdMgXBk98GoKQ4xDv21C60Trt33o2Ln2+ZBUgwNpH/k+kEQKBgB2nXxMwe+jNm1zCnwGv98RgCWxvqvkcwDoVaPwNhaL/kb9ujWIVvGfobpW+a2qM/4n+paQDamNBJAFAmfHdrSdIvLL9GUBcWA0DO/E4dmS8fxdA7fpwuVPGINoGrt2VuSy+ZouuoPinTR02BVysdfuWW0EZzDBYf4XjqmcAXKVhAoGADuutyc/uJf7LeicDXjAlMRbRSPZOkmU77MeVRejb6X0Q9KZCv4KP/Gmvir27RuEiizVMfAZbC9xp5fBApSz2XUqCuaVALQu4V+tJuX4P3bQAY/L+sSNZJI+7M/abCAwWvFUHSuqcBdhyf/xc+ZOjAiGfC9E4OktCo/Kg/GaTDGECgYEAnz/9I0/iS10GBE/PzOYAiyA7Bj9tp+J/K1ZzJjhCjGGJOd6ih1IAhVdFQG+lH3UuGCYB237BGalvhLBsUeY/kcYAozO4DVEpPCFUoC3bWSZSCkotYPpeV6AuZ8IoKvbCelRvO5CJIzX/Ar5CE9d4Dyn0PPav9jtA3fWcZKFOeeE=";


    // 最新生产KEY
//    public static final String publicKey = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAudNwh84GE90APAr3huY1woCgqs4+ZXKA4mT5Cuqvhr8TyF2RYIuPGJRp1kizUZq6oZYn/Dyp/v9sdkF5HlW3rI8ZFaCzYy4K+umOyMvM6sW1ic+V9I4em2c9M8HYcg+I3ZX1Bpea/Zr1rT52XjPFDZJFeldKBymAKJn2qmIcKGD1ejeHw8XOoyTPAqEl7c+3Yk2n2R5tHQEfv7jgV3vpZLWRqkAsb4kSO6GExXE5moipajZPU/A6/jVV5R3liac/+cvC4kX5qxe56GgkN6LYt5zsVg3dlZIl/rD+0I3/sgdMPdQ3ZTOxlpol/lZh6TTDYLh+HyoNw2xxcj4IDaWPHQIDAQAB";
//    public static final String privateKey = "MIIEvwIBADANBgkqhkiG9w0BAQEFAASCBKkwggSlAgEAAoIBAQC503CHzgYT3QA8CveG5jXCgKCqzj5lcoDiZPkK6q+GvxPIXZFgi48YlGnWSLNRmrqhlif8PKn+/2x2QXkeVbesjxkVoLNjLgr66Y7Iy8zqxbWJz5X0jh6bZz0zwdhyD4jdlfUGl5r9mvWtPnZeM8UNkkV6V0oHKYAomfaqYhwoYPV6N4fDxc6jJM8CoSXtz7diTafZHm0dAR+/uOBXe+lktZGqQCxviRI7oYTFcTmaiKlqNk9T8Dr+NVXlHeWJpz/5y8LiRfmrF7noaCQ3oti3nOxWDd2VkiX+sP7Qjf+yB0w91DdlM7GWmiX+VmHpNMNguH4fKg3DbHFyPggNpY8dAgMBAAECggEAE/YioHQBMyEKZWjILjWMkNhAahi9mygxsCAooIOVV2QvO9bRRw220W0f8WTd3mZAphr7MJ1TpZDKlelymU+b621zxF7+5iiMBWgRboB2AsI6PhOOiDa8EvWEHYs1NQt2KFdzesHOZG/A9FtBW90zzcFotTurOBm9Kp9fX+4qGCwjBpSUfwhAwSmFrKlPyhF63PaKqPhh4eUbUyw66+uGsfbNHjpIdnFj2frpO399Iib1CfvifgSsvmvQDGFdNRs3HI3eWkcBVVjPw1tkeeKulfQA3RgJGWpxrJvwIcwk5Qqi3pHmq13Wpao3RBFJVRh1Mgv2+a46n7WegzhvtxeCAQKBgQD0yC49j5/rkMG3/F7KIAWo5YI5ANBUKsJ+vFokwCXCLUAcjd6zTkuJGLq5AGxQpxh70pS3fL+Nk6uJjjNEHYAqRFROTdK5rFrvce494L2TkYAvc75fKqotzlzGnhYY7nqWnC8XUJgE6I0maOsCGMT/0jz+RRYwiexN5zAsxXJp1wKBgQDCV5PxDd2/0gNsU62Kzughvn0xMKF8ED665Nc9Ck1UsJFrCX5SHyL6wl1evI58rE7AwhIDHelN4qnalkiJVSfN3Nli1EFfi8AYkNWKzVOB7P/7GUJ39v7WxMeJu+mxxnnNu6dDFsV+Ac0cJ7oDp6TqvPxVwXO1J3SRL3S7TJd4KwKBgQDM6whK4QGv4u9JZyyzaTtTuU7bCaNd0q4gCu4r9e+mLtuNC/dzhAgYLWujlIcYvcnxXsjBEt4JV6Yy8ahZTZkNyUYKh3vxlChMa8RWaN5Lu3LkRrEIWl89GZTxcUZueLaHfxitG/snoMcJcKvMhY/l2crV0mBRIiWA0hmyYVj24QKBgQCcJF8xyrFCgArOC0EgiHLLQdA2KFtmYWr1IA2q9k8BX0fG1v7OHkQtcuIvzpEwrAQuLP7p0Ct1r0pG3H31ER0E8o8aL21CxfaWBi/78FJKzk8wwK+90Q4ZIksrZ3YwpkWQvVd6uJ3+SpYwK97xNs1y6FpY0DAV+VhXmehQ4A3GtwKBgQDj+MWs7r5For62CkU4GrReR+32nt65nFcBOJLqWAxijcIZdjarn1VfrjN9Al51X/4jH8/GytAI2i7CCeDRrOYv7BGvOzOrBY0xZbNUNpuR5PrLu2r50/TdjMJDqcCTlmGe7r9geUHwHTi1KedJ9gSFcX+uIohYdP0YjkQXSFhFPw==";

    // 生产环境
//    public static final String CLIENT_ID = "P_QYC_AUTO";
//    public static final String CLIENT_SECRET = "e6dHXQ65";
//    public static final String publicKey = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAsq92diDWK5To/ysSEAdDAPUhRmCbuWcR9QYZbE5xIhngHNyaytdw8kMXpTrv2nZjQvm78nDOF1iUInSCEK3L79k/spq1pBspLLgrQgw58J9br47u7sqPKdxiGlT4aEBw+fEcCgUjI3zrO0EaXABHlt6ACZjJp3aHy31oX0CnwYx7Q/I7Qcc7PTKSpeNK4WmjcA/lLRqgPKyZo7Huiy9e+iLjLNRz8XjbmWADxKyXtMeScJZOnyO1mnfk5DeDo6amkcPDm9Z7vHx/OtHepuivHuUK7AxMKo14shEh0x2yGZEK1AgTnPLcmHyjPxz+rMsYIQypUVxEbkc1WOuZbU8JqQIDAQAB";
//    public static final String privateKey = "MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCyr3Z2INYrlOj/KxIQB0MA9SFGYJu5ZxH1BhlsTnEiGeAc3JrK13DyQxelOu/admNC+bvycM4XWJQidIIQrcvv2T+ymrWkGyksuCtCDDnwn1uvju7uyo8p3GIaVPhoQHD58RwKBSMjfOs7QRpcAEeW3oAJmMmndofLfWhfQKfBjHtD8jtBxzs9MpKl40rhaaNwD+UtGqA8rJmjse6LL176IuMs1HPxeNuZYAPErJe0x5Jwlk6fI7Wad+TkN4OjpqaRw8Ob1nu8fH860d6m6K8e5QrsDEwqjXiyESHTHbIZkQrUCBOc8tyYfKM/HP6syxghDKlRXERuRzVY65ltTwmpAgMBAAECggEAENgdkLEzv1QASt2ijERC+rog8uN0ipu+w5xZlS4n2BEcYVwic3Cvwwa0Ge1eYve6D7w/DXG429aL0FuvTyczDF8sdAfFi7zLut15pnZEl/xNxlTxDS2nJUkTLmxIJnu8qrMh84fcciH6gtF2TKnyFbTP2RfAGrs/vd0Kk8AikEone7DWLgPakcLw8F7wwnC4jbnWTW8VvJfmsV+nm/Fk1CffddPn5+Nw1OIFvpmBsjGbxMYGjX9CbHyoAH8hnGLkOsgJrYxHKlQAZcgFcinLjuylhhndFM1IOvmKsLlbOve6YYnU1aY60Ok1Y+xbAQZI3KBhSB0aLaObqhCw/h5zAQKBgQDmz2BGhf4X4fdQ0BOW5K5I9pGWeJ/Tev5iMXgUJIkyoOtqqmhdfsx8MdEARhXrlMyGscpTtBBBiUfyhOaoTc3NWAyEnX+9hmW2KGfAaFWILN7pvrrnRczQrNWPnQhHKa0iKTS5Ay6OipLOHIlDjUao7w9tupjQWQSxp7da7jvEGQKBgQDGL8VX+26dXShqY7Kma+NscJwO6/LBAG6D+DhSFrdhE1MARUl1BDp5FRAbQPX3TgFDVqG98TdsnnGlarSiK/l5xG/fNR7wU0uhIqP/KKT7UtAo2nf2+V+ROCCRXxrOdMgXBk98GoKQ4xDv21C60Trt33o2Ln2+ZBUgwNpH/k+kEQKBgB2nXxMwe+jNm1zCnwGv98RgCWxvqvkcwDoVaPwNhaL/kb9ujWIVvGfobpW+a2qM/4n+paQDamNBJAFAmfHdrSdIvLL9GUBcWA0DO/E4dmS8fxdA7fpwuVPGINoGrt2VuSy+ZouuoPinTR02BVysdfuWW0EZzDBYf4XjqmcAXKVhAoGADuutyc/uJf7LeicDXjAlMRbRSPZOkmU77MeVRejb6X0Q9KZCv4KP/Gmvir27RuEiizVMfAZbC9xp5fBApSz2XUqCuaVALQu4V+tJuX4P3bQAY/L+sSNZJI+7M/abCAwWvFUHSuqcBdhyf/xc+ZOjAiGfC9E4OktCo/Kg/GaTDGECgYEAnz/9I0/iS10GBE/PzOYAiyA7Bj9tp+J/K1ZzJjhCjGGJOd6ih1IAhVdFQG+lH3UuGCYB237BGalvhLBsUeY/kcYAozO4DVEpPCFUoC3bWSZSCkotYPpeV6AuZ8IoKvbCelRvO5CJIzX/Ar5CE9d4Dyn0PPav9jtA3fWcZKFOeeE=";

    public static String getTokenKey() {
        String key = "paci_access_token_" + JwtTokenUtil.getTenant() + "_" + JwtTokenUtil.getUserId();
        System.out.println("paic_token_key = " + key);
        return key;
    }

    public static String getFlowIdKey(String vin) {
        String key = "paci_flow_id_" + JwtTokenUtil.getTenant() + "_" + JwtTokenUtil.getUserId()+"_"+vin;
        System.out.println("paci_flow_id_ = " + key);
        return key;
    }

    public void setFlowId(String vin,String flowId) {
        LOGGER.info("保存平安 flowId...{}", flowId);
        redisUtils.set(MessageUtils.getFlowIdKey(vin), flowId, 60*60, TimeUnit.SECONDS);
    }

    public String getFlowId(String vin) {
        String flowId = (String) redisUtils.get(MessageUtils.getFlowIdKey(vin));
        LOGGER.info("获取平安 flowId...{}", flowId);
        if (StringUtils.isEmpty(flowId))
            throw new BusinessException("平安：投保流程超时，请重新进行车型查询后，再进行操作!");
        return flowId;
    }


    public static TokenRes getAccessToken() {
        Map<String, Object> dataMap = new HashMap<>();
        dataMap.put("client_id", CLIENT_ID);
        dataMap.put("grant_type", "client_credentials");
        if (PAICConstants.InterfaceUrl.PAIC_TOKEN_URL.contains("test")) {
            dataMap.put("client_secret", CLIENT_SECRET_TEST);
        } else {
            dataMap.put("client_secret", CLIENT_SECRET);
        }

        String jsonMsg = HttpClientUtils.sendPost(PAICConstants.InterfaceUrl.PAIC_TOKEN_URL, dataMap);
//        String jsonMsg = HttpClientUtils.sendPost(PAICConstants.InterfaceUrl.PRODUCT_TOKEN_URL, dataMap);
        JSONObject jsonObject = JSONObject.parseObject(jsonMsg);
        LOGGER.info("响应出参: access_token: {}", jsonObject);
        TokenRes tokenRes = jsonObject.toJavaObject(TokenRes.class);
        if ("0".equals(tokenRes.getRet())) {
            return tokenRes;
        } else {
            throw new BusinessException("平安保险：获取 access_token 失败，错误码："
                    + tokenRes.getRet() + "，错误消息：" + tokenRes.getMsg());
        }
    }

    /**
     * 平安：发送请求数据，非加密方式
     *
     * @param serviceName 服务名
     * @param jsonObject 业务数据对象
     * @return
     */
    public static String sendPost(String serviceName, JSONObject jsonObject, String accessToken) {
        // 	Content-Type:application/json;charset=utf-8；Accept:application/json;charset=utf-8
        // 请求头信息
        Map<String, String> headers = new HashMap<>();
        headers.put("Content-Type", "application/json");
        headers.put("Accept", "application/json");

        if (StringUtils.isEmpty(accessToken)) {
            TokenRes tokenRes = getAccessToken();
            accessToken = tokenRes.getData().getAccess_token();
        }

        // 拼接请求的url，access_token={令牌}&request_id={请求随机流水号}
//        String url = PAICConstants.InterfaceUrl.TEST_URL + serviceName;
//        String url = PAICConstants.InterfaceUrl.PRODUCT_URL + serviceName;
        String url = PAICConstants.InterfaceUrl.PAIC_URL + serviceName;
        url += "?access_token=" + accessToken;
        url += "&request_id=" + UUID.randomUUID().toString().replaceAll("-", "");

        String result = HttpClientUtils.sendPost(url, headers, jsonObject);
        LOGGER.info("响应出参：{}", result);
        return result;
    }



    /**
     * 平安：发送请求数据，非加密方式
     *
     * @param serviceName 服务名
     * @param jsonObject 业务数据对象
     * @return
     */
//    public static String sendPost(String serviceName, JSONObject jsonObject) {
//        // 	Content-Type:application/json;charset=utf-8；Accept:application/json;charset=utf-8
//        // 请求头信息
//        Map<String, String> headers = new HashMap<>();
//        headers.put("Content-Type", "application/json");
//        headers.put("Accept", "application/json");
//
//        TokenRes tokenRes = getAccessToken();
//
//        // 拼接请求的url，access_token={令牌}&request_id={请求随机流水号}
//        String url = PAICConstants.InterfaceUrl.TEST_URL + serviceName;
//        url += "?access_token=" + tokenRes.getData().getAccess_token();
//        url += "&request_id=" + UUID.randomUUID().toString().replaceAll("-", "");
//
//        String result = HttpClientUtils.sendPost(url, headers, jsonObject);
//        LOGGER.info("响应出参 {}", result);
//        return result;
//    }

//    /**
//     * 平安：发送请求数据，添加签名方式
//     *
//     * @param serviceName 服务名
//     * @param dataMap 业务数据对象
//     * @return
//     */
//    public static String sendPostWithSignature(String serviceName, Map<String, Object> dataMap) {
//        // 排序
//        String s = RSA.sortParametersWithASCII(dataMap);
//        // 签名
//        String signData = null;
//        try {
//            signData = RSA.sign(s, privateKey);
//        } catch (Exception e) {
//            e.printStackTrace();
//            throw new BusinessException("平安：添加签名失败！");
//        }
//        dataMap.put("signature", signData);
//        String url = PAICConstants.InterfaceUrl.TEST_URL + serviceName;
//        String result = HttpClientUtils.sendPost(url, dataMap);
//        LOGGER.info("响应出参 {}", result);
//        return result;
//    }

    /**
     * 平安：响应数据，解密
     * @param pwd 需要解密的数据
     * @return 解密后的数据
     */
    public static JSONObject decrypt(String pwd) {
        String result;
        try {
//            result = RSA.rsaDecrypt(pwd, privateKey, "UTF-8");
            result = RSA.rsaDecrypt(pwd, PAICConstants.privateKey, "UTF-8");
        } catch (Exception e) {
            e.printStackTrace();
            throw new BusinessException("平安：解密失败！");
        }
        return (JSONObject) JSON.toJSON(result);
    }

    /**
     * 平安：添加签名方式
     *
     * @param dataMap 业务数据对象
     * @return
     */
    public static String getSignature(Map<String, String> dataMap) {
        // 排序
        String s = RSA.sortParametersWithASCII(dataMap);
        // 签名
        String signData = null;
        try {
            signData = RSA.sign(s, PAICConstants.privateKey);
            return signData;
        } catch (Exception e) {
            e.printStackTrace();
            throw new BusinessException("平安：获取签名失败！");
        }
    }

    /**
     * 平安：添加签名方式
     *
     * @param dataMap 业务数据对象
     * @return
     */
    public static String getSignature2(Map<String, Object> dataMap) {
        // 排序
        String s = RSA.sortParametersWithASCII(dataMap);
        // 签名
        String signData = null;
        try {
            signData = RSA.sign(s, PAICConstants.privateKey);
            return signData;
        } catch (Exception e) {
            e.printStackTrace();
            throw new BusinessException("平安：获取签名失败！");
        }
    }

    public static void main(String[] args) {
//        new MessageUtils().getAccessToken();
        // 标的检查
        /*
         * {
         * 	"vehicle.licenseNo":"粤A*-*",
         * 	"inputBy":"XXXXX-00001",
         * 	"saleCode":"214261408104"
         * }
         *
         * 可用的信息
         * 1. 201机构--北京：
         *  "inputBy": "BEIJING-00005","saleCode": "201387602001"
         *  "inputBy": "BJDG-00001",    "saleCode": "201998531263"
         *  "inputBy": "BJJYLH-00001",    "saleCode": "201377418001"，采集器编码：05-03-20140910-0002510448
         *  20119
         *      "inputBy": "BJRJQC-00002",
         *      "saleCode": "201998540202"
         *  20121
         *      "inputBy": "BEIJING-00005",
         *      "saleCode": "201211502146"
         *   
         *      "inputBy": "BJDG-00001",
         *      "saleCode": "201998531263"
         */
        IndexReq req = new IndexReq();
        Vehicle vehicle = new Vehicle();
        vehicle.setLicenseNo("京*-*新");

        req.setUserId(String.valueOf(JwtTokenUtil.getUserId()));
        req.setVehicle(vehicle);
//        req.setCityCode("110100");
//        req.setInputBy(PAICConstants.INPUT_BY);
//        req.setSaleCode(PAICConstants.SALE_CODE);
        JSONObject jsonObject = (JSONObject) JSON.toJSON(req);
//        String s = new MessageUtils().sendPost(PAICConstants.ServiceName.INSURE_INDEX, jsonObject);
//        System.out.println(s);
    }
}
