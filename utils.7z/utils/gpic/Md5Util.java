package com.sinosoft.car.utils.gpic;

import com.cloud.fast.exceptions.BusinessException;
import sun.misc.BASE64Encoder;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Map;
import java.util.TreeMap;


public class Md5Util {
	/**
	 * Used building output as Hex
	 */
	private static final char[] DIGITS = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f' };

	/**
	 * md5
	 */
	public static String md5(String text) {
		MessageDigest msgDigest = null;

		try {
			msgDigest = MessageDigest.getInstance("MD5");
		} catch (NoSuchAlgorithmException e) {
			throw new BusinessException(e.getMessage());
		}

		try {
			msgDigest.update(text.getBytes("GBK")); //
		} catch (UnsupportedEncodingException e) {
			throw new BusinessException(e.getMessage());
		}

		byte[] bytes = msgDigest.digest();

		String md5Str = new String(encodeHex(bytes));

		return md5Str;
	}

	public static String md5(String text, String encoding) {
		MessageDigest msgDigest = null;

		try {
			msgDigest = MessageDigest.getInstance("MD5");
		} catch (NoSuchAlgorithmException e) {
			throw new BusinessException(e.getMessage());
		}

		try {
			msgDigest.update(text.getBytes(encoding)); //
		} catch (UnsupportedEncodingException e) {
			throw new BusinessException(e.getMessage());
		}

		byte[] bytes = msgDigest.digest();

		String md5Str = new String(encodeHex(bytes));

		return md5Str;
	}

	public static char[] encodeHex(byte[] data) {
		int l = data.length;

		char[] out = new char[l << 1];

		// two characters form the hex value.
		for (int i = 0, j = 0; i < l; i++) {
			out[j++] = DIGITS[(0xF0 & data[i]) >>> 4];
			out[j++] = DIGITS[0x0F & data[i]];
		}

		return out;
	}

	/**
	 * pos MD5 加密
	 */
	public static String getMD5Str(String str) {
		MessageDigest messageDigest = null;

		try {
			messageDigest = MessageDigest.getInstance("MD5");
			messageDigest.reset();
			messageDigest.update(str.getBytes("UTF-8"));
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}

		byte[] byteArray = messageDigest.digest();

		StringBuffer md5StrBuff = new StringBuffer();

		for (int i = 0; i < byteArray.length; i++) {
			if (Integer.toHexString(0xFF & byteArray[i]).length() == 1) {
				md5StrBuff.append("0").append(Integer.toHexString(0xFF & byteArray[i]));
			} else {
				md5StrBuff.append(Integer.toHexString(0xFF & byteArray[i]));
			}
		}

		return md5StrBuff.toString();
	}

	public static String MD5Base64_Sign(Map map, String key, String encoding) {
		Map<String, Object> treeMap = new TreeMap();
		treeMap.putAll(map);
		String data = treeMap.toString();
		String datas = data.replace("{", "").replace("}", "").replaceAll(", ", "&");
		datas = datas + "&key=" + key;
		String signStr = "";
		String asc = "";
		try {
			MessageDigest md = MessageDigest.getInstance("MD5");
			md.update(datas.getBytes(encoding));
			byte[] b = md.digest();
			asc = bcd2str(b, 0, 16);
			signStr = (new BASE64Encoder()).encode(b).toUpperCase();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return signStr;
	}

	public static String bcd2str(byte[] bytes, int start, int length) {
		int end = 0;
		if (start + length > bytes.length) {
			end = start + bytes.length;
		} else {
			end = start + length;
		}

		char temp[] = new char[length * 2];
		char val;

		for (int i = start; i < end; i++) {
			val = (char) (((bytes[i] & 0xf0) >> 4) & 0x0f);
			temp[(i - start) * 2] = (char) (val > 9 ? val + 'A' - 10 : val + '0');
			val = (char) (bytes[i] & 0x0f);
			temp[(i - start) * 2 + 1] = (char) (val > 9 ? val + 'A' - 10 : val + '0');
		}

		return new String(temp);
	}

	public static void main(String[] args) throws Exception {
	}
}
