package com.sinosoft.car.utils.gpic;

import javax.servlet.http.HttpServletRequest;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.NetworkInterface;
import java.util.Enumeration;

/**
 * 车商平台 : 获取请求方系统信息工具类
 *
 * @Author XieMengTao
 * @Date 15:25 2021/8/5
 * @Param
 * @return
 **/
public class NetworkUtils {
    /**
     * 国寿 : 判断请求方移动或者PC
     *
     * @Author XieMengTao
     * @Date 21:26 2021/8/8
     * @Param
     * @return
     **/
    public static Boolean getPCBoolean(HttpServletRequest request) {
        boolean isMoblie = false;
        String[] mobileAgents = { "iphone", "android", "phone", "mobile", "wap", "netfront", "java", "opera mobi","opera mini","ucweb", "windows ce", "symbian", "series", "webos", "sony", "blackberry", "dopod",  "nokia", "samsung", "palmsource", "xda", "pieplus", "meizu", "midp", "cldc", "motorola", "foma", "docomo", "up.browser", "up.link", "blazer", "helio", "hosin", "huawei", "novarra", "coolpad", "webos",  "techfaith", "palmsource", "alcatel", "amoi", "ktouch", "nexian","ericsson", "philips", "sagem","wellcom", "bunjalloo", "maui","smartphone", "iemobile", "spice", "bird", "zte-", "longcos","pantech", "gionee", "portalmmm", "jig browser", "hiptop", "benq", "haier", "^lct", "320x320", "240x320", "176x220", "w3c ", "acs-", "alav", "alca", "amoi", "audi", "avan", "benq", "bird", "blac","blaz", "brew", "cell", "cldc", "cmd-", "dang", "doco", "eric", "hipt", "inno", "ipaq", "java", "jigs","kddi", "keji", "leno", "lg-c", "lg-d", "lg-g", "lge-", "maui", "maxo", "midp", "mits", "mmef", "mobi","mot-", "moto", "mwbp", "nec-", "newt", "noki", "oper", "palm", "pana", "pant", "phil", "play", "port","prox", "qwap", "sage", "sams", "sany", "sch-", "sec-", "send", "seri", "sgh-", "shar", "sie-", "siem","smal", "smar", "sony", "sph-", "symb", "t-mo", "teli", "tim-", "tosh", "tsm-", "upg1", "upsi", "vk-v","voda", "wap-", "wapa", "wapi", "wapp", "wapr", "webc", "winw", "winw", "xda", "xda-","Googlebot-Mobile" };
        if (request.getHeader("User-Agent") != null) {
            for (String mobileAgent : mobileAgents) {
                if (request.getHeader("User-Agent").toLowerCase().indexOf(mobileAgent) >= 0) {
                    isMoblie = true;
                    break;
                }
            }
        }
        return isMoblie;
    }
    /**
     * 获取真实的网络请求ip
     * @param request
     * @return
     */
    public static String getIPAddr(HttpServletRequest request) {
        String ip =request.getHeader("x-forwarded-for");

        if (ip ==null ||ip.length() == 0 ||"unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("Proxy-Client-IP");

        }

        if (ip ==null ||ip.length() == 0 ||"unknown".equalsIgnoreCase(ip)) {
            ip =request.getHeader("WL-Proxy-Client-IP");

        }

        if (ip ==null ||ip.length() == 0 ||"unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("HTTP_CLIENT_IP");

        }

        if (ip ==null ||ip.length() == 0 ||"unknown".equalsIgnoreCase(ip)) {
            ip =request.getHeader("HTTP_X_FORWARDED_FOR");

        }

        if (ip ==null ||ip.length() == 0 ||"unknown".equalsIgnoreCase(ip)) {
            ip = request.getRemoteAddr();

        }
        return ip;
    }

    /**
     * 国寿 : 获取物理网卡地址
     *
     * @Author XieMengTao
     * @Date 20:52 2021/8/8
     * @Param [buf]
     * @return java.lang.String
     **/
    protected static   String   toHex(byte   buf)   {
        int   n   =   buf   >=   0   ?   buf   :   256   +   buf;
        String   str   =   Integer.toHexString(n);
        return   str.toUpperCase();
    }
    /**
     * 国寿 : 获取物理网卡地址
     *
     * @Author XieMengTao
     * @Date 20:52 2021/8/8
     * @Param [buf]
     * @return java.lang.String
     **/
    public static String getMac() {
        try {
            Enumeration<NetworkInterface> el = NetworkInterface.getNetworkInterfaces();
            while (el.hasMoreElements()) {
                byte[] mac = el.nextElement().getHardwareAddress();
                if (mac == null)
                    continue;

                StringBuilder builder = new StringBuilder();
                for (byte b : mac) {
                    builder.append(toHex(b));
                    builder.append("-");
                }
                builder.deleteCharAt(builder.length() - 1);
                return builder.toString();

            }
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        return null;
    }

}
