package com.sinosoft.car.utils.gpic;


import javax.net.ssl.SSLContext;
import com.alibaba.fastjson.JSONObject;
import com.cloud.fast.exceptions.BusinessException;
import com.cloud.fast.utils.HttpClientUtils;
import com.sinosoft.car.utils.MD5Utils;
import com.sinosoft.car.utils.contants.GPICConstants;
import com.sinosoft.car.vo.gpic.common.ResponseRoot;
import com.sinosoft.car.vo.gpic.common.ResponseRootList;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.UnsupportedEncodingException;
import java.security.GeneralSecurityException;
import java.util.HashMap;
import java.util.Map;

import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustStrategy;
import org.apache.http.conn.ssl.X509HostnameVerifier;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;

import javax.net.ssl.SSLException;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocket;
import java.io.IOException;
import java.security.cert.X509Certificate;

/**
 * 国寿接口，报文服务工具类
 *
 * @author LiYanLong
 * @version 1.0
 * @date 2021/4/17 17:57
 * @since JDK1.8
 */
public class MessageUtils {

    private static final Logger LOGGER = LoggerFactory.getLogger(MessageUtils.class);

    private static HttpClient client = null;

    static {
        PoolingHttpClientConnectionManager cm = new PoolingHttpClientConnectionManager();
        cm.setMaxTotal(1);
        cm.setDefaultMaxPerRoute(1);
        client = HttpClients.custom().setConnectionManager(cm).build();
    }

    /**
     * 发送请求数据给保司接口
     * @param jsonMsg
     * @return 返回响应数据
     */
    public static String sendPost(String requestUrl, JSONObject jsonMsg) {
        String signature = "";
        try {
            signature = MD5Utils.signMD5(jsonMsg.toJSONString(), MD5Utils.key, "utf-8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        Map<String, String> header = new HashMap<>();
        header.put("signature", signature);
        header.put("Accept-Encoding", "application/json;charset=UTF-8");
        return HttpClientUtils.sendPost(requestUrl, header, jsonMsg);
    }

    /**
     * 判断当前响应是否成功
     * @param responseRoot
     * @return
     */
    public static Boolean isSuccess(ResponseRoot responseRoot) {
        if (!checkResultCode(responseRoot.getResult().getResultCode())) {
            throw new BusinessException(responseRoot.getResult().getResultInfo());
        }
        return true;
    }

    /**
     * 判断当前响应是否成功
     * @param responseRoot
     * @return
     */
    public static Boolean isSuccess(ResponseRootList responseRoot) {
        if (!checkResultCode(responseRoot.getResult().getResultCode())) {
            throw new BusinessException(responseRoot.getResult().getResultInfo());
        }
        return true;
    }

    /**
     * 国寿 :  支付查询订单状态Http调用
     *
     * @Author XieMengTao
     * @Date 11:42 2021/6/11
     * @Param [reqXml, url]
     * @return java.lang.String
     **/
    public static String sendPostOrder(String reqXml, String url) throws Exception{
        String charset = "utf-8";
        int connTimeout = 10*1000;
        int readTimeout = 120*1000;
        HttpClient client = null;
        String respXml = null;
        HttpPost post = new HttpPost(url);
        try {
            if (StringUtils.isNotBlank(reqXml)) {
                HttpEntity entity =new StringEntity(reqXml, ContentType.create("application/xml", charset));
                post.setEntity(entity);
            }
            RequestConfig.Builder customReqConf = RequestConfig.custom();
            customReqConf.setConnectTimeout(connTimeout);
            customReqConf.setSocketTimeout(readTimeout);
            post.setConfig(customReqConf.build());
            HttpResponse res = null;
            if (url.startsWith("https")) {
                // 执行 Https 请求.
                client = createSSLInsecureClient();
                res = client.execute(post);
            } else {
                // 执行 Http 请求.
                client = MessageUtils.client;
                res = client.execute(post);
            }
            respXml = IOUtils.toString(res.getEntity().getContent(), charset);
        } finally {
            post.releaseConnection();
            if (url.startsWith("https") && client != null&& client instanceof CloseableHttpClient) {
                ((CloseableHttpClient) client).close();
            }
        }
        return respXml;
    }

    /**
     * 国寿 : 创建 SSL连接
     *
     * @Author XieMengTao
     * @Date 12:28 2021/6/11
     * @Param []
     * @return org.apache.http.impl.client.CloseableHttpClient
     **/
    private static CloseableHttpClient createSSLInsecureClient() throws GeneralSecurityException {
        try {
            SSLContext sslContext = new SSLContextBuilder().loadTrustMaterial(null, new TrustStrategy() {
                public boolean isTrusted(X509Certificate[] chain,String authType) {
                    return true;
                }
            }).build();

            SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(sslContext, new X509HostnameVerifier() {

                @Override
                public boolean verify(String arg0, SSLSession arg1) {
                    return true;
                }

                @Override
                public void verify(String host, SSLSocket ssl)
                        throws IOException {
                }

                @Override
                public void verify(String host, X509Certificate cert)
                        throws SSLException {
                }

                @Override
                public void verify(String host, String[] cns,
                                   String[] subjectAlts) throws SSLException {
                }

            });

            return HttpClients.custom().setSSLSocketFactory(sslsf).build();

        } catch (GeneralSecurityException e) {
            throw e;
        }
    }

    /**
     * 检查响应代码
     * @param resultCode
     * @return
     */
    private static Boolean checkResultCode(String resultCode) {
        return (GPICConstants.ResultCode.SUCCESS.equals(resultCode)
                || GPICConstants.ResultCode.SUCCESS_PROMPT_INFO.equals(resultCode));
    }
}
