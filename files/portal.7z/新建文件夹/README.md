# portal 前端 front

前端特性：不仅支持 lui（物流 UI 组件库）， 支持 element ui， 同时支持价值供应链 UI 组件库 vsc-front-ui。
Z-INDEX 目前最高值 3000

## 项目开始安装依赖

### 注：如果没有安装 jnpm 执行

```
npm install @jd/jnpm -g --registry=http://registry.m.jd.com

```

### 安装 jnpm 后执行

```
jnpm install

```

### 运行环境

```
npm run serve
```

### 打包时，执行

```
npm run build
```

### 测试环境打包

```
npm run build:release
```

### lui 前端，请参考：

http://lui.jd.com/#/
