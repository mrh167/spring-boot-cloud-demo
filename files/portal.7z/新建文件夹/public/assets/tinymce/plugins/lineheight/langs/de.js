tinymce.addI18n('de', {
    "Line Height": "Zeilen Höhe"
});