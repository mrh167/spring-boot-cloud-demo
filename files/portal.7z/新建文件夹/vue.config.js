const path = require('path')

const IS_PRODUCTION = process.env.NODE_ENV === 'production' // 正式环境
const IS_RELEASE = process.env.NODE_ENV === 'release'
// const UglifyJsPlugin = require('uglifyjs-webpack-plugin')
const MiniCssExtractPlugin = require('mini-css-extract-plugin')
const Timestamp = new Date().getTime()

new MiniCssExtractPlugin({
  // 修改打包后css文件名
  filename: `css/[name].${Timestamp}.css`,
  chunkFilename: `css/[name].${Timestamp}.css`
})

function resolve(dir) {
  return path.join(__dirname, dir)
}

module.exports = {
  publicPath: process.env.NODE_ENV === 'production' ? './' : '/',
  // 输出文件目录
  outputDir: IS_RELEASE ? 'release' : 'dist',
  // 放置生成的静态资源 (js、css、img、fonts) 的目录(相对于outputDir目录)。
  assetsDir: 'assets',
  // eslint-loader 是否在保存的时候检查
  lintOnSave: process.env.NODE_ENV !== 'production',
  productionSourceMap: false,
  configureWebpack: {
    output: {
      // 输出重构  打包编译后的 文件名称  【模块名称.hash值】
      // filename: `assets/js/[name].[hash].js`,
      // chunkFilename: `assets/js/[name].[hash].js`,
      // 输出重构  打包编译后的 文件名称  【模块名称.版本号.时间戳】
      filename: `assets/js/[name].${Timestamp}.js`,
      chunkFilename: `assets/js/[name].${Timestamp}.js`
    }
    //注释console
    // optimization: {
    //   minimizer: [
    //     new UglifyJsPlugin({
    //       uglifyOptions: {
    //         compress: {
    //           // warnings: false,
    //           drop_console: true, //注释console
    //           drop_debugger: false,
    //           pure_funcs: ['console.log'] //移除console
    //         }
    //       }
    //     })
    //   ]
    // }
  },
  chainWebpack: config => {
    config.resolve.alias
      .set('@', resolve('src'))
      .set('assets', resolve('src/assets'))
      .set('components', resolve('src/components'))
      .set('api', resolve('src/api'))
      .set('lib', resolve('src/lib'))
      .set('utils', resolve('src/utils'))
      .set('views', resolve('src/views'))
  },
  devServer: {
    open: true,
    // host: '192.168.43.228',
    host: '0.0.0.0',
    // host: '192.168.137.162',
    allowedHosts: ['.jd.com', '.jdwl.com', '.jdl.cn'],
    port: 80,
    https: false,
    hotOnly: false
    // 配置多个代理
    // proxy: {
    //   '/api': {
    //     target: 'http://127.0.0.1', // 本地模拟数据服务器
    //     changeOrigin: true,
    //     pathRewrite: {
    //       '^/api': '' // 去掉接口地址中的api字符串
    //     }
    //   }
    // }
  },
  css: {
    loaderOptions: {
      postcss: {
        plugins: []
      }
    }
  }
}
