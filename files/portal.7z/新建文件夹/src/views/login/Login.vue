<template>
  <div class="pin-login-form">
    <div v-if="usePwdLogin && loginMode === 'pwd'" class="login_style_withpc">
      <form v-show="isShow" id="add_form">
        <iframe
          id="loginFrameRef"
          ref="loginFrameRef"
          src="https://passport.jd.com/common/loginPage?from=stockctrluniv&btnTag=4725af0c3d848878&ReturnUrl=http://jh.jdwl.com/#/home"
          scrolling="no"
          frameborder="0"
          :style="pwdLoginStyle"></iframe>
      </form>
      <a v-if="usePwdLogin && useQrcLogin" class="login_style" data-for="qrc" title="切换到二维码登录" @click.prevent="doChangeLoginMode"></a>
      <div v-show="isShow" class="channel">
        <span>渠道：</span> <a href="https://ssa.jd.com/sso/login?ReturnUrl=http://jh-pre.jd.com">运营登录</a>
      </div>
    </div>
    <div v-if="useQrcLogin && loginMode === 'qrc'" class="login_style_withqrc">
      <div class="login_withqrc_tit">用手机京东扫码安全登录</div>
      <div class="login_withqrc_code">
        <img ref="qrcImageRef" src="" :width="qrcLoginWidth" :height="qrcLoginHeight">
      </div>
      <!-- <div class="login_withqrc_tip"><a id="refresh_code" href="javascript:;">刷新二维码</a> <span class="login_withqrc_tip_sep">|</span>
           支持京东ME v2.6.0以上版本
       </div>-->
      <div v-if="qrcErrMsg" class="login_form_row warntip">
        <i class="warntip_icon"></i>
        <span ref="warntipMsgRef" class="warntip_text">{{ qrcErrMsg || '登录超时，请刷新后重新扫描' }}</span>
      </div>
      <a v-if="usePwdLogin && useQrcLogin" class="login_style" data-for="pc" title="切换到密码登录" @click.prevent="doChangeLoginMode"></a>
    </div>
  </div>
</template>

<script>
// eslint-disable-next-line import/no-extraneous-dependencies
import $ from 'jquery'

export default {
  name: 'Login',
  props: {
    /**
     * 应用App的Id，需要申请
     */
    appId: {
      type: Number,
      require: true
    },
    /**
     * 登录后的应用系统的url
     * 例子：http://stockctrl-univ.jd.com/index.do
     */
    appUrl: {
      type: String,
      require: true
    },
    /**
     * 是否启用用户密码登录
     */
    usePwdLogin: {
      type: Boolean,
      default: true
    },
    /**
     * 是否启用二维码扫描登录
     */
    useQrcLogin: {
      type: Boolean,
      default: false
    },
    /**
     * 京东用户密码登录的SSO URL链接
     */
    pwdLoginSrc: {
      type: String,
      require: false
    },
    /**
     * 京东二维码登录的SSO URL链接
     */
    qrcLoginSrc: {
      type: String,
      require: false
    },
    pwdLoginWidth: {
      type: Number | String,
      require: false,
      default: '380px'
    },
    pwdLoginHeight: {
      type: Number | String,
      require: false,
      default: '240px'
    },
    qrcLoginWidth: {
      type: Number | String,
      require: false,
      default: '187'
    },
    qrcLoginHeight: {
      type: Number | String,
      require: false,
      default: '187'
    }
  },
  data() {
    return {
      loginMode: 'pwd', // 登录模式：pwd密码登录  qrc二维码扫码登录
      pwdLoginIframeSrc: this.pwdLoginSrc,
      qrcLoginIframeSrc: this.qrcLoginSrc,
      qrcEpollTask: null, // 定时任务Id，轮询二维码是否被app扫描
      qrcWlfstkSmdl: null, // 二维码的Cookie
      qrcScanSucc: false, // 是否二维扫描成功
      qrcErrMsg: '', // 二维扫描失败的信息
      isShow: false
    }
  },
  computed: {
    pwdLoginStyle() {
      const width = this.pwdLoginWidth || '100%'
      const height = this.pwdLoginWidth || '100%'
      return { width, height }
    }
  },
  watch: {
    pwdLoginSrc(newValue) {
      this.pwdLoginIframeSrc = newValue
      this.reloadPwdLogin()
    },
    qrcLoginSrc(newValue) {
      this.qrcLoginIframeSrc = newValue
      this.reloadQrcLogin()
    }
  },
  mounted() {
    this.onloadIframe()
    document.documentElement.scrollTop = 0
  },
  beforeDestroy() {
    this.stopQrcTask()
  },
  methods: {
    onloadIframe() {
      //iframe加载完成后，对其子元素进行操作
      var thls = this
      var iframe = document.getElementById('loginFrameRef')
      if (iframe.attachEvent) {
        iframe.attachEvent('onload', function() {
          thls.isShow = true
          //iframe加载完成后你需要进行的操作
          // $('#re-img').contents().find('img').css('width', '80vw')
        })
      } else {
        iframe.onload = function() {
          thls.isShow = true
          //iframe加载完成后你需要进行的操作
          var _iframe = document.getElementById('loginFrameRef')
          // .contentWindow.document.getElementById('formloginframe')//iframe下的id
          _iframe.style.paddingTop = '40px'//修改样式
          // $('#loginFrameRef').contents().find('#entry').css('padding-top', '50px')
        }
      }
    //if...else...是一种兼容ie的写法
    },
    init() {
      // if (this.usePwdLogin) {
      //   this.reloadPwdLogin()
      // } else if (this.useQrcLogin) {
      this.reloadQrcLogin()
      // }
    },
    doChangeLoginMode() {
      if (this.loginMode === 'qrc') {
        this.loginMode = 'pwd'
        this.$nextTick(() => {
          this.reloadPwdLogin()
        })
      } else {
        this.loginMode = 'qrc'
        this.$nextTick(() => {
          this.reloadQrcLogin()
        })
      }
    },
    reloadPwdLogin() {
      if (this.$refs.loginFrameRef) {
        // this.$refs['loginFrameRef'].src = this.pwdLoginIframeSrc
        this.$refs.loginFrameRef.src = 'https://passport.jd.com/common/loginPage?from=stockctrluniv&btnTag=4725af0c3d848878&ReturnUrl=http://stockctrl-univ.jd.com/index.do'
      }
    },
    reloadQrcLogin() {
      if (this.$refs.qrcImageRef) {
        this.$refs.qrcImageRef.src = this.qrcLoginIframeSrc
        this.qrcWlfstkSmdl = this.getCookie('wlfstk_smdl')
        this.startQrcTask()
      }
    },
    /**
     * 定时轮询二维码是否被app扫描
     */
    startQrcTask() {
      if (!this.qrcWlfstkSmdl) {
        this.qrcChangeState('未接入应用系统，暂无cookie信息')
        return
      }
      this.stopQrcTask()
      this.qrcEpollTask = setInterval(() => {
        this.qrcCheck()
      })
    },
    /**
     * 暂停二维码被扫描任务
     */
    stopQrcTask() {
      this.qrcEpollTask && clearInterval(this.qrcEpollTask)
      this.qrcEpollTask = null
    },
    /**
     * 检查二维码是否app扫描
     */
    qrcCheck() {
      const that = this
      $.ajax({
        url: 'https://qr.m.jd.com/check',
        dataType: 'jsonp',
        data: { appid: this.appId, token: this.qrcWlfstkSmdl },
        scriptCharset: 'utf-8',
        success(result) {
          if (result) {
            const { code } = result
            const { ticket } = result
            this.qrcScanSucc = false
            switch (code) {
              case 200: // 已经确认登录，会返回ticket
                ticket && that.qrcSubmitLogin(ticket)
                break
              case 201: // 二维码，未扫描，未过期
                // main.events.qrcLogin.changeState('二维码未扫描，未过期');
                break
              case 202: // 二维码，已扫描，未确认登录
                that.qrcScanSuccess()
                break
              // 二维码已过期，需重新请求二维码
              case 203:
                that.qrcChangeState('二维码已过期，请重新刷新二维码')
                break
              // 二维码无效
              case 204:
                that.qrcChangeState('二维码无效，请重新刷新二维码')
                break
              // 取消二维码登录
              case 205:
                that.qrcChangeState('已取消二维码登录')
                break
            }
          }
        }
      })
    },

    // 二维扫描成功后登录
    qrcSubmitLogin(ticket) {
      const that = this
      this.qrcEpollTask && this.stopQrcTask()

      $.ajax({
        url: 'https://passport.jd.com/uc/qrCodeTicketValidation',
        dataType: 'jsonp',
        data: { t: ticket, ReturnUrl: this.appUrl },
        scriptCharset: 'utf-8',
        success(result) {
          if (result) {
            const code = result.returnCode
            // let url = result.url

            switch (code) {
              case 0: // 成功，页面跳转
                // window.location.reload();
                that.$emit('on-qrc-login') // 二维扫描成功后登录回调事件
                break
              case 58: // ticket失效
                that.qrcChangeState('ticket失效')
                break
              case 59: // ticket已过期，需要重新获取
                that.qrcChangeState('ticket已过期，需要重新获取')
                break
              case 60: // -1:网络失败 -2:返回数据包格式错误 -3:返回数据包解包失败 -4:输入参数错误
                that.qrcChangeState('ticket出现异常')
                break
              case 70: // ticket为空
                that.qrcChangeState('ticket为空，需要重新获取')
                break
            }
          }
        }
      })
    },
    qrcChangeState(errMsg) {
      this.qrcErrMsg = errMsg
    },
    qrcScanSuccess() {
      this.qrcErrMsg = '扫描成功，正在登录中...'
    },

    /**
     * 获取Cookie
     * @param cookieName
     * @returns {string}
     */
    getCookie(cookieName) {
      let start,
        end
      if (document.cookie.length > 0) {
        start = document.cookie.indexOf(`${cookieName}=`)
        if (start !== -1) {
          start = start + cookieName.length + 1
          end = document.cookie.indexOf(';', start)
          if (end === -1) end = document.cookie.length
          return unescape(document.cookie.substring(start, end))
        }
      }
      return ''
    }
  }
}
</script>
<style lang="stylus">
  .login_style_withpc{
    position: relative;
    #add_form{
      background: #fff;
    }
    .channel{
      position:absolute;
      left:36px;
      bottom:30px;
      font-size: 14px;
    }
  }
  .pin-login-form{
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100%;
    background: url(../../assets/img/loginbanner.png) no-repeat;
  }
</style>
