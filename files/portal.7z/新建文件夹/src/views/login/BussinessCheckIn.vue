<template>
  <div v-if="maskMainShow" ref="container" class="container">
    <div ref="mask" class="login_mask">
      <div ref="masks" class="mask_wapper">
        <div class="wapper-title">
          <div class="imgBox">
            <img src="@/assets/img/applyTitle.png" alt="">
          </div>
          <span>Hi，欢迎来到京慧！</span>
          <i class="lui-icon-close" @click="handelClickClose(1)"></i>
        </div>
        <div class="wapper-body">
          <div class="body-title">
            <h2 class="busiTitle">客户信息</h2>
            <p>如信息有误，请联系您所对接的销售支持。</p>   
          </div>
          <div class="body-main">
            <lui-form
              ref="ruleForm"
              :model="ruleForm"
              label-width="70px">
              <div class="ruleForm-title">
                <lui-form-item
                  label="客户编码"
                  prop="sellerNo">
                  <lui-input
                    v-model="ruleForm.sellerNo"
                    show-word-limit
                    disabled>
                  </lui-input>
                </lui-form-item>

                <lui-form-item
                  label="客户名称"
                  prop="sellerName">
                  <lui-input
                    v-model="ruleForm.sellerName"
                    show-word-limit
                    disabled>
                  </lui-input>
                </lui-form-item>
                <lui-form-item
                  label="客户类型"
                  prop="sellerType">
                  <span>{{ ruleForm.sellerType }}</span>
                </lui-form-item>

                <lui-form-item
                  label="签约区域"
                  prop="registerRegion">
                  <lui-input
                    v-model="ruleForm.registerRegion"
                    show-word-limit
                    disabled>
                  </lui-input>
                </lui-form-item>

                <lui-form-item
                  label-width="0px"
                  label="">
                  <div class="from-div">
                    <div class="div-top" @click="bodyshow=!bodyshow">
                      <span>{{ bodyshow?'收起事业部信息':'展开事业部信息' }}</span>
                      <i :class="bodyshow ? 'lui-icon-arrow-up':'lui-icon-arrow-down'"></i>
                    </div>

                    <lui-collapse-transition>
                      <div v-show="bodyshow" class="div-body">
                        <dl v-for="item in ruleForm.deptList" :key="item.deptNo">
                          <dt>{{ item.deptName }}</dt>
                          <dd>
                            <div>
                              <span>事业部编码：</span>
                              <span>{{ item.deptNo }}</span>
                            </div>
                            <div>
                              <span>事业部名称：</span>
                              <span>{{ item.deptName }}</span>
                            </div>
                            <div>
                              <span>签约区域：</span>
                              <span>{{ item.registerRegion }}</span>
                            </div>
                          </dd>
                        </dl>
                      </div>
                    </lui-collapse-transition>
                    
                  </div>
                </lui-form-item>
                <h2 class="busiTitle">开通版本与有效期</h2>
                <lui-form-item
                  label="开通版本"
                  prop="onlyDistribution">
                  <lui-radio-group v-model="ruleForm.onlyDistribution" disabled>
                    <lui-radio :label="false" class="button_radio">京慧标准版-仓配用户</lui-radio>
                    <lui-radio :label="true" class="button_radio">京慧标准版-纯配用户</lui-radio>
                  </lui-radio-group>
                </lui-form-item>

                <lui-row>
                  <lui-col :span="12">
                    <lui-form-item
                      label="开通时间"
                      prop="startTime">
                      <lui-date-picker
                        v-model="ruleForm.startTime"
                        type="date"
                        disabled
                        placeholder="选择日期">
                      </lui-date-picker>
                    </lui-form-item>
                  </lui-col>

                  <lui-col :span="12">
                    <lui-form-item
                      label="结束时间"
                      prop="endTime">
                      <lui-date-picker
                        v-model="ruleForm.endTime"
                        type="date"
                        disabled
                        placeholder="选择日期">
                      </lui-date-picker>
                    </lui-form-item>
                  </lui-col>
                </lui-row>
              </div>
            </lui-form>
          </div>
        </div>
        <div class="wapper-footer">
          <lui-button type="primary" @click="handelClickClose(2)">提交审批</lui-button>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import Api from '@/api'
export default {
  props: {
    //接收父组件传来的数组
    commercialAccountInfo: {
      type: Object,
      default() {
        return {}
      }
    },
    //接收菜单试用版本
    menuVersionCode: {
      type: Number
    }
  },
  data() {
    return {
      ruleForm: Object.assign({}, this.commercialAccountInfo),
      bodyshow: false,
      radio: 1,
      regionEnum: [],
      maskMainShow: true,
      regionObj: []
    }
  },
  created() {
    
  },
  mounted() {
    // console.log(JSON.stringify(this.ruleForm), '123', this.menuVersionCode)
    this.getListRegisterRegionEnum()
    this.$refs.masks.animate([
      {
        width: '0px',
        height: '0px',
        right: '0%',
        marginRight: '0',
        bottom: '0',
        marginTop: '0', 
        opacity: '0.1'
      },
      { 
        width: '640px',
        height: '640px', 
        marginRight: '-320px',
        right: '50%', 
        bottom: '15%',
        marginTop: '50px',
        opacity: '0.5'
      }
    ], {
      duration: 400
    })
    this.$refs.mask.animate([
      { background: 'rgba(0, 0, 0, 0)' },
      { background: 'rgba(0, 0, 0, 0.8)' }
    ], {
      duration: 400
    })
    setTimeout(() => {
      this.$refs.container.style.display = 'block'
    }, 400)
    
  },
  methods: {
    //获取签约区域枚举的name的值
    getListRegisterRegionEnum() {
      Api.Merchants.regionEnum().then(res => {
        if (res.success) {
          let registerRegion = this.ruleForm.registerRegion === '' ? [] : this.ruleForm.registerRegion.split(',')
          let arr = []
          this.regionObj = res.data
          // console.log(res.data, 12345, registerRegion)
          res.data.forEach((item, index) => {
            //  外层签约区域
            registerRegion.forEach(m => {
              if (item.code === m) {
                arr.push(item.desc)
              }
            })
            //事业部里层签约区域
            this.ruleForm.deptList.forEach(i => {
              if (item.code === i.registerRegion) {
                i.registerRegion = item.desc
              }
            })
          })
          // console.log(arr)
          this.ruleForm.registerRegion = arr.toString() 
        } else {
          this.$showErrorMsg(res.errMessage)
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
      })
    },
    //关闭按钮和提交审批
    handelClickClose(type) {
      if (type === 1) {
        this.bodyshow = false
        this.$refs.masks.animate([
          { 
            width: '640px', 
            height: '640px',
            right: '50%', 
            marginRight: '-320px',
            bottom: '15%',
            marginTop: '50px',
            opacity: '0.5' 
          },
          { 
            width: '0px',
            height: '0px',
            right: '0%', 
            bottom: '0', 
            marginRight: '0', 
            marginTop: '0', 
            opacity: '0.1'
          }//opacity: '0'
        ], {
          duration: 400
        })
        this.$refs.mask.animate([
          { background: 'rgba(0, 0, 0, 0.8)' },
          { background: 'rgba(0, 0, 0, 0)' }
        ], {
          duration: 400
        })
        setTimeout(() => {
          this.$refs.container.style.display = 'none'
          this.maskMainShow = false
          this.$emit('handleQueryUnit', this.maskMainShow)
        }, 400)

      } else {
        //先调下面的接口,成功后再关闭弹框
        this.bodyshow = false
        this.$refs.masks.animate([
          { 
            width: '640px', 
            height: '640px',
            right: '50%', 
            marginRight: '-320px',
            bottom: '15%',
            marginTop: '50px',
            opacity: '0.5' 
          },
          { 
            width: '0px',
            height: '0px',
            right: '0%', 
            bottom: '0', 
            marginRight: '0', 
            marginTop: '0', 
            opacity: '0.1'
          }//opacity: '0'
        ], {
          duration: 400
        })
        this.$refs.mask.animate([
          { background: 'rgba(0, 0, 0, 0.8)' },
          { background: 'rgba(0, 0, 0, 0)' }
        ], {
          duration: 400
        })
        setTimeout(() => {
          this.$refs.container.style.display = 'none'
          this.maskMainShow = false
          this.$emit('handleQueryUnit', this.maskMainShow)
          this.$emit('handleQueryUnitButton', this.maskMainShow)
        }, 400)
        let userSubmitCmd = {}
        userSubmitCmd.sellerNo = this.ruleForm.sellerNo
        //暂时注释
        Api.MerchantLogin.submitApproval(userSubmitCmd).then(res => {
          //审批成功以后
          if (res.success) {
            //关闭弹框
            this.$showSuccessMsg('提交审批成功！') 
            if (this.menuVersionCode === 1) {
              window.location.reload()
            }
          }
        }).catch((e) => {
          this.$showErrorMsg(e)
        })
      }
    }
  }
}
</script>
<style scoped lang='scss'>
@import "@/assets/stylus/main.scss";
  .container{
    position: relative;
    .login_mask{
      position: fixed;
      top: 0;
      bottom: 0;
      left: 0;
      right: 0;
      z-index: 3000;
      background: rgba(0,0,0,0.5);
      overflow-y: scroll;
      .mask_wapper{
        width: 640px;
        overflow: hidden;
        // height: 500px;
        position: absolute;
        margin-top: 50px;
        right: 50%;
        background: #fff;
        margin-right: -320px;
        border-radius: 4px;
        // overflow: hidden;
        box-shadow: 0 4px 12px 0 rgba(0,0,0,0.20);
        // transform: skew(60deg);
        .busiTitle{
          font-size: 16px;
          color: #23252C;
          letter-spacing: 0;
          line-height: 16px;
          margin-bottom: 10px;
        }
        .wapper-title{
          height: 55px;
          background: $--gl-blue;
          // background: url('../../../assets/img/applyTitle.png');
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding-left: 20px;
          padding-right: 20px;
          position: relative;
          .imgBox{
            overflow: hidden;
            width: 100%;
            height: 55px;
            position:absolute;
            top: 0;
            left: 0;
            bottom: 0;
            right: 0;
            img{
              width: 100%;
            }
          }
          span{
            font-size: 16px;
            color: #FFFFFF;
          }
          i{
            cursor: pointer;
            font-size: 18px;
            color: #ccc;
            position: absolute;
            right: 20px;
            z-index: 1;
          }
        }
        .wapper-body{
          width: 100%;
          padding: 20px;
          background: #fff;
          .body-title{
            display: flex;
            align-items: center;
            padding-bottom: 20px;
            h2{
              font-size: 18px;
              font-weight: 600;
              color: #23252C;
            }
            p{
              font-size: 14px;
              color: #656A77;
              padding-left: 12px;
            }
          }
          .body-main{
            .from-div{
              h2{
               font-size: 16px;
                color: #23252C;
                font-weight: 600;
                margin-bottom: 20px;
              }
              border: 1px solid #C8D4E0;
              .div-top{
                height: 33px;
                border-bottom: 1px solid #C8D4E0;
                text-align: center;
                line-height: 32px;
                font-size: 14px;
                color: #656A77;
                cursor: pointer;
                span{
                  padding-right: 10px;
                }
              }
              .div-body{
                max-height: 250px;
                overflow-y: scroll;
                dl{
                  width: 100%;
                  display: flex;
                  min-height: 130px;
                  border-bottom: 1px solid #C8D4E0;
                  // &:last-child{
                  //   border-bottom: none;
                  // }
                  dt{
                    width: 170px;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    font-size: 14px;
                    color: #656A77;
                    border-right: 1px solid #C8D4E0;
                  }
                  dd{
                    width: calc(100% - 170px);
                    padding: 10px 0;
                    div{
                      display: flex;
                      
                      span{
                        font-size: 14px;
                        color: #656A77;
                      }
                      span:nth-child(1){
                        width: 120px;
                        text-align: right;
                      }
                      span:nth-child(2){
                        text-align: left;
                      }
                    }
                  }
                }
              }
            }
          }
        }
        .wapper-footer{
          background: #fff;
          padding-right: 20px;
          height: 60px;
          border-top: 1px solid #E0E9F2;
          text-align: right;
          line-height: 60px;
        }
      }
    }
  }
</style>
<style>
.lui-message-box.message-bg .lui-message-box__header{
  /* background-color: #f00; */
  background:url('../../assets/img/applyTitle.png') no-repeat #1854f3!important
}
.lui-message-box.message-bg .lui-message-box__header .lui-message-box__title{
  color: #FFFFFF;
}
</style>
