<template>
  <div class="public-page">
    <!-- :height="height" -->
    <iframe
      id="child"
      name="child"
      :src="dynamicUrl"
      width="100%"
      border="0"
      :height="height"
      frameborder="0"
      scrolling="auto">
    </iframe>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import $ from 'jquery'

export default {
  // name: 'PublicPage',
  data() {
    return {
      dynamicUrl: '', //动态url
      iframeList: [], //外链列表
      height: 1000 //外链页面高度
    }
  },
  computed: {
    ...mapGetters(['getPublicPage'])
  },
  watch: {
    //监听路由变化
    '$route.path': function(val) {
      this.handleSelect(val)
    }
  },

  mounted() {
    this.iframeList = this.getPublicPage.iframeList
    this.handleSelect(this.$route.path)
  },
  methods: {
    iFrameHeight() {
      const frame = document.getElementById('child')
      const height = document.documentElement.clientHeight
      frame.style.height = height + 'px'
      console.log(document.documentElement.clientHeight, '////////')
    },
    //当路由改变时，改变iframe的src
    handleSelect(path) {
      // const frame = document.getElementById('child')
      // const deviceHeight = document.documentElement.clientHeight
      // let height = Number(deviceHeight) - 80
      // if (height < 400) {
      //   height = 400
      // }
      // console.log(height, '++++++++++')
      // frame.style.height = 'auto'//关键这一句，先取消掉之前iframe设置的高度
      // frame.style.height = height + 'px' //数字是页面布局高度差
     
      // this.iFrameHeight()
      for (let i = 0; i < this.iframeList.length; i++) {
        if (path === this.iframeList[i].path) {
          this.dynamicUrl = this.iframeList[i].meta.url //后端返回的外链url
          this.height = this.iframeList[i].height ? this.iframeList[i].height : 1000 //解决双滚动条
          return
        }
      }
    }
  }
}
</script>

<style scoped lang="scss">
.public-page {
  width: 100%;
  height: 100%;
}
</style>
