<template>
  <div class="Download">
    <lui-table
      :data="tableData"
      style="width: 85%;margin: 0 auto ">
      <lui-table-column
        prop="admin"
        label="账号">
        <template slot-scope="{row}">
          <p class="table-p"><i class="iconfont lui-icon-circle-plus" style="margin-right: 20px;"></i> {{ row.admin }}</p>
        </template>
      </lui-table-column>
      <lui-table-column
        prop="menu"
        label="操作菜单">
        <template slot-scope="{row}">
          <p class="table-p">{{ row.menu }}</p>
        </template>
      </lui-table-column>
      <lui-table-column
        prop="name"
        label="文件名称">
        <template slot-scope="{row}">
          <p class="table-p">{{ row.name }}</p>
        </template>
      </lui-table-column>
      <lui-table-column
        prop="date"
        label="操作时间">
        <template slot-scope="{row}">
          <p class="table-p">{{ row.date }}</p>
        </template>
      </lui-table-column>
      <lui-table-column
        prop="state"
        label="状态">
        <template slot-scope="{row}">
          <p class="table-p">{{ row.state }}</p>
        </template>
      </lui-table-column>
      <lui-table-column
        label="操作"
        width="130">
        <template>
          <div class="delete">
            <span>下载</span>
            <span>删除</span>
          </div>
        </template>
      </lui-table-column>
    </lui-table>


    <div class="Download-pagination">
      <lui-pagination
        background
        layout="prev, pager, next, sizes, jumper"
        :total="0">
      </lui-pagination>
    </div>
  </div>
</template>

<script>
export default {
  name: 'index',
  data() {
    return {
      tableData: []
    }
  }
}
</script>
<style scoped lang="scss">
  .Download{
    background: #fff;
    width: 100%;
    min-height: 600px;
    padding-bottom: 26px;
    padding-top: 35px;
  }
  .Download-pagination{
    width: 100%;
    margin-top: 73px;
    text-align: center;
  }
  .table-p{
    overflow: hidden;
    text-overflow:ellipsis;
    white-space: nowrap;
    cursor: pointer;
    padding-right: 15px;
  }
  .delete{
    display: flex;
    justify-content: space-around;
    span{
      cursor: pointer;
    }
  }
</style>
