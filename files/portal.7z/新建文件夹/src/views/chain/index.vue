<template>
  <div class="container">
    <div class="information-nav">
      <lui-menu
        :default-active="activeIndex"
        class="lui-menu-demo nav-menu"
        mode="horizontal"
        @select="handleSelect">
        <lui-menu-item index="1">商品替代关系</lui-menu-item>
        <!-- <lui-menu-item index="2">新老品关系</lui-menu-item> -->
      </lui-menu>
      <div class="line"></div>
    </div>
    <div class="container-content">
      <!-- 动态组件切换 -->
      <component :is="currentRole" />
    </div>
  </div>
</template>

<script>
import commodity from './commodity/index.vue'
import relationship from './relationship/index.vue'
export default {
  name: 'index',
  components: {
    commodity,
    relationship
  },
  data() {
    return {
      activeIndex: '1',
      currentRole: 'commodity'
    }
  },
  methods: {
    // 页面跳转
    handleSelect(key) {
      switch (key) {
        case '1':
          //商品替代关系
          this.currentRole = 'commodity'
          break
        case '2':
          //新老品关系
          this.currentRole = 'relationship'
          break
      }
    }
  }
}
</script>

<style scoped lang="scss">
  .container{
    width: 100%;
    .information-nav{
      box-shadow: 2px 2px 7px 2px #ccc;
      border-radius: 0 0 4px 4px;
      padding-top: 20px;
      width: 100%;
      background: #ffffff;
      /*margin-bottom: 20px;*/
      .nav-menu{
        li{
          font-size: 14px;
        }
        li:first-child{
          margin-left: 30px;
        }
      }
    }

    .container-content{
      width: 100%;
      padding-bottom: 30px;
      /*border: 1px solid red;*/
    }
  }
</style>
