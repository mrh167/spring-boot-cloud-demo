<template>
  <div class="configure">
    <div class="configure-title">
      <div class="title-text">筛选搜索</div>
      <div class="title-serch">
        <div class="serch-left">
          <div class="select-content">
            <span class="content-title">事业部</span>
            <lui-select
              v-model="deptName"
              style="width: 180px;"
              placeholder="请选择事业部">
              <lui-option
                v-for="(item,index) in deptNoList"
                :key="index"
                :label="item.deptName"
                :value="item.deptNo">
              </lui-option>
            </lui-select>
          </div>

          <div class="select-content">
            <span class="content-title">新品</span>
            <lui-autocomplete
              v-model="value"
              clearable
              style="width: 180px;"
              class="inline-input"
              :fetch-suggestions="(queryString,cd)=>{queryUnit(queryString,cd,1)}"
              placeholder="输入搜索新品"
              @select="(item)=>{handleSelect(item,1)}">
            </lui-autocomplete>
          </div>
          
          <div class="select-content">
            <span class="content-title">老品</span>
          
            <lui-autocomplete
              v-model="value"
              clearable
              style="width: 180px;"
              class="inline-input"
              :fetch-suggestions="(queryString,cd)=>{queryUnit(queryString,cd,2)}"
              placeholder="输入搜索老品"
              @select="(item)=>{handleSelect(item,2)}">
            </lui-autocomplete>
          </div>
          
          <div class="select-content">
            <span class="content-title">商品关系名</span>
            <lui-autocomplete
              v-model="value"
              clearable
              style="width: 180px;"
              class="inline-input"
              :fetch-suggestions="(queryString,cd)=>{queryUnit(queryString,cd,3)}"
              placeholder="输入搜索商品关系名"
              @select="(item)=>{handleSelect(item,3)}">
            </lui-autocomplete>
          </div>

          <div class="select-content">
            <span class="content-title">版本</span>
            <lui-input
              v-model="value"
              clearable
              style="width: 180px;"
              placeholder="请输入版本"
            ></lui-input>
          </div>

        </div>
        <div class="serch-right">
          <lui-button type="primary" style="width: 80px;">查询</lui-button>
          <lui-button style="width: 80px;">重置</lui-button>
        </div>
      </div>
    </div>
    <div class="master-container">
      <div class="container-top">
        <div class="container-top-left">
          <span class="header-border"></span>
          <span class="header-title">数据列表</span>
        </div>
        <div class="container-top-right">
          <lui-button type="primary" @click="download">批量下载</lui-button>
          <lui-button type="primary">批量上传</lui-button>
          <lui-button type="primary">手工删除</lui-button>
          <lui-button type="primary">手工添加</lui-button>
        </div>
      </div>

      <div class="container-table">
        <div class="container-table-cont">
          <lui-table
            v-loading="LoadingTable"
            :data="tableData"
            border
            style="width: 100%"
            @selection-change="handleSelectionChange">
            <template slot="empty">
              <showEmptyImage></showEmptyImage>
            </template>
            <lui-table-column
              align="center"
              fixed="left"
              type="selection"
              width="50"
              show-overflow-tooltip>
            </lui-table-column>

            <lui-table-column
              prop="deptNo"
              min-width="170"
              label="商品关系名"
              show-overflow-tooltip>
            </lui-table-column>

            <lui-table-column
              prop="deptNo"
              min-width="170"
              label="关系类型"
              show-overflow-tooltip>
            </lui-table-column>

            <lui-table-column
              prop="sellerNo"
              label="新品商品编码"
              min-width="170"
              show-overflow-tooltip>
            </lui-table-column>

            <lui-table-column
              prop="sellerNo"
              label="新品商品名称"
              min-width="170"
              show-overflow-tooltip>
            </lui-table-column>

            <lui-table-column
              prop="goodsNo"
              label="老品商品编码"
              min-width="170"
              show-overflow-tooltip>
            </lui-table-column>

            <lui-table-column
              prop="goodsNo"
              label="老品商品名称"
              min-width="170"
              show-overflow-tooltip>
            </lui-table-column>

            <lui-table-column
              prop="goodsNo"
              label="新品首次入库时间"
              min-width="170"
              show-overflow-tooltip>
            </lui-table-column>

            <lui-table-column
              prop="updateUser"
              width="130"
              label="修改时间"
              show-overflow-tooltip>
            </lui-table-column>

            <lui-table-column
              prop="updateUser"
              width="130"
              label="版本"
              show-overflow-tooltip>
            </lui-table-column>

            <lui-table-column
              fixed="right"
              width="120"
              align="center"
              label="操作">
              <template v-slot="{row}">
                <div class="table-button">
                  <span class="table-look">编辑</span>
                  <span class="table-look">查看</span>
                </div>
              </template>
            </lui-table-column>
          </lui-table>
        </div>
        <div v-show="tableData.length>0" class="knowledge-pagination">
          <lui-pagination
            background
            :current-page.sync="pageNum"
            :page-sizes="[10, 20, 50, 70, 100]"
            layout="prev, pager, next, sizes, jumper"
            :total="totals"
            @current-change="handleSizeChange"
            @size-change="sizeChange">
          </lui-pagination>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import showEmptyImage from '@/components/common/showEmptyImage/index.vue'
import Api from '@/api'
export default {
  name: 'configure.veu',
  components: {
    showEmptyImage
  },
  data() {
    return {
      options: [
        {
          value: '选项1',
          label: '黄金糕'
        },
        {
          value: '选项2',
          label: '双皮奶'
        },
        {
          value: '选项3',
          label: '蚵仔煎'
        },
        {
          value: '选项4',
          label: '龙须面'
        },
        {
          value: '选项5',
          label: '北京烤鸭'
        }
      ],
      value: '',
      value3: '',


      deptNoList: [],
      deptName: '', //事业部
      tableData: [],
      LoadingTable: false,
      totals: 0,
      pageNum: 1, //页
      pageSize: 10 //条数
    }
  },
  mounted() {
    this.queryDept()
  },
  methods: {

    //数据列表
    getList() {},
    //下载模版
    download() {},
    //全选反选
    handleSelectionChange(val) {
      this.multipleSelection = val
    },
    //分页条数改变
    sizeChange(val) {
      this.pageSize = val
      this.getList()
    },
    //翻页-----根据页码变换
    handleSizeChange(val) {
      this.pageNum = val
      this.getList()
    },

    //获取事业部编码
    queryDept() {
      Api.BodCommodity.queryDept().then(row => {
        if (row.success) {
          this.deptNoList = row.data
        } else {
          this.$showErrorMsg(row.errMessage)
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
      })
    },
    // 获取BOD下拉模糊搜索 ------------多次调用懒得起名
    queryUnit(queryString, cb, type) {
      if (type === 1) { //新品查询
        Api.BodConfig.getBaseByBodNo({
          bodNo: this.deptName
        }).then((res) => {
          if (res.success) {
            var results = []
            if (res.data !== '') {
              for (let i = 0, len = res.data.length; i < len; i++) {
                res.data[i].value = res.data[i].bodName
              }
              results = res.data
            }
            cb(results)
          }
        }).catch((e) => {
          this.$showErrorMsg(e)
        })
      } else if (type === 2) { //老品

        Api.BodConfig.getBaseByBodNo({
          bodNo: this.deptName
        }).then((res) => {
          if (res.success) {
            var results = []
            if (res.data !== '') {
              for (let i = 0, len = res.data.length; i < len; i++) {
                res.data[i].value = res.data[i].bodName
              }
              results = res.data
            }
            cb(results)
          }
        }).catch((e) => {
          this.$showErrorMsg(e)
        })

      } else if (type === 3) { //商品关系名

        Api.BodConfig.getBaseByBodNo({
          bodNo: this.deptName
        }).then((res) => {
          if (res.success) {
            var results = []
            if (res.data !== '') {
              for (let i = 0, len = res.data.length; i < len; i++) {
                res.data[i].value = res.data[i].bodName
              }
              results = res.data
            }
            cb(results)
          }
        }).catch((e) => {
          this.$showErrorMsg(e)
        })

      }
    },
    handleSelect(item, type) {
      if (type === 1) { //新品查询
        
      } else if (type === 2) { //老品
        
      } else if (type === 3) { //商品关系名
        
      }
    }
  }
}
</script>

<style scoped lang="scss">
@import '../common/common';
</style>
