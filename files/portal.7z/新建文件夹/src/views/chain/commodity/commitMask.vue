<template>
  <div class="commitMask">
    <div class="container">
      <div class="container_title">
        <div class="title-header">
          <span>历史版本</span>
          <span ref="spanClose" @mouseover="changeActive($event)" @mouseout="removeActive($event)"><i class="lui-icon-close" @click="closeDialogdetils"></i></span>
        </div>

      </div>

      <div class="container_main">
        <div class="container_content">

          <div class="detilsVisible_container">
            <div class="container-title">
              <div class="title-txt">事业部：{{ detailsData.deptName }}</div>
              <div class="title-txt">老品库存使用方式： {{ detailsData.oldGoodsUseForm }}</div>
              <div class="title-txt">替换链名称：{{ detailsData.replaceName }}</div>
              <div class="title-txt">版本：{{ detailsData.replaceVersion }}</div>
            </div>

            <div class="container-table">
              <div class="table-title">
                <span>替代关系</span>
                <span @click="replaceShow = !replaceShow">
                  <i v-if="replaceShow">收起</i>
                  <i v-else>展开</i>
                </span>
              </div>
              <lui-collapse-transition>
                <div v-show="replaceShow">
                  <div class="table-content">
                    <lui-table
                      v-loading="vShow"
                      :data="detailsData.goodsRelationList"
                      border
                      style="width: 100%">
                      <template slot="empty">
                        <showEmptyImage></showEmptyImage>
                      </template>

                      <lui-table-column
                        prop="replaceBeforeGoodsNo"
                        min-width="140"
                        label="替换前件商品编码"
                        show-overflow-tooltip>
                      </lui-table-column>

                      <lui-table-column
                        prop="replaceBeforeIsvGoodsNo"
                        min-width="170"
                        label="替换前件商家商品编码"
                        show-overflow-tooltip>
                      </lui-table-column>

                      <lui-table-column
                        prop="replaceBeforeGoodsName"
                        label="替换前件商品名称"
                        min-width="140"
                        show-overflow-tooltip>
                      </lui-table-column>

                      <lui-table-column
                        prop="replaceAfterGoodsNo"
                        label="替换后件商品编码"
                        min-width="140"
                        show-overflow-tooltip>
                      </lui-table-column>
                      <lui-table-column
                        prop="replaceAfterIsvGoodsNo"
                        label="替换后件商家商品编码"
                        min-width="170"
                        show-overflow-tooltip>
                      </lui-table-column>

                      <lui-table-column
                        prop="replaceAfterGoodsName"
                        label="替换后件商品名称"
                        min-width="140"
                        show-overflow-tooltip>
                      </lui-table-column>

                      <lui-table-column
                        prop="beforeLevel"
                        label="前件层级"
                        width="100"
                        show-overflow-tooltip>
                      </lui-table-column>

                      <lui-table-column
                        prop="afterLevel"
                        label="后件层级"
                        width="100"
                        show-overflow-tooltip>
                      </lui-table-column>

                      <lui-table-column
                        prop="startFlag"
                        label="开始件标识"
                        width="100"
                        show-overflow-tooltip>
                        <template v-slot="{row}">
                          <span v-if="row.startFlag ===1 ">是</span>
                          <span v-if="row.startFlag === 0">否</span>
                          <span v-else></span>
                        </template>
                      </lui-table-column>


                      <lui-table-column
                        prop="lastFlag"
                        label="末尾件标识"
                        width="100"
                        show-overflow-tooltip>
                        <template v-slot="{row}">
                          <span v-if="row.lastFlag ===1 ">是</span>
                          <span v-if="row.lastFlag === 0">否</span>
                          <span v-else></span>
                        </template>
                      </lui-table-column>

                      <lui-table-column
                        prop="direction"
                        label="方向"
                        width="80"
                        show-overflow-tooltip>
                        <template v-slot="{row}">
                          <span v-if="row.direction===1">单向</span>
                          <span v-if="row.direction===2">双向</span>
                          <span v-else></span>
                        </template>
                      </lui-table-column>
                    </lui-table>
                  </div>
                </div>
              </lui-collapse-transition>
            </div>

            <div v-if="detailsData.goodsRatioList!=''" class="container-table">
              <div class="table-title">
                <span>补货比例</span>
                <span @click="goodShow = !goodShow">
                  <i v-if="goodShow">收起</i>
                  <i v-else>展开</i>
                </span>
              </div>
              <lui-collapse-transition>
                <div v-show="goodShow">
                  <div class="table-content">
                    <lui-table
                      v-loading="vShow"
                      :data="detailsData.goodsRatioList"
                      border
                      style="width: 100%">
                      <template slot="empty">
                        <showEmptyImage></showEmptyImage>
                      </template>
                      <lui-table-column
                        prop="goodsNo"
                        min-width="170"
                        label="商品编码"
                        show-overflow-tooltip>
                      </lui-table-column>

                      <lui-table-column
                        prop="isvGoodsNo"
                        min-width="170"
                        label="商家商品编码"
                        show-overflow-tooltip>
                      </lui-table-column>

                      <lui-table-column
                        prop="replenishmentRatio"
                        min-width="170"
                        label="比例"
                        show-overflow-tooltip>
                      </lui-table-column>
                    </lui-table>
                  </div>
                </div>
              </lui-collapse-transition>
            </div>



            <div class="container-table">
              <div class="table-title">
                <span>替换关系视图</span>
                <span @click="treeShow = !treeShow">
                  <i v-if="treeShow">收起</i>
                  <i v-else>展开</i>
                </span>
              </div>

              <lui-collapse-transition>
                <div v-show="treeShow">
                  <p style="margin-bottom: 8px;font-size: 14px;color: #999;padding-left: 15px;">替代方向：右侧商品替代左侧商品</p>
                  <div v-if="detilsVisibleViersion" id="container"></div>
                </div>
              </lui-collapse-transition>
            </div>
          </div>
        </div>

      </div>
    </div>
  </div>
</template>

<script>
import G6 from '@antv/g6'
import showEmptyImage from '@/components/common/showEmptyImage/index.vue'
import Api from '@/api'
export default {
  components: {
    showEmptyImage
  },
  data() {
    return {
      detailsData: [], //详情数据
      detilsVisibleViersion: false, //详情图形显示隐藏
      replaceShow: true,
      goodShow: true,
      editionShow: true, //版本显示隐藏
      treeShow: true, //替换关系视图
      deptNo: '',
      replaceNo: '',
      vShow: false //版本表格动画
    }
  },
  created() {
    this.deptNo = this.$route.query.deptNo
    this.replaceNo = this.$route.query.replaceNo
  },
  mounted() {
    this.getList()
  },
  methods: {
    changeActive() {
      this.$refs.spanClose.style.transform = 'rotate(90deg)'
      this.$refs.spanClose.style.transition = 'all 0.1s linear'
    },
    removeActive() {
      this.$refs.spanClose.style.transform = 'rotate(0deg)'
      this.$refs.spanClose.style.transition = 'all 0.1s linear'
    },
    closeDialogdetils() {
      var userAgent = navigator.userAgent
      if (userAgent.indexOf('Firefox') !== -1 || userAgent.indexOf('Chrome') !== -1) {
        window.open('', '_self').close()
      } else {
        // window.opener = null
        window.open('about:blank', '_self')
        window.close()
      }
    },
    getList() {
      Api.ChainCommodity.detailReplaceRelationList({
        deptNo: this.deptNo,
        replaceNo: this.replaceNo
      }).then(res => {
        if (res.success) {
          this.replaceShow = true
          if (res.data.oldGoodsUseForm === 1) {
            res.data.oldGoodsUseForm = '单双向关系'
          } else if (res.data.oldGoodsUseForm === 2) {
            res.data.oldGoodsUseForm = '只用于自己'
          }
          this.detailsData = res.data
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
      })
      //视图数据
      Api.ChainCommodity.detailReplaceRelationTree({
        deptNo: this.deptNo,
        replaceNo: this.replaceNo
      }).then(res => {
        if (res.success) {
          this.treeShow = true
          this.detilsVisibleViersion = true
          this.$nextTick(() => {
            this.treeImg(res.data)
            this.vShow = false
            document.body.scrollTop = 0
          })
        } else {
          this.vShow = false
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
        this.vShow = false
      })
    },

    treeImg(data) {
      var _this = this
      _this.lineData = []
      G6.registerNode('icon-node', {
        draw(cfg, group) {
          const styles = this.getShapeStyle(cfg)
          const { labelCfg = {}} = cfg
          const keyShape = group.addShape('rect', {
            attrs: {
              ...styles,
              x: 0,
              y: 0
            }
          })
          if (cfg.replaceBeforeGoodsNo) {
            const texts = cfg.replaceBeforeIsvGoodsNo + '【' + cfg.replaceBeforeGoodsName + '】'
            if (texts.length > 10) {
              group.addShape('text', {
                attrs: {
                  ...labelCfg.style,
                  text: texts.substring(0, 10) + '...',
                  x: 10,
                  y: 26
                }
              })
            } else {
              group.addShape('text', {
                attrs: {
                  ...labelCfg.style,
                  text: texts,
                  x: 10,
                  y: 26
                }
              })
            }
          }
          return keyShape
        }
      },
      'rect',
      )

      const defaultStateStyles = {
        hover: {
          stroke: '#91d5ff',
          lineWidth: 2,
          fillOpacity: 0.3
        }
      }
      const defaultNodeStyle = {
        fill: '#91d5ff',
        opacity: '0.6',
        stroke: '#40a9ff',
        radius: 5
      }

      const tooltip = new G6.Tooltip({
        // offsetX: 10,
        // offsetY: 10,
        getContent(e) {
          const texts = e.item._cfg.model.replaceBeforeGoodsName
          if (texts === undefined) {
            return `<div style='max-width: 350px;'></div>`
          } else {
            const htmls = e.item._cfg.model.replaceBeforeIsvGoodsNo + '【' + e.item._cfg.model.replaceBeforeGoodsName + '】'
            return `<div style='max-width: 350px;' class="classNameLi"><ul id='menu'><li title='1'>` + htmls + `</li></ul></div>`
          }
        },
        className: 'className'
      })

      const defaultLayout = {
        type: 'compactBox',
        direction: 'RL',
        nodesep: 50, //节点距离
        ranksep: 50, //层次距离
        getId: function getId(d) {
          if (d.direction === 2) {
            d.direction = '双向'
          } else if (d.direction === 1) {
            d.direction = '单向'
          } else if (d.direction === null) {
            d.direction = ''
          }
          return d
        },
        getHeight: function getHeight() {
          return 16
        },
        getWidth: function getWidth() {
          return 16
        },
        getVGap: function getVGap() {
          return 40
        },
        getHGap: function getHGap() {
          return 100
        }
      }

      const defaultLabelCfg = {
        style: {
          fill: '#000',
          fontSize: 10
        }
      }

      var width = '', height = ''
      width = document.getElementById('container').scrollWidth
      height = document.getElementById('container').scrollHeight || 500
      const minimap = new G6.Minimap({
        size: [150, 70]
      })
      const graph = new G6.TreeGraph({
        container: 'container',
        width,
        height,
        // linkCenter: true,
        plugins: [minimap, tooltip],
        modes: {
          default: ['drag-canvas', 'zoom-canvas']
        },
        defaultNode: {
          type: 'icon-node',
          // type: 'modelRect',
          size: [120, 40],
          style: defaultNodeStyle,
          labelCfg: defaultLabelCfg
        },
        defaultEdge: {
          type: 'cubic-horizontal',
          style: {
            stroke: '#91d5ff',
            startArrow: true
          }
        },

        nodeStateStyles: defaultStateStyles,


        edgeStateStyles: defaultStateStyles,
        layout: defaultLayout
      })
      // let i = 0
      graph.edge(function(val) {
        const arr = val.target._cfg.model.direction
        return {
          type: 'cubic-horizontal',
          color: '#A3B1BF',
          label: arr
        }
      })
      // graph.refresh()
      // graph.paint()
      graph.data(data)
      graph.render()
      graph.fitCenter()


      graph.on('edge:mouseenter', (evt) => {
        const { item } = evt
        graph.setItemState(item, 'hover', true)
      })

      graph.on('edge:mouseleave', (evt) => {
        const { item } = evt
        graph.setItemState(item, 'hover', false)
      })
      graph.on('node:mouseenter', (evt) => {
        const { item } = evt
        graph.setItemState(item, 'hover', true)
      })

      graph.on('node:mouseleave', (evt) => {
        const { item } = evt
        graph.setItemState(item, 'hover', false)
      })

    }
  }
}
</script>

<style lang="scss" scoped>
  .commitMask{
    position: fixed;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    background: #fff;
    z-index: 999999;
    .container{
      width: 100%;
      height: 100%;
      margin: 0 auto;
      .container_title{
        position: relative;
        z-index: 100;
        padding-top: 20px;
        padding-bottom: 15px;
        width: 100%;
        // height: 60px;
        // border-bottom: 1px solid #ddd;
        box-shadow: 0px 3px 5px #ddd;
        .title-header{
          width: 90%;
          margin: 0 auto;
          display: flex;
          justify-content: space-between;
          span{
            font-size: 20px;
          }
          span:nth-child(1){
            padding-left: 15px;
          }
          span:nth-child(2){
            cursor: pointer;
            margin-right: 15px;
            i{
              color: #999;
            }
            &:hover{

              i{
                color: #666;
                font-size: 22px;
              }
            }

          }
        }
      }
      .container_main{
        width: 100%;
        height: 100%;
        padding-bottom: 100px;
        overflow-x: auto;
      }
      .container_content{
        width: 90%;
        margin: 20px auto;
      }
    }
  }

  .detilsVisible_container{
    .container-title{
      border-bottom: 1px solid #ddd;
      width: 100%;
      padding-bottom: 8px;
      padding-left: 15px;
      display: flex;
      flex-wrap: wrap;
      align-items: center;
      .title-txt{
        display: flex;
        line-height: 30px;
        font-size: 14px;
        padding-right: 80px;
      }
    }
    .container-table{
       .table-title{
         margin:15px 0  20px 0;
         border-bottom: 1px solid #ddd;
         font-size: 16px;
         color: #333;
         line-height: 50px;
         font-weight: 500;
         display: flex;
         justify-content: space-between;
         align-items: center;
         span:nth-child(1){
           padding-left: 15px;
         }
         span:last-child{
           cursor: pointer;
           padding-right: 15px;
         }
       }
    }
  }
  #container {
    width: 100%;
    height: 100%;
    border: 1px #ddd solid;
    position: relative;
  }

  .p_title{
    padding-bottom: 10px;
    letter-spacing: 1px;
  }
  /deep/ .className{
    .classNameLi{
      box-shadow: 0 0 12px #ccc;
      background: #fff;
      font-size: 12px;
      border-radius: 4px;
      padding: 15px 20px;
    }
    }

</style>
