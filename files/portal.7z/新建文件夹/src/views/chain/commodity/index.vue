<template>
  <!-- 商品替代关系 -->
  <div class="configure">
    <!-- 筛选条件 -->
    <div class="configure-title">
      <div class="title-text">筛选搜索</div>
      <div class="title-serch">
        <div class="serch-left">
          <div class="select-content">
            <span class="content-title">事业部</span>
            <lui-select
              v-model="deptNo"
              clearable
              style="width: 180px;"
              placeholder="请选择事业部">
              <lui-option
                v-for="(item,index) in deptNoList"
                :key="index"
                :label="item.deptName"
                :value="item.deptNo">
              </lui-option>
            </lui-select>
          </div>
          <div class="select-content">
            <span class="content-title">新品</span>
            <lui-autocomplete
              v-model="newGoodsName"
              clearable
              style="width: 180px;"
              class="inline-input"
              :trigger-on-focus="false"
              :fetch-suggestions="(queryString,cd)=>{queryUnit(queryString,cd,1)}"
              placeholder="输入搜索新品"
              @change="(item)=>{handleSelect(item,1)}"
              @clear="(item)=>{setValueNull(item,1)}">
            </lui-autocomplete>
          </div>

          <div class="select-content">
            <span class="content-title">老品</span>
            <lui-autocomplete
              v-model="oldGoodsName"
              clearable
              style="width: 180px;"
              class="inline-input"
              :trigger-on-focus="false"
              :fetch-suggestions="(queryString,cd)=>{queryUnit(queryString,cd,2)}"
              placeholder="输入搜索老品"
              @change="(item)=>{handleSelect(item,2)}"
              @clear="(item)=>{setValueNull(item,2)}">
            </lui-autocomplete>
          </div>

          <div class="select-content">
            <span class="content-title">替换链名称</span>
            <lui-autocomplete
              v-model="replaceName"
              clearable
              style="width: 180px;"
              :trigger-on-focus="false"
              class="inline-input"
              :fetch-suggestions="(queryString,cd)=>{queryUnit(queryString,cd,3)}"
              placeholder="输入搜索替换链名称"
              @change="(item)=>{handleSelect(item,3)}"
              @clear="(item)=>{setValueNull(item,3)}">
            </lui-autocomplete>
          </div>

        </div>
        <div class="serch-right">
          <lui-button type="primary" style="width: 80px;" @click="getList()">查询</lui-button>
          <lui-button style="width: 80px;" @click="handleReset">重置</lui-button>
        </div>
      </div>
    </div>

    <!-- 表格数据 -->
    <div class="master-container">
      <div class="container-top">
        <div class="container-top-left">
          <span class="header-border"></span>
          <span class="header-title">数据列表</span>
        </div>
        <div class="container-top-right">
          <lui-button type="primary" @click="download">批量下载</lui-button>
          <button-list :buttons="buttons" :configdept-no="deptNo.split('&')[0]" :configdept-name="deptNo.split('&')[1]" :check-dept-no="checkDeptNo" @uploadSuccess="getList"></button-list>
          <lui-button type="primary" @click="handleDel">手工删除</lui-button>
          <lui-button type="primary" @click="handleAdd">手工添加</lui-button>
        </div>
      </div>

      <div class="container-table">
        <div class="container-table-cont">
          <lui-table
            v-loading="LoadingTable"
            :data="tableData"
            border
            style="width: 100%"
            @selection-change="handleSelectionChange">
            <template slot="empty">
              <showEmptyImage></showEmptyImage>
            </template>
            <lui-table-column
              fixed="left"
              align="center"
              type="selection"
              width="50"
              show-overflow-tooltip>
            </lui-table-column>

            <lui-table-column
              prop="deptNo"
              min-width="170"
              label="事业部编码"
              show-overflow-tooltip>
            </lui-table-column>

            <lui-table-column
              prop="deptName"
              min-width="170"
              label="事业部名称"
              show-overflow-tooltip>
            </lui-table-column>

            <lui-table-column
              prop="replaceName"
              min-width="170"
              label="替换链名称"
              show-overflow-tooltip>
            </lui-table-column>

            <lui-table-column
              prop="replaceAfterGoodsNo"
              label="新品商品编码"
              min-width="170"
              show-overflow-tooltip>
            </lui-table-column>

            <lui-table-column
              prop="replaceAfterIsvGoodsNo"
              label="新品商家商品编码"
              min-width="170"
              show-overflow-tooltip>
            </lui-table-column>

            <lui-table-column
              prop="replaceAfterGoodsName"
              label="新品商品名称"
              show-overflow-tooltip
              min-width="170">
            </lui-table-column>

            <lui-table-column
              prop="replaceBeforeGoodsNo"
              label="老品商品编码"
              min-width="170">
              <template v-slot="{row}">
                <lui-tooltip placement="top">
                  <div slot="content" v-dompurify-html="row.replaceBeforeGoodsNoBr"></div>
                  <p class="table_p">{{ row.replaceBeforeGoodsNo }}</p>
                </lui-tooltip>
              </template>
            </lui-table-column>

            <lui-table-column
              prop="replaceBeforeIsvGoodsNo"
              label="老品商家商品编码"
              min-width="170">
              <template v-slot="{row}">
                <lui-tooltip placement="top">
                  <div slot="content" v-dompurify-html="row.replaceBeforeIsvGoodsNoBr"></div>
                  <p class="table_p">{{ row.replaceBeforeIsvGoodsNo }}</p>
                </lui-tooltip>
              </template>
            </lui-table-column>

            <lui-table-column
              prop="replaceBeforeGoodsName"
              label="老品商品名称"
              min-width="170">
              <template v-slot="{row}">
                <lui-tooltip placement="top">
                  <div slot="content" v-dompurify-html="row.replaceBeforeGoodsNameBr"></div>
                  <p class="table_p">{{ row.replaceBeforeGoodsName }}</p>
                </lui-tooltip>
              </template>
            </lui-table-column>

            <lui-table-column
              prop="replaceVersion"
              width="130"
              label="版本"
              show-overflow-tooltip>
            </lui-table-column>

            <lui-table-column
              prop="updateUser"
              width="170"
              label="修改人"
              show-overflow-tooltip>
            </lui-table-column>

            <lui-table-column
              prop="updateTime"
              width="170"
              label="修改时间"
              show-overflow-tooltip>
            </lui-table-column>

            <lui-table-column
              fixed="right"
              width="120"
              align="center"
              label="操作">
              <template v-slot="{row}">
                <div class="table-button">
                  <lui-button type="text" @click="handleEdit(row)">编辑</lui-button>
                  <lui-button type="text" @click="handleLook(row)">查看</lui-button>
                </div>
              </template>
            </lui-table-column>
          </lui-table>
        </div>
        <div v-show="tableData.length>0" class="knowledge-pagination">
          <lui-pagination
            background
            :current-page.sync="pageNum"
            :page-sizes="[10, 20, 50, 70, 100]"
            layout="prev, pager, next, sizes, jumper"
            :total="totals"
            @current-change="handleSizeChange"
            @size-change="sizeChange">
          </lui-pagination>
        </div>
      </div>
    </div>
    <!-- 添加、编辑 -->
    <lui-dialog
      :visible.sync="centerDialogVisible"
      width="90%"
      top="10vh"
      :close-on-click-modal="false"
      custom-class="dialog_mask"
      :title="stateTitle"
      @close="closeDialog('ruleForm')">
      <lui-form
        ref="ruleForm"
        :model="ruleForm"
        :rules="rules"
        class="demo-ruleForm">
        <div class="ruleForm-title">
          <lui-form-item
            label-width="80px"
            label="事业部"
            prop="deptNo">
            <lui-select
              v-model="ruleForm.deptNo"
              :disabled="showEdit"
              style="width: 100%;"
              placeholder="请选择事业部"
              @change="handlerSelectDeptNo">
              <lui-option
                v-for="(item,index) in deptNoList"
                :key="index"
                :label="item.deptName"
                :value="item.deptNo">
              </lui-option>
            </lui-select>
          </lui-form-item>

          <lui-form-item
            label-width="125px"
            label="替换链名称"
            prop="replaceName">
            <lui-input
              v-model="ruleForm.replaceName"
              :disabled="showEdit"
              placeholder="请输入替换链名称">
            </lui-input>
          </lui-form-item>

          <lui-form-item
            label-width="160px"
            label="老品库存使用方式"
            prop="oldGoodsUseForm">
            <lui-select
              v-model="ruleForm.oldGoodsUseForm"
              :disabled="showEdit"
              style="width: 100%;"
              placeholder="请选择老品库存使用方式"
              @change="handlerSelectOldGoodsUseForm">
              <lui-option
                v-for="item in oldGoodsUseFormList"
                :key="item.code"
                :label="item.name"
                :value="item.code">
              </lui-option>
            </lui-select>
          </lui-form-item>
        </div>

        <div class="ruleForm-container">
          <div class="container-left">
            <lui-form-item
              label-width="0">
              <lui-table
                ref="dialogTable2"
                :data="ruleForm.goodsRelationList"
                style="width:100%"
                border
                height="400">
                <template slot="empty">
                  <showEmptyImage></showEmptyImage>
                </template>
                <lui-table-column
                  label="序号"
                  align="center"
                  fixed="left"
                  width="50">
                  <template v-slot="scope">
                    <span>{{ scope.$index+1 }}</span>
                  </template>
                </lui-table-column>

                <lui-table-column
                  prop="beforeName"
                  label="替换前件商品名称"
                  width="200">
                  <template v-slot="{row}">
                    <lui-autocomplete
                      v-model="row.beforeName"
                      style="width: 100%;"
                      class="inline-input"
                      :fetch-suggestions="(queryString,cd)=>{queryReplace(queryString,cd,row,1)}"
                      placeholder="请输入搜索替换前件商品名称"
                      @select="(item)=>{handleSelectReplace(item,row,1)}">
                    </lui-autocomplete>
                  </template>
                </lui-table-column>

                <lui-table-column
                  label="替换前件商品编码"
                  prop="replaceBeforeGoodsNo"
                  show-overflow-tooltip
                  min-width="170">
                </lui-table-column>

                <lui-table-column
                  label="替换前件商家商品编码"
                  prop="replaceBeforeIsvGoodsNo"
                  show-overflow-tooltip
                  min-width="170">
                </lui-table-column>

                <lui-table-column
                  prop="afterName"
                  label="替换后件商品名称"
                  width="200">
                  <template v-slot="{row}">
                    <lui-autocomplete
                      v-model="row.afterName"
                      style="width: 100%;"
                      class="inline-input"
                      :fetch-suggestions="(queryString,cd)=>{queryReplace(queryString,cd,row,2)}"
                      placeholder="请输入搜索替换前件商品名称"
                      @select="(item)=>{handleSelectReplace(item,row,2)}">
                    </lui-autocomplete>
                  </template>
                </lui-table-column>

                <lui-table-column
                  prop="replaceAfterGoodsNo"
                  label="替换后件商品编码"
                  show-overflow-tooltip
                  min-width="170">
                </lui-table-column>

                <lui-table-column
                  prop="replaceAfterIsvGoodsNo"
                  label="替换后件商家商品编码"
                  show-overflow-tooltip
                  min-width="170">
                </lui-table-column>

                <lui-table-column
                  v-if="ruleForm.oldGoodsUseForm === 1"
                  prop="direction"
                  fixed="right"
                  label="方向"
                  width="110">
                  <template v-slot="{row}">
                    <lui-select
                      v-model="row.direction"
                      @change="(val)=>{handleSelectDir(val,row)}">
                      <lui-option
                        v-for="item in direction"
                        :key="item.code"
                        :label="item.name"
                        :value="item.code"
                      ></lui-option>
                    </lui-select>
                  </template>
                </lui-table-column>

                <lui-table-column
                  label="操作"
                  align="center"
                  fixed="right"
                  width="50">
                  <template v-slot="scope">
                    <lui-button type="text" icon="lui-icon-delete" @click="handleTableDel(scope.row,scope.$index)"></lui-button>
                  </template>
                </lui-table-column>
              </lui-table>
            </lui-form-item>
            <lui-button icon="lui-icon-plus" class="table-puls" @click="handleNodeAdd(ruleForm.goodsRelationList)"></lui-button>

          </div>
          <div v-if="ruleForm.oldGoodsUseForm === 1" class="container-right">
            <lui-form-item
              label-width="0">
              <lui-table
                ref="dialogTable1"
                :data="ruleForm.goodsRatioList"
                style="width:100%"
                border
              >
                <lui-table-column
                  label="序号"
                  align="center"
                  width="50">
                  <template v-slot="scope">
                    <span>{{ scope.$index+1 }}</span>
                  </template>
                </lui-table-column>

                <lui-table-column
                  label="商品编码"
                  prop="goodsNo"
                  width="140"
                  show-overflow-tooltip>
                </lui-table-column>

                <lui-table-column
                  label="商家商品编码"
                  prop="isvGoodsNo"
                  show-overflow-tooltip>
                </lui-table-column>

                <lui-table-column
                  label="比例"
                  width="70"
                  prop="replenishmentRatio">
                  <template v-slot="{row}">
                    <lui-input
                      v-model.trim="row.replenishmentRatio"
                      oninput="if(value > 100 || value < 0 || isNaN(value)){value = ''}"
                    ></lui-input>
                  </template>
                </lui-table-column>

              </lui-table>
            </lui-form-item>
          </div>
        </div>

      </lui-form>
      <span slot="footer" class="dialog-footer">
        <lui-button @click="cancelForm('ruleForm',1)">取 消</lui-button>
        <lui-button type="primary" :loading="loadingButton" @click="previewForm('ruleForm')">预 览</lui-button>
        <lui-button type="primary" :loading="loadingButton" @click="submitForm('ruleForm')">提 交</lui-button>
      </span>
    </lui-dialog>
    <!-- 预览 -->
    <lui-dialog
      :visible.sync="previewVisible"
      width="65%"
      top="6vh"
      :close-on-click-modal="false"
      title="预览">
      <p class="p_title">替代方向：右侧商品替代左侧商品</p>
      <!-- <p style="margin-bottom: 8px;"></p> -->
      <div class="previewForm_container">
        <div v-if="previewVisible" id="container"></div>
      </div>
    </lui-dialog>
    <!-- 查看详情 -->
    <lui-dialog
      :visible.sync="detilsVisible"
      width="75%"
      top="10vh"
      custom-class="dialogVersion"
      :close-on-click-modal="false"
      title="详情"
      @close="closeDialogdetils">
      <div class="detilsVisible_container">
        <div class="container-title">
          <div class="title-txt">事业部：{{ detailsData.deptName }}</div>
          <div class="title-txt">老品库存使用方式： {{ detailsData.oldGoodsUseForm }}</div>
          <div class="title-txt">替换链名称：{{ detailsData.replaceName }}</div>
          <div class="title-txt">版本：{{ detailsData.replaceVersion }}</div>
        </div>
        <div class="container-table">
          <div class="table-title">
            <span>替代关系</span>
            <span @click="replaceShow = !replaceShow">
              <i v-if="replaceShow">收起</i>
              <i v-else>展开</i>
            </span>
          </div>
          <lui-collapse-transition>
            <div v-show="replaceShow">
              <div class="table-content">
                <lui-table
                  v-loading="vShow"
                  :data="detailsData.goodsRelationList"
                  border
                  style="width: 100%">
                  <template slot="empty">
                    <showEmptyImage></showEmptyImage>
                  </template>

                  <lui-table-column
                    prop="replaceBeforeGoodsNo"
                    min-width="140"
                    label="替换前件商品编码"
                    show-overflow-tooltip>
                  </lui-table-column>

                  <lui-table-column
                    prop="replaceBeforeIsvGoodsNo"
                    min-width="170"
                    label="替换前件商家商品编码"
                    show-overflow-tooltip>
                  </lui-table-column>

                  <lui-table-column
                    prop="replaceBeforeGoodsName"
                    label="替换前件商品名称"
                    min-width="140"
                    show-overflow-tooltip>
                  </lui-table-column>

                  <lui-table-column
                    prop="replaceAfterGoodsNo"
                    label="替换后件商品编码"
                    min-width="140"
                    show-overflow-tooltip>
                  </lui-table-column>

                  <lui-table-column
                    prop="replaceAfterIsvGoodsNo"
                    label="替换后件商家商品编码"
                    min-width="170"
                    show-overflow-tooltip>
                  </lui-table-column>

                  <lui-table-column
                    prop="replaceAfterGoodsName"
                    label="替换后件商品名称"
                    min-width="140"
                    show-overflow-tooltip>
                  </lui-table-column>

                  <lui-table-column
                    prop="beforeLevel"
                    label="前件层级"
                    width="100"
                    show-overflow-tooltip>
                  </lui-table-column>

                  <lui-table-column
                    prop="afterLevel"
                    label="后件层级"
                    width="100"
                    show-overflow-tooltip>
                  </lui-table-column>

                  <lui-table-column
                    prop="startFlag"
                    label="开始件标识"
                    width="100"
                    show-overflow-tooltip>
                    <template v-slot="{row}">
                      <span v-if="row.startFlag ===1 ">是</span>
                      <span v-if="row.startFlag === 0">否</span>
                      <span v-else></span>
                    </template>
                  </lui-table-column>

                  <lui-table-column
                    prop="lastFlag"
                    label="末尾件标识"
                    width="100"
                    show-overflow-tooltip>
                    <template v-slot="{row}">
                      <span v-if="row.lastFlag ===1 ">是</span>
                      <span v-if="row.lastFlag === 0">否</span>
                      <span v-else></span>
                    </template>
                  </lui-table-column>

                  <lui-table-column
                    prop="direction"
                    label="方向"
                    width="80"
                    show-overflow-tooltip>
                    <template v-slot="{row}">
                      <span v-if="row.direction===1">单向</span>
                      <span v-if="row.direction===2">双向</span>
                      <span v-else></span>
                    </template>
                  </lui-table-column>
                </lui-table>
              </div>
            </div>
          </lui-collapse-transition>
        </div>

        <div v-if="detailsData.goodsRatioList!=''" class="container-table">
          <div class="table-title">
            <span>补货比例</span>
            <span @click="goodShow = !goodShow">
              <i v-if="goodShow">收起</i>
              <i v-else>展开</i>
            </span>
          </div>
          <lui-collapse-transition>
            <div v-show="goodShow">
              <div class="table-content">
                <lui-table
                  v-loading="vShow"
                  :data="detailsData.goodsRatioList"
                  border
                  style="width: 100%">
                  <template slot="empty">
                    <showEmptyImage></showEmptyImage>
                  </template>
                  <lui-table-column
                    prop="goodsNo"
                    label="商品编码"
                    min-width="170"
                    show-overflow-tooltip>
                  </lui-table-column>

                  <lui-table-column
                    prop="isvGoodsNo"
                    min-width="170"
                    label="商家商品编码"
                    show-overflow-tooltip>
                  </lui-table-column>

                  <lui-table-column
                    min-width="170"
                    prop="replenishmentRatio"
                    label="比例"
                    show-overflow-tooltip>
                  </lui-table-column>
                </lui-table>
              </div>
            </div>
          </lui-collapse-transition>
        </div>

        <div class="container-table">
          <div class="table-title">
            <span>替换关系视图</span>
            <span @click="treeShow = !treeShow">
              <i v-if="treeShow">收起</i>
              <i v-else>展开</i>
            </span>
          </div>

          <lui-collapse-transition>
            <div v-show="treeShow">
              <p style="margin-bottom: 8px;">替代方向：右侧商品替代左侧商品</p>
              <div v-if="detilsVisibleViersion" id="container"></div>
            </div>
          </lui-collapse-transition>
        </div>

        <div class="container-table">
          <div class="table-title">
            <span>历史版本</span>
            <span @click="editionShow = !editionShow">
              <i v-if="editionShow">收起</i>
              <i v-else>展开</i>
            </span>
          </div>
          <lui-collapse-transition>
            <div v-show="editionShow">
              <div class="table-content">
                <lui-table
                  v-loading="vShow"
                  :data="versionData"
                  border
                  style="width: 100%">
                  <template slot="empty">
                    <showEmptyImage></showEmptyImage>
                  </template>
                  <lui-table-column
                    width="80"
                    align="center"
                    label="序号">
                    <template v-slot="scope">
                      <span>{{ (pageNumV-1)*pageSizeV+scope.$index + 1 }}</span>
                    </template>
                  </lui-table-column>

                  <lui-table-column
                    prop="replaceVersion"
                    min-width="170"
                    label="版本号"
                    show-overflow-tooltip>
                  </lui-table-column>

                  <lui-table-column
                    prop="createTime"
                    min-width="170"
                    label="创建时间"
                    show-overflow-tooltip>
                  </lui-table-column>

                  <lui-table-column
                    prop="replaceName"
                    min-width="170"
                    label="替换链名称"
                    show-overflow-tooltip>
                  </lui-table-column>

                  <lui-table-column
                    width="80"
                    align="center"
                    label="查看详情"
                    show-overflow-tooltip>
                    <template v-slot="{row}">
                      <lui-button type="text" @click="handleVersion(row)">详情</lui-button>
                    </template>
                  </lui-table-column>
                </lui-table>
                <div v-if="totalsV>5" class="knowledge-paginationVersion">
                  <lui-pagination
                    background
                    :current-page.sync="pageNumV"
                    :page-size="pageSizeV"
                    :page-sizes="[5, 10, 20, 50, 70, 100]"
                    layout="prev, pager, next, sizes, jumper"
                    :total="totalsV"
                    @current-change="handleSizeChangeVersion"
                    @size-change="sizeChangeVersion">
                  </lui-pagination>
                </div>
              </div>
            </div>
          </lui-collapse-transition>
        </div>
      </div>
      <span slot="footer" class="dialog-footer">
        <lui-button @click="cancelForm('ruleForm',2)">取 消</lui-button>
      </span>
    </lui-dialog>
    <!-- 添加失败 -->
    <Operation v-if="successShow" :operation-list="operationList" @event1="changeAdd($event)"></Operation>
  </div>
</template>

<script>
import G6 from '@antv/g6'
import util from '@/utils/utils.js'
import http from '@/lib/http'
import ButtonList from '@/views/common/ButtonList'
import Operation from '@/views/common/Operation'
import showEmptyImage from '@/components/common/showEmptyImage/index.vue'
import { exportExcel } from '@/utils/downloadRequest'
import Api from '@/api'
const buttons = {
  upload: {
    noAsync: true,
    maxM: 10,
    uploadtips: '只能上传xlsx文件，文件大小不超过10M',
    label: '批量上传',
    uploadConfig: {
      uploadActionUrl: http.baseContextUrl + 'replaceRelation/upload'
    },
    templateUrl: http.baseContextUrl + 'replaceRelation/downloadTemplate'
  }
}
export default {
  name: 'configure.veu',
  components: {
    showEmptyImage,
    ButtonList,
    Operation
  },
  data() {
    return {
      replaceShow: true,
      goodShow: true,
      editionShow: true, //版本显示隐藏
      treeShow: true, //替换关系视图
      detilsVisible: false, //查看
      //老品库存使用方式
      oldGoodsUseFormList: [
        {
          code: 1,
          name: '单双向关系'
        },
        {
          code: 2,
          name: '只用于自己'
        }
      ],
      //方向
      direction: [
        {
          code: 1,
          name: '单向'
        },
        {
          code: 2,
          name: '双向'
        }
      ],
      successShow: false,

      br: '服务和分别为结合 `<br/>`凡是能激发你看见你',
      //组件传参
      operationList: {
        title: '',
        data: ''
      },
      showEdit: false, //控制编辑状态
      loadingButton: false,
      checkDeptNo: false, //默认false表示不上传事业部
      deptNo: '', //列表页事业部编码
      newGoodsNo: '', //新品商品编码
      newGoodsName: '', //新品商品名称
      oldGoodsNo: '', //老品商品编码
      oldGoodsName: '', //老品商品名称
      replaceNo: '', //商品关系编码
      replaceName: '', //商品关系名称
      buttons,
      deptNoList: [], //事业部列表
      deptName: '', //事业部名称
      tableData: [], //表格数据
      LoadingTable: false, //表格加载动画
      totals: 0,
      pageNum: 1, //页
      pageSize: 10, //条数
      baseURL: http.baseContextUrl,
      multipleSelection: [], //全选反选
      //---------------------------------新增
      centerDialogVisible: false, //弹窗
      previewVisible: false, // 预览
      stateTitle: '添加商品关系配置',
      ruleForm: {
        deptName: '', //事业部名称
        deptNo: '', //事业部编码
        replaceName: '', //商品关系名称
        oldGoodsUseForm: '', //库存使用方式
        goodsRelationList: [], //结构图
        goodsRatioList: [] //比例
      },
      rules: {
        deptNo: [{ required: true, message: '请选择事业部', trigger: ['blur', 'change'] }],
        replaceName: [{ required: true, message: '请输入替换链名称', trigger: ['blur', 'change'] }],
        oldGoodsUseForm: [{ required: true, message: '请选择老品库存使用方式', trigger: ['blur', 'change'] }]
      },
      lineData: [], //图形展示
      treeData: {}, // 图形数据列表
      versionData: [], //版本号数据
      detailsData: [], //详情数据
      LoadingTableVersion: false,
      versionValue: '', //版本号
      versionObj: {}, //查看获取当前list 数据
      detilsVisibleViersion: false, //详情图形显示隐藏
      vShow: false, //版本表格动画
      totalsV: 0,
      htmls: '',
      pageNumV: 1, //页
      pageSizeV: 5 //条数
    }
  },
  mounted() {
    //事业部获取
    this.queryDept()
    //列表获取
    this.getList()
  },
  methods: {
    treeImg(data) {
      var _this = this
      _this.lineData = []
      G6.registerNode('icon-node', {
        draw(cfg, group) {
          const styles = this.getShapeStyle(cfg)
          const { labelCfg = {}} = cfg
          const keyShape = group.addShape('rect', {
            attrs: {
              ...styles,
              x: 0,
              y: 0
            }
          })
          if (cfg.replaceBeforeGoodsName) {
            const texts = cfg.replaceBeforeIsvGoodsNo + '【' + cfg.replaceBeforeGoodsName + '】'
            if (texts.length > 10) {
              group.addShape('text', {
                attrs: {
                  ...labelCfg.style,
                  text: texts.substring(0, 10) + '...',
                  x: 10,
                  y: 26
                }
              })
            } else {
              group.addShape('text', {
                attrs: {
                  ...labelCfg.style,
                  text: texts,
                  x: 10,
                  y: 26
                }
              })
            }
          }
          return keyShape
        }
      },
      'rect',
      )

      const defaultStateStyles = {
        hover: {
          stroke: '#91d5ff',
          lineWidth: 2,
          fillOpacity: 0.3
        }
      }
      const defaultNodeStyle = {
        fill: '#91d5ff',
        opacity: '0.6',
        stroke: '#40a9ff',
        radius: 5
      }

      const tooltip = new G6.Tooltip({
        getContent(e) {
          const texts = e.item._cfg.model.replaceBeforeGoodsName
          if (texts === undefined) {
            return `<div style='max-width: 350px;'></div>`
          } else {
            const htmls = e.item._cfg.model.replaceBeforeIsvGoodsNo + '【' + e.item._cfg.model.replaceBeforeGoodsName + '】'
            return `<div style='max-width: 350px;' class="classNameLi"><ul id='menu'><li title='1'>` + htmls + `</li></ul></div>`
          }
        },
        className: 'className'
      })

      const defaultLayout = {
        type: 'compactBox',
        direction: 'RL',
        nodesep: 50, //节点距离
        ranksep: 50, //层次距离
        getId: function getId(d) {
          if (d.direction === 2) {
            d.direction = '双向'
          } else if (d.direction === 1) {
            d.direction = '单向'
          } else if (d.direction === null) {
            d.direction = ''
          }
          return d
        },
        getHeight: function getHeight() {
          return 16
        },
        getWidth: function getWidth() {
          return 16
        },
        getVGap: function getVGap() {
          return 40
        },
        getHGap: function getHGap() {
          return 100
        }
      }

      const defaultLabelCfg = {
        style: {
          fill: '#000',
          fontSize: 10
        }
      }

      var width = '', height = ''
      width = document.getElementById('container').scrollWidth
      height = document.getElementById('container').scrollHeight || 500
      const minimap = new G6.Minimap({
        size: [150, 70]
      })
      const graph = new G6.TreeGraph({
        container: 'container',
        width,
        height,
        // linkCenter: true,
        plugins: [minimap, tooltip],
        modes: {
          default: ['drag-canvas', 'zoom-canvas']
        },
        defaultNode: {
          type: 'icon-node',
          // type: 'modelRect',
          size: [120, 40],
          style: defaultNodeStyle,
          labelCfg: defaultLabelCfg
        },
        defaultEdge: {
          type: 'cubic-horizontal',
          style: {
            stroke: '#91d5ff',
            startArrow: true
          }
        },

        nodeStateStyles: defaultStateStyles,
        edgeStateStyles: defaultStateStyles,
        layout: defaultLayout
      })
      // let i = 0
      graph.edge(function(val) {
        const arr = val.target._cfg.model.direction
        return {
          type: 'cubic-horizontal',
          color: '#A3B1BF',
          label: arr
        }
      })
      graph.data(data)
      graph.render()
      graph.fitCenter()


      graph.on('edge:mouseenter', (evt) => {
        const { item } = evt
        graph.setItemState(item, 'hover', true)
      })

      graph.on('edge:mouseleave', (evt) => {
        const { item } = evt
        graph.setItemState(item, 'hover', false)
      })
      graph.on('node:mouseenter', (evt) => {
        const { item } = evt
        graph.setItemState(item, 'hover', true)
      })

      graph.on('node:mouseleave', (evt) => {
        const { item } = evt
        graph.setItemState(item, 'hover', false)
      })

    },

    //新增、编辑 失败提示
    changeAdd(data) {
      if (!data) {
        this.successShow = false
      }
    },
    //-------------------------------------------------查看
    handleLook(row) {
      this.detailsData = []
      this.detilsVisible = true
      this.detilsVisibleViersion = false
      this.treeShow = true
      this.replaceShow = true
      this.editionShow = true
      this.goodShow = true
      this.versionObj = row
      //替代关系
      Api.ChainCommodity.detailReplaceRelationList({
        deptNo: row.deptNo,
        replaceNo: row.replaceNo
      }).then(res => {
        if (res.success) {
          if (res.data.oldGoodsUseForm === 1) {
            res.data.oldGoodsUseForm = '单双向关系'
          } else if (res.data.oldGoodsUseForm === 2) {
            res.data.oldGoodsUseForm = '只用于自己'
          }
          this.detailsData = res.data
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
      })
      this.detilsVisibleViersion = true
      //视图数据
      Api.ChainCommodity.detailReplaceRelationTree({
        deptNo: row.deptNo,
        replaceNo: row.replaceNo
      }).then(res => {
        if (res.success) {
          this.$nextTick(() => {
            this.treeImg(res.data)
          })
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
      })
      //版本号
      this.getVersionList()
    },

    getVersionList() {
      //版本号
      Api.ChainCommodity.replaceHistory({
        deptNo: this.versionObj.deptNo,
        replaceNo: this.versionObj.replaceNo,
        pageNum: this.pageNumV,
        pageSize: this.pageSizeV
      }).then(res => {
        if (res.success) {
          this.totalsV = res.total
          this.versionData = res.data
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
      })
    },

    //版本查看详情
    handleVersion(val) {
      const routes = this.$router.resolve({ name: 'commitMask', query: { deptNo: this.versionObj.deptNo, replaceNo: val.replaceNo }})
      window.open(routes.href, '_blank')
    },
    //分页条数改变
    sizeChangeVersion(val) {
      this.pageSizeV = val
      this.getVersionList()
    },
    //翻页-----根据页码变换
    handleSizeChangeVersion(val) {
      this.pageNumV = val
      this.getVersionList()
    },
    //--------------------------------------------------------编辑
    handleEdit(row) {
      this.LoadingTable = true
      this.showEdit = true
      Api.ChainCommodity.detailReplaceRelationList({
        deptNo: row.deptNo,
        replaceNo: row.replaceNo
      }).then(res => {
        if (res.success) {
          this.centerDialogVisible = true
          for (let i = 0; i < res.data.goodsRelationList.length; i++) {
            res.data.goodsRelationList[i].beforeName = res.data.goodsRelationList[i].replaceBeforeIsvGoodsNo + '【' + res.data.goodsRelationList[i].replaceBeforeGoodsName + '】'
            res.data.goodsRelationList[i].afterName = res.data.goodsRelationList[i].replaceAfterIsvGoodsNo + '【' + res.data.goodsRelationList[i].replaceAfterGoodsName + '】'
          }
          this.ruleForm = res.data
          this.ruleForm.replaceNo = row.replaceNo
          if (this.ruleForm.oldGoodsUseForm === 2) {
            this.$nextTick(() => {
              const width = document.getElementsByClassName('container-left')[0]
              width.style.width = '100%'
            })
          } else {
            this.$nextTick(() => {
              const width = document.getElementsByClassName('container-left')[0]
              width.style.width = 'calc(100% - 400px)'
            })
          }
          this.LoadingTable = false
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
        this.LoadingTable = false
      })
    },
    //---------------------------------------------------------新增
    //校验是否没填
    sar() {
      if (this.ruleForm.oldGoodsUseForm === 1) {
        if (this.ruleForm.goodsRelationList.length > 0) {
          for (let i = 0, goodsRelationList = this.ruleForm.goodsRelationList; i < goodsRelationList.length; i++) {
            if (goodsRelationList[i].replaceBeforeGoodsNo === '' || goodsRelationList[i].beforeName === '' || goodsRelationList[i].replaceAfterGoodsNo === '' || goodsRelationList[i].afterName === '' || goodsRelationList[i].direction === '') {
              return '请完善第 ' + (i + 1) + ' 条信息'
            }
          }
        }
      } else {
        if (this.ruleForm.goodsRelationList.length > 0) {
          for (let i = 0, goodsRelationList = this.ruleForm.goodsRelationList; i < goodsRelationList.length; i++) {
            if (goodsRelationList[i].replaceBeforeGoodsNo === '' || goodsRelationList[i].beforeName === '' || goodsRelationList[i].replaceAfterGoodsNo === '' || goodsRelationList[i].afterName === '') {
              return '请完善第 ' + (i + 1) + ' 条信息'
            }
          }
        }
      }
    },

    //提交
    submitForm(ruleForm) {
      if (this.ruleForm.goodsRelationList.length <= 0) {
        this.$showErrorMsg('请添加替换商品')
        return
      }
      if (this.sar() !== undefined) {
        return this.$showErrorMsg(this.sar())
      }


      //补货比例控制
      let num = 0
      if (this.ruleForm.oldGoodsUseForm === 1) {
        if (this.ruleForm.goodsRatioList.length > 0) {
          for (let i = 0, goodsRatioList = this.ruleForm.goodsRatioList; i < goodsRatioList.length; i++) {
            if (goodsRatioList[i].replenishmentRatio === '') {
              return this.$showErrorMsg('请填写补货比例')
            } else {
              num += Number(goodsRatioList[i].replenishmentRatio)
            }
          }
          if (num !== 100) {
            return this.$showErrorMsg('双向商品补货比例之和必须等于100')
          }
        }
      }
      this.$refs[ruleForm].validate((valid) => {
        if (valid) {
          this.loadingButton = true
          if (this.showEdit) { //编辑
            Api.ChainCommodity.editSave(this.ruleForm).then(res => {
              if (res.success) {
                if (res.errCode === 'DETAIL_ERROR') {
                  this.successShow = true
                  this.operationList.title = '编辑失败反馈'
                  this.operationList.data = res.data.detaileds
                  this.loadingButton = false
                } else {
                  this.$showSuccessMsg('编辑成功')
                  this.loadingButton = false
                  this.centerDialogVisible = false
                  this.getList()
                }
              } else {
                this.$showErrorMsg(res.errMessage)
                this.loadingButton = false
              }
            }).catch((e) => {
              this.$showErrorMsg(e)
              this.loadingButton = false
            })

          } else { //新增
            Api.ChainCommodity.addReplaceRelation(this.ruleForm).then(res => {
              if (res.success) {
                if (res.errCode === 'DETAIL_ERROR') {
                  this.successShow = true
                  this.operationList.title = '新增失败反馈'
                  this.operationList.data = res.data.detaileds
                  this.loadingButton = false
                } else {
                  this.$showSuccessMsg('添加成功')
                  this.loadingButton = false
                  this.centerDialogVisible = false
                  this.getList()
                }
              } else {
                this.$showErrorMsg(res.errMessage)
                this.loadingButton = false
              }
            }).catch((e) => {
              this.$showErrorMsg(e)
              this.loadingButton = false
            })
          }
        }
      })
    },
    //预览
    previewForm(ruleForm) {
      this.treeData = {}
      if (this.ruleForm.goodsRelationList.length <= 0) {
        this.$showErrorMsg('请添加替换商品')
        return
      }
      //判断是否有未填数据
      if (this.sar() !== undefined) {
        return this.$showErrorMsg(this.sar())
      }
      this.loadingButton = true
      const obj = {}
      obj.goodsRelationList = this.ruleForm.goodsRelationList
      Api.ChainCommodity.preview(obj).then(res => {
        if (res.success) {
          if (res.errCode === 'DETAIL_ERROR') {
            this.successShow = true
            this.operationList.data = res.data.detaileds
            this.loadingButton = false
          } else {
            this.treeData = res.data[0]
            this.previewVisible = true
            this.loadingButton = false
            this.$nextTick(() => {
              this.treeImg(this.treeData)
            })
          }
        } else {
          this.loadingButton = false
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
        this.loadingButton = false
      })
    },
    //取消弹窗
    cancelForm(ruleForm, type) {
      if (type === 1) { //新增编辑
        if (ruleForm) {
          this.$refs[ruleForm].resetFields()
          this.centerDialogVisible = false
        }
      } else if (type === 2) { //详情弹窗
        this.detilsVisible = false
        this.detilsVisibleViersion = false
      }
    },

    //关闭详情弹窗
    closeDialogdetils() {
      this.detilsVisible = false
      this.detilsVisibleViersion = false
    },

    //关闭弹窗
    closeDialog(ruleForm) {
      if (ruleForm) {
        this.$refs[ruleForm].resetFields()
        this.centerDialogVisible = false
      }
    },

    //手工添加
    handleAdd() {
      this.showEdit = false
      this.centerDialogVisible = true
      this.$nextTick(() => {
        this.ruleForm = {
          deptName: '', //事业部名称
          deptNo: '', //事业部编码
          replaceName: '', //商品关系名称
          oldGoodsUseForm: '', //库存使用方式
          goodsRelationList: [], //结构图
          goodsRatioList: []
        }
        this.$refs['ruleForm'].resetFields()
        const width = document.getElementsByClassName('container-left')[0]
        width.style.width = '100%'
      })
    },
    //新增事业部选择
    handlerSelectDeptNo(val) {
      var obj = {} //多条件查找
      obj = this.deptNoList.find(function(item) {
        return item.deptNo === val
      })
      this.ruleForm.deptName = obj.deptName
      //当事业部发生变化时清空数据列表
      this.ruleForm.goodsRelationList = []
      this.ruleForm.goodsRatioList = []
    },
    //老品库存方式---改变页面样式
    handlerSelectOldGoodsUseForm(val) {
      const width = document.getElementsByClassName('container-left')[0]
      if (val === 1) {
        width.style.width = 'calc( 100% - 400px )'
      } else {
        width.style.width = '100%'
      }
    },
    //表格新增
    handleNodeAdd(tableData) {
      if (this.ruleForm.deptNo === '') {
        this.$showErrorMsg('请选择事业部')
        return
      }
      if (this.sar() !== undefined) {
        return this.$showErrorMsg(this.sar())
      }

      const obj = {
        replaceBeforeGoodsNo: '',
        replaceBeforeGoodsName: '',
        beforeName: '',
        replaceAfterGoodsNo: '',
        replaceAfterGoodsName: '',
        afterName: '',
        replaceBeforeIsvGoodsNo: '',
        replaceAfterIsvGoodsNo: '',
        direction: ''
      }
      tableData.push(obj)
      //table 滚动条永远固定底部
      this.$nextTick((e) => {
        this.$refs.dialogTable2.bodyWrapper.scrollTop = this.$refs.dialogTable2.bodyWrapper.scrollHeight
      })
    },
    //删除新增table数据 ---如果表格数据为空直接删除 否则提示删除
    handleTableDel(row, index) {
      // 如果已经有值则判断是否删除  没值直接则删除
      if (row.replaceBeforeGoodsNo !== '' || row.replaceBeforeGoodsName !== '' || row.replaceAfterGoodsNo !== '' || row.replaceAfterGoodsName !== '' || row.direction !== '') {
        this.$alert('<p style="font-size: 18px;color:#333">确定删除此条配置吗？</p><p style="font-size: 13px;color: #666"></p>', '', {
          dangerouslyUseHTMLString: true,
          type: 'warning',
          center: true
        }).then(() => {
          this.ruleForm.goodsRelationList.splice(index, 1)
          this.listobj(this.ruleForm.goodsRelationList, this.ruleForm.goodsRatioList)
        }).catch(() => {})
      } else {
        this.ruleForm.goodsRelationList.splice(index, 1)
      }
    },

    //新增下拉模糊搜索  替换前件商品名称
    queryReplace(queryString, cb, row, type) {
      if (type === 1) {
        if (queryString === '') {
          row.replaceBeforeGoodsNo = ''
          row.replaceBeforeIsvGoodsNo = ''
        }
      } else {
        if (queryString === '') {
          row.replaceAfterGoodsNo = ''
          row.replaceAfterIsvGoodsNo = ''
        }
      }
      const arr = queryString.split('【')
      let texts = ''

      if (arr.length < 2) {
        texts = arr[0]
      } else {
        if (arr[1].indexOf('】') !== -1) {
          texts = arr[1].slice(0, -1)
        } else {
          texts = arr[1]
        }
      }
      Api.ChainCommodity.dropdownGoods({
        deptNo: this.ruleForm.deptNo,
        keywords: texts
      }).then((res) => {
        if (res.success) {
          var results = []
          if (res.data.length > 0) {
            for (let i = 0, len = res.data.length; i < len; i++) {
              res.data[i].value = res.data[i].isvGoodsNo + '【' + res.data[i].goodsName + '】'
            }
            results = res.data
          } else {
            switch (type) {
              case 1:
                row.replaceBeforeGoodsName = ''
                row.replaceBeforeGoodsNo = ''
                break
              case 2:
                row.replaceAfterGoodsName = ''
                row.replaceAfterGoodsNo = ''
                break
            }
          }
          cb(results)
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
      })


      // Api.ChainCommodity.keywords({
      //   displayFields: ['goodsNo', 'goodsName', 'isvGoodsNo'],
      //   keyWords: ['goodsNo', 'goodsName', 'isvGoodsNo'],
      //   rout: 'chain',
      //   deptNo: this.ruleForm.deptNo,
      //   value: texts
      // }).then((res) => {
      //   if (res.success) {
      //     var results = []
      //     if (res.data.length > 0) {
      //       for (let i = 0, len = res.data.length; i < len; i++) {
      //         res.data[i].value = res.data[i].isvGoodsNo + '【' + res.data[i].goodsName + '】'
      //       }
      //       results = res.data
      //     } else {
      //       switch (type) {
      //         case 1:
      //           row.replaceBeforeGoodsName = ''
      //           row.replaceBeforeGoodsNo = ''
      //           break
      //         case 2:
      //           row.replaceAfterGoodsName = ''
      //           row.replaceAfterGoodsNo = ''
      //           break
      //       }
      //     }
      //     cb(results)
      //   }
      // }).catch((e) => {
      //   this.$showErrorMsg(e)
      // })
    },
    //商品名称下拉选择 赋值ID 判断补货比例
    handleSelectReplace(item, row, type) {
      switch (type) {
        case 1: //替换前件商品编码
          row.replaceBeforeGoodsNo = item.goodsNo
          row.replaceBeforeIsvGoodsNo = item.isvGoodsNo
          row.replaceBeforeGoodsName = item.goodsName
          break
        case 2: //替换后件商品编码
          row.replaceAfterGoodsNo = item.goodsNo
          row.replaceAfterGoodsName = item.goodsName
          row.replaceAfterIsvGoodsNo = item.isvGoodsNo
          break
      }
      this.listobj(this.ruleForm.goodsRelationList, this.ruleForm.goodsRatioList)
    },
    //双向按钮点击
    handleSelectDir(val, row) {
      this.listobj(this.ruleForm.goodsRelationList, this.ruleForm.goodsRatioList)
    },
    //补货比例信息
    listobj(obj, ratio) {
      // 获取双向数据
      var brr = []
      //循环遍历左边数据 如果为双向则push brr
      for (const n of obj) {
        if (n.direction === 2) {
          if (n.replaceAfterGoodsNo !== '') {
            const table1 = {
              goodsNo: n.replaceAfterGoodsNo,
              isvGoodsNo: n.replaceAfterIsvGoodsNo,
              replenishmentRatio: ''
            }
            brr.push(table1)
          }
          if (n.replaceAfterGoodsNo !== '') {
            const table2 = {
              goodsNo: n.replaceBeforeGoodsNo,
              isvGoodsNo: n.replaceBeforeIsvGoodsNo,
              replenishmentRatio: ''
            }
            brr.push(table2)
          }
        }
      }
      //如果左边list没有双向状态 右边清空
      if (brr.length === 0) {
        this.ruleForm.goodsRatioList = []
        return
      }
      //去重 brr 重复数据
      for (let i = 0; i < brr.length; i++) {
        for (let j = i + 1; j < brr.length; j++) {
          if (brr[i].goodsNo === brr[j].goodsNo) {
            brr.splice(j, 1)
            j--
          }
        }
      }
      //判断右边数据是否为空 如果为空直接添加 不为空则进入条件判断
      if (ratio.length > 0) {
        //删除右边在左边不存在的数据
        for (let i = 0; i < ratio.length; i++) {
          let bool = false
          for (let j = 0; j < brr.length; j++) {
            if (ratio[i].goodsNo === brr[j].goodsNo) {
              bool = true
              break
            }
          }
          //如果左边没有右边数据直接截取
          if (!bool) {
            ratio.splice(i, 1)
            i--
          }
        }
        //比较左右数据  如果左边数据在右边不存在，将左边数据添加右边
        for (let i = 0; i < brr.length; i++) {
          let bool = false
          for (let j = 0; j < ratio.length; j++) {
            if (brr[i].goodsNo === ratio[j].goodsNo) {
              bool = true
              break
            }
          }
          //如果不存在直接push
          if (!bool) {
            ratio.push(brr[i])
          }
        }
      } else {
        this.ruleForm.goodsRatioList = brr
      }
    },
    //--------------------------------------------------------------------------------列表数据
    //手工删除
    handleDel() {
      if (this.multipleSelection.length === 0) {
        this.$showErrorMsg('请选择数据')
        return
      }
      const crrId = []
      for (let i = 0; i < this.multipleSelection.length; i++) {
        crrId.push(this.multipleSelection[i].replaceNo)
      }
      this.delete(crrId)
    },
    //  删除方法
    delete(row) {
      this.$alert('<p style="font-size: 18px;color:#333">确认删除此条消息吗?</p><p style="font-size: 13px;color: #666">删除后，此条消息的相关内容信息将无法恢复</p>', '', {
        dangerouslyUseHTMLString: true,
        type: 'warning',
        center: true
      }).then(() => {
        Api.ChainCommodity.listDelete({ replaceNoList: row }).then(res => {
          if (res.success) {
            this.$showSuccessMsg('删除成功')
            this.getList()
          } else {
            this.$showErrorMsg(res.errMessage)
          }
        }).catch((e) => {
          this.$showErrorMsg(e)
        })
      }).catch(() => {})
    },
    //重置数据列表页
    handleReset() {
      this.deptNo = ''
      this.newGoodsNo = ''
      this.newGoodsName = ''
      this.oldGoodsNo = ''
      this.oldGoodsName = ''
      this.replaceNo = ''
      this.replaceName = ''
      this.getList()
    },
    //数据列表
    getList() {
      this.LoadingTable = true
      Api.ChainCommodity.listPage({
        deptNo: this.deptNo,
        newGoodsName: this.newGoodsName,
        oldGoodsName: this.oldGoodsName,
        replaceName: this.replaceName,
        pageNum: this.pageNum,
        pageSize: this.pageSize
      }).then(res => {
        if (res.success) {
          for (let i = 0; i < res.data.length; i++) {
            res.data[i].replaceBeforeGoodsNameBr = res.data[i].replaceBeforeGoodsNameBr ? util.htmlDecode(res.data[i].replaceBeforeGoodsNameBr) : ''
            res.data[i].replaceBeforeGoodsNoBr = res.data[i].replaceBeforeGoodsNoBr ? util.htmlDecode(res.data[i].replaceBeforeGoodsNoBr) : ''
            res.data[i].replaceBeforeIsvGoodsNoBr = res.data[i].replaceBeforeIsvGoodsNoBr ? util.htmlDecode(res.data[i].replaceBeforeIsvGoodsNoBr) : ''
          }

          this.LoadingTable = false
          this.tableData = res.data
          this.totals = res.total
        } else {
          this.LoadingTable = false
          this.$showErrorMsg(res.errMessage)
        }
      }).catch((e) => {
        this.LoadingTable = false
        this.$showErrorMsg(e)
      })
    },
    //批量下载
    download() {
      const params = {
        deptNo: this.deptNo,
        newGoodsName: this.newGoodsName,
        oldGoodsName: this.oldGoodsName,
        replaceName: this.replaceName,
        pageNum: this.pageNum,
        pageSize: this.pageSize
      }
      const actionUrl = this.baseURL + Api.ChainCommodity.download
      exportExcel(actionUrl, params)
    },
    //全选反选
    handleSelectionChange(val) {
      this.multipleSelection = val
    },
    //分页条数改变
    sizeChange(val) {
      this.pageSize = val
      this.getList()
    },
    //翻页-----根据页码变换
    handleSizeChange(val) {
      this.pageNum = val
      this.getList()
    },
    //获取事业部编码
    queryDept() {
      Api.BodCommodity.queryDept().then(row => {
        if (row.success) {
          this.deptNoList = row.data
        } else {
          this.$showErrorMsg(row.errMessage)
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
      })
    },
    //模糊下拉 clear  触发事件
    setValueNull(item, type) {
      switch (type) {
        case 1:
          this.newGoodsNo = ''
          this.newGoodsName = ''
          break
        case 2:
          this.oldGoodsNo = ''
          this.oldGoodsName = ''
          break
        case 3:
          this.replaceNo = ''
          this.replaceName = ''
          break
      }
    },
    // 列表下拉模糊搜索
    queryUnit(queryString, cb, type) {
      // if (queryString !== '') {
      // this.$refs.elautocomplete.activated = true || this.$refs.elautocomplete.handleFocus() //清除之后弹出下拉菜单
      if (type === 3) { //替换链名称查询
        Api.ChainCommodity.dropDownReplaceName({
          deptNo: this.deptNo,
          replaceName: queryString
        }).then((res) => {
          if (res.success) {
            var results = []
            if (res.data.length > 0) {
              for (let i = 0, len = res.data.length; i < len; i++) {
                res.data[i].value = res.data[i].replaceName
              }
              results = res.data
            }
            cb(results)
          }
        }).catch((e) => {
          this.$showErrorMsg(e)
        })

      } else if (type === 1) { //新品
        Api.ChainCommodity.keywords({
          displayFields: ['replaceAfterIsvGoodsNo', 'replaceAfterGoodsNo', 'replaceAfterGoodsName'],
          keyWords: ['replaceAfterIsvGoodsNo', 'replaceAfterGoodsNo', 'replaceAfterGoodsName'],
          rout: 'chain_replace',
          deptNo: this.deptNo,
          value: queryString
        }).then((res) => {
          if (res.success) {
            var results = []
            if (res.data.length > 0) {
              for (let i = 0, len = res.data.length; i < len; i++) {
                res.data[i].value = res.data[i].replace_after_goods_name
              }
              results = res.data
            }

            cb(results)
          }
        }).catch((e) => {
          this.$showErrorMsg(e)
        })
      } else if (type === 2) { //老品查询
        Api.ChainCommodity.keywords({
          // displayFields: ['goodsNo', 'goodsName'],
          // keyWords: ['goodsNo', 'goodsName'],
          // rout: 'chain',
          // deptNo: this.deptNo,
          // value: queryString

          displayFields: ['replaceBeforeIsvGoodsNo', 'replaceBeforeGoodsNo', 'replaceBeforeGoodsName'],
          keyWords: ['replaceBeforeIsvGoodsNo', 'replaceBeforeGoodsNo', 'replaceBeforeGoodsName'],
          rout: 'chain_replace',
          deptNo: this.deptNo,
          value: queryString
        }).then((res) => {
          if (res.success) {
            var results = []
            if (res.data.length > 0) {
              for (let i = 0, len = res.data.length; i < len; i++) {
                res.data[i].value = res.data[i].replace_before_goods_name
              }
              results = res.data
            }

            cb(results)
          }
        }).catch((e) => {
          this.$showErrorMsg(e)
        })
      }
      // }
    },
    //列表页迷糊下拉选择事件
    handleSelect(item, type) {
      if (type === 1) { //新品查询
        this.newGoodsNo = item.goodsNo
      } else if (type === 2) { //老品
        this.oldGoodsNo = item.goodsNo
      } else if (type === 3) { //商品关系名
        this.replaceNo = item.replaceName
      }
    }
  }
}
</script>

<style scoped lang="scss">
@import '@/assets/stylus/main';
@import '../common/common';

.knowledge-paginationVersion{
  padding-top: 20px;
  text-align: right;
}


.ruleForm-title{
  width: 100%;
  display: flex;
}
.ruleForm-container{
  width: 100%;
  min-height: 400px;
  display: flex;
  // border: 1px solid #DDDDDD;
  border-right: none;
  border-radius: 4px;
  .container-left{
    width: 100%;
    border: 1px solid #DDDDDD;
    border-radius: 5px;
  }
  .container-right{
    margin-left: 20px;
    width: 400px;
    border: 1px solid #DDDDDD;
    border-radius: 5px;
  }
  .table-puls {
    margin-top: 15px;
    width: 100%;
    height: 40px;
    border: 1px $--gl-blue dashed;
    border-radius: 6px;
    text-align: center;
    color: $--gl-blue;
    cursor: pointer;
  }
}
.ruleForm-container-footer{
    width: 100%;
    display: flex;
    .footer-left{
      width: calc(100% - 250px);
    }
    .footer-right{
      width: 250px;
    }
  }
.previewForm_container{
  width: 100%;
  min-height: 500px;
}
.detilsVisible_container{
  .container-title{
     border-bottom: 1px solid #ddd;
    // height: 50px;
    width: 100%;
    // border: 1px solid red;
    padding-bottom: 8px;
    display: flex;
    flex-wrap: wrap;
    // justify-content: space-between;
    align-items: center;
    .title-txt{
      display: flex;
      // width: 50%;
      line-height: 30px;
      font-size: 14px;
      padding-right: 80px;
    }
  }
  .container-table{
     .table-title{
       margin:10px 0  20px 0;
       border-bottom: 1px solid #ddd;
       font-size: 16px;
       color: #666666;
       line-height: 50px;
       font-weight: 500;
       display: flex;
       justify-content: space-between;
       align-items: center;
       span:last-child{
         cursor: pointer;
       }
     }
  }
}
#container {
  width: 100%;
  height: 100%;
  border: 1px #ddd solid;
  position: relative;
}

.p_title{
  padding-bottom: 10px;
  letter-spacing: 1px;
}
/deep/ .className{
  .classNameLi{
    box-shadow: 0 0 12px #ccc;
    background: #fff;
    font-size: 12px;
    border-radius: 4px;
    padding: 15px 20px;
  }
}

.table_p{
white-space: nowrap;
overflow: hidden;
text-overflow: ellipsis;
}

</style>
