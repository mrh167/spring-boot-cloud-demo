<template>
  <div v-loading="loading">
    <div v-if="showState === 0" class="config-info">
      <div class="search-box is-always-shadow">
        <div class="header-title">
          <div><i class="lui-icon-search"></i>筛选搜索</div>
          <div></div>
        </div>
        <lui-form ref="searchform" :model="searchform" label-width="80px" style="padding: 0;margin: 0;margin-bottom: 20px;">
          <lui-row style="width: 96%;margin: 15px auto">
            <lui-col :span="8" style="text-align: left">
              <div class="grid-content filterrow1">
                <div class="grid-content filterrow1">
                  <lui-form-item label="账号" style="width:90%">
                    <lui-input v-model="searchform.account" clearable placeholder="请输入账号ID"></lui-input>
                  </lui-form-item>
                </div>
              </div>
            </lui-col>
            <lui-col :span="8">
              <div class="grid-content filterrow1">
                <lui-form-item label="开通产品" prop="serverCode" style="width:90%">
                  <lui-select v-model="searchform.serverCode" value-key="serverCode" filterable clearable placeholder="请选择" style="width:100%">
                    <lui-option
                      v-for="item in serversOptions"
                      :key="item.serverCode"
                      :label="item.serverName"
                      :value="item.serverCode">
                    </lui-option>
                  </lui-select>
                </lui-form-item>
              </div>
            </lui-col>
            <!-- <lui-col :span="8">
            <div class="grid-content filterrow1">
              <lui-form-item label="角色">
                <lui-select v-model="searchform.menuRoleCode" filterable placeholder="请选择" style="width:260px">
                  <lui-option
                    v-for="item in menuRoleOptions"
                    :key="item.roleCode"
                    :label="item.roleName"
                    :value="item.roleCode">
                  </lui-option>
                </lui-select>
              </lui-form-item>
            </div>
          </lui-col>-->
            <lui-col :span="8" style="text-align: right">
              <div class="grid-content filterrow1">
                <lui-form-item label="状态" style="width:90%">
                  <lui-select v-model="searchform.status" filterable clearable style="width:100%" placeholder="请选择">
                    <lui-option
                      v-for="item in statusOptions"
                      :key="item.value"
                      :label="item.name"
                      :value="item.value">
                    </lui-option>
                  </lui-select>
                </lui-form-item>
              </div>
            </lui-col>
          </lui-row>
          <div class="btn-wrap">
            <lui-form-item>
              <lui-button class="filters-btn-group" style="width: 87px;" type="primary" @click="searchClick"><i class="fa fa-search"></i>查询</lui-button>
            </lui-form-item>
            <lui-form-item>
              <lui-button class="filters-btn-group" style="width: 87px;" @click="handleReset('searchform')"><i class="fa fa-refresh"></i>重置</lui-button>
            </lui-form-item>
          </div>
        </lui-form>
      </div>
      <!-- <lui-card class="operate-container" shadow="never">
      <button-list
        ref="buttons"
        :buttons="buttons"
        @handleAddClick="handleAddClick"
        @deleteClick="handDeleteClick"
        @downloadClick="downloadClick">
      </button-list>
    </lui-card>-->
      <div class="addManually">
        <div class="manually-title">
          <div class="title-left"> <i class="lui-icon-document-empty"></i><span>数据列表</span></div>
          <div class="title-right">
            <!--<div class="uploadRelative">
            <lui-button class="lui-button lui-button&#45;&#45;default" type="primary"><span>批量上传</span></lui-button>
            <input type="file" multiple="multiple" style="position: absolute;left:0;top:0;width:100%;height:100%;opacity: 0;" @change="uploadClick" />
          </div>-->
            <!--暂时禁用-->
            <!-- <button-list
            ref="buttons"
            :buttons="buttons"
            @uploadSuccess="getList"
          ></button-list>-->
            <!-- <lui-button type="primary" @click="uploadClickWarn">批量上传</lui-button> -->
            <lui-button type="primary" @click="downloadClick">批量下载</lui-button>
            <lui-button type="primary" class="disabled-is" @click="deleteClick">手工删除</lui-button>
            <lui-button type="primary" @click="handleAddClick">手工添加</lui-button>
          </div>
        </div>
        <!--table列表-->
        <lui-table
          v-loading="listLoading"
          :data="dataSource"
          class="slisttable table-list"
          style="width:96%;margin: 0 auto;"
          @selection-change="handleSelectionChange">
          <template slot="empty">
            <showEmptyImage></showEmptyImage>
          </template>
          <lui-table-column type="selection" width="60" fixed="left" align="center">
          </lui-table-column>
          <input type="hidden" prop="id" />
          <lui-table-column 
            prop="account" 
            label="账号">
          </lui-table-column>
          <lui-table-column 
            prop="account" 
            label="渠道">
            <template slot-scope="scope">
              <span v-if="scope.row.accountType == 1">运营登录</span>
              <span v-if="scope.row.accountType == 2">商家登录</span>
            </template>
          </lui-table-column>
          <lui-table-column label="商家">
            <template slot-scope="scope">
              <lui-popover
                placement="right"
                width="600"
                trigger="hover">
                <lui-table :data="scope.row.sellerList" size="mini">
                  <lui-table-column show-overflow-tooltip type="index" label="序号"></lui-table-column>
                  <lui-table-column show-overflow-tooltip property="sellerName" label="商家名称"></lui-table-column>
                  <lui-table-column show-overflow-tooltip property="sellerNo" label="商家编码"></lui-table-column>
                </lui-table>
                <div slot="reference" class="table-link">{{ sellerListFormat(scope.row.sellerList) }}</div>
              </lui-popover>
            </template>
          </lui-table-column>
          <lui-table-column prop="userServers" label="开通产品">
            <template slot-scope="scope">
              <lui-tooltip
                class="item"
                effect="dark"
                :content="scope.row.userServers"
                placement="bottom">
                <div class="table-link">{{ scope.row.userServers }}</div>
              </lui-tooltip>
            </template>
          </lui-table-column>
          <lui-table-column
            prop="alwaysAllPermission"
            label="是否全数据"
            min-width="120"
            show-overflow-tooltip>
            <template v-slot="{row}">
              <span v-if="row.alwaysAllPermission===1">是</span>
              <span v-else>否</span>
            </template>
          </lui-table-column>
          <lui-table-column prop="status" label="状态" width="100">
            <template slot-scope="scope">
              <lui-tag
                :type="scope.row.status===true?'success':(scope.row.status===false?'info':'')"
              >{{ scope.row.status===true?'正常':'禁用' }}</lui-tag>
            </template>
          </lui-table-column>
          <lui-table-column prop="status" label="状态修改" width="100">
            <template slot-scope="scope">
              <lui-switch
                v-model="scope.row.status"
                active-circle-class="1"
                active-color="rgba(60,110,240,.2)"
                inactive-color="rgba(142,145,152,.2)"
                @change="changeStatusTab(scope.row)">
              </lui-switch>
            </template>
          </lui-table-column>
          <lui-table-column
            prop="updateUser"
            min-width="100"
            label="修改人">
          </lui-table-column>
          <lui-table-column prop="updateTime" label="修改时间" width="170">
          </lui-table-column>
          <lui-table-column
            label="操作"
            width="320px"
            align="center"
            fixed="right">
            <template slot-scope="scope">
              <lui-button size="mini" plain @click="viewHandle(scope.$index, scope.row)">查看角色</lui-button>
              <lui-button size="mini" plain @click="editHandle(scope.$index, scope.row)">修改角色</lui-button>
              <div v-if="showfigureBtn" class="showmargin">
                <lui-button plain size="mini" @click="handelConfig(scope.$index, scope.row,true)">配置数据</lui-button>
                <lui-button plain size="mini" @click="handelConfig(scope.$index, scope.row,false)">查看数据</lui-button>  
              </div>
            </template>
          </lui-table-column>
        </lui-table>
        <!--分页-->
        <div v-show="dataSource != undefined && dataSource.length>0" class="block rotation-pagination">
          <lui-pagination
            background
            :current-page.sync="pageNum"
            :page-sizes="[10, 20, 50, 100]"
            layout="prev, pager, next, sizes, jumper, total"
            :total="total"
            @current-change="handleSizeChange"
            @size-change="sizeChange"
          >
          </lui-pagination>
        </div>
      </div>
    </div>
    <addConfig v-if="showState === 1" @func="changeState"></addConfig>
    <updateConfig v-if="showState === 2" :id="id" @func="changeState"></updateConfig>
    <viewConfig v-if="showState === 3" :id="id" @func="changeState"></viewConfig>

    <!-- 配置数据弹框 -->
    <lui-dialog
      v-if="congfigDialogVisible"
      :title="titleConfigdata"
      :close-on-click-modal="false"
      :visible.sync="congfigDialogVisible"
      :width="width"
      class="configFormdialog"
      top="10vh"
      @close="handelConfigDataCancel">
      <lui-form
        ref="configForm"
        :model="configForm"
        :rules="configRules"
        label-width="110px">
        <lui-row>
          <lui-col :span="12">
            <lui-form-item
              label="账号："
              prop="account">
              <span>{{ configForm.account }}</span>
            </lui-form-item>
          </lui-col>
        </lui-row>
        <lui-row>
          <lui-col :span="12">
            <lui-form-item
              label="是否全数据："
              prop="alwaysAllPermission">
              <lui-radio-group v-model="configForm.alwaysAllPermission" :disabled="configShow" @change="radioChange">
                <lui-radio :label="1" class="button_radio">是</lui-radio>
                <lui-radio :label="0" class="button_radio">否</lui-radio>
              </lui-radio-group>
            </lui-form-item>
          </lui-col>
        </lui-row>
        <lui-row v-if="configForm.alwaysAllPermission === 0">
          <lui-col :span="24">
            <lui-form-item label="事业部：">
              <div v-show="!configShow" class="text">
                <lui-button type="text" @click="handelDeptAdd">配置</lui-button>
                <i class="lui-icon-info" style="margin-left: 15px;font-size: 12px;color: #999;">&nbsp;&nbsp;只能选择所属于账号关联商家的事业部</i>
              </div>
              <!-- 事业部表格 -->
              <lui-table
                ref="configTable"
                v-loading="loadingDepTable"
                :data="configForm.deptList"
                border
                class="transfertable"
                size="mini"
                max-height="226px"
                style="width: 100%">
                <lui-table-column
                  type="index"
                  label="序号"
                  align="center"
                  width="50">
                </lui-table-column>
                <lui-table-column
                  prop="deptNo"
                  label="事业部编码"
                  min-width="150"
                  show-overflow-tooltip>
                </lui-table-column>
                <lui-table-column
                  prop="deptName"
                  label="事业部名称"
                  min-width="150"
                  show-overflow-tooltip>
                </lui-table-column>
                <lui-table-column
                  prop="sellerNo"
                  label="商家编码"
                  min-width="150"
                  show-overflow-tooltip>
                </lui-table-column>
                <lui-table-column
                  prop="sellerName"
                  label="商家名称"
                  min-width="150"
                  show-overflow-tooltip>
                </lui-table-column>
              </lui-table>
            </lui-form-item>
          </lui-col>
        </lui-row>

        <lui-row v-if="configForm.alwaysAllPermission === 0">
          <lui-col :span="24">
            <lui-form-item label="库节点：">
              <div v-show="!configShow" class="text">
                <lui-button type="text" @click="handelNodeAdd">配置</lui-button>
                <i class="lui-icon-info" style="margin-left: 15px;font-size: 12px;color: #999;">&nbsp;&nbsp;只能选择已选中的所属事业部的库节点</i>
              </div>
              <!-- 库节点表格 -->
              <lui-table
                v-loading="loadingNodeTable"
                :data="configForm.nodeList"
                border
                class="transfertable"
                max-height="226px"
                size="mini"
                style="width: 100%">
                <lui-table-column
                  type="index"
                  label="序号"
                  align="center"
                  width="50">
                </lui-table-column>

                <lui-table-column
                  prop="nodeTypeDesc"
                  label="库节点类型"
                  min-width="130"
                  show-overflow-tooltip>
                </lui-table-column>

                <lui-table-column
                  prop="nodeNo"
                  label="库节点编码"
                  min-width="130"
                  show-overflow-tooltip>
                </lui-table-column>

                <lui-table-column
                  prop="nodeName"
                  label="库节点名称"
                  min-width="130"
                  show-overflow-tooltip>
                </lui-table-column>

                <lui-table-column
                  prop="deptNo"
                  label="事业部编码"
                  min-width="130"
                  show-overflow-tooltip>
                </lui-table-column>

                <lui-table-column
                  prop="deptName"
                  label="事业部名称"
                  min-width="130"
                  show-overflow-tooltip>
                </lui-table-column>

                <lui-table-column
                  prop="sellerNo"
                  label="商家编码"
                  min-width="130"
                  show-overflow-tooltip>
                </lui-table-column>

                <lui-table-column
                  prop="sellerName"
                  label="商家名称"
                  min-width="130"
                  show-overflow-tooltip>
                </lui-table-column>
              </lui-table>
            </lui-form-item>
          </lui-col>
        </lui-row>
      </lui-form>
    </lui-dialog>
    <addTransferConfigData
      v-if="configureData.dialogVisible"
      :configure-data="configureData"
      @func="getConfigInfo">
    </addTransferConfigData>
  </div>
</template>
<script>
import { mapGetters } from 'vuex'
import addTransferConfigData from '@/views/userInfo/addTransferConfigData.vue'
import Http from '@/lib/http'
import Api from '@/api'
// import ButtonList from '@/views/common/ButtonList'
import { exportExcel } from '@/utils/downloadRequest'
import addConfig from '@/views/configInfo/AddConfig.vue'
import updateConfig from '@/views/configInfo/UpdateConfig.vue'
import viewConfig from '@/views/configInfo/ViewConfig.vue'
import showEmptyImage from '@/components/common/showEmptyImage/index.vue'
const buttons = {
  add: {},
  delete: {},
  upload: {
    noAsync: true,
    maxM: 10,
    uploadtips: '只能上传[xls或xlsx]文件，文件大小不超过10M',
    uploadConfig: {
      uploadActionUrl: Http.baseContextUrl + Api.ConfigInfo.uploadActionUrl
    },
    templateUrl: Http.baseContextUrl + Api.ConfigInfo.downloadTemplate
  },
  fileName: 'userInfoFile'
}
export default {
  components: {
    showEmptyImage,
    addConfig,
    updateConfig,
    viewConfig,
    addTransferConfigData
    // ButtonList
  },
  data() {
    return {
      //---------------配置数据开始--------------
      showfigureBtn: false,
      loadingDepTable: false, //加载事业部数据
      loadingNodeTable: false, //加载库节点数据
      titleConfigdata: '', //配置数据弹框
      configShow: false, //查看和编辑的标识
      congfigDialogVisible: false, //数据配置弹框标识
      configRules: {}, //数据配置form校验规则
      //数据配置form
      configForm: {
        'account': '',
        'alwaysAllPermission': '',
        'deptList': [],
        'nodeList': [
          {
            'deptName': '',
            'deptNo': '',
            'nodeName': '',
            'nodeNo': '',
            'nodeType': 0,
            'sellerName': '',
            'sellerNo': ''
          }
        ]
      }, 
      sellerNo: '', //编码
      accountId: ' ', //账号id
      //数据配置标识
      isViewConfig: false,
      configPageNum: 1, // 起始页
      configPageSize: 10, // 每页条数
      configTotal: 0, //总数
      nodePageNum: 1, // 起始页
      nodePageSize: 10, // 每页条数
      nodeTotal: 0, //总数
      //有关穿梭框里面的传送数据
      //穿梭框是否有
      showfigureTransfer: false,
      //穿梭框的数据configureData穿梭框的配置
      configureData: {
        id: '',
        dialogVisible: false, //穿梭弹框弹框的显示标识
        title: '选择库节点', //表头名称
        account: '', //账号 //传参
        sellerShow: false, //判断商家穿梭框是否显示
        alwaysAllPermission: 0, //某人是1不展示
        deptList: [], //事业部
        nodeList: [] //库节点
      },
      //配置数据按钮
      buttonConfigDisabled: false,
      //--------------配置数据结束---------------
      id: '',
      showState: 0,
      baseURL: Http.baseContextUrl,
      //上传组件按钮
      buttons,
      //面包屑
      breadCrumbObj: {
        hrefList: [
          {
            title: '项目列表',
            href: 'new-project'
          }
        ],
        currRentTitle: '方案列表'
      },
      serversOptions: [], //开通服务下拉
      menuRoleOptions: [], //菜单角色
      //筛选搜索
      searchform: {
        sellerNo: '', //商家编码
        sellerName: '', //商家名称
        account: '', //账号
        menuRoleCode: '', //菜单角色
        serverCode: '', //开通服务
        status: '' //状态
      },
      //商家类型下拉
      sellerTypeOptions: [
        {
          name: 'ECLP',
          value: 'ECLP'
        },
        {
          name: 'CLPS',
          value: 'CLPS'
        },
        {
          name: '其他',
          value: 'OTHER'
        }
      ],
      buildOptions: [
        {
          name: '京东内部署',
          value: 'JS'
        },
        {
          name: '云部署',
          value: 'JY'
        },
        {
          name: '私有化部署',
          value: 'OTHER'
        }
      ], //部署方式下拉
      //状态下拉
      statusOptions: [
        {
          name: '正常',
          value: 1
        },
        {
          name: '禁用',
          value: 0
        }
      ],
      multipleSelection: [],
      //table列表
      tableData: [],
      loading: false,
      listLoading: false,
      selections: [],
      options: {
        label: '全部',
        selection: true,
        index: false
      },
      searchData: {},
      //分页
      pageNum: 1, // 起始页
      pageSize: 10, // 每页条数
      currentPage: 1, // 起始页
      total: 0,
      dataSource: [],
      width: '80%'
    }
  },
  computed: {
    ...mapGetters(['getdepList', 'getnodeList'])
  },
  watch: {
    getdepList: {
      handler(oldVal, newVal) {
        this.configForm.deptList = this.getdepList
        this.$forceUpdate()
        this.$set(this.configForm, 'deptList', this.getdepList)
        console.log(this.configForm.deptList, 555555555555555)
      }
    },
    getnodeList: {
      handler(oldVal, newVal) {
        this.configForm.nodeList = this.getnodeList
        this.$forceUpdate()
        this.$set(this.configForm, 'nodeList', this.getnodeList)
        console.log(this.configForm.nodeList, 666666666666)
      }
    },
    deep: true
  },
  mounted() {
    this.getServerOptions()
    this.getList()
    //是否有配置数据权限
    this.hasDataPermission()
  },
  
  methods: {
    //-----------------------------配置数据开始
    //根据账户下拉商家 this.dropDownSellerByAccount()
    dropDownSellerByAccount() {
      let paramObj = {}
      let accountId = this.configureData.account
      paramObj.accountId = accountId
      //这里需要 **accountId
      Api.UserInfo.dropDownSellerByAccount(paramObj).then((res) => {
        // this.listLoading = false
        if (res.success) {
          this.configureData.sellerList = res.data
          console.log('下拉选项', this.configureData.sellerList)
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
      })
    },
    radioChange(val) {
      // this.width = '50%'
      let params = {}
      params.id = this.configureData.id
      params.alwaysAllPermission = val
      Api.UserInfo.toggleAlwaysAllPermission(params).then(res => {
      }).catch((e) => {
        this.$showErrorMsg(e)
      })
    },
    //是否有配置数据权限
    hasDataPermission() {
      this.showfigureBtn = true
      //暂时注释//
      Api.UserInfo.hasDataPermission().then(res => {
        if (res.success) {
          this.showfigureBtn = res.data 
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
      })
    },
    //配置数据<--------->查看数据
    handelConfig(index, row, type) {
      console.log(row, '2222')
      this.configureData.id = row.id
      this.configureData.account = row.account
      this.congfigDialogVisible = true
      this.isViewConfig = false
      this.listLoading = true
      //获取数据权限详情是否全数据
      this.getPermissionByUser(row)
      //获取全量的事业部
      this.getDeptPermissionByAccount(row)
      //获取全量的库节点
      this.getUserNodePermissionByAccount(row)
      //获取商家下拉事业部的接口
      this.dropDownSellerByAccount()
      //第二个弹框的下拉列表第一次展示一下
      if (type) {
        this.titleConfigdata = '配置数据权限'
        this.configShow = false
      } else {
        this.configShow = true
        this.titleConfigdata = '查看数据权限'
      }
    },
    //获取数据配置详情
    getConfigInfo(row) {
      this.getPermissionByUser(row)
      this.getDeptPermissionByAccount(row)
      this.getUserNodePermissionByAccount(row) 
      console.log(row, '触发了', this.configForm.deptList)  
    },
    //关闭时刷新列表数据
    handelConfigDataCancel() {
      this.getList()
    },
    //获取数据权限详情
    getPermissionByUser(row) {
      let params = {}
      params.id = this.configureData.id
      Api.UserInfo.getPermissionByUser(params).then(res => {
        if (res.success) {
         
          this.configureData.account = res.data.account
          this.configForm.account = res.data.account
          this.configForm.alwaysAllPermission = res.data.alwaysAllPermission
          // this.configForm.alwaysAllPermission = 0
          this.listLoading = false
          console.log(this.configureData, '详情1')
        }
      }).catch((e) => {
        this.listLoading = false
        this.$showErrorMsg(e)
      })
    },
    //一进来全部调取回显事业部数据(全量)
    getDeptPermissionByAccount(row) {
      let paramObj = {}
      paramObj.accountId = row.account
      this.loadingDepTable = true
      Api.UserInfo.getDeptPermissionByAccount(paramObj).then((res) => {
        if (res.success) {
          this.loadingDepTable = false
          this.configForm.deptList = res.data
          //存一份库节点传给库节点弹框
          this.configureData.deptList = res.data
          this.$store.dispatch('depList', res.data)
          console.log(res.data, '详情2')
       
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
      })
    },
    //一进来全部回显库节点数据（全量）
    getUserNodePermissionByAccount(row) {
      let params = {}
      params.accountId = row.account
      this.loadingNodeTable = true
      Api.UserInfo.getUserNodePermissionByAccount(params).then(res => {
        if (res.success) {
          this.loadingNodeTable = false
          this.configForm.nodeList = res.data
          this.$store.dispatch('nodeList', res.data)
          console.log(res.data, '详情3')
        }
      }).catch((e) => {
        // this.listLoading = false
        this.$showErrorMsg(e)
      })
    },
    //回显事业部数据(分页)
    pageListDeptPermissionByAccount(row) {
      let params = {}
      params.accountId = row.account
      params.pageNum = this.configPageNum
      params.pageSize = this.configPageSize
     
      Api.UserInfo.pageListDeptPermissionByAccount(params).then(res => {
        if (res.success) {
          console.log(res.data, 33)
          this.configForm.deptList = res.data
          this.configTotal = res.total

        }
      }).catch((e) => {
        this.listLoading = false
        this.$showErrorMsg(e)
      })

    },
    //回显库节点数据（分页）
    pageListUserNodePermissionByAccount(row) {
      let params = {}
      params.accountId = row.account
      params.nodePageNum = this.nodePageNum
      params.nodePageSize = this.nodePageSize
      Api.UserInfo.pageListUserNodePermissionByAccount(params).then(res => {
        if (res.success) {
          console.log(res.data, 33)
          this.configForm.nodeList = res.data
          this.nodeTotal = res.total
          //穿梭框隐藏
          this.configureData.dialogVisible = false
          //这里需要有另外一个弹框的visible 和loading选择

        }
      }).catch((e) => {
        // this.listLoading = false
        this.$showErrorMsg(e)
      })

    },
    // 添加事业部,展示穿梭框
    handelDeptAdd() {
      this.configureData.title = '选择事业部'
      this.configureData.sellerShow = true //判断商家是否显示   
      this.configureData.alwaysAllPermission = 0    
      this.showfigureTransfer = true
      this.configureData.dialogVisible = true
       
    },
    //添加库节点
    handelNodeAdd() {
      this.configureData.title = '选择库节点'
      this.configureData.sellerShow = false
      this.configureData.alwaysAllPermission = 0
      this.showfigureTransfer = true
      this.configureData.dialogVisible = true
    },
    //提交事业部数据筛选完以后
    submitDeptPermission() {
      let params = {
        id: this.id,
        userDataPermission: this.configForm
      }
      Api.UserInfo.submitDeptPermission(params).then(res => {
        if (res.success) {
          this.showfigureTransfer = false
          //回调事业部列表 这里有重复，可以考虑优化
          this.getDeptPermissionByAccount()
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
      })
    },
    //提交库节点数据
    submitUserNodePermission() {
      let params = {
        id: this.id,
        userDataPermission: this.configForm
      }
      Api.UserInfo.submitUserNodePermission(params).then(res => {
        if (res.success) {
          this.showfigureTransfer = false
          //回显库节点table
          this.getUserNodePermissionByAccount()
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
      })
    },
    //提交所有配置数据表单
    handleCongfigSubmit() {
      console.log(this.configureData.id)
      let params = {
        id: this.configureData.id,
        userDataPermission: this.configForm
      }
      console.log(params)
      Api.UserInfo.submitUserPermission(params).then(res => {
        if (res.success) {
          this.congfigDialogVisible = false
          //回调事业部列表 这里有重复，可以考虑优化
          this.$message({
            message: '提交成功！',
            type: 'success',
            duration: 1000
          })
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
      })
    },
    //-----------------------------配置数据结束
    //商家列表
    sellerListFormat(sellerList) {
      const sellers = []
      sellerList.forEach(item => {
        sellers.push(item.sellerName) 
      })
      const tmp = sellers.join(',')
      return tmp
    },
    changeState(val) {
      this.showState = val
      this.getList()
    },
    //获取所有开通服务下拉
    getServerOptions() {
      Api.ConfigInfo.getMyServerWithMenuRoles().then((res) => {
        if (res.success) {
          //获取开通服务的下拉选项
          this.serversOptions = res.data.sellerServerList
        }
      }).catch((error) => {})
    },
    //重置
    handleReset() {
      this.searchform = {
        sellerNo: '', //商家编码
        sellerName: '', //商家名称
        sellerType: '', //商家类型
        build: '', //部署方式
        serverCode: '', //开通模块
        status: '' //状态
      }
      this.getList()
    },
    //查询表格事件
    getList() {
      this.listLoading = true
      const paramObj = {
        sellerName: this.searchform.sellerName,
        sellerNo: this.searchform.sellerNo,
        account: this.searchform.account,
        menuRoleCode: this.searchform.menuRoleCode,
        serverCode: this.searchform.serverCode,
        status: this.searchform.status
      }
      paramObj.pageNum = this.pageNum
      paramObj.pageSize = this.pageSize
      Api.ConfigInfo.getAccountPageList(paramObj).then((res) => {
        this.listLoading = false
        if (res.data) {
          for (let i = 0; i < res.data.length; i++) {
            if (res.data[i].status === 1) {
              res.data[i].status = true
            } else {
              res.data[i].status = false
            }
          }
          this.dataSource = res.data
          this.total = res.total
        }
      }).catch((error) => {
        this.$showErrorMsg(error)
        this.listLoading = false
        this.dataSource = []
        this.pageNum = 1
        this.total = 0
      })
    },
    searchClick(val) {
      this.getList()
    },
    //修改这里的状态
    changeStatusTab(row) {
      if (row.status) {
        this.$confirm('是否开启该账号的所有权限？', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          Api.ConfigInfo.updateAccountStatus({ id: row.id, status: 1 }).then((res) => {
            this.$message({
              type: 'success',
              message: '修改成功!'
            })
          }).catch((e) => {
            this.$showErrorMsg(e)
            row.status = false
          })
        }).catch((e) => {
          row.status = false
        })
      } else {
        this.$confirm('是否禁用该账号的所有权限？', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          Api.ConfigInfo.updateAccountStatus({ id: row.id, status: 0 }).then((res) => {
            this.$message({
              type: 'success',
              message: '修改成功!'
            })
          }).catch((e) => {
            this.$showErrorMsg(e)
            row.status = true
          })
        }).catch((e) => {
          row.status = true
        })
      }
    },
    //清除表格内容
    toggleRowSelection(that) {
      return that.clearSelection()
    },
    //翻页-----根据页码变换
    handleSizeChange(val) {
      this.pageNum = val
      this.getList()
    },
    //分页条数改变
    sizeChange(val) {
      this.pageSize = val
      this.getList()
    },
    handleAddClick() {
      this.showState = 1
      // this.$router.push({ path: '/configInfo/addConfig' })
    },
    // 获取选中的id
    getSelectionId() {
      const selectIds = []
      this.multipleSelection.map((item) => {
        selectIds.push(item.id)
      })
      return selectIds
    },
    //这里开始
    handleSelectionChange(val) {
      this.multipleSelection = val
    },
    uploadClick2(e) {
      // console.log('上传')
      /*this.importlistLoading=true;
        let formData=new FormData();
        formData.append('file',event.target.files[0]);
        axios.post('/auditMgr/auditProject/auditProjectUpload',formData,config).then((res)=>{
          this.importlistLoading=false;
          if(res.data.resultCode=='0001'){
            if(res.data.resultMsg=="规则校验不通过"){
              this.errorTitle=res.data.resultMsg;
              this.gridData=JSON.parse(res.data.data);
              this.dialogTableVisible=true;
            }else{
              this.$message.error(res.data.resultMsg);
            }

          }else{
            this.$message({
              message:res.data.resultMsg,
              type:'success'
            });
          }
          e.srcElement.value = ""//及时清当前的文件
        });*/
    },
    //批量上传
    uploadClickWarn() {
      this.$message({
        type: 'warning',
        message: '批量上传功能暂不支持！'
      })
    },
    uploadClick() {
      //已开发、暂时禁用
      this.isUploadModalShow = true
    },
    //批量下载 downloadUserInfo
    downloadClick() {
      const options = Object.assign({}, this.searchform)
      const ids = this.getSelectionId()
      if (ids.length > 0) {
        options.ids = ids
      }
      const actionUrl = this.baseURL + Api.ConfigInfo.downloadUserInfoUrl
      exportExcel(actionUrl, options)
    },
    //批量删除的方法
    deleteClick() {
      const param = {}
      param.idList = this.getSelectionId()
      if (param.idList.length < 1) {
        this.$message({
          message: '未选择要删除的内容',
          type: 'warning',
          duration: 1000
        })
        return
      }
      this.$confirm('确定要删除选中的账号吗？', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        this.loading = true
        Api.ConfigInfo.deleteUserInfo(param).then(response => {
          this.$message({
            message: '删除成功',
            type: 'success',
            duration: 1000
          })
          this.loading = false
          this.getList()
        }).catch(err => {
          this.loading = false
          this.$showErrorMsg(err)
        })
      }).catch(err => {
        this.loading = false
        console.log(err)
      })
    },
    //编辑方法 修改角色
    editHandle(index, row) {
      this.id = row.id
      this.showState = 2
      // this.$router.push({ path: '/configInfo/updateConfig', query: { id: row.id }})
    },
    //查看方法
    viewHandle(index, row) {
      this.id = row.id
      this.showState = 3
      // this.$router.push({ path: '/configInfo/viewConfig', query: { id: row.id }})
    }
  }
}
</script>

<style lang="scss" scoped >
@import "@/assets/stylus/main.scss";
.showmargin{
  display: inline-block;
  padding-left:8px;
}
.config-info{
  /deep/ .is-disabled{
    color: rgba(255, 255, 255, 0.55) !important;
    background-color: rgba(13, 108, 162, 0.54) !important;
    border-color: rgba(13, 108, 162, 0.54) !important;
  }
  .header-title{
    width: 96%;
    margin: 0 auto;
    margin-top: 20px;
    height: 40px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    div{
      font-size: 18px;
      color: #666;
      i{
        margin-right: 10px;
      }
    }
  }
  /*手工添加部分*/
  .addManually{
    padding-top: 10px;
    padding-bottom: 30px;
    width: 100%;
    background: #fff;
    box-shadow:0 0 5px 5px #eee;
    .manually-title{  //头部
      width: 96%;
      margin: 0 auto;
      height: 70px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      .title-left{
        i{
          font-size: 16px;
          margin-right: 10px;
        }
        span{
          font-size: 14px;
          color: #666
        }
      }
    }
    .table-button{ //表格内部按钮
      display: flex;
      justify-content: space-around;
      span{
        color: $--gl-blue;
        cursor: pointer;
      }
    }
    .rotation-pagination{ //分页
      width: 100%;
      margin-top: 50px;
      text-align: center;
      /deep/ .lui-pagination__total{
        margin-left: 20px;
      }
    }
  }
  .is-always-shadow{
    box-shadow: 0 2px 12px 0 rgba(0,0,0,.1);
  }
  .search-box{
    border: 1px solid #EAEAEA;
    background: #FFFFFF;
    margin-bottom: 20px;
  }
  .lui-breadcrumb{
    border-bottom: 1px solid rgb(230, 230, 230);
    padding: 5px 0 10px;
    margin-bottom: 10px;
  }
  /deep/ .lui-form-item{
    display: inline-block;
    margin-bottom: 15px;
  }
  /deep/ .btn-wrap {
    width: 96%;
    padding: 0;
    margin: 0 auto;
    text-align: right;
    .lui-form-item .lui-form-item__content {
      margin-left: 10px !important;
    }
    i {
      padding: 0 2px;
    }
  }
  .filters-btn-group{
    display: inline-block;
  }
  .search-box{
    text-align: center;
  }
  .table-list{
    box-shadow: 0px 1px 8px #EBEEF5;
  }
  /deep/ .lui-button--mini{
    padding:5px 8px
  }
  .uploadRelative{
    position: relative;
    display:inline-block;
    margin-right: 10px;
  }
  .table-link{ //表格溢出隐藏
    overflow: hidden;
    text-overflow:ellipsis;
    white-space: nowrap;
    cursor: pointer;
  }
  // /*去除多选框颜色*/
  // /deep/ .lui-table th>.cell>.is-disabled {
  //   color: rgba(255, 255, 255, 0.55) !important;
  //   background-color:  #F1F4F9 !important;
  //   border-color: #F1F4F9 !important;
  // }
  // /deep/ .lui-table th>.cell>.is-disabled>.is-disabled {
  //   color: #F1F4F9 !important;
  //   background-color: #F1F4F9 !important;
  //   border-color: #F1F4F9 !important;
  // }
}
 /deep/ .lui-table.transfertable thead th{
  background: #D9F0FE!important;
}
/deep/ .lui-table{
   overflow: inherit!important;
}
.lui-table--border{
  border-bottom:1px solid #EAEAEA;
}
/deep/ .lui-radio__input.is-disabled+span.lui-radio__label {
    color: #B5B5B5;
    cursor: not-allowed;
}
/deep/ .lui-radio__input.is-disabled.is-checked .lui-radio__inner {
    background-color: #fff;
    border-color: #D9D9D9;
}
/deep/ .lui-radio__input.is-disabled.is-checked .lui-radio__inner::after {
    background-color: #D9D9D9;
}
</style>
