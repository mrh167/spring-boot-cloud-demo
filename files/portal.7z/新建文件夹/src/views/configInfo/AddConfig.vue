<template>
  <div style="position: relative">
    <lui-card v-loading="loading" class="form-container" shadow="never">
      <lui-form ref="userFrom" :model="user" :rules="rules" label-width="150px">
        <!-- <lui-row>
          <lui-col :span="16">
            <lui-form-item label="商家编码：" prop="sellerNo">
              <lui-input
                v-model="user.sellerNo"
                placeholder="请输入商家编码"
                maxlength="30"
                @input="e => user.sellerNo = numberStringForbid (e)">
              </lui-input>
            </lui-form-item>
          </lui-col>
          <lui-col :span="8">
            <div align="right">
              <lui-button v-waves @click="resetSellerInfo">重置</lui-button>
              <lui-button v-waves type="primary" @click="getSellerInfo">查询商家</lui-button>
            </div>
          </lui-col>
        </lui-row>
        <lui-row>
          <lui-col :span="16">
            <lui-form-item label="商家名称：" prop="sellerName">
              <lui-input
                v-model="user.sellerName"
                placeholder="系统自动"
                :disabled="true"
                maxlength="50"
                @input="e => user.sellerName = specialForbid (e)">
              </lui-input>
            </lui-form-item>
          </lui-col>
        </lui-row>-->
        <lui-form-item
          v-if="!isEdit"
          key="accountList"
          label="账号绑定："
          prop="accountList">
          <lui-select
            v-model.trim="user.accountList"
            multiple
            filterable
            allow-create
            default-first-option
            style="width: 458px"
            placeholder="请输入绑定账号名称，最多10条"
            :multiple-limit="10"
            :popper-append-to-body="false"
            @input="e => user.account = formatLength (e)">
            <lui-option
              v-for="item in accountOptions"
              :key="item.value"
              :label="item.label"
              :value="item.value">
            </lui-option>
          </lui-select>
        </lui-form-item>
        <lui-form-item
          v-if="isEdit"
          key="account"
          label="账号绑定："
          prop="account"
        >
          <lui-input
            v-model="user.account"
            :disabled="isEdit"
            maxlength="30"
            @input="e => user.account = specialForbid (e)">
          </lui-input>
        </lui-form-item>
        <lui-form-item
          key="userServerList"
          label="产品及角色："
          prop="account">
          <lui-cascader
            v-model="serveList"
            :options="options"
            :props="props"
            clearable
            style="width: 458px"
            @change="treeChange"></lui-cascader>
        </lui-form-item>
        <lui-form-item align="right" class="sellerBtnright">
          <lui-button v-if="!isEdit" v-waves @click="onBack">取消</lui-button>
          <lui-button v-if="!isEdit" v-waves type="primary" @click="onSubmit('userFrom')">提交</lui-button>
        </lui-form-item>
      </lui-form>
    </lui-card>
  </div>
</template>
<script>
import Api from '@/api'
// import { getSellerInfoBySeller } from '@/api/sellerInfo'
// import { getRole, addUserInfo, getUserById } from '@/api/userInfo'

const defaultuser = {
  account: '',
  sellerNo: '',
  sellerName: '',
  createType: '',
  accountList: [],
  userServerList: []
}
export default {
  name: 'UserInfoDetail',
  props: {
    // isEdit 为true是可编辑页，为false是增加页
    isEdit: {
      type: Boolean,
      default: false
    },
    //通过source来判断 是商家的添加用户页还是账号配置的手工添加 true是商家的添加用户页
    source: {
      type: Boolean,
      default: true
    }
  },
  data() {
    var trimvalidator = (rule, value, callback) => {
      var myreg = /\s+/g
      if (value === '') {
        callback(new Error('请输入账号'))
      } else if (myreg.test(value)) {
        callback(new Error('输入的账号有空格'))
      } else {
        callback() //重点在这 如果在验证通过后不添加callback()函数在验证时是条件会为false
      }
      callback()
    }
    return {
      user: Object.assign({}, defaultuser),
      loading: false,
      resetSeller: false,
      newAdd: false,
      props: { multiple: true },
      tree: [],
      serveList: [
        {
          menuRoleCodeList: [],
          serverCode: '',
          serverName: ''
        }
      ],
      //options指的是所有选择项
      options: [],
      rules: {
        sellerNo: [
          { required: true, message: '商家编码不能为空', trigger: 'blur' }
        ],
        accountList: [
          { validator: trimvalidator, trigger: 'change' },
          { required: true, message: '账号不能为空', trigger: 'change' }
        ],
        serveList: [
          { required: true, message: '产品及角色不能为空', trigger: 'change' }
        ]
      },
      roleOptions: [],
      serverCodeMap: {},
      accountOptions: [] //账号的下拉选项
    }
  },
  mounted() {
    this.loadserveList()
    //暂时先返全部的，后期后端回返已添加的
    this.getServerOptions()
  },
  methods: {
    formatLength(value) {
      if (value.length) {
        value.forEach((item, index) => {
          if (item.length > 20) {
            this.user.accountList.splice(index, 1)
            this.$showErrorMsg('账号长度不能超过20位')
            // this.user.accountList[index] = item.substring(0, 15)
          }
        })
      }
    },
    treeChange(val) {
      //将this.serveList的格式转化成后台想要的格式
      var map = {}
      var userServerList = []
      this.serveList.forEach((item) => {
        if (!map[item[0]]) {
          userServerList.push({
            serverCode: item[0],
            serverName: this.serverCodeMap[item[0]],
            menuRoleCodeList: [item[1]]
          })
          map[item[0]] = item
        } else {
          userServerList.forEach(userServer => {
            if (userServer.serverCode === item[0]) {
              userServer.menuRoleCodeList.push(item[1])
            }
          })
        }
      })
      this.user.userServerList = userServerList
    },
    // 如果是添加的方法，其实可以先不执行
    loadserveList() {
      // let data=[]
      //Cascader 本身的树形结构
      // 从后台获取数据后，将后台数据转化成aaa这种数据，然后返给this.serveList
      const serveListNew = [
        [3, '3-1'],
        [3, '3-2'],
        [3, '3-3'],
        [2, '2-3'],
        [2, '1-3']
      ]
      var user = {
        accountList: ['aaa', 'bbb', 'ccc'],
        createType: '',
        sellerName: '',
        sellerNo: '',
        userServerList: [
          {
            menuRoleCodeList: [1, 2, 3],
            serverCode: '2'
          },
          {
            menuRoleCodeList: [7, 8, 9],
            serverCode: '3'
          }
        ]
      }
      user.userServerList.forEach((serve, i) => {
        serve.menuRoleCodeList.forEach((menuRoleCode, j) => {
          const obj = []
          // [3, '3-1'],
          obj[0] = serve.serverCode
          obj[1] = menuRoleCode
          serveListNew.push(obj)
        })
      })
      this.serveList = serveListNew
    },
    //获取所有开通服务下拉
    getServerOptions() {
      Api.ConfigInfo.getMyServerWithMenuRoles().then((res) => {
        if (res.success) {
          //获取开通服务的下拉选项
          this.options = res.data.sellerServerList
          res.data.sellerServerList.forEach(item => {
            this.serverCodeMap[item.serverCode] = item.serverName
          })
        }
      }).catch((err) => {
        this.$showErrorMsg(err)
      })
    },
    //获取所有option就是指能选的产品菜单所有值，这个是后台给我返的格式，我放到options上绑定
    getRole() {
      Api.UserInfo.getRole().then(res => {
        this.roleOptions = res.data
        //this.roleOptions把这个结构遍历成前端想要的格式,目前前后端数据格式一样
        this.options = res.data
        res.data.forEach(item => {
          this.serverCodeMap[item.serverCode] = item.serverName
        })
      }).catch(err => {
        this.$showErrorMsg(err)
      })
    },

    initUser(value) {
      this.$refs['userFrom'].resetFields()
      this.user = Object.assign({}, defaultuser)
      this.user.accountList = []
    },
    // 点击查询商家信息
    getSellerInfo() {
      Api.ConfigInfo.getSellerBySellerNo({ sellerNo: this.user.sellerNo }).then(response => {
        this.user.sellerNo = response.data.sellerNo
        this.user.sellerName = response.data.sellerName
        this.options = response.data.sellerServerList
        response.data.sellerServerList.forEach(item => {
          this.serverCodeMap[item.serverCode] = item.serverName
        })
        this.resetSeller = true
      }).catch(err => {
        this.$showErrorMsg(err)
      })
    },
    // 取消
    onBack() {
      this.$emit('func', 0)
      // this.$router.push({ path: '/configInfo' })
    },
    //添加提交
    onSubmit(formName) {
      if (this.user.accountList.length <= 0 || this.user.userServerList.length <= 0) {
        this.$message({
          message: '账号、产品及角色必须填写',
          type: 'error',
          duration: 1000
        })
        return false
      }
      this.$refs[formName].validate((valid) => {
        if (valid) {
          //如果是添加页
          if (!this.isEdit) {
            this.loading = true
            let params = {}
            //先把格式处理好
            params = this.user
            const _this = this
            Api.ConfigInfo.getUserAdd(params).then(res => {
              if (res.success) {
                this.$message({
                  message: '提交成功',
                  type: 'success',
                  duration: 1000
                })
                _this.$emit('func', 0)
                // _this.$router.push({ path: '/configInfo' })
                _this.loading = false
              } else {
                _this.$showErrorMsg(res.errMessage)
              }

            }).catch((err) => {
              _this.$showErrorMsg(err)
              _this.loading = false
            })
          }
        } else {
          this.$message({
            message: '验证失败',
            type: 'error',
            duration: 1000
          })
          return false
        }
      })
    },
    resetSellerInfo() {
      this.user.sellerNo = ''
      this.user.sellerName = ''
      this.resetSeller = false
    }
  }
}
</script>
<style lang="scss">
  .form-container {
      .lui-select-dropdown{
        border: 0;
        .lui-select-dropdown__empty{
          display: none!important;
        }
    }
  }
</style>
<style scoped>
  .form-container {
    position: unset !important;
  }
</style>

