<template>
  <div style="position: relative">
    <lui-card v-loading="loading" class="form-container" shadow="never">
      <lui-form ref="userFrom" :model="user" :rules="rules" label-width="150px">

        <lui-form-item label="账号：" prop="account">
          <lui-input
            v-model="user.account"
            placeholder="系统自动"
            :disabled="true"
            maxlength="50"
            style="width: 458px"
          >
          </lui-input>
        </lui-form-item>
        <lui-form-item
          key="userServerList"
          label="产品及角色："
          prop="account">
          <lui-cascader
            v-model="serveList"
            :options="options"
            :props="props"
            clearable
            style="width: 458px"
            @change="treeChange"></lui-cascader>
        </lui-form-item>

        <lui-form-item align="right" class="sellerBtnright">
          <lui-button v-if="!isEdit" v-waves @click="onBack">取消</lui-button>
          <lui-button v-if="!isEdit" v-waves type="primary" @click="onSubmit('userFrom')">提交</lui-button>
        </lui-form-item>
      </lui-form>
    </lui-card>
  </div>
</template>
<script>
import Api from '@/api'
const defaultuser = {
  sellerNo: '',
  account: '',
  userServerList: []
}
export default {
  name: 'UserInfoDetail',
  props: {
    // isEdit 为true是可编辑页，为false是增加页
    isEdit: {

      type: Boolean,
      default: false
    },
    //通过source来判断 是商家的添加用户页还是账号配置的手工添加 true是商家的添加用户页
    source: {
      type: Boolean,
      default: true
    },
    id: {
      type: Number,
      default: 0
    }
  },
  data() {
    return {
      user: Object.assign({}, defaultuser),
      loading: false,
      resetSeller: false,
      newAdd: false,
      props: { multiple: true },
      tree: [],
      serveList: [
        {
          menuRoleCodeList: [],
          serverCode: '',
          serverName: ''
        }
      ],
      //options指的是所有选择项
      options: [],
      rules: {
        /*createType: [
              { required: true, message: '创建类型不能为空', trigger: 'blur' }
            ]*/

      },
      roleOptions: [],
      serverCodeMap: {},
      accountOptions: [] //账号的下拉选项
    }
  },
  created() {
  },
  mounted() {
  //  this.loadserveList()
    this.accountGetById()
    this.getServerOptions()
    // this.getRole()
  },
  methods: {
    //change完以后给后台传这个值
    treeChange(val) {
      //先自己v-model一个数组，最后将他赋给this.user.userServerList,这里需要把一个数组改成后端想要的格式，
      // 赋给this.user.userServerList
      //将this.serveList的格式转化成后台想要的格式
      var map = {}
      var userServerList = []

      this.serveList.forEach((item) => {
        if (!map[item[0]]) {
          //var userServer =
          // userServer.serverCode = item[0]
          //userServer.menuRoleCodeList.push(item[1])
          userServerList.push({
            serverCode: item[0],
            serverName: this.serverCodeMap[item[0]],
            menuRoleCodeList: [item[1]]
          })
          map[item[0]] = item
        } else {
          userServerList.forEach(userServer => {
            if (userServer.serverCode === item[0]) {
              userServer.menuRoleCodeList.push(item[1])
            }
          })
        }
      })
      this.user.userServerList = userServerList
    },
    // 根据id查询商户信息
    accountGetById() {
      Api.ConfigInfo.accountGetById({ id: this.id }).then(res => {
        this.user.sellerName = res.data.sellerName
        this.user.sellerNo = res.data.sellerNo
        this.user.account = res.data.account
        this.user.userServerList = res.data.userServerList
        var serveListArr = []
        // 将后端的数据格式转化成前端所需要的菜单格式
        res.data.userServerList.forEach((serve, i) => {
          serve.menuRoleCodeList.forEach((menuRoleCode, j) => {
            const obj = []
            // [3, '3-1'],
            obj[0] = serve.serverCode
            obj[1] = menuRoleCode
            serveListArr.push(obj)
          })
        })
        this.serveList = serveListArr
      }).catch(err => {
        this.$showErrorMsg(err)
      })
    },
    //获取所有开通服务下拉
    getServerOptions() {
      Api.ConfigInfo.getMyServerWithMenuRoles().then((res) => {
        if (res.success) {
          //获取开通服务的下拉选项
          this.options = res.data.sellerServerList
        }
      }).catch((error) => {})
    },
    //获取所有option就是指能选的产品菜单所有值，这个是后台给我返的格式，我放到options上绑定
    getRole() {
      Api.ConfigInfo.getRole().then(res => {
        this.roleOptions = res.data
        //this.roleOptions把这个结构遍历成前端想要的格式,目前前后端数据格式一样
        this.options = res.data
        res.data.forEach(item => {
          this.serverCodeMap[item.serverCode] = item.serverName
        })
      }).catch(err => {
        this.$showErrorMsg(err.message)
      })
    },

    // 取消
    onBack() {
      this.$emit('func', 0)
      // this.$router.push({ path: '/configInfo' })
    },
    //添加提交
    onSubmit(formName) {
      if (this.user.userServerList.length <= 0) {
        this.$message({
          message: '产品及角色必须填写',
          type: 'error',
          duration: 1000
        })
        return false
      }
      this.$refs[formName].validate((valid) => {
        if (valid) {
          //编辑页
          this.loading = true
          let params = {}
          //先把格式处理好
          params = this.user
          params.id = this.id
          const _this = this
          Api.ConfigInfo.handleEdit(params).then(res => {
            if (res.success) {
              _this.$message({
                message: '提交成功',
                type: 'success',
                duration: 1000
              })
              _this.$emit('func', 0)
              // _this.$router.push({ path: '/configInfo' })
              _this.loading = false
            } else {
              _this.$showErrorMsg(res.errMessage)
            }

          }).catch((err) => {
            this.$showErrorMsg(err)
            this.loading = false
          })
        } else {
          this.$message({
            message: '验证失败',
            type: 'error',
            duration: 1000
          })
          return false
        }
      })
    },
    resetSellerInfo() {
      this.user.sellerNo = ''
      this.user.sellerName = ''
      this.resetSeller = false
    }
  }
}
</script>

<style scoped>
  .form-container {
    position: unset !important;
  }
</style>
