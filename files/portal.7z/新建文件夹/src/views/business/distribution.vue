<template>
  <div class="distribution">
    <div class="header">
      <div class="header-title">
        <div class="line left"></div>
        筛选项
      </div>
      <div class="search-box">
        <div class="header-left">
          <lui-form :inline="true" label-width="85px">
            <lui-form-item label="统计时间" class="cust-item statisTime">
              <lui-date-picker
                v-model="searchForm.timeValue"
                type="daterange"
                :picker-options="pickerOptions"
                range-separator="至"
                start-placeholder="开始日期"
                end-placeholder="结束日期"
                value-format="yyyy-MM-dd"
                @change="getDateTime">
              </lui-date-picker>
            </lui-form-item>
            <lui-form-item label="商家" class="cust-item division">
              <lui-select v-model="searchForm.sellerNoList" multiple collapse-tags clearable filterable placeholder="请选择" @change="getDeptOpt">
                <lui-option
                  v-for="item in sellerOpt"
                  :key="item.sellerNo"
                  :label="item.sellerName"
                  :value="item.sellerNo">
                </lui-option>
              </lui-select>
            </lui-form-item>
            <lui-form-item label="事业部" class="cust-item division">
              <lui-select v-model="searchForm.deptNoList" multiple collapse-tags clearable filterable placeholder="请选择" @change="getWarehouseOpt">
                <lui-option
                  v-for="item in deptOpt"
                  :key="item.deptNo"
                  :label="item.deptName"
                  :value="item.deptNo">
                </lui-option>
              </lui-select>
            </lui-form-item>
            <lui-form-item label="仓" class="cust-item division">
              <lui-select v-model="searchForm.wareHouseNoList" multiple collapse-tags clearable filterable placeholder="请选择">
                <lui-option
                  v-for="item in wareHouseOpt"
                  :key="item.warehouseNo"
                  :label="item.warehouseName"
                  :value="item.warehouseNo">
                </lui-option>
              </lui-select>
            </lui-form-item>
          </lui-form>
        </div>
        <div class="header-right">
          <lui-button
            v-waves
            type="primary"
            @click="query">查询</lui-button>
          <lui-button
            v-waves
            @click="handleRest">重置</lui-button>
        </div>
      </div>
    </div>
    <div class="custom-table">
      <div class="table-header">
        <div class="header-title">
          <div class="line left"></div>
          <span class="sp1">数据列表</span>
        </div>
        <div>
          <lui-button
            v-waves
            type="primary"
            @click="downloadClickAll">全量下载</lui-button>
          <lui-button
            v-waves
            type="primary"
            @click="downloadClick">批量下载</lui-button>
          <!-- <button-list
            ref="buttons"
            :buttons="buttons"
            :configdept-no=""
            :configdept-name=""
            :check-dept-no="checkDeptNo"
            @uploadSuccess="postListPage">
          </button-list> -->
        </div>
      </div>
      <lui-table
        v-loading="LoadingTable"
        :data="tableData"
        border
        row-class-name="custom-table_row"
        style="width: 100%"
        @selection-change="handleSelectionChange">
        <template slot="empty">
          <showEmptyImage></showEmptyImage>
        </template>
        <lui-table-column
          type="selection"
          fixed="left"
          align="center"
          width="50">
        </lui-table-column>
        <lui-table-column
          prop="sellerName"
          label="商家名称"
          min-width=""
          show-overflow-tooltip
        >
        </lui-table-column>
        <lui-table-column
          prop="deptNo"
          label="事业部编码"
          min-width="100"
          show-overflow-tooltip
        >
        </lui-table-column>
        <lui-table-column
          prop="warehouseName"
          label="仓库名称"
          show-overflow-tooltip
          min-width="">
        </lui-table-column>
        <lui-table-column
          prop="overRegionRatio"
          label="跨区配送占比"
          min-width="110">
          <template slot-scope="scope">
            <div>{{ scope.row.overRegionRatio + '%' }}</div>
          </template>
        </lui-table-column>
        <lui-table-column
          prop="averageAllotTime"
          label="平均调拨时长"
          min-width="110">
        </lui-table-column>
        <lui-table-column
          prop="averageDeliveryTime"
          label="平均配送时效"
          min-width="110">
        </lui-table-column>
        <lui-table-column
          prop="oneDayArriveRatio"
          label="当日达订单占比"
          min-width="120">
          <template slot-scope="scope">
            <div>{{ scope.row.oneDayArriveRatio + '%' }}</div>
          </template>
        </lui-table-column>
        <lui-table-column
          prop="twoDayArriveRatio"
          label="次日达订单占比"
          min-width="120">
          <template slot-scope="scope">
            <div>{{ scope.row.twoDayArriveRatio + '%' }}</div>
          </template>
        </lui-table-column>
        <lui-table-column
          prop="threeDayArriveRatio"
          label="隔日达订单占比"
          min-width="120">
          <template slot-scope="scope">
            <div>{{ scope.row.threeDayArriveRatio + '%' }}</div>
          </template>
        </lui-table-column>
        <lui-table-column
          prop="fourDayArriveRatio"
          label="四日达订单占比"
          min-width="120">
          <template slot-scope="scope">
            <div>{{ scope.row.fourDayArriveRatio + '%' }}</div>
          </template>
        </lui-table-column>
        <lui-table-column
          prop="fiveDayArriveRatio"
          label="五日达及以上订单占比"
          min-width="170">
          <template slot-scope="scope">
            <div>{{ scope.row.fiveDayArriveRatio + '%' }}</div>
          </template>
        </lui-table-column>
      </lui-table>
      <div class="footer">
        <lui-pagination
          v-show="tableData.length>0"
          background
          :page-size="pageSize"
          :current-page="pageNum"
          :page-sizes="[10, 20, 50, 70, 100]"
          layout="total,prev, pager, next, sizes, jumper"
          :total="total"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange">
        </lui-pagination>
      </div>
    </div>
  </div>
</template>

<script>
var now = new Date($.ajax({ async: false }).getResponseHeader('Date'))
var nowTimeNew = now.getTime()
import $ from 'jquery'
import Api from '@/api/index'
import Http from '@/lib/http'
import { exportExcel } from '@/utils/downloadRequest'
import utils from '@/utils/utils'
// import ButtonList from '@/views/common/ButtonList'
import showEmptyImage from '@/components/common/showEmptyImage/index.vue'
const buttons = {
  upload: {
    noAsync: true,
    maxM: 10,
    uploadtips: '只能上传xlsx文件，文件大小不超过10M。',
    uploadtipsadd: '',
    uploadConfig: {
      uploadActionUrl: Http.baseContextUrl + 'baseNodePriority/batchUpload'
    },
    templateUrl: Http.baseContextUrl + 'baseNodePriority/downloadTemplate'
  }
  // fileName: 'userInfoFile'
}
export default {
  name: 'NodeRange',
  components: {
    // ButtonList,
    showEmptyImage
    // draggable
  },

  data() {
    return {
      sellerOpt: [], //商家下拉
      deptOpt: [], //事业部下拉
      wareHouseOpt: [], //仓下拉
      bandOpt: [], //band下拉
      dialogTableVisible: false, //删除错误提示
      buttons,
      isEclp: false,
      buttonDisabled: false,
      LoadingTable: false,
      checkDeptNo: true, //默认false表示不上传事业部
      dialogVisible: false,
      dialogMask: false,
      isEdit: false,
      baseURL: Http.baseContextUrl,
      tableData: [],
      total: 0,
      pageSize: 10,
      pageNum: 1,
      id: '',
      step: 1,
      ruleForm: {
        dept: ''
      },
      rules: {
        dept: [
          { required: true, message: '请选择事业部', trigger: 'change' }
        ]
      },
      multipleSelection: [],
      searchForm: {
        timeValue: '',
        sellerNoList: '',
        deptNoList: '',
        wareHouseNoList: ''
      },
      pickerOptions: {
        disabledDate(time) {
          const lastYearDate = new Date(utils.getLastFormatYear(time)).getTime()
          return time.getTime() >= nowTimeNew - 8.64e7 || time.getTime() < lastYearDate
        }
      }
    }
  },
  created() {
    const startTime = new Date()
    const endTime = new Date()
    this.searchForm.timeValue = [
      utils.getLastFormatDate(startTime),
      utils.getLastFormatDate(endTime)
    ]
  },
  mounted() {
    this.postListPage()
    this.getSellerOpt()
  },
  methods: {
    //获取商家列表
    getSellerOpt() {
      Api.Business.luckWithFindseller().then((res) => {
        if (res.success) {
          this.sellerOpt = res.data
        } else {
          this.$showErrorMsg(res.errMessage)
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
      })
    },
    //获取事业部列表
    getDeptOpt() {
      this.deptOpt = []
      this.wareHouseOpt = []
      this.searchForm.deptNoList = []
      this.searchForm.wareHouseNoList = []
      const params = this.searchForm.sellerNoList
      if (this.searchForm.sellerNoList.length > 0) {
        Api.Business.luckWithDeptSearch(params).then((res) => {
          if (res.success) {
            this.deptOpt = res.data
          } else {
            this.$showErrorMsg(res.errMessage)
          }
        }).catch((e) => {
          this.$showErrorMsg(e)
        })
      } else {
        this.searchForm.deptNoList = []
        this.searchForm.wareHouseNoList = []
      }
    },
    //获取仓列表
    getWarehouseOpt() {
      this.wareHouseOpt = []
      this.searchForm.wareHouseNoList = []
      const params = {
        sellerNoList: this.searchForm.sellerNoList,
        deptNoList: this.searchForm.deptNoList
      }
      if (this.searchForm.deptNoList.length > 0) {
        Api.Business.luckWithFindWarehouse(params).then((res) => {
          if (res.success) {
            this.wareHouseOpt = res.data
          } else {
            this.$showErrorMsg(res.errMessage)
          }
        }).catch((e) => {
          this.$showErrorMsg(e)
        })
      } else {
        this.searchForm.wareHouseNoList = []
      }

    },
    getDateTime(date) {
      let startTime, endTime, thirtyDay
      if (date) {
        startTime = new Date(date[0]).getTime()
        endTime = new Date(date[1]).getTime()
        thirtyDay = 30 * 24 * 3600 * 1000

        if (endTime - startTime >= thirtyDay) {
          this.$showErrorMsg('查询时间的间隔必须在30天以内！')
          this.searchForm.timeValue = []
          return false
        }
        this.postListPage()
      }
    },
    query() {
      this.pageNum = 1
      this.postListPage()
    },
    handleRest() {
      this.searchForm.timeValue = [utils.getLastFormatDate(new Date()), utils.getLastFormatDate(new Date())]
      this.searchForm.sellerNoList = []
      this.searchForm.bandNoList = []
      this.searchForm.wareHouseNoList = []
      this.searchForm.deptNoList = []
      this.postListPage()
    },
    handleSelectionChange(val) {
      this.multipleSelection = val
      // val.forEach(item => {
      //   item.bodies.forEach(el => {
      //     //这里看一下具体后台要啥
      //     this.multipleSelection.push(el)
      //   })
      // })
    },
    //查询列表
    postListPage() {
      this.LoadingTable = true
      const params = {
        sellerNoList: this.searchForm.sellerNoList,
        deptNoList: this.searchForm.deptNoList,
        wareHouseNoList: this.searchForm.wareHouseNoList,
        startDate: this.searchForm.timeValue ? this.searchForm.timeValue[0] : '',
        endDate: this.searchForm.timeValue ? this.searchForm.timeValue[1] : '',
        pageNum: this.pageNum,
        pageSize: this.pageSize
      }
      if (params.startDate === '' || params.endDate === '') {
        this.$showWarningMsg('请输入统计时间！')
        this.LoadingTable = false
        this.tableData = []
        return
      }
      Api.Business.findLuckWith(params).then((res) => {
        if (res.success) {
          this.tableData = res.data
          this.total = res.total
          this.LoadingTable = false
        } else {
          this.$showErrorMsg(res.errMessage)
        }
      }).catch((e) => {
        this.LoadingTable = false
        this.$showErrorMsg(e)
      })

    },
    downloadClickAll() {
      const actionUrl = this.baseURL + Api.Business.luckWithDownloadAll
      const params = {
        sellerNoList: this.searchForm.sellerNoList,
        deptNoList: this.searchForm.deptNoList,
        wareHouseNoList: this.searchForm.wareHouseNoList,
        bandNoList: this.searchForm.bandNoList,
        startDate: this.searchForm.timeValue[0],
        endDate: this.searchForm.timeValue[1],
        pageNum: this.pageNum,
        pageSize: this.pageSize
      }
      exportExcel(actionUrl, params)
    },

    downloadClick() {
      const actionUrl = this.baseURL + Api.Business.luckWithDownload
      const params = this.multipleSelection
      if (!this.multipleSelection.length) {
        this.$showErrorMsg('请选择数据！')
        return
      }
      exportExcel(actionUrl, params)
    },
    handleSizeChange(val) {
      this.pageSize = val
      this.postListPage()
    },
    handleCurrentChange(val) {
      this.pageNum = val
      this.postListPage()
    }
  }
}
</script>
<style lang="scss">
  .statisTime .lui-date-editor .lui-range__close-icon{
    z-index: -20!important;
  }
.table-p {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  cursor: pointer;
  padding-right: 10px;
}
.distribution {
  .lui-range-separator {
    width: 12%;
  }
  .division .lui-select__tags-text {
      display: inline-block;
      max-width: 100px;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;

    }
     .division .lui-tag__close{
        position:absolute;
        top:9px;
    }
}


</style>
<style lang="scss" scoped>
@import '@/assets/stylus/main';
.distribution {
  min-height: 600px;
  .header-title {
    font-size: 16px;
    font-weight: 600;
    color: #333333;
    letter-spacing: 0;
    line-height: 16px;
    .line {
      margin: 2px 6px 0 0;
      width: 2px;
      height: 12px;
      background: $--gl-blue;
      border-radius: 2px;
    }
  }
  .header {
    background: #fff;
    padding: 30px 24px;
    box-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.1);
    border-radius: 0 4px 4px 4px;
    .search-box {
      margin-top: 20px;
      display: flex;
      justify-content: space-between;
      .header-left{
        width: calc(100% - 130px);
      }
      .cust-item{
        margin-right: 24px;
      }
      .label {
        font-size: 14px;
        height: 32px;
        line-height: 32px;
        margin-right: 12px;
      }
      .lui-select,
      .lui-input , .lui-cascader {
        width: 220px;
      }
    }
  }
  .custom-table {
    margin-top: 20px;
    background: #fff;
    padding: 0 24px;
    box-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.1);
    border-radius: 4px;
    .table-header {
      display: flex;
      justify-content: space-between;
      padding: 20px 0;
      .header-title {
        height: 32px;
        line-height: 32px;
        .line {
          margin: 10px 6px 0 0;
        }
        .sp2{
          margin-left:24px;
          font-size: 14px;
          color: #666666;
          font-weight: normal;
          i{margin-right: 8px;}
        }
      }
    }
  }
  .footer {
    padding: 20px 0 30px 0;
    text-align: right;
  }
}
</style>
