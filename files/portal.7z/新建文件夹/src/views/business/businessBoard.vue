<template>
  <div class="business-board">
    <div class="supply">
      <div class="title">供需情况</div>
      <div ref="whQttyLineChartPaneRef">
        <gl-line-chart
          ref="whQttyRef"
          :chart-width="width"
          :chart-height="height"
          :data="chartData">
        </gl-line-chart>
      </div>
      <div ref="lineChartPanelRef" style="height:300px;margin-top:30px">
        <lui-col :span="12">
          <div>
            <gl-line-chart
              ref="avgOnWhQttyRef"
              :chart-width="lineChartWidth"
              :chart-height="lineChartHeight"
              :data="avgOnWhQttyChartData">
            </gl-line-chart>
          </div>
        </lui-col>
        <lui-col :span="12">
          <div>
            <gl-line-chart
              ref="outWhQttyRef" 
              :chart-width="lineChartWidth"
              :chart-height="lineChartHeight"
              :data="outWhQttyChartData">
            </gl-line-chart>
          </div>
        </lui-col>
      </div>
    </div>
    <div class="result">
      <div class="title">时效达成</div>
      <div ref="pieChartPanelRef" style="height:300px">
        <lui-col :span="12">
          <div>
            <gl-pie-chart
              ref="weekRef"
              :chart-width="pieChartWidth"
              :chart-height="300"
              :data="weekAgingOrderOptions">
            </gl-pie-chart>
          </div>
        </lui-col>
        <lui-col :span="12">
          <div>
            <gl-pie-chart
              ref="mongthRef"
              :chart-width="pieChartWidth"
              :chart-height="300"
              :data="mongthAgingOrderOptions">
            </gl-pie-chart>
          </div>
        </lui-col>
      </div>
    </div>
  </div>
</template>

<script>
import Api from '@/api/index'
import $ from 'jquery'
import echarts from 'echarts'
import GlLineChart from '@/components/shared/GlLineChart'
import utils from '@/utils/utils'
export default {
  name: 'BusinessBoard',
  components: {
    GlLineChart,
    GlPieChart: () => import('components/shared/GlPieChart.vue')
  },
  data() {
    return {
      width: 900,
      height: 340,
      lineChartWidth: 450,
      lineChartHeight: 300,
      pieChartWidth: 450,
      weekAgingLegend: [],
      weekAgingSeries: [],
      mongthAgingLegend: [],
      mongthAgingSeries: [],
      // 时效达成 -- 近7日时效订单占比
      weekAgingOrderOptions: {
        title: '近7日时效订单占比',
        tooltip: {},
        legend: {},
        color: ['#4C8FD3', '#78C7E8', '#64CFAB', '#F7DA76', '#FF7F65'],
        seriesArray: []
      },
      // 时效达成 -- 上自然月时效订单占比
      mongthAgingOrderOptions: {
        title: '上自然月时效订单占比',
        tooltip: {},
        legend: {},
        color: ['#4C8FD3', '#78C7E8', '#64CFAB', '#F7DA76', '#FF7F65'],
        seriesArray: []
      },
      chartData: {
        title: {
          text: '近7日库存与出库量',
          subtext: '2020-09-01 至 2020-09-07',
          y: 'top',
          x: 'center',
          textStyle: {
            color: 'rgba(0,0,0,0.75)',
            fontSize: '14'
          }
        },
        legend: {
          x: 'center',
          y: 'bottom',
          data: ['出库量', '库存量'],
          icon: 'rect',
          itemWidth: 12,
          itemHeight: 5
          // bottom: '440'
        },
        grid: {
          top: 60,
          left: 60,
          right: 40,
          bottom: 40,
          height: 220
        },
        xAxis: [{
          splitArea: {
            show: true
          },
          data: [],
          type: 'category',
          // boundaryGap: false, //边距
          axisPointer: {
            snap: false,
            lineStyle: {
              color: '#fff',
              opacity: 0.8,
              width: 5
            },
            label: {
              icon: 'rect',
              show: false,
              backgroundColor: '#004E52'
            },
            handle: {
              show: false,
              color: '#004E52'
            }
          },
          axisTick: { //y轴刻度线
            show: false
          },
          axisLine: {
            show: false
          },
          splitLine: {//x轴分割线
            show: false
          }
        }],
        yAxis: [{
          type: 'value',
          axisTick: {
            show: false //取消坐标轴刻度线
          },
          handle: {
            show: false,
            color: '#004E52'
          },
          axisLine: {
            show: false
          },
          splitLine: {//取消网格线
            show: true
          },
          axisLabel: {//Y轴坐标值
            show: true,
            formatter(value) {
              if (value < 10000) {
                return (value) + ''
              } else if (value >= 10000 && value < 1000000) {
                return (value / 10000) + '万'
              } else if (value >= 1000000 && value < 10000000) {
                return (value / 1000000) + '百万'
              } else if (value >= 10000000 && value < 100000000) {
                return (value / 10000000) + '千万'
              } else if (value >= 100000000) {
                return (value / 100000000) + '亿'
              }
            }
          }
        }],
        seriesArray: []
      },
      avgOnWhQttyChartData: {
        title: {
          text: '近7日各仓平均库存量',
          subtext: '2020-09-01 至 2020-09-07',
          y: 'top',
          x: 'center',
          textStyle: {
            color: 'rgba(0,0,0,0.75)',
            fontSize: '14'
          }
        },
        grid: {
          top: 60,
          left: 80,
          right: 0,
          bottom: 40,
          height: 200
        },
        xAxis: [{
          show: false,
          // splitArea: {
          //   show: true
          // },
          data: [],
          type: 'category',
          boundaryGap: false, //边距
          axisPointer: {
            snap: false,
            lineStyle: {
              color: '#fff',
              opacity: 0.8,
              width: 5
            },
            label: {
              icon: 'rect',
              show: false,
              backgroundColor: '#64CFAB'
            },
            handle: {
              show: false,
              color: '#64CFAB'
            }
          },
          axisTick: { //y轴刻度线
            show: false
          },
          axisLine: {
            show: false
          },
          axisLabel: {
            interval: 0,
            rotate: 10
          },
          splitLine: {//x轴分割线
            show: false
          }
        }],
        yAxis: [{
          type: 'value',
          axisTick: {
            show: false //取消坐标轴刻度线
          },
          handle: {
            show: false,
            color: '#64CFAB'
          },
          axisLine: {
            show: false
          },
          splitLine: {//取消网格线
            show: true
          },
          axisLabel: {//Y轴坐标值
            show: true,
            formatter(value) {
              if (value < 10000) {
                return (value) + ''
              } else if (value >= 10000 && value < 1000000) {
                return (value / 10000) + '万'
              } else if (value >= 1000000 && value < 10000000) {
                return (value / 1000000) + '百万'
              } else if (value >= 10000000 && value < 100000000) {
                return (value / 10000000) + '千万'
              } else if (value >= 100000000) {
                return (value / 100000000) + '亿'
              }
            }
          }
        }],
        seriesArray: [
          {
            name: '',
            type: 'line',
            smooth: true,
            symbol: 'circle',
            showSymbol: false,
            symbolSize: 5,
            // sampling: 'average',
            itemStyle: {
              normal: {
                color: '#64CFAB', //折点颜色
                borderColor: '#fff',
                borderWidth: 4,
                lineStyle: {
                  color: '#64CFAB', //折线颜色
                  width: '2'
                }
              }
            },
            // stack: 'a',
            areaStyle: {
              color: 
                new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                  offset: 0,
                  color: '#64CFAB'
                }, {
                  offset: 1,
                  color: '#ffe'
                }])
            },
            data: []
          }
        ]
      },
      outWhQttyChartData: {
        title: {
          text: '近7日各仓销售出库量',
          subtext: '2020-09-01 至 2020-09-07',
          y: 'top',
          x: 'center',
          textStyle: {
            color: 'rgba(0,0,0,0.75)',
            fontSize: '14'
          }
        },
        grid: {
          top: 60,
          left: 80,
          right: 0,
          bottom: 40,
          height: 200
        },
        xAxis: [{
          show: false,
          data: [],
          type: 'category',
          boundaryGap: false, //边距
          axisPointer: {
            snap: false,
            lineStyle: {
              color: '#fff',
              opacity: 0.8,
              width: 5
            },
            label: {
              icon: 'rect',
              show: false,
              backgroundColor: '#4C8FD3'
            },
            handle: {
              show: false,
              color: '#4C8FD3'
            }
          },
          axisTick: { //y轴刻度线
            show: false
          },
          axisLine: {
            show: false
          },
          axisLabel: {
            interval: 0,
            rotate: 10
          },
          splitLine: {//x轴分割线
            show: false
          }
        }],
        yAxis: [{
          type: 'value',
          axisTick: {
            show: false //取消坐标轴刻度线
          },
          handle: {
            show: false,
            color: '#4C8FD3'
          },
          axisLine: {
            show: false
          },
          splitLine: {//取消网格线
            show: true
          },
          axisLabel: {//Y轴坐标值
            show: true,
            formatter(value) {
              if (value < 10000) {
                return (value) + ''
              } else if (value >= 10000 && value < 1000000) {
                return (value / 10000) + '万'
              } else if (value >= 1000000 && value < 10000000) {
                return (value / 1000000) + '百万'
              } else if (value >= 10000000 && value < 100000000) {
                return (value / 10000000) + '千万'
              } else if (value >= 100000000) {
                return (value / 100000000) + '亿'
              }
            }
          }
        }],
        seriesArray: [
          {
            name: '',
            type: 'line',
            smooth: true,
            symbol: 'circle',
            showSymbol: false,
            symbolSize: 5,
            // sampling: 'average',
            itemStyle: {
              normal: {
                color: '#4C8FD3', //折点颜色
                borderColor: '#fff',
                borderWidth: 4,
                lineStyle: {
                  color: '#4C8FD3', //折线颜色
                  width: '2'
                }
              }
            },
            // stack: 'a',
            areaStyle: {
              color: 
                new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                  offset: 0,
                  color: '#4C8FD3'
                }, {
                  offset: 1,
                  color: '#ffe'
                }])
            },
            data: []
          }
        ]
      }
    }
  },
  created() {
    this.findAvgOnWhQtty() //近7日各仓平均库存量
    this.findOutWhQtty() //近7日各仓销售出库量
    this.findWeekAging() //近7日时效订单占比
    this.findMongthAging() //自然月时效订单
    this.findWhQtty()//近7日库存与出库量
  },
  mounted() {
    this.width = Math.floor($(this.$refs.whQttyLineChartPaneRef).width())
    this.pieChartWidth = Math.floor(($(this.$refs.pieChartPanelRef).width() / 2))
    this.lineChartWidth = Math.floor(($(this.$refs.lineChartPanelRef).width() / 2))
    setTimeout(() => {
      window.addEventListener('resize', () => {
        const whQttyLineChartPaneWidth = $(this.$refs.whQttyLineChartPaneRef).width()
        this.width = Math.floor(whQttyLineChartPaneWidth)
        const pieChartPanelWidth = $(this.$refs.pieChartPanelRef).width()
        this.pieChartWidth = Math.floor((pieChartPanelWidth / 2))
        const lineChartPanelWidth = $(this.$refs.lineChartPanelRef).width()
        this.lineChartWidth = Math.floor((lineChartPanelWidth / 2))
        this.$nextTick(() => {
          this.$refs.whQttyRef && this.$refs.whQttyRef.resize()
          this.$refs.weekRef && this.$refs.weekRef.resize()
          this.$refs.mongthRef && this.$refs.mongthRef.resize()
          this.$refs.avgOnWhQttyRef && this.$refs.avgOnWhQttyRef.resize()
          this.$refs.outWhQttyRef && this.$refs.outWhQttyRef.resize()
        })
      })
    }, 200)
  },
  methods: {
    //近7日库存与出库量
    findWhQtty() {
      const params = {
        startDate: utils.getDay(-7),
        endDate: utils.getDay(-1)
      }
      this.chartData.title.subtext = `${utils.getDay(-7)} 至 ${utils.getDay(-1)}`
      Api.Business.findWhQtty(params).then((res) => {
        if (res.success) {
          let data = res.data
          let onWhQttyList = [], outWhQttyList = [], opDateList = []
          data.forEach(item => {
            opDateList.push(item.opDate) //统计日期
            onWhQttyList.push(item.onWhQtty) //库存量
            outWhQttyList.push(item.outWhQtty) //出库量
          })
          this.chartData.xAxis = [{
            splitArea: {
              show: true
            },
            data: opDateList,
            type: 'category',
            boundaryGap: false, //边距
            axisPointer: {
              snap: false,
              lineStyle: {
                color: '#fff',
                opacity: 0.8,
                width: 5
              },
              label: {
                icon: 'rect',
                show: false,
                backgroundColor: '#004E52'
              },
              handle: {
                show: false,
                color: '#004E52'
              }
            },
            axisTick: { //y轴刻度线
              show: false
            },
            axisLine: {
              show: false
            },
            splitLine: {//x轴分割线
              show: false
            }
          }]
          // var arr = [...onWhQttyList, ...outWhQttyList]
          // var min = utils.calMaxMin(arr).min
          // var max = utils.calMaxMin(arr).max
          // this.chartData.yAxis = [{
          //   type: 'value',
          //   axisTick: {
          //     show: false //取消坐标轴刻度线
          //   },
          //   handle: {
          //     show: false,
          //     color: '#004E52'
          //   },
          //   axisLine: {
          //     show: false
          //   },
          //   splitLine: {//取消网格线
          //     show: true
          //   },
            
          //   axisLabel: {//Y轴坐标值
          //     show: true,
          //     formatter(value) {
                
          //       if (value < 10000) {
          //         return (value) + ''
          //       } else if (value >= 10000 && value < 1000000) {
          //         return (value / 10000) + '万'
          //       } else if (value >= 1000000 && value < 10000000) {
          //         return (value / 1000000) + '百万'
          //       } else if (value >= 10000000 && value < 100000000) {
          //         return (value / 10000000) + '千万'
          //       } else if (value >= 100000000) {
          //         return (value / 100000000) + '亿'
          //       }
          //     }
          //   }
          // }],
          this.chartData.seriesArray.push(
            {
              name: '出库量',
              type: 'line',
              smooth: true,
              symbol: 'circle',
              showSymbol: false,
              symbolSize: 5,
              // sampling: 'average',
              itemStyle: {
                normal: {
                  color: '#4C8FD3', //折点颜色
                  borderColor: '#fff',
                  borderWidth: 4,
                  lineStyle: {
                    color: '#4C8FD3', //折线颜色
                    width: '2'
                  }
                }
              },
              // stack: 'a',
              areaStyle: {
                color:
                  new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                    offset: 0,
                    color: '#4C8FD3'
                  }, {
                    offset: 1,
                    color: '#ffe'
                  }])
              },
              data: outWhQttyList
            },
            {
              name: '库存量',
              type: 'line',
              smooth: true,
              symbol: 'circle',
              showSymbol: false,
              symbolSize: 5,
              // sampling: 'average',
              itemStyle: {
                normal: {
                  color: '#64CFAB', //折点颜色
                  borderColor: '#fff',
                  borderWidth: 4,
                  lineStyle: {
                    color: '#64CFAB', //折线颜色
                    width: '2'
                  }
                }
              },
              areaStyle: {
                color:
                  new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                    offset: 0,
                    color: '#64CFAB'
                  }, {
                    offset: 1,
                    color: '#ffe'
                  }])
              },
              data: onWhQttyList
            }
          )
          //this.chartData.title.subtext = `${data[0].opDate} 至 ${data[data.length - 1].opDate}`
        }
      }).catch((e) => {
        console.error(e)
      })
    },
    //近7日各仓平均库存量
    findAvgOnWhQtty() {
      const params = {
        startDate: utils.getDay(-7),
        endDate: utils.getDay(-1)
      }
      this.avgOnWhQttyChartData.title.subtext = `${utils.getDay(-7)} 至 ${utils.getDay(-1)}`
      Api.Business.findAvgOnWhQtty(params).then((res) => {
        if (res.success) {
          let data = res.data
          let avgWhQttyList = [], wareHouseNameList = []
          data.forEach(item => {
            avgWhQttyList.push(item.avgWhQtty) //平均库存量
            wareHouseNameList.push(item.warehouseName) //仓库名称
          })
          this.avgOnWhQttyChartData.xAxis[0].data = wareHouseNameList
          this.avgOnWhQttyChartData.seriesArray[0].data = avgWhQttyList

        }
      }).catch((e) => {
        console.error(e)
      })
    },
    //近7日各仓销售出库量
    findOutWhQtty() {
      const params = {
        startDate: utils.getDay(-7),
        endDate: utils.getDay(-1)
      }
      this.outWhQttyChartData.title.subtext = `${utils.getDay(-7)} 至 ${utils.getDay(-1)}`
      Api.Business.findOutWhQtty(params).then((res) => {
        if (res.success) {
          let data = res.data
          const outWhQttyList = [], wareHouseNameList = []
          data.forEach(item => {
            outWhQttyList.push(item.outWhQtty) //平均库存量
            wareHouseNameList.push(item.warehouseName) //仓库名称
          })
          this.outWhQttyChartData.xAxis[0].data = wareHouseNameList
          this.outWhQttyChartData.seriesArray[0].data = outWhQttyList
        }
      }).catch((e) => {
        console.error(e)
      })
    },
    //近7日时效订单占比
    findWeekAging() {
      const params = {
        startDate: utils.getDay(-7),
        endDate: utils.getDay(-1)
      }
      this.weekAgingOrderOptions.subtext = `${utils.getDay(-7)} 至 ${utils.getDay(-1)}`
      this.weekAgingOrderOptions.tooltip = {
        trigger: 'item',
        formatter: '{a} <br/>{b} : {c} ({d}%)'
      }
      Api.Business.findWeekAging(params).then((res) => {
        if (res.success) {
          let weekAging = [], weekAgingLegend = []
          let data = res.data
          data.forEach(item => {
            weekAging.push({
              name: item.name,
              value: item.ratio
            })
            weekAgingLegend.push(item.name)
          })
          this.weekAgingSeries = weekAging
          this.weekAgingLegend = weekAgingLegend
          this.weekAgingOrderOptions.seriesArray.push(
            {
              name: '近7日时效订单占比',
              radius: ['32%', '46%'],
              center: ['50%', '50%'],
              label: {
                formatter: '{b}:  {d}%'
              },
              data: this.weekAgingSeries
            }
          )
          this.weekAgingOrderOptions.legend = {
            x: 'center',
            y: 'bottom',
            icon: 'circle', // 设置间距形状
            itemWidth: 10, // 设置图例宽度
            itemHeight: 10, // 设置图例高度
            itemGap: 10, // 设置间距图例
            data: this.weekAgingLegend
          }
        }
      }).catch((e) => {
        console.error(e)
      })
    },
    //上自然月时效订单占比
    findMongthAging() {
      const params = {
        startDate: utils.getDay(-7),
        endDate: utils.getDay(-1)
      }
      this.mongthAgingOrderOptions.subtext = `${utils.getDay(-7)} 至 ${utils.getDay(-1)}`
      this.mongthAgingOrderOptions.tooltip = {
        trigger: 'item',
        formatter: '{a} <br/>{b} : {c} ({d}%)'
      }
      Api.Business.findMongthAging(params).then((res) => {
        if (res.success) {
          let mongthAging = [], mongthAgingLegend = []
          let data = res.data
          data.forEach(item => {
            mongthAging.push({
              name: item.name,
              value: item.ratio
            })
            mongthAgingLegend.push(item.name)
          })
          this.mongthAgingSeries = mongthAging
          this.mongthAgingLegend = mongthAgingLegend
          this.mongthAgingOrderOptions.seriesArray.push(
            {
              name: '上自然月时效订单占比',
              // radius: '55%',
              radius: ['32%', '46%'],
              center: ['50%', '50%'],
              label: {
                formatter: '{b}:  {d}%'
              },
              // roseType: 'radius', // 使用玫瑰饼图
              data: this.mongthAgingSeries
            }
          )
          this.mongthAgingOrderOptions.legend = {
            x: 'center',
            y: 'bottom',
            icon: 'circle', // 设置间距形状
            itemWidth: 10, // 设置图例宽度
            itemHeight: 10, // 设置图例高度
            itemGap: 10, // 设置间距图例
            data: this.mongthAgingLegend
          }
        }
      }).catch((e) => {
        console.error(e)
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.business-board {
  min-height: 600px;
  .title{
      font-size: 16px;
      font-weight: 600;
      color: #333333;
      &:before{
        content: '';
        width: 2px;
        display: inline-block;
        height: 12px;
        background: #0D6CA2;
        margin-right: 6px;
      }
  }
  .supply{
    padding: 30px 24px;
    background: #FFFFFF;
    box-shadow: 0 2px 4px 0 rgba(0,0,0,0.10);
    border-radius: 4px;
  }
  .result{
    padding: 30px 24px;
    margin-top: 30px;
    background: #FFFFFF;
    box-shadow: 0 2px 4px 0 rgba(0,0,0,0.10);
    border-radius: 4px;
  }
}
</style>
