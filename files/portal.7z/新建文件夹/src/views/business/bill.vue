<template>
  <div class="bill">
    <div class="header">
      <div class="header-title">
        <div class="line left"></div>
        筛选项
      </div>
      <div class="search-box">
        <div class="header-left">
          <lui-form :inline="true" label-width="85px">
            <lui-form-item label="商家" class="cust-item division">
              <lui-select
                v-model="searchForm.business"
                multiple
                filterable
                collapse-tags
                clearable
                placeholder="请选择"
                @change="handleChangeSeller">
                <lui-option
                  v-for="item in searchForm.businessOpt"
                  :key="item.sellerNo"
                  :label="item.sellerName"
                  :value="item.sellerNo"
                >
                </lui-option>
              </lui-select>
            </lui-form-item>
            <lui-form-item label="事业部" class="cust-item division">
              <lui-select
                v-model="searchForm.deptNo"
                multiple
                filterable
                collapse-tags

                clearable
                placeholder="请选择"
                @change="handleChangeDept">
                <lui-option
                  v-for="item in searchForm.deptOpt"
                  :key="item.deptNo"
                  :label="item.deptName"
                  :value="item.deptNo">
                </lui-option>
              </lui-select>
            </lui-form-item>
            <lui-form-item label="始发仓" class="cust-item division">
              <lui-select
                v-model="searchForm.warehouse"
                multiple
                filterable
                collapse-tags
                clearable
                placeholder="请选择">
                <lui-option
                  v-for="item in searchForm.warehouseOpt"
                  :key="item.startingWareHouseNo"
                  :label="item.warehouseName"
                  :value="item.warehouseNo">
                </lui-option>
              </lui-select>
            </lui-form-item>
            <lui-form-item label="下单时间" class="cust-item statisTime">
              <lui-date-picker
                v-model="searchForm.timeValue"
                :picker-options="pickerOptions"
                type="daterange"
                range-separator="至"
                value-format="yyyy-MM-dd"
                start-placeholder="开始日期"
                end-placeholder="结束日期"
                @change="getDateTime">
              </lui-date-picker>
            </lui-form-item>
          </lui-form>
          <lui-form :inline="true" label-width="85px">
            <lui-form-item label="查询单据" class="cust-item">
              <lui-select v-model="searchForm.billType" placeholder="请选择" @change="handleBillType">
                <lui-option
                  v-for="item in billOpt"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value">
                </lui-option>
              </lui-select>
            </lui-form-item>
            <lui-form-item label="" class="cust-item">
              <lui-input v-model="searchForm.bill" style="width:305px;" clearable placeholder="请输入单号"></lui-input>
            </lui-form-item>
            <lui-form-item label="SKU编码" class="cust-item">
              <lui-input v-model="searchForm.skuNo" clearable placeholder="请输入SKU编码"></lui-input>
            </lui-form-item>
          </lui-form>
        </div>
        <div class="header-right">
          <lui-button
            v-waves
            type="primary"
            @click="query">查询</lui-button>
          <lui-button
            v-waves
            @click="handleRest">重置</lui-button>
        </div>
      </div>
    </div>
    <div class="custom-table">
      <div class="table-header">
        <div class="header-title">
          <div class="line left"></div>
          <span class="sp1">数据列表</span>
        </div>
        <div>
          <lui-button
            v-waves
            type="primary"
            @click="downloadClick">全量下载</lui-button>
          <lui-button
            v-waves
            type="primary"
            @click="handleDownloadPart">批量下载</lui-button>
        </div>
      </div>
      <lui-table
        v-loading="LoadingTable"
        :data="tableData"
        border
        row-class-name="custom-table_row"
        style="width: 100%"
        @selection-change="handleSelectionChange">
        <template slot="empty">
          <showEmptyImage></showEmptyImage>
        </template>
        <div v-if="searchForm.billType == 1">
          <lui-table-column
            type="selection"
            fixed="left"
            align="center"
            width="50">
          </lui-table-column>
          <lui-table-column
            show-overflow-tooltip
            prop="allotCode"
            label="调拨单号"
            min-width="100">
          </lui-table-column>
          <lui-table-column
            show-overflow-tooltip
            prop="sellerName"
            label="商家名称"
            min-width="100">
          </lui-table-column>
          <lui-table-column
            show-overflow-tooltip
            prop="deptNo"
            label="事业部编码"
            min-width="100">
          </lui-table-column>
          <lui-table-column
            show-overflow-tooltip
            prop="skuNo"
            label="SKU编码"
            min-width="100">
          </lui-table-column>
          <lui-table-column
            show-overflow-tooltip
            prop="skuName"
            label="SKU名称"
            min-width="100">
          </lui-table-column>
          <lui-table-column
            prop="orderQtty"
            label="下单数量"
            min-width="">
          </lui-table-column>
          <lui-table-column
            prop="checkQtty"
            label="验收数量"
            min-width="">
          </lui-table-column>
          <lui-table-column
            show-overflow-tooltip
            prop="startWarehouseName"
            label="始发仓库"
            min-width="110">
          </lui-table-column>
          <lui-table-column
            show-overflow-tooltip
            prop="endWarehouseName"
            label="目的仓库"
            min-width="110">
          </lui-table-column>
          <lui-table-column
            prop="opDate"
            label="下单时间"
            show-overflow-tooltip
            min-width="120">
          </lui-table-column>
        </div>
        <div v-else>
          <lui-table-column
            type="selection"
            fixed="left"
            align="center"
            width="50">
          </lui-table-column>
          <lui-table-column
            show-overflow-tooltip
            prop="orderCode"
            label="销售订单号"
            min-width="100">
          </lui-table-column>
          <lui-table-column
            prop="sellerName"
            label="商家名称"
            show-overflow-tooltip
            min-width="100">
          </lui-table-column>
          <lui-table-column
            prop="deptNo"
            label="事业部编码"
            show-overflow-tooltip
            min-width="100">
          </lui-table-column>
          <lui-table-column
            prop="skuNo"
            label="SKU编码"
            show-overflow-tooltip
            min-width="100">
          </lui-table-column>
          <lui-table-column
            prop="skuName"
            label="SKU名称"
            show-overflow-tooltip
            min-width="100">
          </lui-table-column>
          <lui-table-column
            prop="orderQtty"
            label="下单数量"
            min-width="">
          </lui-table-column>
          <lui-table-column
            prop="delieveredQtty"
            label="妥投数量"
            min-width="">
          </lui-table-column>
          <lui-table-column
            prop="startWarehouseName"
            label="始发仓库"
            show-overflow-tooltip
            min-width="110">
          </lui-table-column>
          <lui-table-column
            prop="overRegionStr"
            label="是否跨区"
            min-width="80">
          </lui-table-column>
          <lui-table-column
            prop="opDate"
            label="下单时间"
            show-overflow-tooltip
            min-width="120">
          </lui-table-column>
          <lui-table-column
            prop="reviewPackTime"
            label="复核打包时间"
            show-overflow-tooltip
            min-width="120">
          </lui-table-column>
          <lui-table-column
            prop="deliveryTime"
            label="出库时间"
            show-overflow-tooltip
            min-width="120">
          </lui-table-column>
          <lui-table-column
            prop="delieveredTime"
            label="妥投时间"
            show-overflow-tooltip
            min-width="120">
          </lui-table-column>
        </div>
      </lui-table>
      <div class="footer">
        <lui-pagination
          v-show="tableData.length>0"
          background
          :page-size="pageSize"
          :current-page="pageNum"
          :page-sizes="[10, 20, 50, 70, 100]"
          layout="total,prev, pager, next, sizes, jumper"
          :total="total"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange">
        </lui-pagination>
      </div>
    </div>
  </div>
</template>

<script>
import $ from 'jquery'
import Api from '@/api/index'
import Http from '@/lib/http'
import { exportExcel } from '@/utils/downloadRequest'
import showEmptyImage from '@/components/common/showEmptyImage/index.vue'
import utils from '@/utils/utils'
var now = new Date($.ajax({ async: false }).getResponseHeader('Date'))
var nowTimeNew = now.getTime()

export default {
  name: 'Bill',
  components: {
    showEmptyImage
  },
  data() {
    return {

      billOpt: [
        {
          value: '1',
          label: '调拨单'
        }, {
          value: '2',
          label: '销售订单'
        }
      ],
      isEclp: false,
      buttonDisabled: false,
      LoadingTable: false,
      baseURL: Http.baseContextUrl,
      tableData: [],
      total: 0,
      pageSize: 10,
      pageNum: 1,
      multipleSelection: [],
      searchForm: {
        timeValue: '',
        business: '',
        deptNo: '',
        warehouse: '',
        skuNo: '',
        bill: '',
        billType: '1',
        businessOpt: [],
        deptOpt: [],
        warehouseOpt: []
      },
      pickerOptions: {
        disabledDate(time) {
          const lastYearDate = new Date(utils.getLastFormatYear(time)).getTime()
          return time.getTime() >= nowTimeNew - 8.64e7 || time.getTime() < lastYearDate
        }
      }
    }
  },
  created() {
    const startTime = new Date()
    const endTime = new Date()
    this.searchForm.timeValue = [
      utils.getLastFormatDate(startTime),
      utils.getLastFormatDate(endTime)
    ]
  },
  mounted() {
    this.orderFindseller()
    this.postListPage()
  },
  methods: {
    getDateTime(date) {
      let startTime, endTime, thirtyDay
      if (date) {
        startTime = new Date(date[0]).getTime()
        endTime = new Date(date[1]).getTime()
        thirtyDay = 30 * 24 * 3600 * 1000

        if (endTime - startTime >= thirtyDay) {
          this.$showErrorMsg('查询时间的间隔必须在30天以内！')
          this.searchForm.timeValue = []
          return false
        }
      }
    },
    query() {
      this.pageNum = 1
      this.postListPage()
    },
    handleBillType() {
      this.pageNum = 1
      this.postListPage()
    },
    handleRest() {
      this.searchForm.timeValue = []
      this.searchForm.business = []
      this.searchForm.warehouse = []
      this.searchForm.deptNo = []
      this.searchForm.bill = ''
      this.searchForm.skuNo = ''
      this.searchForm.billType = '1'
      this.postListPage()
    },
    handleSelectionChange(val) {
      this.multipleSelection = val
    },
    handleChangeSeller(val) {
      if (this.searchForm.business.length) {
        this.searchForm.deptNo = []
        this.searchForm.warehouse = []
        this.queryDept(val)
      } else {
        this.searchForm.deptNo = []
        this.searchForm.deptOpt = []
        this.searchForm.warehouse = []
        this.searchForm.warehouseOpt = []
      }
    },
    handleChangeDept(val) {
      if (this.searchForm.business.length && this.searchForm.deptNo.length) {
        this.searchForm.warehouse = []
        this.orderStaringWareHouse()
      } else {
        this.searchForm.warehouse = []
        this.searchForm.warehouseOpt = []
      }
    },
    //查询列表
    postListPage() {
      this.LoadingTable = true
      Api.Business.findOrder(
        {
          pageNum: this.pageNum,
          pageSize: this.pageSize,
          orderType: this.searchForm.billType, //单据类型 1：调拨单 2：销售单
          deptNoList: this.searchForm.deptNo, //事业部编码list
          orderCode: this.searchForm.bill, //单号
          sellerNoList: this.searchForm.business, //商家编码list
          skuNo: this.searchForm.skuNo, //sku编码
          startingWareHouseNoList: this.searchForm.warehouse, //始发仓list
          startDate: this.searchForm.timeValue ? this.searchForm.timeValue[0] : null,
          endDate: this.searchForm.timeValue ? this.searchForm.timeValue[1] : null
        }
      ).then((res) => {
        if (res.success) {
          if (this.searchForm.billType === '1') {
            this.tableData = res.allotCoList
          } else {
            this.tableData = res.orderCoList
          }
          this.total = res.total
          this.LoadingTable = false
        }
      }).catch((e) => {
        this.LoadingTable = false
        this.$showErrorMsg(e)
      })
    },
    //下载部分
    handleDownloadPart() {
      if (!this.multipleSelection.length) {
        this.$showErrorMsg('请选择数据')
        return
      }
      let actionUrl = ''
      if (this.searchForm.billType === '1') {
        actionUrl = `${this.baseURL}business/order/downloadAllot`
      } else {
        actionUrl = `${this.baseURL}business/order/downloadMarket`
      }
      const params = this.multipleSelection
      exportExcel(actionUrl, params)
    },
    //下载全部
    downloadClick() {
      const actionUrl = `${this.baseURL}business/order/downloadAll`
      const params = {
        pageNum: this.pageNum,
        pageSize: this.pageSize,
        orderType: this.searchForm.billType, //单据类型 1：调拨单 2：销售单
        deptNoList: this.searchForm.deptNo, //事业部编码list
        orderCode: this.searchForm.bill, //单号
        sellerNoList: this.searchForm.business, //商家编码list
        skuNo: this.searchForm.skuNo, //sku编码
        startingWareHouseNoList: this.searchForm.warehouse, //始发仓list
        startDate: this.searchForm.timeValue ? this.searchForm.timeValue[0] : null,
        endDate: this.searchForm.timeValue ? this.searchForm.timeValue[1] : null
      }
      exportExcel(actionUrl, params)
    },
    //事业部列表
    queryDept(sellerNo) {
      Api.Business.orderDeptSearch(sellerNo).then((res) => {
        if (res.success) {
          this.searchForm.deptOpt = res.data
        }
      }).catch((e) => {
        console.error(e)
      })
    },
    //商家列表
    orderFindseller() {
      Api.Business.orderFindseller().then((res) => {
        if (res.success) {
          this.searchForm.businessOpt = res.data
        }
      }).catch((e) => {
        console.error(e)
      })
    },
    //始发仓列表
    orderStaringWareHouse() {
      const params = {
        'deptNoList': this.searchForm.deptNo,
        'sellerNoList': this.searchForm.business
      }
      Api.Business.orderStaringWareHouse(params).then((res) => {
        if (res.success) {
          this.searchForm.warehouseOpt = res.data
        }
      }).catch((e) => {
        console.error(e)
      })
    },
    handleSizeChange(val) {
      this.pageSize = val
      this.postListPage()
    },
    handleCurrentChange(val) {
      this.pageNum = val
      this.postListPage()
    }
  }
}
</script>
<style lang="scss">
.bill {
   .statisTime .lui-date-editor .lui-range__close-icon{
    z-index: -20!important;
  }
  .lui-date-editor .lui-range-separator {
    width: 12%;
  }
    .division .lui-select__tags-text {
      display: inline-block;
      max-width: 100px;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;

    }
     .division .lui-tag__close{
        position:absolute;
        top:9px;
    }
}


</style>
<style lang="scss" scoped>
@import '@/assets/stylus/main';

.bill {
  min-height: 600px;
  .header-title {
    font-size: 16px;
    font-weight: 600;
    color: #333333;
    letter-spacing: 0;
    line-height: 16px;
    .line {
      margin: 2px 6px 0 0;
      width: 2px;
      height: 12px;
      background: $--gl-blue;
      border-radius: 2px;
    }
  }
  .header {
    background: #fff;
    padding: 30px 24px;
    box-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.1);
    border-radius: 0 4px 4px 4px;
    .search-box {
      margin-top: 20px;
      display: flex;
      justify-content: space-between;
      .header-left{
        width: calc(100% - 130px);
      }
      .cust-item{
        margin-right: 24px;
      }
      .label {
        font-size: 14px;
        height: 32px;
        line-height: 32px;
        margin-right: 12px;
      }
     .lui-select,
      .lui-input , .lui-cascader {
        width: 220px;
      }
    }
  }
  .custom-table {
    margin-top: 20px;
    background: #fff;
    padding: 0 24px;
    box-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.1);
    border-radius: 4px;
    .table-header {
      display: flex;
      justify-content: space-between;
      padding: 20px 0;
      .header-title {
        height: 32px;
        line-height: 32px;
        .line {
          margin: 10px 6px 0 0;
        }
        .sp2{
          margin-left:24px;
          font-size: 14px;
          color: #666666;
          font-weight: normal;
          i{margin-right: 8px;}
        }
      }
    }
  }
  .footer {
    padding: 20px 0 30px 0;
    text-align: right;
  }
}
</style>
