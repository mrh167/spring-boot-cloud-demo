<template>
  <div class="warehouse-data">
    <div class="header">
      <div class="header-title">
        <div class="line left"></div>
        筛选项
      </div>
      <div class="search-box">
        <div class="header-left">
          <lui-form :inline="true" label-width="80px">
            <lui-form-item label="统计时间" class="cust-item statisTime">
              <lui-date-picker
                v-model="searchForm.timeValue"
                type="daterange"
                :picker-options="pickerOptions"
                range-separator="至"
                start-placeholder="开始日期"
                end-placeholder="结束日期"
                value-format="yyyy-MM-dd"
                @change="getDateTime">
              </lui-date-picker>
            </lui-form-item>
            <lui-form-item label="商家" class="cust-item division">
              <lui-select v-model="searchForm.sellerNoList" multiple collapse-tags clearable filterable placeholder="请选择" @change="getDeptOpt">
                <lui-option
                  v-for="item in sellerOpt"
                  :key="item.sellerNo"
                  :label="item.sellerName"
                  :value="item.sellerNo">
                </lui-option>
              </lui-select>
            </lui-form-item>
            <lui-form-item label="事业部" class="cust-item division" label-width="85px">
              <lui-select v-model="searchForm.deptNoList" multiple collapse-tags clearable filterable placeholder="请选择" @change="getWarehouseOpt">
                <lui-option
                  v-for="item in deptOpt"
                  :key="item.deptNo"
                  :label="item.deptName"
                  :value="item.deptNo">
                </lui-option>
              </lui-select>
            </lui-form-item>
            <lui-form-item label="仓" class="cust-item division">
              <lui-select v-model="searchForm.wareHouseNoList" multiple collapse-tags clearable filterable placeholder="请选择">
                <lui-option
                  v-for="item in wareHouseOpt"
                  :key="item.warehouseNo"
                  :label="item.warehouseName"
                  :value="item.warehouseNo">
                </lui-option>
              </lui-select>
            </lui-form-item>
            <lui-form-item label="BAND" class="cust-item">
              <lui-select v-model="searchForm.bandNoList" multiple collapse-tags clearable filterable placeholder="请选择">
                <lui-option
                  v-for="item in bandOpt"
                  :key="item.bandNo"
                  :label="item.bandName"
                  :value="item.bandNo">
                </lui-option>
              </lui-select>
            </lui-form-item>
          </lui-form>
        </div>
        <div class="header-right">
          <lui-button
            v-waves
            type="primary"
            @click="query">查询</lui-button>
          <lui-button
            v-waves
            @click="handleRest">重置</lui-button>
        </div>
      </div>
    </div>
    <div class="custom-table">
      <div class="table-header">
        <div class="header-title">
          <div class="line left"></div>
          <span class="sp1">数据列表</span>
        </div>
        <div>
          <lui-button
            v-waves
            type="primary"
            @click="downloadClickAll">全量下载</lui-button>
          <lui-button
            v-waves
            type="primary"
            @click="downloadClick">批量下载</lui-button>
          <!-- <button-list
            ref="buttons"
            :buttons="buttons"
            :configdept-no=""
            :configdept-name=""
            :check-dept-no="checkDeptNo"
            @uploadSuccess="postListPage">
          </button-list> -->
        </div>
      </div>
      <lui-table
        v-loading="LoadingTable"
        :data="tableData"
        border
        row-class-name="custom-table_row"
        style="width: 100%"
        @selection-change="handleSelectionChange">
        <template slot="empty">
          <showEmptyImage></showEmptyImage>
        </template>
        <div>
          <lui-table-column
            type="selection"
            fixed="left"
            align="center"
            width="50">
          </lui-table-column>
          <lui-table-column
            prop="sellerName"
            label="商家名称"
            min-width=""
            show-overflow-tooltip
          >
          </lui-table-column>
          <lui-table-column
            prop="deptNo"
            label="事业部编码"
            min-width="100"
            show-overflow-tooltip
          >
          </lui-table-column>
          <lui-table-column
            prop="warehouseName"
            label="仓库名称"
            min-width="100"
            show-overflow-tooltip
          >
          </lui-table-column>
          <lui-table-column
            prop="bandName"
            label="BAND"
            min-width="90"
            show-overflow-tooltip
          >
          </lui-table-column>
          <lui-table-column
            prop="inWhQtty"
            label="入库件数"
            min-width="">
          </lui-table-column>
          <lui-table-column
            prop="onWhQtty"
            label="在库件数"
            min-width="100">
          </lui-table-column>
          <lui-table-column
            prop="outWhQtty"
            label="出库件数"
            min-width="">
          </lui-table-column>
        </div>
        <div v-if="dataequal">
          <lui-table-column
            prop="purchaseRouteQtty"
            label="采购在途件数"
            min-width="110">
          </lui-table-column>
          <lui-table-column
            prop="allotRouteQtty"
            label="调拨在途件数"
            min-width="110">
          </lui-table-column>
          <lui-table-column
            prop="turnoverDays"
            label="周转天数"
            min-width="">
          </lui-table-column>
          <lui-table-column
            prop="theSpotRatio"
            label="现货率"
            min-width="">
            <template slot-scope="scope">
              <div>{{ scope.row.theSpotRatio + '%' }}</div>
            </template>
          </lui-table-column>
          <lui-table-column
            prop="validRatio"
            label="动销比"
            min-width="">
            <template slot-scope="scope">
              <div>{{ scope.row.validRatio + '%' }}</div>
            </template>
          </lui-table-column>
          <lui-table-column
            prop="sixtyDaysUnsalableRatio"
            label="60日滞销占比"
            min-width="110">
            <template slot-scope="scope">
              <div>{{ scope.row.sixtyDaysUnsalableRatio + '%' }}</div>
            </template>
          </lui-table-column>
          <lui-table-column
            prop="ninetyDaysUnsalableRatio"
            label="90日滞销占比"
            min-width="110">
            <template slot-scope="scope">
              <div>{{ scope.row.ninetyDaysUnsalableRatio + '%' }}</div>
            </template>
          </lui-table-column>
          <lui-table-column
            prop="localOrderFillRatio"
            label="本地订单满足率"
            min-width="120">
            <template slot-scope="scope">
              <div>{{ scope.row.localOrderFillRatio + '%' }}</div>
            </template>
          </lui-table-column>
        </div>
      </lui-table>
      <div class="footer">
        <lui-pagination
          v-show="tableData.length>0"
          background
          :page-size="pageSize"
          :current-page="pageNum"
          :page-sizes="[10, 20, 50, 70, 100]"
          layout="total,prev, pager, next, sizes, jumper"
          :total="total"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange">
        </lui-pagination>
      </div>
    </div>
  </div>
</template>

<script>
import $ from 'jquery'
import Api from '@/api'
import Http from '@/lib/http'
import { exportExcel } from '@/utils/downloadRequest'
import showEmptyImage from '@/components/common/showEmptyImage/index.vue'
import utils from '@/utils/utils'
var now = new Date($.ajax({ async: false }).getResponseHeader('Date'))
var nowTimeNew = now.getTime()
export default {
  name: 'NodeRange',
  components: {
    // ButtonList,
    showEmptyImage
    // draggable
  },
  data() {
    return {
      dataequal: true,
      sellerOpt: [], //商家下拉
      deptOpt: [], //事业部下拉
      wareHouseOpt: [], //仓下拉
      bandOpt: [], //band下拉
      isEclp: false,
      buttonDisabled: false,
      LoadingTable: false,
      checkDeptNo: true, //默认false表示不上传事业部
      dialogVisible: false,
      dialogMask: false,
      isEdit: false,
      baseURL: Http.baseContextUrl,
      tableData: [],
      total: 0,
      pageSize: 10,
      pageNum: 1,
      id: '',
      step: 1,
      ruleForm: {
        dept: ''
      },
      rules: {
        dept: [
          { required: true, message: '请选择事业部', trigger: 'change' }
        ]
      },
      multipleSelection: [],
      searchForm: {
        timeValue: '',
        sellerNoList: '',
        deptNoList: '',
        bandNoList: '',
        wareHouseNoList: ''
      },
      nowTimeNew: '', //ajax获取时间
      pickerOptions: {
        disabledDate(time) {
          const lastYearDate = new Date(utils.getLastFormatYear(time)).getTime()
          return time.getTime() >= nowTimeNew - 8.64e7 || time.getTime() < lastYearDate
        }
      }
    }
  },
  created() {
    const startTime = new Date()
    const endTime = new Date()
    this.searchForm.timeValue = [
      utils.getLastFormatDate(startTime),
      utils.getLastFormatDate(endTime)
    ]
  },
  mounted() {
    this.postListPage()
    this.getSellerOpt() //获取商家
    this.getBandOpt() //获取band
  },
  methods: {
    dataAjax() { //获取当前时间
      const now = new Date($.ajax({ async: false }).getResponseHeader('Date'))
      this.nowTimeNew = now.getTime()
    },
    //获取商家列表
    getSellerOpt() {
      Api.Business.warehouseFindseller().then((res) => {
        if (res.success) {
          this.sellerOpt = res.data
        } else {
          this.$showErrorMsg(res.data.errMessage)
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
      })
    },
    //获取事业部列表
    getDeptOpt() {
      this.deptOpt = []
      this.wareHouseOpt = []
      this.searchForm.deptNoList = []
      this.searchForm.wareHouseNoList = []
      const params = this.searchForm.sellerNoList
      if (this.searchForm.sellerNoList.length > 0) {
        Api.Business.warehouseDeptSearch(params).then((res) => {
          if (res.success) {
            this.deptOpt = res.data
          } else {
            this.$showErrorMsg(res.errMessage)
          }
        }).catch((e) => {
          this.$showErrorMsg(e)
        })
      } else {
        this.searchForm.deptNoList = []
        this.searchForm.wareHouseNoList = []
      }
    },
    //获取仓列表
    getWarehouseOpt() {
      this.wareHouseOpt = []
      this.searchForm.wareHouseNoList = []
      const params = {
        sellerNoList: this.searchForm.sellerNoList,
        deptNoList: this.searchForm.deptNoList
      }
      if (this.searchForm.deptNoList.length > 0) {
        Api.Business.findWarehouse(params).then((res) => {
          if (res.success) {
            this.wareHouseOpt = res.data
          } else {
            this.$showErrorMsg(res.errMessage)
          }
        }).catch((e) => {
          this.$showErrorMsg(e)
        })
      } else {
        this.searchForm.wareHouseNoList = []
      }
    },
    //获取band列表
    getBandOpt() {
      Api.Business.warehouseFindBand().then((res) => {
        if (res.success) {
          this.bandOpt = res.data
        } else {
          this.$showErrorMsg(res.errMessage)
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
      })
    },
    getDateTime(date) {
      let startTime, endTime, thirtyDay
      if (date) {
        startTime = new Date(date[0]).getTime()
        endTime = new Date(date[1]).getTime()
        thirtyDay = 30 * 24 * 3600 * 1000
        if (endTime - startTime >= thirtyDay) {
          this.$showErrorMsg('查询时间的间隔必须在30天以内！')
          this.searchForm.timeValue = []
          return false
        }
        this.postListPage()
      }

    },
    query() {
      this.pageNum = 1
      this.postListPage()
    },
    handleRest() {
      this.searchForm.timeValue = [utils.getLastFormatDate(new Date()), utils.getLastFormatDate(new Date())]
      this.searchForm.sellerNoList = []
      this.searchForm.bandNoList = []
      this.searchForm.wareHouseNoList = []
      this.searchForm.deptNoList = []
      this.postListPage()
    },
    handleSelectionChange(val) {
      this.multipleSelection = val
    },
    //查询列表
    postListPage() {
      this.LoadingTable = true
      const params = {
        sellerNoList: this.searchForm.sellerNoList,
        deptNoList: this.searchForm.deptNoList,
        wareHouseNoList: this.searchForm.wareHouseNoList,
        bandNoList: this.searchForm.bandNoList,
        startDate: this.searchForm.timeValue ? this.searchForm.timeValue[0] : '',
        endDate: this.searchForm.timeValue ? this.searchForm.timeValue[1] : '',
        pageNum: this.pageNum,
        pageSize: this.pageSize
      }
      if (params.startDate === '' || params.endDate === '') {
        this.$showWarningMsg('请输入统计时间！')
        this.LoadingTable = false
        this.tableData = []
        return
      }
      if (this.searchForm.timeValue.length > 0) {
        if (this.searchForm.timeValue[0] === this.searchForm.timeValue[1]) {
          this.dataequal = true
        } else {
          this.dataequal = false
        }
      }
      Api.Business.findWarehouseMessage(params).then((res) => {
        if (res.success) {
          this.tableData = res.data
          this.total = res.total
          this.LoadingTable = false
        } else {
          this.$showErrorMsg(res.errMessage)
        }
      }).catch((e) => {
        this.LoadingTable = false
        this.$showErrorMsg(e)
      })
    },
    downloadClickAll() {
      const actionUrl = `${this.baseURL}business/warehouse/downloadAll`
      const params = {
        sellerNoList: this.searchForm.sellerNoList,
        deptNoList: this.searchForm.deptNoList,
        wareHouseNoList: this.searchForm.wareHouseNoList,
        bandNoList: this.searchForm.bandNoList,
        startDate: this.searchForm.timeValue[0],
        endDate: this.searchForm.timeValue[1],
        pageNum: this.pageNum,
        pageSize: this.pageSize
      }
      exportExcel(actionUrl, params)
    },

    downloadClick() {
      const actionUrl = `${this.baseURL}business/warehouse/download`
      if (!this.multipleSelection.length) {
        this.$showErrorMsg('请选择数据！')
        return
      }
      const params = {
        'bandNoList': this.searchForm.bandNoList,
        'deptNoList': this.searchForm.deptNoList,
        'pageNum': this.pageNum,
        'pageSize': this.pageSize,
        'sellerNoList': this.searchForm.sellerNoList,
        'startDate': this.searchForm.timeValue ? this.searchForm.timeValue[0] : '',
        'endDate': this.searchForm.timeValue ? this.searchForm.timeValue[1] : '',
        'wareHouseNoList': this.searchForm.wareHouseNoList,
        'wareHouseList': this.multipleSelection
      }
      exportExcel(actionUrl, params)
    },
    handleSizeChange(val) {
      this.pageSize = val
      this.postListPage()
    },
    handleCurrentChange(val) {
      this.pageNum = val
      this.postListPage()
    }
  }
}
</script>
<style lang="scss">
  .statisTime .lui-date-editor .lui-range__close-icon{
    z-index: -20!important;
  }
.table-p {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  cursor: pointer;
  padding-right: 10px;
}
.warehouse-data{
  .lui-date-editor .lui-range-separator {
    width: 10%;
  }
  .division .lui-select__tags-text {
      display: inline-block;
      max-width: 100px;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;

    }
     .division .lui-tag__close{
        position:absolute;
        top:9px;
    }
}

// .warehouse-data {
//   .custom-item {
//     &:hover{
//       cursor: pointer;
//       background: #FFFFFF;
//       box-shadow: 0 1px 6px 0 rgba(0,0,0,0.20);
//     }
//     .lui-date-editor .lui-range-separator {
//       width: 12%;
//     }
//     .lui-input-number .lui-input__inner {
//       -webkit-appearance: none;
//       padding-left: 0;
//       padding-right: 0;
//       text-align: left;
//     }
//     .lui-input-number__decrease,
//     .lui-input-number__increase {
//       width: 16px;
//     }
//   }
// }
</style>
<style lang="scss" scoped>
@import '@/assets/stylus/main';
.warehouse-data {
  min-height: 600px;
  .header-title {
    font-size: 16px;
    font-weight: 600;
    color: #333333;
    letter-spacing: 0;
    line-height: 16px;
    .line {
      margin: 2px 6px 0 0;
      width: 2px;
      height: 12px;
      background: $--gl-blue;
      border-radius: 2px;
    }
  }
  .header {
    background: #fff;
    padding: 30px 24px;
    box-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.1);
    border-radius: 0 4px 4px 4px;
    .search-box {
      margin-top: 20px;
      display: flex;
      justify-content: space-between;
      .header-left{
        width: calc(100% - 130px);
      }
      .cust-item{
        margin-right: 24px;
      }
      .label {
        font-size: 14px;
        height: 32px;
        line-height: 32px;
        margin-right: 12px;
      }
      .lui-select,
      .lui-input , .lui-cascader {
        width: 220px;
      }
    }
  }
  .custom-table {
    margin-top: 20px;
    background: #fff;
    padding: 0 24px;
    box-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.1);
    border-radius: 4px;
    .table-header {
      display: flex;
      justify-content: space-between;
      padding: 20px 0;
      .header-title {
        height: 32px;
        line-height: 32px;
        .line {
          margin: 10px 6px 0 0;
        }
        .sp2{
          margin-left:24px;
          font-size: 14px;
          color: #666666;
          font-weight: normal;
          i{margin-right: 8px;}
        }
      }
    }
  }
  .footer {
    padding: 20px 0 30px 0;
    text-align: right;
  }
}
</style>
