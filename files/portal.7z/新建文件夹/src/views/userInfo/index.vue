<template>
  <div v-loading="loading">
    <div class="user-info">
      <div class="search-box is-always-shadow">
        <div class="header-title">
          <div><i class="lui-icon-search"></i>筛选搜索</div>
          <div></div>
        </div>
        <lui-form ref="searchform" :model="searchform" label-width="80px" style="padding: 0;margin: 0;margin-bottom: 20px;">
          <lui-row style="width: 96%;margin: 15px auto">
            <lui-col :span="8" style="text-align: left">
              <div class="grid-content filterrow1">
                <div class="grid-content filterrow1">
                  <lui-form-item label="账号" style="width: 90%;margin-bottom: 0;">
                    <lui-input v-model="searchform.account" clearable style="width:100%" placeholder="请输入账号ID"></lui-input>
                  </lui-form-item>
                </div>
              </div>
            </lui-col>
            <lui-col :span="8">
              <div class="grid-content filterrow1">
                <div class="grid-content filterrow1">
                  <lui-form-item label="商家名称" style="width: 90%;margin-bottom: 0;">
                    <lui-input v-model="searchform.sellerName" clearable style="width:100%" placeholder="请输入商家名称"></lui-input>
                  </lui-form-item>
                </div>
              </div>
            </lui-col>
            <lui-col :span="8" style="text-align: right">
              <div class="grid-content filterrow1">
                <div class="grid-content filterrow1">
                  <lui-form-item label="渠道" style="width: 90%;margin-bottom: 0;">
                    <lui-select v-model="searchform.accountType" filterable clearable placeholder="请选择" style="width:100%">
                      <lui-option
                        v-for="item in accountTypeOptions"
                        :key="item.value"
                        :label="item.name"
                        :value="item.value">
                      </lui-option>
                    </lui-select>
                  </lui-form-item>
                </div>
              </div>
            </lui-col>
          </lui-row>
          <lui-row style="width: 96%;margin: 15px auto">
            <lui-col :span="8" style="text-align: left">
              <div class="grid-content filterrow1">
                <lui-form-item label="状态" style="width: 90%;margin-bottom: 0;">
                  <lui-select v-model="searchform.status" filterable clearable placeholder="请选择" style="width:100%">
                    <lui-option
                      v-for="item in statusOptions"
                      :key="item.value"
                      :label="item.name"
                      :value="item.value">
                    </lui-option>
                  </lui-select>
                </lui-form-item>
              </div>
            </lui-col>
            <lui-col :span="8" style="text-align: center">
              <div class="grid-content filterrow1">
                <lui-form-item label="管理维度" style="width: 90%;">
                  <lui-select
                    v-model="searchform.manageDimension"
                    filterable
                    clearable
                    placeholder="请选择签约区域"
                    style="width:100%">
                    <lui-option
                      v-for="item in dimensionList"
                      :key="item.val"
                      :label="item.label"
                      :value="item.val">
                    </lui-option>
                  </lui-select>
                </lui-form-item>
              </div>
            </lui-col>
            <!-- <lui-col :span="8" style="text-align: center">
              <div class="grid-content filterrow1">
                <lui-form-item label="签约区域" style="width: 90%;">
                  <lui-select
                    v-model="searchform.registerRegion"
                    filterable
                    clearable
                    placeholder="请选择签约区域"
                    style="width:100%">
                    <lui-option
                      v-for="item in regionList"
                      :key="item.code"
                      :label="item.desc"
                      :value="item.code">
                    </lui-option>
                  </lui-select>
                </lui-form-item>
              </div>
            </lui-col> -->
          </lui-row>

          <div class="btn-wrap">
            <lui-button class="filters-btn-group" style="width: 88px;" type="primary" @click="searchClick"><i class="fa fa-search"></i>查询</lui-button>
            <lui-button class="filters-btn-group" style="width: 88px;" @click="handleReset('searchform')"><i class="fa fa-refresh"></i>重置</lui-button>
          </div>
        </lui-form>
      </div>
      <div class="addManually">
        <div class="manually-title">
          <div class="title-left"> <i class="lui-icon-document-empty"></i><span>数据列表</span></div>
          <div class="title-right">
            <!-- 暂时禁用 -->
            <button-list
              ref="buttons"
              :buttons="buttons"
              @uploadSuccess="getList"
            >
            </button-list>
            <lui-button type="primary" @click="downloadClick">批量下载</lui-button>
            <lui-button type="primary" class="disabled-is" @click="deleteClick">手工删除</lui-button>
            <lui-button type="primary" @click="handleAddClick">手工添加</lui-button>
          </div>
        </div>
        <!--table列表-->
        <lui-table
          v-loading="listLoading"
          border
          :data="dataSource"
          class="slisttable table-list"
          style="width:96%; margin: 0 auto;"
          @selection-change="handleSelectionChange">
          <template slot="empty">
            <showEmptyImage></showEmptyImage>
          </template>
          <lui-table-column
            type="selection"
            width="50"
            fixed="left"
            align="center">
          </lui-table-column>
          <!-- <input type="hidden" prop="id" /> -->
          <lui-table-column
            prop="account"
            label="账号"
            min-width="170"
            show-overflow-tooltip>
          </lui-table-column>
          <lui-table-column
            prop="account"
            min-width="170"
            label="渠道">
            <template slot-scope="scope">
              <span v-if="scope.row.accountType == 1">运营登录</span>
              <span v-if="scope.row.accountType == 2">商家登录</span>
            </template>
          </lui-table-column>
          <lui-table-column
            prop="manageDimension"
            min-width="170"
            label="管理维度">
            <template v-slot="{row}">
              <span v-for="(item,index) in dimensionList" :key="index">
                <span v-if="row.manageDimension === item.val">{{ item.label }}</span>
              </span>
            </template>
          </lui-table-column>
          <lui-table-column
            label="商家"
            min-width="170">
            <template slot-scope="scope">
              <lui-popover
                placement="right"
                width="600"
                trigger="hover">
                <lui-table :data="scope.row.sellerList" size="mini">
                  <lui-table-column show-overflow-tooltip type="index" label="序号"></lui-table-column>
                  <lui-table-column show-overflow-tooltip property="sellerName" label="商家名称"></lui-table-column>
                  <lui-table-column show-overflow-tooltip property="sellerNo" label="商家编码"></lui-table-column>
                </lui-table>
                <div slot="reference" class="table-link">{{ sellerListFormat(scope.row.sellerList) }}</div>
              </lui-popover>
            </template>
          </lui-table-column>
          <!-- <lui-table-column
            prop="registerRegion"
            label="签约区域"
            min-width="170"
            show-overflow-tooltip>
            <template v-slot="{row}">
              <span v-for="(res,keys) in regionList" :key="keys">
                <span v-for="(item,index) in row.registerRegion" :key="index">
                  <span v-if="res.code === item">{{ res.desc }}<i v-if="index!== row.registerRegion.length-1">，</i></span> 
                </span>
              </span>
            </template>
          </lui-table-column> -->
          <lui-table-column
            prop="userServers"
            label="开通产品"
            min-width="170"
            show-overflow-tooltip>
          </lui-table-column>
          <lui-table-column
            prop="alwaysAllPermission"
            label="是否全数据"
            min-width="120"
            show-overflow-tooltip>
            <template v-slot="{row}">
              <span v-if="row.alwaysAllPermission===1">是</span>
              <span v-else>否</span>
            </template>
          </lui-table-column>
          <lui-table-column
            prop="status"
            label="状态"
            min-width="120"
            show-overflow-tooltip>
            <template slot-scope="scope">
              <lui-tag
                :type="scope.row.status===true?'success':(scope.row.status===false?'info':'')"
              >{{ scope.row.status===true?'正常':'禁用' }}</lui-tag>
            </template>
          </lui-table-column>
          <lui-table-column
            prop="status"
            label="状态修改"
            min-width="120">
            <template slot-scope="scope">
              <lui-switch
                v-model="scope.row.status"
                active-circle-class="1"
                active-color="rgba(60,110,240,.2)"
                inactive-color="rgba(142,145,152,.2)"
                @change="changeStatusTab(scope.row)">
              </lui-switch>
            </template>
          </lui-table-column>
          <lui-table-column
            prop="updateUser"
            label="修改人"
            min-width="170"
            show-overflow-tooltip>
          </lui-table-column>

          <lui-table-column
            prop="updateTime"
            label="修改时间"
            min-width="170"
            show-overflow-tooltip>
          </lui-table-column>
          <lui-table-column
            label="操作"
            width="320px"
            align="center"
            fixed="right">
            <template slot-scope="scope">
              <lui-button plain size="mini" @click="viewHandle(scope.$index, scope.row)">查看角色</lui-button>
              <lui-button plain size="mini" @click="editHandle(scope.$index, scope.row)">修改角色</lui-button>
              <div v-if="showfigureBtn" class="showmargin">
                <lui-button plain size="mini" @click="handelConfig(scope.$index, scope.row,true)">配置数据</lui-button>
                <lui-button plain size="mini" @click="handelConfig(scope.$index, scope.row,false)">查看数据</lui-button>  
              </div>
            </template>
          </lui-table-column>
        </lui-table>
        <!--分页-->
        <div v-show="dataSource != undefined && dataSource.length>0" class="block rotation-pagination">
          <lui-pagination
            background
            :current-page.sync="pageNum"
            :page-sizes="[10, 20, 50, 100]"
            layout="prev, pager, next, sizes, jumper, total"
            :total="total"
            @current-change="handleSizeChange"
            @size-change="sizeChange"
          >
          </lui-pagination>
        </div>
      </div>
    </div>
    <!-- 手工添加 -->
    <lui-dialog
      :title="title"
      class="userinfo-dialog"
      :close-on-click-modal="false"
      :visible.sync="dialogVisible"
      width="840px"
      @close="resetForm('ruleForm')">
      <lui-form ref="ruleForm" :model="user" :rules="rules" label-width="136px">
        <lui-form-item label="账号绑定：" prop="accountList">
          <lui-select
            v-model="user.accountList"
            multiple
            :disabled="isEdit"
            filterable
            clearable
            allow-create
            placeholder="请输入绑定账号名称，最多10条"
            style="width: 100%"
            :multiple-limit="10"
            default-first-option
            :popper-append-to-body="false"
            @input="e => user.account = formatLength (e)">
            <lui-option
              v-for="item in accountOptions"
              :key="item.value"
              :label="item.label"
              :value="item.value">
            </lui-option>
          </lui-select>
        </lui-form-item>
        <lui-form-item 
          label="渠道："
          prop="accountType">
          <lui-radio v-model="user.accountType" :disabled="isEdit" label="2" @change="handelRadio2(2)">商家登录</lui-radio>
          <lui-radio v-model="user.accountType" :disabled="isEdit" label="1" @change="handelRadio2(1)">运营登录</lui-radio>
        </lui-form-item>
        <!-- 新增条件 -->

        <lui-form-item 
          v-if="user.accountType === '1'"
          label="管理维度："
          prop="manageDimension">
          <lui-radio-group v-model="user.manageDimension" :disabled="isView">
            <!-- span 临时添加，判断是否需要销售字段 -->
            <span v-for="item in dimensionList" :key="item.val" style="padding-right: 25px;">
              <lui-radio 
                v-if="item.val!==4"
                :label="item.val"
                @change="handelRadio(item)">{{ item.label }}</lui-radio>
            </span>

            
          </lui-radio-group>
        </lui-form-item>
        <div v-if="user.manageDimension === 1">
          <lui-form-item 
            label="商家：" 
            prop="sellerInfos">
            <lui-select
              v-model="user.sellerInfos"
              multiple
              filterable
              style="width: 100%"
              value-key="sellerNo"
              placeholder="请选择商家"
              clearable
              :disabled="isView"
              @change="handleSelectSeller">
              <lui-option
                v-for="item in user.sellerOptions"
                :key="item.sellerNo"
                :label="item.sellerName"
                :value="item">
              </lui-option>
            </lui-select>
          </lui-form-item>
        </div>
        <!-- <div v-if="user.manageDimension === 2">
          <lui-form-item 
            label="签约区域："
            prop="registerRegion">
            <lui-select
              v-model="user.registerRegion"
              style="width: 100%"
              multiple
              filterable
              clearable
              placeholder="请选择签约区域">
              <lui-option
                v-for="(item,index) in regionList"
                :key="index"
                :label="item.desc"
                :value="item.code">
              </lui-option>
            </lui-select>
          </lui-form-item>
        </div> -->
        
        <!-- 新增条件结束 -->
        
      
        <lui-form-item v-if="!isEdit">
          <lui-button
            v-if="user.accountType === '2' && user.accountList.length === 1"
            style="float: right;"
            type="primary"
            @click="handleAccountList">
            自动关联
          </lui-button>
        </lui-form-item>
        <lui-form-item
          label="产品及菜单角色："
          prop="serveList">
          <lui-cascader
            v-if="isCascader"
            :key="isResouceShow"
            v-model="user.serveList"
            :options="serveListOptions"
            :props="props"
            clearable
            :disabled="isView"
            style="width: 100%"
            @change="treeChange"></lui-cascader>
        </lui-form-item>
      </lui-form>
      <span
        slot="footer"
        class="dialog-footer">
        <lui-button @click="resetForm('ruleForm')"> {{ isView ?'关 闭':'取 消' }}</lui-button>
        <lui-button
          v-if="!isView"
          :disabled="buttonDisabled"
          :loading="buttonDisabled"
          type="primary"
          @click="submitForm('ruleForm')">{{ buttonDisabled ? '提交中' : '确 定' }} </lui-button>
      </span>
    </lui-dialog>
    <!-- 配置数据弹框 -->
    <lui-dialog
      v-if="congfigDialogVisible"
      :title="titleConfigdata"
      :close-on-click-modal="false"
      :visible.sync="congfigDialogVisible"
      :width="width"
      class="configFormdialog"
      top="10vh"
      @close="handelConfigDataCancel">
      <lui-form
        ref="configForm"
        :model="configForm"
        :rules="configRules"
        label-width="110px">
        <lui-row>
          <lui-col :span="12">
            <lui-form-item
              label="账号："
              prop="account">
              <span>{{ configForm.account }}</span>
            </lui-form-item>
          </lui-col>
        </lui-row>
        <lui-row>
          <lui-col :span="12">
            <lui-form-item
              label="是否全数据："
              prop="alwaysAllPermission">
              <lui-radio-group v-model="configForm.alwaysAllPermission" :disabled="configShow" @change="radioChange">
                <lui-radio :label="1" class="button_radio">是</lui-radio>
                <lui-radio :label="0" class="button_radio">否</lui-radio>
              </lui-radio-group>
            </lui-form-item>
          </lui-col>
        </lui-row>
        <lui-row v-if="configForm.alwaysAllPermission === 0">
          <lui-col :span="24">
            <lui-form-item label="事业部：">
              <div v-show="!configShow" class="text">
                <lui-button type="text" @click="handelDeptAdd">配置</lui-button>
                <i class="lui-icon-info" style="margin-left: 15px;font-size: 12px;color: #999;">&nbsp;&nbsp;只能选择所属于账号关联商家的事业部</i>
              </div>
              <!-- 事业部表格 -->
              <lui-table
                v-loading="loadingDepTable"
                :data="configForm.deptList"
                border
                class="transfertable"
                size="mini"
                max-height="226px"
                style="width: 100%">
                <lui-table-column
                  type="index"
                  label="序号"
                  align="center"
                  width="50">
                </lui-table-column>
                <lui-table-column
                  prop="deptNo"
                  label="事业部编码"
                  min-width="150"
                  show-overflow-tooltip>
                </lui-table-column>
                <lui-table-column
                  prop="deptName"
                  label="事业部名称"
                  min-width="150"
                  show-overflow-tooltip>
                </lui-table-column>
                <lui-table-column
                  prop="sellerNo"
                  label="商家编码"
                  min-width="150"
                  show-overflow-tooltip>
                </lui-table-column>
                <lui-table-column
                  prop="sellerName"
                  label="商家名称"
                  min-width="150"
                  show-overflow-tooltip>
                </lui-table-column>
              </lui-table>
            </lui-form-item>
          </lui-col>
        </lui-row>

        <lui-row v-if="configForm.alwaysAllPermission === 0">
          <lui-col :span="24">
            <lui-form-item label="库节点：">
              <div v-show="!configShow" class="text">
                <lui-button type="text" @click="handelNodeAdd">配置</lui-button>
                <i class="lui-icon-info" style="margin-left: 15px;font-size: 12px;color: #999;">&nbsp;&nbsp;只能选择已选中的所属事业部的库节点</i>
              </div>
              <!-- 库节点表格 -->
              <lui-table
                v-loading="loadingNodeTable"
                :data="configForm.nodeList"
                border
                class="transfertable"
                max-height="226px"
                size="mini"
                style="width: 100%">
                <lui-table-column
                  type="index"
                  label="序号"
                  align="center"
                  width="50">
                </lui-table-column>
                <lui-table-column
                  prop="nodeTypeDesc"
                  label="库节点类型"
                  min-width="130"
                  show-overflow-tooltip>
                </lui-table-column>

                <lui-table-column
                  prop="nodeNo"
                  label="库节点编码"
                  min-width="130"
                  show-overflow-tooltip>
                </lui-table-column>

                <lui-table-column
                  prop="nodeName"
                  label="库节点名称"
                  min-width="130"
                  show-overflow-tooltip>
                </lui-table-column>

                <lui-table-column
                  prop="deptNo"
                  label="事业部编码"
                  min-width="130"
                  show-overflow-tooltip>
                </lui-table-column>

                <lui-table-column
                  prop="deptName"
                  label="事业部名称"
                  min-width="130"
                  show-overflow-tooltip>
                </lui-table-column>

                <lui-table-column
                  prop="sellerNo"
                  label="商家编码"
                  min-width="130"
                  show-overflow-tooltip>
                </lui-table-column>

                <lui-table-column
                  prop="sellerName"
                  label="商家名称"
                  min-width="130"
                  show-overflow-tooltip>
                </lui-table-column>
              </lui-table>
            </lui-form-item>
          </lui-col>
        </lui-row>
      </lui-form>
    </lui-dialog>
    <addTransferConfigData
      v-if="configureData.dialogVisible"
      :configure-data="configureData"
      @func="getConfigInfo">
    </addTransferConfigData>

  </div>
</template>
<script>
import Http from '@/lib/http'
import Api from '@/api'
import ButtonList from '@/views/common/ButtonList'
import addTransferConfigData from '@/views/userInfo/addTransferConfigData.vue'
import { exportExcel } from '@/utils/downloadRequest'
import showEmptyImage from '@/components/common/showEmptyImage/index.vue'
import { mapGetters } from 'vuex'
//文件上传集合 
const buttons = {
  upload: {
    noAsync: true,
    maxM: 10,
    uploadtips: '只能上传xlsx文件，文件大小不超过10M',
    uploadConfig: {
      uploadActionUrl: Http.baseContextUrl + Api.UserInfo.uploadActionUrl
    },
    templateUrl: Http.baseContextUrl + Api.UserInfo.downloadTemplate
  },
  fileName: 'userInfoFile'
}
export default {
  components: {
    showEmptyImage,
    ButtonList,
    addTransferConfigData
  },
  data() {
    var trimvalidator = (rule, value, callback) => {
      var myreg = /\s+/g
      if (value === '') {
        callback(new Error('请输入账号'))
      } else if (myreg.test(value)) {
        callback(new Error('输入的账号有空格'))
      } else {
        callback() //重点在这 如果在验证通过后不添加callback()函数在验证时是条件会为false
      }
      callback()
    }
    return {
      dimensionList: [
        { label: '商家', val: 1 },
        // { label: '签约区域', val: 2 },
        { label: '全部商家', val: 3 },
        { label: '销售', val: 4 }
      ],
      // regionList: [],
      //---------------配置数据开始--------------
      showfigureBtn: false,
      loadingDepTable: false, //加载事业部数据
      loadingNodeTable: false, //加载库节点数据
      titleConfigdata: '', //配置数据弹框
      configShow: false, //查看和编辑的标识
      congfigDialogVisible: false, //数据配置弹框标识
      configRules: {}, //数据配置form校验规则
      //数据配置form
      configForm: {
        'account': '',
        'alwaysAllPermission': '',
        'deptList': [],
        'nodeList': [
          {
            'deptName': '',
            'deptNo': '',
            'nodeName': '',
            'nodeNo': '',
            'nodeType': 0,
            'sellerName': '',
            'sellerNo': ''
          }
        ]
      }, 
      sellerNo: '', //编码
      accountId: ' ', //账号id
      //数据配置标识
      isViewConfig: false,
      configPageNum: 1, // 起始页
      configPageSize: 10, // 每页条数
      configTotal: 0, //总数
      nodePageNum: 1, // 起始页
      nodePageSize: 10, // 每页条数
      nodeTotal: 0, //总数
      //有关穿梭框里面的传送数据
      //穿梭框是否有
      showfigureTransfer: false,
      //穿梭框的数据configureData穿梭框的配置
      configureData: {
        id: '',
        dialogVisible: false, //穿梭弹框弹框的显示标识
        title: '选择库节点', //表头名称
        account: '', //账号 //传参
        sellerShow: false, //判断商家穿梭框是否显示
        alwaysAllPermission: 0, //某人是1不展示
        deptList: [], //事业部
        nodeList: [], //库节点
        sellerList: [] //获取商家下的所有事业部
      },
      //配置数据按钮
      buttonConfigDisabled: false,
      //--------------配置数据结束---------------
      id: '',
      showState: 0,
      baseURL: Http.baseContextUrl,
      //上传组件按钮
      buttons,
      isUploadModalShow: false, //上传模态窗
      //筛选搜索
      searchform: {
        sellerNo: '', //商家编码
        sellerName: '', //商家名称
        account: '', //账号
        menuRoleCode: '', //菜单角色
        serverCode: '', //开通服务
        status: '', //状态
        accountType: '',
        manageDimension: ''
        // registerRegion: '' //区域
      },
      //列表的多选
      multipleSelection: [],
      serversOptions: [], //开通模块下拉
      //状态下拉
      statusOptions: [
        {
          name: '正常',
          value: '1'
        },
        {
          name: '禁用',
          value: '0'
        }
      ],
      //渠道下拉
      accountTypeOptions: [
        {
          name: '商家登录',
          value: '2'
        },
        {
          name: '运营登录',
          value: '1'
        }
      ],
      //table列表
      tableData: [],
      //整体loading
      loading: false,
      //table的loading
      listLoading: true,
      options: {
        label: '全部',
        selection: true,
        index: false
      },
      //分页
      pageNum: 1, // 起始页
      pageSize: 10, // 每页条数
      currentPage: 1, // 起始页
      total: 0,
      dataSource: [],
      buttonDisabled: false,
      //整个form的对象
      user: {
        account: '',
        sellerNo: '',
        sellerName: '',
        accountList: [],
        userServerList: [],
        accountType: '2',
        sellerInfos: [],
        sellerOptions: [],
        serveList: [],
        manageDimension: 1
        // registerRegion: []
      },
      rules: {
        sellerNo: [
          { required: true, message: '商家编码不能为空', trigger: 'blur' }
        ],
        accountType: [
          { required: true, message: '渠道不能为空', trigger: 'blur' }
        ],
        accountList: [
          { validator: trimvalidator, trigger: 'change' },
          { required: true, message: '账号不能为空', trigger: 'change' }
        ],
        sellerInfos: [
          { required: true, message: '商家不能为空', trigger: 'change' }
        ],
        serveList: [
          { required: true, message: '产品及菜单角色不能为空', trigger: 'change' }
        ],
        // registerRegion: [
        //   { required: true, message: '签约区域不能为空', trigger: 'change' }
        // ],
        manageDimension: [
          { required: true, message: '请选择管理维度', trigger: 'change' }
        ]
      },

      props: { multiple: true },
      // 产品及菜单角色下拉
      serveListOptions: [],
      dialogVisible: false,
      //角色配置标识
      isEdit: false,
      isView: false,
      //产品及菜单角色标识
      isCascader: false,
      //服务标识
      serverCodeMap: {},
      //账号的下拉选项
      accountOptions: [],
      isResouceShow: 0,
      title: '',
      width: '80%'
    }
  },
  computed: {
    ...mapGetters(['getdepList', 'getnodeList'])
  },
  watch: {
    getdepList: {
      handler(oldVal, newVal) {
        this.configForm.deptList = this.getdepList
        // this.$forceUpdate()
        this.$set(this.configForm, 'deptList', this.getdepList)
        console.log(this.configForm.deptList, 555555555555555)
      }
    },
    getnodeList: {
      handler(oldVal, newVal) {
        this.configForm.nodeList = this.getnodeList
        // this.$forceUpdate()
        this.$set(this.configForm, 'nodeList', this.getnodeList)
        console.log(this.configForm.nodeList, 666666666666)
      }
    },
    deep: true
  },
  created() {},
  mounted() {
    // this.regionEnum()
    this.getList()
    this.getServerOptions()
    this.hasDataPermission()
  },
  methods: {
    // -----------------------------------新增区域------开始
    //区域列表
    // regionEnum() {
    //   Api.Merchants.regionEnum().then(res => {
    //     if (res.success) {
    //       if (Array.isArray(res.data) && res.data.length) {
    //         this.regionList = res.data
    //       }
    //     } else {
    //       this.$showErrorMsg(res.errMessage)
    //     }
    //   }).catch((e) => {
    //     console.error(e)
    //   })
    // },
    // -----------------------------------新增区域-----结束
    handelRadio2(val) {
     
      this.user.serveList = []
      this.user.sellerInfos = []
      this.user.manageDimension = 1
      this.serveListOptions = []
      this.$nextTick(() => {
        this.$refs.ruleForm.clearValidate('sellerInfos')
        this.$refs.ruleForm.clearValidate('serveList')
      })
      
    },
    //商家维度选择
    handelRadio(row) {
      if (this.isEdit) { //编辑
        if (row.val === 1) { //区域
          // this.user.sellerInfos = []
          this.getMenuRolesBySellerNoList()
        } else {
          this.serveListOptions = []
          this.getMenuRolesBySellerNoList()
        }
      } else {
        this.user.serveList = []
        this.serveListOptions = []
        if (row.val !== 1) { //区域
          this.user.sellerInfos = []
          this.getMenuRolesBySellerNoList()
        }
      }
      
      this.$refs.ruleForm.clearValidate('sellerInfos')
      this.$refs.ruleForm.clearValidate('serveList')
    },
    //-----------------------------配置数据开始
    //根据账户下拉商家 this.dropDownSellerByAccount()
    dropDownSellerByAccount() {
      let paramObj = {}
      let accountId = this.configureData.account
      paramObj.accountId = accountId
      //这里需要 **accountId
      Api.UserInfo.dropDownSellerByAccount(paramObj).then((res) => {
        // this.listLoading = false
        if (res.success) {
          this.configureData.sellerList = res.data
          console.log('下拉选项', this.configureData.sellerList)
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
      })
    },
    //切换是否全数据
    radioChange() {
      // this.width = '50%'
      let params = {}
      params.id = this.configureData.id
      params.alwaysAllPermission = this.configForm.alwaysAllPermission
      Api.UserInfo.toggleAlwaysAllPermission(params).then(res => {
      }).catch((e) => {
        this.$showErrorMsg(e)
      })
    },
    //是否有配置数据权限
    hasDataPermission() {
      this.showfigureBtn = true
      Api.UserInfo.hasDataPermission().then(res => {
        if (res.success) {
          this.showfigureBtn = res.data 
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
      })
    },
    //配置数据<--------->查看数据
    handelConfig(index, row, type) {
      console.log(row, '2222')
      this.configureData.id = row.id
      this.configureData.account = row.account
      this.congfigDialogVisible = true
      this.isViewConfig = false
      this.listLoading = true
      //获取数据权限详情是否全数据
      this.getPermissionByUser(row)
      //获取全量的事业部
      this.getDeptPermissionByAccount(row)
      //获取全量的库节点
      this.getUserNodePermissionByAccount(row)
      //获取商家下拉事业部的接口
      this.dropDownSellerByAccount()
      //第二个弹框的下拉列表第一次展示一下
      if (type) {
        this.titleConfigdata = '配置数据权限'
        this.configShow = false
      } else {
        this.configShow = true
        this.titleConfigdata = '查看数据权限'
      }
    },
    //获取数据
    getConfigInfo(row) {
      this.getPermissionByUser(row)
      this.getDeptPermissionByAccount(row)
      this.getUserNodePermissionByAccount(row) 
      console.log(row, '触发了', this.configForm.deptList) 
    },
    //关闭时刷新列表数据
    handelConfigDataCancel() {
      this.getList()
    },
    //获取数据权限详情是否全数据
    getPermissionByUser(row) {
      let params = {}
      params.id = this.configureData.id
      Api.UserInfo.getPermissionByUser(params).then(res => {
        if (res.success) {
         
          this.configureData.account = res.data.account
          this.configForm.account = res.data.account
          this.configForm.alwaysAllPermission = res.data.alwaysAllPermission
          // this.configForm.alwaysAllPermission = 0
          this.listLoading = false
          console.log(this.configureData, '详情1')
        }
      }).catch((e) => {
        this.listLoading = false
        this.$showErrorMsg(e)
      })
    },
    //一进来全部调取回显事业部数据(全量)
    getDeptPermissionByAccount(row) {
      let paramObj = {}
      paramObj.accountId = row.account
      this.loadingDepTable = true
      Api.UserInfo.getDeptPermissionByAccount(paramObj).then((res) => {
        if (res.success) {
          this.loadingDepTable = false
          this.configForm.deptList = res.data
          //存一份库节点传给库节点弹框
          this.configureData.deptList = res.data
          this.$store.dispatch('depList', res.data)
          console.log(res.data, '详情2')
       
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
      })
    },
    //一进来全部回显库节点数据（全量）
    getUserNodePermissionByAccount(row) {
      let params = {}
      params.accountId = row.account
      this.loadingNodeTable = true
      Api.UserInfo.getUserNodePermissionByAccount(params).then(res => {
        if (res.success) {
          this.loadingNodeTable = false
          this.configForm.nodeList = res.data
          this.$store.dispatch('nodeList', res.data)
          console.log(res.data, '详情3')
        }
      }).catch((e) => {
        // this.listLoading = false
        this.$showErrorMsg(e)
      })
    },
    //回显事业部数据(分页)
    pageListDeptPermissionByAccount(row) {
      let params = {}
      params.accountId = row.account
      params.pageNum = this.configPageNum
      params.pageSize = this.configPageSize
     
      Api.UserInfo.pageListDeptPermissionByAccount(params).then(res => {
        if (res.success) {
          // console.log(res.data, 33)
          this.configForm.deptList = res.data
          this.configTotal = res.total

        }
      }).catch((e) => {
        this.listLoading = false
        this.$showErrorMsg(e)
      })

    },
    //回显库节点数据（分页）
    pageListUserNodePermissionByAccount(row) {
      let params = {}
      params.accountId = row.account
      params.nodePageNum = this.nodePageNum
      params.nodePageSize = this.nodePageSize
      Api.UserInfo.pageListUserNodePermissionByAccount(params).then(res => {
        if (res.success) {
          console.log(res.data, 33)
          this.configForm.nodeList = res.data
          this.nodeTotal = res.total
          //穿梭框隐藏
          this.configureData.dialogVisible = false
          //这里需要有另外一个弹框的visible 和loading选择

        }
      }).catch((e) => {
        // this.listLoading = false
        this.$showErrorMsg(e)
      })

    },
    // 添加事业部,展示穿梭框
    handelDeptAdd() {
      this.configureData.title = '选择事业部'
      this.configureData.sellerShow = true //判断商家是否显示
      this.configureData.alwaysAllPermission = 0
      this.showfigureTransfer = true
      this.configureData.dialogVisible = true
    },
    //添加库节点
    handelNodeAdd() {
      this.configureData.title = '选择库节点'
      this.configureData.sellerShow = false
      this.configureData.alwaysAllPermission = 0
      this.showfigureTransfer = true
      this.configureData.dialogVisible = true
     
    },
    //提交事业部数据筛选完以后
    submitDeptPermission() {
      let params = {
        id: this.id,
        userDataPermission: this.configForm
      }
      Api.UserInfo.submitDeptPermission(params).then(res => {
        if (res.success) {
          this.showfigureTransfer = false
          //回调事业部列表 这里有重复，可以考虑优化
          this.getDeptPermissionByAccount()
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
      })
    },
    //提交库节点数据
    submitUserNodePermission() {
      let params = {
        id: this.id,
        userDataPermission: this.configForm
      }
      Api.UserInfo.submitUserNodePermission(params).then(res => {
        if (res.success) {
          this.showfigureTransfer = false
          //回显库节点table
          this.getUserNodePermissionByAccount()
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
      })
    },
    //提交所有配置数据表单
    handleCongfigSubmit() {
      console.log(this.configureData.id)
      let params = {
        id: this.configureData.id,
        userDataPermission: this.configForm
      }
      console.log(params)
      Api.UserInfo.submitUserPermission(params).then(res => {
        if (res.success) {
          this.congfigDialogVisible = false
          //回调事业部列表 这里有重复，可以考虑优化
          this.$message({
            message: '提交成功！',
            type: 'success',
            duration: 1000
          })
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
      })
    },
    //-----------------------------配置数据结束
    formatLength(value) {
      if (value.length) {
        value.forEach((item, index) => {
          if (item.length > 20) {
            this.user.accountList.splice(index, 1)
            this.$showErrorMsg('账号长度不能超过20位')
            // this.user.accountList[index] = item.substring(0, 15)
          }
        })
      }
    },
    //商家列表
    sellerListFormat(sellerList) {
      const sellers = []
      sellerList.forEach(item => {
        sellers.push(item.sellerName)
      })
      const tmp = sellers.join(',')
      return tmp
    },
    //添加
    handleAddClick() {
      this.id = ''
      this.isEdit = false
      this.isView = false
      this.title = '添加角色'
      this.user.sellerNo = ''
      this.user.accountList = [] //账号
      this.user.accountType = '2' //渠道类型
      this.user.sellerInfos = [] //商家
      this.user.sellerOptions = [] //商家下拉
      this.user.serveList = [] //产品及角色
      // this.user.registerRegion = [] //区域
      this.serveListOptions = [] //产品及角色下拉
      this.getSellerList()//查询所有商家
      this.isCascader = true
      this.dialogVisible = true
      this.$nextTick(() => {
        this.$refs['ruleForm'].clearValidate()
      })
      // this.showState = 1
    },
    //编辑角色
    editHandle(index, row) {
      this.id = row.id
      this.isEdit = true
      this.isView = false
      this.title = '修改角色'
      this.user.sellerNo = row.sellerNo
      this.user.accountList = [row.account] //账号
      this.user.accountType = row.accountType + '' //渠道类型
      this.user.sellerInfos = row.sellerList //商家
      // this.user.registerRegion = row.registerRegion //区域
      this.user.manageDimension = row.manageDimension //维度
      console.log(this.user, '-----')
      ++this.isResouceShow
      this.accountGetById()//查询产品菜单及角色
      this.getSellerList()//查询所有商家下拉
      this.isCascader = true
      this.dialogVisible = true
      this.$nextTick(() => {
        this.$refs['ruleForm'].clearValidate()
        this.getMenuRolesBySellerNoList()
      })
      // this.showState = 2
    },
    //查看角色
    viewHandle(index, row) {
      console.log(row, '----=======///')
      this.id = row.id
      this.isEdit = true
      this.isView = true
      this.title = '查看角色'
      this.user.sellerNo = row.sellerNo
      this.user.accountList = [row.account] //账号
      this.user.accountType = row.accountType + '' //渠道类型
      this.user.sellerInfos = row.sellerList //商家
      // this.user.registerRegion = row.registerRegion//区域
      this.user.manageDimension = row.manageDimension //维度
      ++this.isResouceShow
      
      console.log(this.user, '-----')
      this.accountGetById()//查询产品菜单及角色
      this.getSellerList()//查询所有商家下拉
      this.isCascader = true
      this.dialogVisible = true
      this.$nextTick(() => {
        this.$refs['ruleForm'].clearValidate()
        this.getMenuRolesBySellerNoList()
      })
      // this.showState = 3
    },
    //重置表单
    resetForm(formName) {
      this.isCascader = false
      this.dialogVisible = false
      this.$refs[formName].resetFields()
    },
    //表单检验
    submitForm(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          this.buttonDisabled = true
          if (this.isEdit) {
            this.editUserInfo()
          } else {
            this.addUserInfo()
          }
        } else {
          return false
        }
      })
    },
    //添加
    addUserInfo() {
      const params = {
        'accountList': this.user.accountList,
        'accountType': this.user.accountType,
        'sellerInfos': this.user.sellerInfos,
        'userServerList': this.user.userServerList,
        // 'registerRegion': this.user.registerRegion.toString(),
        'manageDimension': this.user.manageDimension
      }
      Api.UserInfo.getUserAdd(params).then(res => {
        if (res.success) {
          this.$message({
            message: '添加成功',
            type: 'success',
            duration: 1000
          })
          this.dialogVisible = false
          this.buttonDisabled = false
          this.getList()
        } else {
          this.buttonDisabled = false
          this.$showErrorMsg(res.errMessage)
        }
      }).catch((err) => {
        this.$showErrorMsg(err)
        this.buttonDisabled = false
      })
    },
    //编辑
    editUserInfo() {
      const params = {
        'id': this.id,
        'accountList': this.user.accountList,
        'accountType': this.user.accountType,
        'sellerInfos': this.user.sellerInfos,
        // 'registerRegion': this.user.registerRegion.toString(),
        'userServerList': this.user.userServerList,
        'manageDimension': this.user.manageDimension
      }
      console.log(params, 'paramsparams')
      Api.UserInfo.editUserInfo(params).then(res => {
        if (res.success) {
          this.$message({
            message: '编辑成功',
            type: 'success',
            duration: 1000
          })
          this.dialogVisible = false
          this.buttonDisabled = false
          this.getList()
        } else {
          this.buttonDisabled = false
          this.$showErrorMsg(res.errMessage)
        }
      }).catch((err) => {
        this.$showErrorMsg(err)
        this.buttonDisabled = false
      })
    },
    //根据id查询商户信息
    accountGetById() {
      Api.UserInfo.accountGetById({ id: this.id }).then(res => {
        var serveListArr = []
        // 将后端的数据格式转化成前端所需要的菜单格式
        res.data.userServerList.forEach((serve, i) => {
          serve.menuRoleCodeList.forEach((menuRoleCode, j) => {
            const obj = []
            obj[0] = serve.serverCode
            obj[1] = menuRoleCode
            serveListArr.push(obj)
          })
        })
        this.user.serveList = serveListArr //回显
        this.user.userServerList = res.data.userServerList //传给后台
      }).catch(err => {
        this.$showErrorMsg(err)
      })
    },
    //查询是否eclp商家
    handleAccountList() {
      if (this.user.accountList.length === 1) {
        this.getEclpSellerByAccount()
      } else {
        this.$showErrorMsg('多个账号无法自动关联！')
      }
    },
    //根据商家查询产品及菜单角色
    handleSelectSeller(val) {
      ++this.isResouceShow
      this.user.serveList = []
      this.serveListOptions = []
      this.getMenuRolesBySellerNoList()
    },
    //根据多个商家获取产品并集
    getMenuRolesBySellerNoList() {
      this.serveListOptions = []
      if (this.user.manageDimension === 1) {
        if (!this.user.sellerInfos || !this.user.sellerInfos.length) {
          return
        }
      }
      
      Api.UserInfo.getMenuRolesBySellerNoList({
        'accountType': this.user.accountType,
        'sellerNoList': this.user.sellerInfos,
        'manageDimension': this.user.manageDimension
      }).then((res) => {
        if (res.success) {
          if (res.data.length) {
            this.serveListOptions = res.data
            res.data.forEach(item => {
              this.serverCodeMap[item.serverCode] = item.serverName
              item.label = item.label + '(' + item.value + ')'
              item.children.forEach(el => {
                el.label = el.label + '(' + el.value + ')'
              })
            })
          } else {
            this.serveListOptions = []
          }
        }
      }).catch((error) => {})
    },
    //根据账号关联eclp商家
    getEclpSellerByAccount() {
      Api.UserInfo.getEclpSellerByAccount({ 'account': this.user.accountList[0] }).then((res) => {
        if (res.success) {
          const sellerInfos = res.data
          // const sellerInfos = { sellerName: '测试ECLP商家', sellerNo: 'test', deptList: null }
          if (this.user.sellerInfos.length) {
            var seller = this.user.sellerInfos.find(function(value, index, arr) {
              return value.sellerNo === sellerInfos.sellerNo
            })
            console.log(seller, '****')
            if (seller === undefined) {
              console.log('pushv')
              this.user.sellerInfos.push(sellerInfos)
            }
            console.log(this.user.sellerInfos, '!!!')
          } else {
            this.user.sellerInfos = [res.data]
          }
          this.getMenuRolesBySellerNoList()
        }
      }).catch((error) => {
        this.$showErrorMsg(error)
      })
    },
    //查询商家列表
    getSellerList() {
      Api.UserInfo.getSellerList().then((res) => {
        if (res.success) {
          this.user.sellerOptions = res.data
        }
      }).catch((error) => {})
    },
    treeChange(val) {
      //先自己v-model一个数组，最后将他赋给this.user.userServerList,这里需要把一个数组改成后端想要的格式，
      //将this.serveList的格式转化成后台想要的格式
      var map = {}
      var userServerList = []
      this.user.serveList.forEach((item) => {
        if (!map[item[0]]) {
          userServerList.push({
            serverCode: item[0],
            serverName: this.serverCodeMap[item[0]],
            menuRoleCodeList: [item[1]]
          })
          map[item[0]] = item
        } else {
          userServerList.forEach(userServer => {
            if (userServer.serverCode === item[0]) {
              userServer.menuRoleCodeList.push(item[1])
            }
          })
        }
      })
      this.user.userServerList = userServerList
    },
    changeState(val) {
      this.showState = val
      this.getList()
    },
    //获取所有开通服务下拉
    getServerOptions() {
      Api.SellerInfo.getAllSysServer().then((res) => {
        if (res.success) {
          this.serversOptions = res.data
        }
        this.listLoading = false
      }).catch((error) => {
        this.listLoading = false
      })
    },
    //重置
    handleReset() {
      this.searchform = {
        account: '', //账号
        sellerNo: '', //商家编码
        sellerName: '', //商家名称
        serverCode: '', //开通模块
        status: '', //状态
        accountType: '', //渠道，
        manageDimension: ''
        // registerRegion: ''//区域
      }
      this.getList()
    },
    //查询列表
    getList() {
      this.listLoading = true
      const paramObj = {
        sellerName: this.searchform.sellerName,
        sellerNo: this.searchform.sellerNo,
        account: this.searchform.account,
        menuRoleCode: this.searchform.menuRoleCode,
        serverCode: this.searchform.serverCode,
        status: this.searchform.status,
        accountType: this.searchform.accountType,
        manageDimension: this.searchform.manageDimension
        // registerRegion: this.searchform.registerRegion
      }
      paramObj.pageNum = this.pageNum
      paramObj.pageSize = this.pageSize
      Api.UserInfo.getAccountPageList(paramObj).then((res) => {
        this.listLoading = false
        if (res.data) {
          for (let i = 0; i < res.data.length; i++) {
            // res.data[i].registerRegion = res.data[i].registerRegion ? res.data[i].registerRegion.split(',') : [] //区域
            if (res.data[i].status === 1) {
              res.data[i].status = true
            } else {
              res.data[i].status = false
            }
          }
          this.dataSource = res.data
          this.total = res.total
        }
      }).catch((error) => {
        this.$showErrorMsg(error)
        this.listLoading = false
        this.dataSource = []
        this.pageNum = 1
        this.total = 0
      })
    },
    searchClick(val) {
      this.getList()
    },
    //修改这里的状态
    changeStatusTab(row) {
      if (row.status) {
        this.$confirm('是否开启该账号的所有权限？', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          Api.UserInfo.updateAccountStatus({ id: row.id, status: 1 }).then((res) => {
            this.$message({
              type: 'success',
              message: '修改成功!'
            })
          }).catch((e) => {
            this.$showErrorMsg(e)
            row.status = false
          })
        }).catch((e) => {
          row.status = false
        })
      } else {
        this.$confirm('是否禁用该账号的所有权限？', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          Api.UserInfo.updateAccountStatus({ id: row.id, status: 0 }).then((res) => {
            this.$message({
              type: 'success',
              message: '修改成功!'
            })
          }).catch((e) => {
            this.$showErrorMsg(e)
            row.status = true
          })
        }).catch((e) => {
          row.status = true
        })
      }
    },
    //清除表格内容
    toggleRowSelection(that) {
      return that.clearSelection()
    },
    //翻页-----根据页码变换
    handleSizeChange(val) {
      this.pageNum = val
      this.getList()
    },
    //分页条数改变
    sizeChange(val) {
      this.pageSize = val
      this.getList()
    },
    // 获取选中的id
    getSelectionId() {
      const selectIds = []
      this.multipleSelection.map((item) => {
        selectIds.push(item.id)
      })
      return selectIds
    },
    //多选方法
    handleSelectionChange(val) {
      this.multipleSelection = val
    },
    //批量上传
    uploadClickWarn() {
      // this.isUploadModalShow = true
      this.$message({
        type: 'warning',
        message: '批量上传功能暂不支持！'
      })
    },
    uploadClick() {
      //已开发、暂时禁用
      this.isUploadModalShow = true
    },
    //批量下载 downloadUserInfo
    downloadClick() {
      const options = Object.assign({}, this.searchform)
      const ids = this.getSelectionId()
      if (ids.length > 0) {
        options.ids = ids
      }
      const actionUrl = this.baseURL + Api.UserInfo.downloadUserInfoUrl
      exportExcel(actionUrl, options)
    },
    //批量删除的方法
    deleteClick() {
      const param = {}
      param.idList = this.getSelectionId()
      if (param.idList.length < 1) {
        this.$message({
          message: '未选择要删除的内容',
          type: 'warning',
          duration: 1000
        })
        return
      }
      this.$confirm('确定要删除选中的账号吗？', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        this.loading = true
        Api.UserInfo.deleteUserInfo(param).then(response => {
          this.$message({
            message: '删除成功',
            type: 'success',
            duration: 1000
          })
          this.loading = false
          this.getList()
        }).catch(err => {
          this.loading = false
          this.$showErrorMsg(err)
        })
      }).catch(err => {
        this.loading = false
        console.log(err)
      })
    },
    //重置数据表单
    resetFormConfig(formName) {
      this.congfigDialogVisible = false
      this.$refs[formName].resetFields()
    }
  }
}
</script>
<style lang="scss">
  .lui-popover{
    max-height: 500px;
    overflow-y: auto;
  }
 .userinfo-dialog {
   .lui-select-dropdown{
      border: 0;
      .lui-select-dropdown__empty{
        display: none!important;
      }
   }
  .lui-cascader__tags .lui-tag .lui-icon-error {
    display: none;
  }
 }
</style>
<style lang="scss" scoped >
@import "@/assets/stylus/main.scss";
.user-info{
  .header-title{
    width: 96%;
    margin: 0 auto;
    margin-top: 20px;
    height: 40px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    div{
      font-size: 18px;
      color: #666;
      i{
        margin-right: 10px;
      }
    }
  }
  /*手工添加部分*/
  .addManually{
    padding-top: 10px;
    padding-bottom: 30px;
    width: 100%;
    background: #fff;
    box-shadow:0 0 5px 5px #eee;
    .manually-title{  //头部
      width: 96%;
      margin: 0 auto;
      height: 70px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      .title-left{
        i{
          font-size: 16px;
          margin-right: 10px;
        }
        span{
          font-size: 14px;
          color: #666
        }
      }
    }
    .table-button{ //表格内部按钮
      display: flex;
      justify-content: space-around;
      span{
        color: $--gl-blue;
        cursor: pointer;
      }
    }

    .rotation-pagination{ //分页
      width: 100%;
      margin-top: 50px;
      text-align: center;
      /deep/ .lui-pagination__total{
        margin-left: 20px;
      }
    }
  }

  .is-always-shadow{
    box-shadow: 0 2px 12px 0 rgba(0,0,0,.1);
  }
  .search-box{
    border: 1px solid #EAEAEA;
    background: #FFFFFF;
    margin-bottom: 20px;
  }
  .lui-breadcrumb{
    border-bottom: 1px solid rgb(230, 230, 230);
    padding: 5px 0 10px;
    margin-bottom: 10px;
  }
  /deep/ .lui-form-item{
    display: inline-block;
    margin-bottom: 15px;
  }
  /deep/ .btn-wrap {
    width: 96%;
    padding: 0;
    margin: 0 auto;
    text-align: right;
    .lui-form-item .lui-form-item__content {
      margin-left: 10px !important;
    }
    i {
      padding: 0 2px;
    }
  }
  .filters-btn-group{
    display: inline-block;
  }
  .search-box{
    text-align: center;
  }
  .table-list{
    /*background: #f00;*/
    box-shadow: 0px 1px 8px #EBEEF5;
  }
  /deep/ .lui-button--mini{
    padding:5px 8px
  }
  .uploadRelative{
    position: relative;
    display:inline-block;
    margin-right: 10px;
  }
  // /deep/ .is-disabled{
  //   color: rgba(255, 255, 255, 0.55) !important;
  //   background-color: rgba(13, 108, 162, 0.54) !important;
  //   border-color: rgba(13, 108, 162, 0.54) !important;
  // }
  // /deep/ .lui-tag.lui-tag--success{
  //   color:#0D6CA2;
  //   border-color:rgba(60, 110, 240, 0.2);
  //   background-color: rgba(60, 110, 240, 0.2);
  // }

  // /*去除多选框颜色*/
  // /deep/ .lui-table th>.cell>.is-disabled {
  //   color: rgba(255, 255, 255, 0.55) !important;
  //   background-color:  #F1F4F9 !important;
  //   border-color: #F1F4F9 !important;
  // }
  // /deep/ .lui-table th>.cell>.is-disabled>.is-disabled {
  //   color: #F1F4F9 !important;
  //   background-color: #F1F4F9 !important;
  //   border-color: #F1F4F9 !important;
  // }
  /*去除多选框颜色*/

  .table-link{ //表格溢出隐藏
    overflow: hidden;
    text-overflow:ellipsis;
    white-space: nowrap;
    cursor: pointer;
  }
}
</style>

<style lang="scss" scoped>
.showmargin{
  display: inline-block;
  padding-left:8px;
}
.configFormdialog .lui-dialog__body{
  padding:20px
}
  /deep/ .lui-table.transfertable thead th{
  background: #D9F0FE!important;
}
/deep/ .lui-table{
   overflow: inherit!important;
}
.lui-table--border{
  border-bottom:1px solid #EAEAEA;
}
</style>



