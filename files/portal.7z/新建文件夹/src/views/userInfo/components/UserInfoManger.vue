<template>
  <div style="position: relative">
    <lui-card v-loading="loading" class="form-container" shadow="never">
      <lui-form ref="userFrom" :model="user" :rules="rules" label-width="150px">
        <!--<lui-form-item label="账号类型：" prop="createType">
          <lui-radio-group v-model="user.createType" :disabled="!source || isEdit" @change="initUser">
            <lui-radio :label="1">系统账号</lui-radio>
            <lui-radio :label="2">商家账号</lui-radio>
          </lui-radio-group>
        </lui-form-item>-->
        <lui-row>
          <lui-col :span="16">
            <lui-form-item label="商家编码：" prop="sellerNo">
              <lui-input
                v-model="user.sellerNo"
                placeholder="请输入商家编码"
                :disabled="!isEdit || source"
                maxlength="30"
                @input="e => user.sellerNo = numberStringForbid (e)">
              </lui-input>
            </lui-form-item>
          </lui-col>
          <lui-col :span="8">
            <div align="right">
              <lui-button v-waves :disabled="!isEdit || source" @click="resetSellerInfo">重置</lui-button>
              <lui-button v-waves type="primary" :disabled="!isEdit || source " @click="getSellerInfo">查询商家
              </lui-button>
            </div>
          </lui-col>
        </lui-row>
        <lui-form-item label="商家名称：" prop="sellerName">
          <lui-input
            v-model="user.sellerName"
            placeholder="系统自动"
            :disabled="true"
            maxlength="50"
            @input="e => user.sellerName = specialForbid (e)">
          </lui-input>
        </lui-form-item>
        <!--<lui-form-item
          key="userType"
          label="登录账号类型："
          prop="userType">
          <lui-radio-group v-model="user.userType">
            <lui-radio :label="1" name="userType" disabled>ECLP商家账号</lui-radio>
          </lui-radio-group>
        </lui-form-item>-->
        <lui-form-item
          v-if="!isEdit"
          key="accountList"
          label="账号绑定："
          prop="accountList">
          <lui-select
            v-model="user.accountList"
            multiple
            filterable
            allow-create
            default-first-option
            style="width: 458px"
            placeholder="请输入绑定账号名称，最多10条"
            :multiple-limit="10">
            <lui-option
              v-for="item in accountOptions"
              :key="item.value"
              :label="item.label"
              :value="item.value">
            </lui-option>
          </lui-select>
        </lui-form-item>
        <lui-form-item
          v-if="isEdit"
          key="account"
          label="账号绑定："
          prop="account"
        >
          <lui-input
            v-model="user.account"
            :disabled="isEdit"
            maxlength="30"
            @input="e => user.account = specialForbid (e)">
          </lui-input>
        </lui-form-item>
        <lui-form-item
          key="userServerList"
          label="产品及角色："
          prop="account">
          <lui-cascader
            v-model="serveList"
            :options="options"
            :props="props"
            clearable
            style="width: 458px"
            @change="treeChange"></lui-cascader>
        </lui-form-item>
        <lui-form-item align="right">
          <lui-button v-if="!isEdit" v-waves @click="onBack">取消</lui-button>
          <lui-button v-if="!isEdit" v-waves type="primary" @click="onSubmit('userFrom')">提交</lui-button>
        </lui-form-item>
      </lui-form>
    </lui-card>
  </div>
</template>
<script>
import Api from '@/api'
// import { getSellerInfoBySeller } from '@/api/sellerInfo'
// import { getRole, addUserInfo, getUserById } from '@/api/userInfo'

const defaultuser = {
  sellerNo: '',
  sellerName: '',
  accountList: [],
  userServerList: []
}
export default {
  name: 'UserInfoDetail',
  props: {
    // isEdit 为true是可编辑页，为false是增加页
    isEdit: {
      type: Boolean,
      default: false
    },
    //通过source来判断 是商家的添加用户页还是账号配置的手工添加 true是商家的添加用户页
    source: {
      type: Boolean,
      default: true
    }
  },
  data() {
    return {
      user: Object.assign({}, defaultuser),
      loading: false,
      resetSeller: false,
      newAdd: false,
      props: { multiple: true },
      tree: [],
      serveList: [
        {
          menuRoleCodeList: [],
          serverCode: '',
          serverName: ''
        }
      ],
      //options指的是所有选择项
      options: [
        /* {
          value: 1,
          label: '商品布局',
          children: [{
            value: '1-1',
            label: '首页'
          }, {
            value: '1-2',
            label: '配置页'
          }, {
            value: '1-3',
            label: '管理员'
          }]
        }, {
          value: 2,
          label: '库存仿真',
          children: [{
            value: '2-1',
            label: '首页'
          }, {
            value: '2-2',
            label: '产品页2'
          }, {
            value: '2-3',
            label: '仿真页'
          }]
        },
        {
          value: 3,
          label: '销量预测',
          children: [{
            value: '3-1',
            label: '首页'
          }, {
            value: '3-2',
            label: '产品页3'
          }, {
            value: '3-3',
            label: '销量预测'
          }]
        },
        {
          value: 4,
          label: '补货调拨',
          children: [{
            value: '4-1',
            label: '首页'
          }, {
            value: '4-2',
            label: '产品页4'
          }, {
            value: '4-3',
            label: '补货调拨'
          }
          ]
        }*/
      ],
      rules: {
        /*createType: [
          { required: true, message: '创建类型不能为空', trigger: 'blur' }
        ]*/

      },
      roleOptions: [],
      serverCodeMap: {},
      accountOptions: [] //账号的下拉选项
    }
  },
  created() {
    if (this.isEdit) {
      Api.getUserSellerNo({ sellerNo: '' }).then(response => {
      //  this.roleOptions = response.data
        /* Api.getUserById({ 'id': this.$route.query.id }).then(response => {
          this.user = response.data
        })*/
      }).catch(error => {
        this.$message({
          message: '获取角色失败。',
          type: 'warning',
          duration: 1000
        })
      })

    } else {
    //  this.getRole()
      this.user = Object.assign({}, defaultuser)
      if (this.source) {
        //用户页面添加

      }
    }
  },
  mounted() {
    this.getSellerInfo()
    this.loadserveList()
    this.getRole()
  },
  methods: {
    //change完以后给后台传这个值
    treeChange(val) {
      //先自己v-model一个数组，最后将他赋给this.user.userServerList,这里需要把一个数组改成后端想要的格式，
      // 赋给this.user.userServerList
      //将this.serveList的格式转化成后台想要的格式
      var map = {}
      var userServerList = []
      this.serveList.forEach((item) => {
        if (!map[item[0]]) {
          userServerList.push({
            serverCode: item[0],
            serverName: this.serverCodeMap[item[0]],
            menuRoleCodeList: [item[1]]
          })
          map[item[0]] = item
        } else {
          userServerList.forEach(userServer => {
            if (userServer.serverCode === item[0]) {
              userServer.menuRoleCodeList.push(item[1])
            }
          })
        }
      })
      this.user.userServerList = userServerList
    },
    // 如果是添加的方法，其实可以先不执行
    loadserveList() {
      // let data=[]
      //Cascader 本身的树形结构
      // 从后台获取数据后，将后台数据转化成aaa这种数据，然后返给this.serveList

      const aaa = [
        [3, '3-1'],
        [3, '3-2'],
        [3, '3-3'],
        [2, '2-3'],
        [2, '1-3']
      ]

      var user = {
        accountList: ['aaa', 'bbb', 'ccc'],
        createType: '',
        sellerName: '',
        sellerNo: '',
        userServerList: [
          {
            menuRoleCodeList: [1, 2, 3],
            serverCode: '2'
          },
          {
            menuRoleCodeList: [7, 8, 9],
            serverCode: '3'

          }
        ]
      }
      user.userServerList.forEach((serve, i) => {
        serve.menuRoleCodeList.forEach((menuRoleCode, j) => {
          const obj = []
          // [3, '3-1'],
          obj[0] = serve.serverCode
          obj[1] = menuRoleCode
          aaa.push(obj)
        })
      })
      this.serveList = aaa
    },
    //获取所有option就是指能选的产品菜单所有值，这个是后台给我返的格式，我放到options上绑定
    getRole() {
      Api.UserInfo.getRole().then(res => {

        this.roleOptions = res.data
        //this.roleOptions把这个结构遍历成前端想要的格式,目前前后端数据格式一样
        this.options = res.data
        res.data.forEach(item => {
          this.serverCodeMap[item.serverCode] = item.serverName
        })
      }).catch(err => {
        this.$showErrorMsg(err.message)
      })
    },

    initUser(value) {
      this.$refs['userFrom'].resetFields()
      this.user = Object.assign({}, defaultuser)
      this.user.accountList = []
    //  this.user.createType = value
    },
    // 一进来获取商家信息
    getSellerInfo() {
      const sellerNo = this.$route.query.sellerNo
      this.user.sellerNo = sellerNo
      Api.UserInfo.getSellerBySellerNo({ sellerNo: this.user.sellerNo }).then(response => {
        this.user.sellerNo = response.data.sellerNo
        this.user.sellerName = response.data.sellerName
        this.resetSeller = true
      })
    },
    // 取消
    onBack() {
      this.$router.push({ path: '/seller/user' })
    },
    //添加提交
    onSubmit(formName) {
      if (!this.user.sellerNo || !this.user.sellerName || !this.user.userServerList) {
        this.$message({
          message: '商家编码名称和产品角色必须填写',
          type: 'error',
          duration: 1000
        })
        return false
      }
      this.$refs[formName].validate((valid) => {
        if (valid) {
          //如果是添加页
          if (!this.isEdit) {
            this.loading = true
            let params = {}
            //先把格式处理好
            params = this.user
            Api.UserInfo.getUserAdd(params).then(res => {
              this.$message({
                message: '提交成功',
                type: 'success',
                duration: 1000
              })
              this.$router.push({ path: '/sellerInfo' })
              this.loading = false
            }).catch((e) => {
              this.loading = false
            })
          }
        } else {
          this.$message({
            message: '验证失败',
            type: 'error',
            duration: 1000
          })
          return false
        }
      })
    },
    resetSellerInfo() {
      this.user.sellerNo = ''
      this.user.sellerName = ''
      this.resetSeller = false
    }
  }
}
</script>

<style scoped>
  .form-container {
    position: unset !important;
  }
</style>
