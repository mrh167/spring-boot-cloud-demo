<template>
  <div style="position: relative">
    <lui-card v-loading="loading" class="form-container" shadow="never">
      <lui-form ref="userFrom" :model="user" :rules="rules" label-width="150px">
        <lui-row>
          <lui-col :span="16">
            <lui-form-item label="商家编码：" prop="sellerNo">
              <lui-input
                v-model="user.sellerNo"
                placeholder="请输入商家编码"
                maxlength="30"
                :disabled="true"
                @input="e => user.sellerNo = numberStringForbid (e)">
              </lui-input>
            </lui-form-item>
          </lui-col>
        </lui-row>
        <lui-row>
          <lui-col :span="16">
            <lui-form-item label="商家名称：" prop="sellerName">
              <lui-input
                v-model="user.sellerName"
                placeholder="系统自动"
                :disabled="true"
                maxlength="50"
                @input="e => user.sellerName = specialForbid (e)">
              </lui-input>
            </lui-form-item>
          </lui-col>
        </lui-row>
        <lui-row>
          <lui-col :span="16">
            <lui-form-item label="账号：" prop="account">
              <lui-input
                v-model="user.account"
                placeholder="系统自动"
                :disabled="true"
                maxlength="50"
                style="width: 100%"
              >
              </lui-input>
            </lui-form-item>
          </lui-col>
        </lui-row>

        <lui-row>
          <lui-col :span="16">
            <lui-form-item
              key="userServerList"
              label="产品及角色："
              prop="account">
              <lui-cascader
                v-model="serveList"
                :options="options"
                :props="props"
                clearable
                disabled
                style="width: 100%"
                @change="treeChange"></lui-cascader>
            </lui-form-item>
          </lui-col>
        </lui-row>
        <lui-row>
          <lui-col>
            <lui-form-item align="right" class="sellerBtnright">
              <lui-button v-waves @click="onBack">返回</lui-button>
            </lui-form-item>
          </lui-col>
        </lui-row>
      </lui-form>
    </lui-card>
  </div>
</template>
<script>
import Api from '@/api'
const defaultuser = {
  sellerNo: '',
  account: '',
  userServerList: []
}
export default {
  name: 'UserInfoDetail',
  props: {
    // isEdit 为true是可编辑页，为false是增加页
    isEdit: {
      type: Boolean,
      default: false
    },
    //通过source来判断 是商家的添加用户页还是账号配置的手工添加 true是商家的添加用户页
    source: {
      type: Boolean,
      default: true
    },
    id: {
      type: Number,
      default: 0
    }
  },
  data() {
    return {
      user: Object.assign({}, defaultuser),
      loading: false,
      resetSeller: false,
      newAdd: false,
      props: { multiple: true },
      tree: [],
      serveList: [
        {
          menuRoleCodeList: [],
          serverCode: '',
          serverName: ''
        }
      ],
      //options指的是所有选择项
      options: [],
      rules: {},
      roleOptions: [],
      serverCodeMap: {},
      accountOptions: [] //账号的下拉选项
    }
  },
  created() {
  },
  mounted() {
    this.accountGetById()
    this.getRole()
  },
  methods: {
    //change完以后给后台传这个值
    treeChange(val) {
      //先自己v-model一个数组，最后将他赋给this.user.userServerList,这里需要把一个数组改成后端想要的格式，
      // 赋给this.user.userServerList
      //将this.serveList的格式转化成后台想要的格式
      var map = {}
      var userServerList = []
      this.serveList.forEach((item) => {
        if (!map[item[0]]) {
          userServerList.push({
            serverCode: item[0],
            serverName: this.serverCodeMap[item[0]],
            menuRoleCodeList: [item[1]]
          })
          map[item[0]] = item
        } else {
          userServerList.forEach(userServer => {
            if (userServer.serverCode === item[0]) {
              userServer.menuRoleCodeList.push(item[1])
            }
          })
        }
      })
      this.user.userServerList = userServerList
    },
    // 根据id查询商户信息
    accountGetById() {
      Api.UserInfo.accountGetById({ id: this.id }).then(res => {
        this.user.sellerName = res.data.sellerName
        this.user.sellerNo = res.data.sellerNo
        this.user.account = res.data.account
        this.user.userServerList = res.data.userServerList
        var serveListArr = []
        // 将后端的数据格式转化成前端所需要的菜单格式
        res.data.userServerList.forEach((serve, i) => {
          serve.menuRoleCodeList.forEach((menuRoleCode, j) => {
            const obj = []
            obj[0] = serve.serverCode
            obj[1] = menuRoleCode
            serveListArr.push(obj)
          })
        })
        this.serveList = serveListArr

      }).catch(err => {
        this.$showErrorMsg(err)
      })
    },
    //返回
    onBack() {
      this.$emit('func', 0)
      // this.$router.push({ path: '/userInfo' })
    },
    //获取所有option就是指能选的产品菜单所有值，这个是后台给我返的格式，我放到options上绑定
    getRole() {
      Api.UserInfo.getRole().then(res => {
        this.roleOptions = res.data
        //this.roleOptions把这个结构遍历成前端想要的格式,目前前后端数据格式一样
        this.options = res.data
        res.data.forEach(item => {
          this.serverCodeMap[item.serverCode] = item.serverName
        })
      }).catch(err => {
        this.$showErrorMsg(err)
      })
    }
  }
}
</script>

<style scoped>
  .form-container {
    position: unset !important;
  }
</style>

