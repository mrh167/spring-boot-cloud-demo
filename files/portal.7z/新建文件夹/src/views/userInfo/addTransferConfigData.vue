<template>
  <div>
    <lui-dialog
      v-if="configureData.dialogVisible"
      :title="configureData.title"
      :close-on-click-modal="false"
      :visible.sync="configureData.dialogVisible"
      width="95%"
      class="addTransferForm"
      top="5vh"
      @close="handelTransferCancel"
    >
      <div v-if="configureData.sellerShow">
        <elt-transfer
          ref="transferBussiness"
          v-model="depTableData"
          :show-query="true"
          :show-pagination="true"
          :pagination-call-back="paginationCallBack"
          :left-columns="leftColumns"
          :title-texts="['可选事业部','已选事业部']"
          :button-texts="['>','<']"
          :query-texts="['查询','查询']"
          :table-row-key="tableRow"
          :left-table-data="leftPagedepTableData"
          @input="getTablerightData"
        >
          <!-- 可以使用插槽获取到列信息和行信息，从而进行数据的处理 -->
          <template v-slot:leftCondition="{scope}">
            <lui-form-item label="商家">
              <lui-select
                v-model="scope.sellerNo"
                placeholder="请选择商家"
                clearable
                filterable
              >
                <lui-option
                  v-for="item in sellerList"
                  :key="item.sellerNo"
                  :label="item.sellerName"
                  :value="item.sellerNo">
                </lui-option>
              </lui-select>
            </lui-form-item>
          </template>
          <template v-slot:rightCondition="{scope}">
            <lui-form-item label="商家">
              <lui-select
                v-model="scope.sellerNo"
                placeholder="请选择商家"
                clearable
                filterable
                value-key="scope.sellerNo"
                @change="handelLettSeller2(scope.sellerNo,scope.sellerName)">
                <lui-option
                  v-for="item in sellerList"
                  :key="item.sellerNo"
                  :label="item.sellerName"
                  :value="item.sellerNo">
                </lui-option>
              </lui-select>
            </lui-form-item>
          </template>
        </elt-transfer>
      </div>
      <div v-else>
        <elt-transfer
          ref="transferLibrary"
          v-model="nodeTableData"
          :show-query="true"
          :show-pagination="true"
          :pagination-call-back="paginationCallBack2"
          :left-columns="leftColumnsNode"
          :title-texts="['可选库节点','已选库节点']"
          :button-texts="['>','<']"
          :query-texts="['查询','查询']"
          :table-row-key="row => row.sellerNo + row.deptNo + row.nodeNo"
          @input="getTablerightData"
          @handleLeftDeptClear="handleLeftDeptClear"
          @handleRightDeptClear="handleRightDeptClear"
        >
          <!-- 可以使用插槽获取到列信息和行信息，从而进行数据的处理 -->
          <template v-slot:leftCondition="{scope}">
            <lui-form-item label="商家">
              <lui-select
                v-model="scope.sellerNo"
                placeholder="请选择商家"
                clearable
                filterable
                @change="dropDownUserDeptBySellerLeft(scope,scope.sellerNo)"
              >
                <lui-option
                  v-for="item in sellerList"
                  :key="item.sellerNo"
                  :label="item.sellerName"
                  :value="item.sellerNo">
                </lui-option>
              </lui-select>
            </lui-form-item>
            <lui-form-item label="事业部">
              <lui-select
                v-model="scope.deptNo"
                placeholder="请选择事业部"
                clearable
                filterable
                @change="changedeptNo"
              >
                <lui-option
                  v-for="item in deptListAllLeft"
                  :key="item.deptNo"
                  :label="item.deptName"
                  :value="item.deptNo">
                </lui-option>
              </lui-select> 
            </lui-form-item>
            <lui-form-item label="类型">
              <lui-select
                v-model="scope.nodeType"
                placeholder="请选择类型"
                clearable
                filterable
                value-key="scope.nodeType"
              >
                <lui-option
                  v-for="item in baseNodeList"
                  :key="item.code"
                  :label="item.name"
                  :value="item.code">
                </lui-option>
              </lui-select> 
            </lui-form-item>
            <lui-form-item label="库节点">
              <lui-input v-model="scope.nodeNoOrNameKeyword" clearable style="width:100%" placeholder="请输入库节点"></lui-input>    
            </lui-form-item>
          </template>
          <template v-slot:rightCondition="{scope}">
            <lui-form-item label="商家">
              <lui-select
                v-model="scope.sellerNo"
                placeholder="请选择商家"
                clearable
                filterable
                @change="dropDownUserDeptBySellerRight(scope,scope.sellerNo)"
              >
                <lui-option
                  v-for="item in sellerList"
                  :key="item.sellerNo"
                  :label="item.sellerName"
                  :value="item.sellerNo">
                </lui-option>
              </lui-select>
            </lui-form-item>
            <lui-form-item label="事业部">
              <lui-select
                v-model="scope.deptNo"
                placeholder="请选择事业部"
                clearable
                filterable
                @change="changedeptNo"
              >
                <lui-option
                  v-for="item in deptListAllRight"
                  :key="item.deptNo"
                  :label="item.deptName"
                  :value="item.deptNo">
                </lui-option>
              </lui-select> 
            </lui-form-item>
            <lui-form-item label="类型">
              <lui-select
                v-model="scope.nodeType"
                placeholder="请选择类型"
                clearable
                filterable
                value-key="scope.nodeType"
              >
                <lui-option
                  v-for="item in baseNodeList"
                  :key="item.code"
                  :label="item.name"
                  :value="item.code">
                </lui-option>
              </lui-select> 
            </lui-form-item>
            <lui-form-item label="库节点">
              <lui-input v-model="scope.nodeNoOrNameKeyword" clearable style="width:100%" placeholder="请输入库节点"></lui-input>    
            </lui-form-item>
          </template>
        </elt-transfer>
        <!-- <div>
          v-Model : {{ tableData.length }}
        </div>
        <lui-button @click="clearTransfer()">清空</lui-button> -->
      </div>
      <!-- 公共用一个提交按钮 -->
      <span slot="footer" class="dialog-footer">
        <lui-button @click="handelTransferCancel"> {{ isViewConfig ?'关闭':'取消' }}</lui-button>
        <lui-button
          type="primary"
          @click="handleTransferSubmit">{{ buttonConfigDisabled ? '提交中' : '确定' }} </lui-button>
      </span>
    </lui-dialog>
  </div>
</template>

<script>
import Api from '@/api'
import eltTransfer from '@/components/shared/eltTransfer'
import { mapGetters, mapState } from 'vuex'
export default {
  name: 'app',
  components: {
    'elt-transfer': eltTransfer
  },
  props: {
    //configureData穿梭框的配置
    configureData: {
      type: Object,
      default: () => {}
    }
  },
  data() {
    return {
      //---------------配置数据开始--------------
      showfigureTransfer: false,
      showfigureBtn: false,
      isViewConfig: false,
      //穿梭框的数据
      // configureData: {
      //   dialogVisible: true, //穿梭弹框的显示
      //   title: '选择库节点',
      //   account: '', //账号
      //   sellerShow: false //判断商家是否显示
      // },
      titleConfigdata: '',
      configShow: false, //查看和编辑的标识
      congfigDialogVisible: false, //弹窗是否可见
      buttonConfigDisabled: false, //编辑和查看部分字段是否显示
      configRules: {},
      //数据配置
      configForm: {
        'account': '',
        'alwaysAllPermission': 0,
        'deptList': [
          // {
          //   'deptName': '',
          //   'deptNo': '',
          //   'sellerName': '',
          //   'sellerNo': ''
          // }
        ],
        'nodeList': [
          // {
          //   'deptName': '',
          //   'deptNo': '',
          //   'nodeName': '',
          //   'nodeNo': '',
          //   'nodeType': 0,
          //   'sellerName': '',
          //   'sellerNo': ''
          // }
        ]
      },
      //根据商家
      sellerList: [],
      //事业部下拉
      deptListAllLeft: [],
      deptListAllRight: [],
      //类型下拉
      baseNodeList: [],
      // 模拟事业部数据
      sellerNo: '', //编码
      leftdeptNo: '', //左侧事业部
      rightDeptNo: '', //右侧事业部
      accountId: ' ', //账号id
      //是否为事业部或者库节点标识
      isBusiness: true,
      tableData: [],
      //右侧已选事业
      depTableData: [],
      //depTableData: this.configureData.deptList || [],
      //右侧已选库节点
      nodeTableData: [],
      leftColumns: [
        { label: '事业部编码', id: 'deptNo', width: '120px' },
        { label: '事业部名称', id: 'deptName', width: '120px' },
        { label: '商家编码', id: 'sellerNo' },
        { label: '商家名称', id: 'sellerName' }
      ],
      //左侧全部的数据
      leftPagedepTableData: [],
      tablerightDataList: [],  
      leftColumnsNode: [
        { label: '库节点编码', id: 'nodeNo', width: '120px' },
        { label: '库节点名称', id: 'nodeName', width: '120px' },
        // { label: '库节点类型', id: 'nodeType', width: '120px' },
        { label: '库节点类型', id: 'nodeTypeDesc', width: '120px' },
        { label: '事业部编码', id: 'deptNo', width: '120px' },
        { label: '事业部名称', id: 'deptName', width: '120px' },
        { label: '商家编码', id: 'sellerNo' },
        { label: '商家名称', id: 'sellerName' }
      ],
      //分页
      pageNum: 1, // 起始页
      currentPage: 1, // 起始页
      total: 0,
      pageIndex: 1, // 起始页
      pageSize: 10, // 每页条数
      totalSize: 0,
      pageIndex2: 1,
      pageSize2: 10,
      totalSize2: 0,
      defaultDepTableData: [], //存储一进弹框页面显示的原有的事业部列表
      defaultNodeTableData: [] //存储一进弹框页面显示的原有的库节点列表
      //--------------配置数据结束---------------
    }
  },
  computed: {
    ...mapGetters(['getdepList', 'getnodeList']),
    ...mapState({
      nodeList: state => state.nodeList,
      deptList: state => state.deptList
    })

  },
  watch: {
    //  this.$set(this.configForm, 'deptList', this.getdepList)
    getdepList: {
      handler(oldName, newName) {
        console.log(this.depTableData, this.getdepList, 343434, oldName, newName)
        this.depTableData = this.getdepList
        this.$forceUpdate()
        console.log(this.depTableData, 77777)
      }
    },
    getnodeList: {
      handler(oldVal, newVal) {
        this.nodeTableData = this.getnodeList
        this.$forceUpdate()
        this.$set(this.configForm, 'nodeList', this.getnodeList)
        console.log(this.nodeTableData, 555555555555555)
      }
    },
    configureData: {
      handler(oldVal, newVal) {
        console.log(oldVal, newVal, '89')
        this.configureData.sellerList = newVal.sellerList
        this.configureData.dialogVisible = newVal.dialogVisible

        this.sellerList = newVal.sellerList
      },
      deep: true
    }
  },
  created() {
    if (this.configureData.dialogVisible) {
      this.sellerList = this.configureData.sellerList
    }
  },
  mounted() {
    this.getAllrightTransfer() //判断事业部或者库节点获取穿梭框数据（右侧数据、下拉数据等）
    console.log(this.configureData.dialogVisible, 77)
  
  },
  methods: {
    //右侧传过来已选定的数据
    getTablerightData(param) {
      this.tablerightDataList = param
      console.log(this.tablerightDataList, 'this.tablerightDataList')
    },
    // 判断调取哪个事业部or库节点全量数据
    getAllrightTransfer() {
      console.log(this.configureData.sellerShow, 222)
      if (this.configureData.sellerShow) {
        this.getDeptPermissionByAccount() //获取右侧已选的全量事业部数据
        this.depTableData = this.getdepList
        this.defaultDepTableData = JSON.parse(JSON.stringify(this.depTableData))
      } else {
        this.getUserNodePermissionByAccount() //获取右侧已选的库节点数据
        this.nodeTableData = this.getnodeList
        this.defaultNodeTableData = JSON.parse(JSON.stringify(this.nodeTableData))
        this.baseNodeInfo() //获取库节点类型
      }
    },
    tableRow(row) {
      return row.sellerNo + row.deptNo
    },
    getasyncFunc(data) {
      console.log(data, 1)
      this.tableData = data
    },
    //获取左侧table的事业部的
    paginationCallBack(obj) {
      console.log(obj, 'obj1111111')
      let paramObj = {}
      //一进来调取左侧接口
      // if (obj.sellerNo) {
      paramObj.pageNum = obj.pageIndex
      paramObj.pageSize = obj.pageSize
      paramObj.sellerNo = obj.sellerNo
      console.log(this.configureData.sellerList, '12345')
      //paramObj.allUserSellerList = this.configureData.sellerList
      console.log(this.configureData, 4567890)
      paramObj.allUserSellerList = this.configureData.sellerList
      console.log(paramObj, '909090')
   
      return new Promise((resolve, reject) => {
        console.log(this.leftPagedepTableData, '打印')
        Api.UserInfo.listPageDeptBySeller(paramObj).then((res) => {
        // this.listLoading = false
          if (res.success) {
            console.log(this.leftPagedepTableData, 1234)
            this.leftPagedepTableData = res.data
            this.totalSize = res.total
            resolve({ total: this.totalSize, data: this.leftPagedepTableData })
          }
        }).catch((e) => {
          console.log('错误')
          reject(e)
          // this.$showErrorMsg(e)
        }) 
      }).catch((e) => {
        this.$showErrorMsg(e)
      })
    },
    //获取左侧table的库节点的
    paginationCallBack2(obj) {
      console.log(obj, 888888)
      let paramObj = {}
      // paramObj.deptNo = this.leftdeptNo
      paramObj.deptNo = obj.deptNo
      paramObj.nodeNo = obj.nodeNo
      paramObj.nodeNoOrNameKeyword = obj.nodeNoOrNameKeyword
      paramObj.nodeType = obj.nodeType
      paramObj.pageNum = obj.pageIndex
      paramObj.pageSize = obj.pageSize
      paramObj.sellerNo = obj.sellerNo
      paramObj.allUserDeptList = this.configureData.deptList
      console.log(paramObj, '11110000')
      // if (!obj.sellerNo && !obj.deptNo && !obj.nodeNo && !obj.nodeType && !obj.nodeNoOrNameKeyword) {
      //   return { total: 0, data: null }
      // }
      return new Promise((resolve, reject) => {
        Api.UserInfo.listPageBaseNodeBySeller(paramObj).then((res) => {
          if (res.success) {
            this.leftPagedepTableData = res.data
            this.totalSize = res.total
            resolve({ total: this.totalSize, data: this.leftPagedepTableData })
          }
        }).catch((e) => {
          console.log('c错误2')
          reject(e)
          // this.$showErrorMsg(e)
        }) 
      }).catch((e) => {
        this.$showErrorMsg(e)
      })
    },
    // clearTransferBussiness() {
    //   this.$refs.transferBussiness.clear()
    // },
    // clearTransferLibary() {
    //   this.$refs.transferLibary.clear()
    // },
   
    //根据商家下拉change事业部
    // dropDownDeptBySeller(sellerNo) {
    //   let paramObj = {}
    //   paramObj.sellerNo = sellerNo
    //   console.log(sellerNo, 4)
    //   Api.UserInfo.dropDownDeptBySeller(paramObj).then((res) => {
    //     // this.listLoading = false
    //     if (res.success) {
    //       this.deptListAll = []
    //       this.deptListAll = res.data
    //     }
    //   }).catch((e) => {
    //     this.$showErrorMsg(e)
    //   })
    // },
    //库节点-根据商家下拉已配置的事业部
    dropDownUserDeptBySellerLeft(scope, sellerNo) {
      console.log(scope, sellerNo, 'sellerNo')
      let paramObj = {}
      paramObj.sellerNo = sellerNo
      console.log(this.configureData, '123456')
      paramObj.accountId = this.configureData.account
   
      console.log(sellerNo, 4, this.configureData.account)
      Api.UserInfo.dropDownUserDeptBySeller(paramObj).then((res) => {
        // this.listLoading = false
        if (res.success) {
          //this.leftdeptNo = ''
          // this.rightDeptNo = ''
          console.log(scope, 23433)
          this.deptListAllLeft = res.data
          scope.deptNo = ''
          console.log(scope, '121')
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
      })
    },
    dropDownUserDeptBySellerRight(scope, sellerNo) {
      console.log(scope, sellerNo, 'sellerNo')
      let paramObj = {}
      paramObj.sellerNo = sellerNo
      console.log(this.configureData, '123456')
      paramObj.accountId = this.configureData.account
   
      console.log(sellerNo, 4, this.configureData.account)
      Api.UserInfo.dropDownUserDeptBySeller(paramObj).then((res) => {
        // this.listLoading = false
        if (res.success) {
          // this.rightDeptNo = ''
          console.log(scope, 23433)
          this.deptListAllRight = res.data
          scope.deptNo = ''
          console.log(scope, '121')
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
      })
    },
    changedeptNo() {
      this.$forceUpdate()
    },
    //重置时清空商家下对应的事业部数据
    handleLeftDeptClear() {
      this.deptListAllLeft = []
    },
    handleRightDeptClear() {
      this.deptListAllRight = []
    }, 
    //获取下拉的库节点数据
    baseNodeInfo() {
      Api.UserInfo.baseNodeInfo().then((res) => {
        // this.listLoading = false
        if (res.success) {
          this.baseNodeList = res.data
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
      })
    },
    //右侧的方法
    handelLettSeller2(sellerNo, sellerName) {
      console.log(this.sellerList, 11)
    },
    //根据分页查询商家下事业部
    listPageDeptBySeller(sellerNo, sellerName, allUserSellerList) {
      let paramObj = {}
      //左侧的分页暂时先按照这个写死，都通了以后再加
      paramObj.pageNum = this.pageIndex
      paramObj.pageSize = this.pageSize
      paramObj.sellerNo = sellerNo
      paramObj.allUserSellerList = allUserSellerList
      console.log(paramObj, 'qqqqqqqqq')
      Api.UserInfo.listPageDeptBySeller(paramObj).then((res) => {
        // this.listLoading = false
        if (res.success) {
          console.log(this.leftPagedepTableData, 1234)
          this.leftPagedepTableData = res.data
          this.totalSize = res.total
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
      })
    },
    //提交事业部数据筛选完以后
    submitDeptPermission() {
      this.configForm.account = this.configureData.account
      this.configureData.alwaysAllPermission = 0
      console.log(this.configForm, this.getdepList, 'qqqq')
      // console.log(this.rightTableData, this.tablerightDataList, '问题')
      // console.log(this.configForm, ' this.configForm')
      //如果右侧数据右边的赋值
      console.log(this.getdepList, 12345)
      this.configForm.deptList = this.getdepList
      let params = {
        id: this.configureData.id,
        userDataPermission: this.configForm
      }
      this.$confirm('确定要更新事业部权限吗', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        Api.UserInfo.submitDeptPermission(params).then(res => {
          if (res.success) {
            if (res.errCode === 'CONFIRM') {
              this.$confirm('您本次移除的事业部下已经关联了对应的库节点，本次操作会自动移除对应事业部下的库节点，确定更新吗？', '提示', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
              }).then(() => {
                params.paramsSign = res.data
                Api.UserInfo.confirmSubmitUserDeptPermission(params).then(res => {
                  if (res.success) {
                    console.log(res)
                    this.showfigureTransfer = false
                    this.configureData.dialogVisible = false
                    this.$message({
                      message: '配置成功！',
                      type: 'success',
                      duration: 1000
                    })
                  
                    this.$emit('func', this.configureData)
                  }
                }).catch((e) => {
                  this.$showErrorMsg(e)
         
                })
              })
            
            } else {
              //没有更改事业部也提交成功
              this.showfigureTransfer = false
              this.configureData.dialogVisible = false
              this.$message({
                message: '配置成功！',
                type: 'success',
                duration: 1000
              })
              this.$emit('func', this.configureData)
            }
          }
        })
        
      })
       
    },
    //提交库节点数据
    submitUserNodePermission() {
      this.configForm.account = this.configureData.account
      this.configureData.alwaysAllPermission = 0
      console.log(this.configForm, this.getnodeList, '看一下问题')
      this.configForm.nodeList = this.getnodeList
      let params = {
        id: this.configureData.id,
        userDataPermission: this.configForm
      }
      this.$confirm('确定要更新库节点权限吗？', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        Api.UserInfo.submitUserNodePermission(params).then(res => {
          if (res.success) {
            this.showfigureTransfer = false
            this.configureData.dialogVisible = false
            this.$emit('func', this.configureData)
          }
        }).catch((e) => {
          this.$showErrorMsg(e)
         
        })
      })
    },
    //提交所有
    submitUserPermission() {
      this.configForm.account = this.configureData.account
      console.log(this.configureData.alwaysAllPermission, 'kankan')
      this.configureData.alwaysAllPermission = 0
      console.log(this.rightTableData, this.tablerightDataList, '看一下问题')
      console.log(this.configForm, ' this.configForm')
      //如果右侧数据右边的赋值
      this.configForm.deptList = this.getdepList
      let params = {
        id: this.configureData.id,
        userDataPermission: this.configForm
      }
      console.log(params, '测试测试')
      this.$confirm('修改事业部相对应的库节点也会改变', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
      //  this.loading = true
        Api.UserInfo.submitUserPermission(params).then(res => {
          if (res.success) {
            console.log(res)
            this.showfigureTransfer = false
            this.configureData.dialogVisible = false
            // this.$store.dispatch('depList', this.depTableData)
            //调取获得库节点全量
            this.getUserNodePermissionByAccount()
            console.log(this.configureData, '--------------------=======')
            this.$emit('func', this.configureData)
          //this.getDeptPermissionByAccount()
          }
        })
      }).catch(err => {
        this.loading = false
        console.log(err)
      })
    },
    //点击取消的时候
    handelTransferCancel() {
      // console.log(this.defaultDepTableData, '默认值')
      // console.log(this.defaultDepTableData, this.depTableData, '默认值')
      this.$store.dispatch('depList', this.defaultDepTableData)
      this.$store.dispatch('nodeList', this.defaultNodeTableData)
      this.depTableData = this.defaultDepTableData
      this.nodeTableData = this.defaultNodeTableData
      this.configureData.dialogVisible = false
      this.$emit('func', this.configureData)
    },
    //提交已选穿梭框的数据
    handleTransferSubmit() {
      console.log(this.configureData.sellerShow, 'mmmmm') 
      //提交事业部所有接口
      if (this.configureData.sellerShow) {
        //提交事业部集合
        this.submitDeptPermission()
      } else {
        //提交库节点集合
        this.submitUserNodePermission()
      }
    },
    //穿梭框显示时回显右侧已选的全量数据
    // 回显事业部数据(全量)
    getDeptPermissionByAccount() {
      let paramObj = {}
      paramObj.accountId = this.configureData.account
      Api.UserInfo.getDeptPermissionByAccount(paramObj).then((res) => {
        // this.listLoading = false
        console.log(res, 'mmmm')
        if (res.success) {
          this.depTableData = res.data
          this.defaultDepTableData = res.data
          console.log(this.depTableData, 12345)
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
      })
    },
    //回显库节点数据（全量）
    getUserNodePermissionByAccount() {
      let params = {}
      params.accountId = this.configureData.account
      Api.UserInfo.getUserNodePermissionByAccount(params).then(res => {
        if (res.success) {
          this.nodeTableData = res.data
          this.defaultNodeTableData = res.data
        }
      }).catch((e) => {
        // this.listLoading = false
        this.$showErrorMsg(e)
      })
    }
    
  }
}
</script>
<style lang="scss" scope>
.addTransferForm .lui-dialog__body{
  padding: 20px;
}

</style>
