<template>
  <div>
    <main>
      <div class="trumpet">afsdf</div>
      <div class="main-content">
        <ul class="main-left">
          <li>
            <ul class="main-left_top">
              <li class="operation-state" :class="{flag1:flag1}" @click="handleflag1">运营动态</li>
              <li class="abnormal-warning" :class="{flag2:flag2}" @click="handleflag2">异常预警</li>
              <li class="inventory-health" :class="{flag3:flag3}" @click="handleflag3">库存健康</li>
              <li class="service-level" :class="{flag4:flag4}" @click="handleflag4">服务水平</li>
            </ul></li>
          <li>
            <ul v-if="flag1" class="main-left_bottom_1">
              <li class="today-control">今日监控</li>
              <li class="prediction-week">本周预测</li>
            </ul>
            <ul v-if="flag2" class="main-left_bottom_2">
              <li class="today-control">今日监控2</li>
              <li class="prediction-week">本周预测2</li>
            </ul>
            <ul v-if="flag3" class="main-left_bottom_3">
              <li class="today-control">今日监控3</li>
              <li class="prediction-week">本周预测3</li>
            </ul>
            <ul v-if="flag4" class="main-left_bottom_4">
              <li class="today-control">今日监控4</li>
              <li class="prediction-week">本周预测4</li>
            </ul>
          </li>
        </ul>
       
        <ul class="main-right">
          <li class="unfollow-metter">待跟进事项</li>
          <li class="system-Notice">系统公告</li>
        </ul>
      </div>
    </main>

  </div>
</template>

<script typtrumpete="text/ecmascript-6">
export default {
  name: 'Msite',
  data() {
    return {
      flag1: true,
      flag2: false,
      flag3: false,
      flag4: false
    }
  },
  methods: {
    handleflag1() {
      this.flag1 = true
      this.flag2 = false
      this.flag3 = false
      this.flag4 = false
    },
    handleflag2() {
      this.flag1 = false
      this.flag2 = true
      this.flag3 = false
      this.flag4 = false
    },
    handleflag3() {
      this.flag1 = false
      this.flag2 = false
      this.flag3 = true
      this.flag4 = false
    },
    handleflag4() {
      this.flag1 = false
      this.flag2 = false
      this.flag3 = false
      this.flag4 = true
    }
  }
}
</script>

<style scoped  lang= "stylus" rel="stylesheet/stylus">
main 
  .trumpet
    height 50px
    width 1000px
    background-color #002563
  .main-content
     display: -webkit-flex; /* Safari */
     display: flex;
     flex-direction row
     .main-left
      display: -webkit-flex; /* Safari */
      display: flex;
      flex-direction column
      .main-left_top
        display: -webkit-flex; /* Safari */
        display: flex;
        flex-direction row
        .operation-state
          width 200px
          height 200px
          &:hover
            background-color red
          background-color #255251
        .abnormal-warning
          width 200px
          height 200px
          background-color #125125
        .inventory-health
          width 400px
          height 200px
          background-color red
        .service-level
          width 400px
          height 200px
          background-color yellow
      .main-left_bottom_1
        display: -webkit-flex; /* Safari */
        display: flex;
        flex-direction row
        .today-control
          width 800px
          height 400px
          background-color #255251 
        .prediction-week
          width 400px
          height 400px
          background-color #255251
      .main-left_bottom_2
        display: -webkit-flex; /* Safari */
        display: flex;
        flex-direction row
        .today-control
          width 800px
          height 400px
          background-color #255251 
        .prediction-week
          width 400px
          height 400px
          background-color #255251 
      .main-left_bottom_3
        display: -webkit-flex; /* Safari */
        display: flex;
        flex-direction row
        .today-control
          width 800px
          height 400px
          background-color #255251 
        .prediction-week
          width 400px
          height 400px
          background-color #255251 
      .main-left_bottom_4
        display: -webkit-flex; /* Safari */
        display: flex;
        flex-direction row
        .today-control
          width 800px
          height 400px
          background-color #255251 
        .prediction-week
          width 400px
          height 400px
          background-color #255251  
    .main-right
      .unfollow-metter
        width 400px
        height 400px
        background-color #210210
      .system-Notice
        width 400px
        height 400px
        background-color pink

        
      
     

    
 
</style>
