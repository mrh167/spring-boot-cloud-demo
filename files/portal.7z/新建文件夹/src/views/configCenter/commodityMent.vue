<template>
  <div class="configure">
    <div class="configure-title">
      <div class="title-text">筛选搜索</div>
      <div class="title-serch">
        <lui-row>
          <lui-col :span="20" class="serch-left">
            <div class="select-content">
              <span class="content-title">事业部</span>
              <lui-select
                v-model="deptNo"
                clearable
                style="width: 220px;"
                placeholder="请选择事业部"
                @change="handlerSelectListDept">
                <lui-option
                  v-for="(item,index) in deptNoList"
                  :key="index"
                  :label="item.deptName"
                  :value="item.deptNo">
                </lui-option>
              </lui-select>
            </div>

            <div class="select-content">
              <span class="content-title">库节点</span>
              <lui-select
                ref="selectblur"
                v-model="nodeNo"
                multiple
                clearable
                style="width: 220px;"
                placeholder="请选择库节点"
                collapse-tags
                @remove-tag="removeTag">
                <lui-option
                  v-for="item in getlibraryList"
                  :key="item.id"
                  :label="item.nodeName"
                  :value="item.nodeNo">
                </lui-option>
              </lui-select>
            </div>

            <div class="select-content">
              <span class="content-title">商品分类</span>
              <lui-cascader
                v-model="cate3Id"
                style="width: 220px;"
                placeholder="请选择商品分类"
                :options="commodityList"
                :props="optionProps"
                :show-all-levels="false"
                collapse-tags
                clearable>
              </lui-cascader>
            </div>
          </lui-col>
          <lui-col :span="4" class="serch-right">
            <lui-button type="primary" style="width: 80px;" @click="handlerSerch">查询</lui-button>
            <lui-button style="width: 80px;" @click="handlerReset">重置</lui-button>
          </lui-col>
        </lui-row>
      </div>
    </div>
    <div class="master-container">
      <div class="container-top">
        <div class="container-top-left">
          <span class="header-border"></span>
          <span class="header-title">数据列表</span>
          <span v-if="deptNo!==''" class="header-text"><i class="lui-icon-info-empty" style="margin-right: 10px;"></i>当前事业部，有 {{ count }} 个库节点，在库节点基础信息页面中状态为开启，未配置库节点商品信息。</span>
        </div>
        <div class="container-top-right">
          <lui-button type="primary" @click="download">批量下载</lui-button>
          <button-list
            ref="buttons"
            :configdept-no="deptNo"
            :configdept-name="deptName"
            :buttons="buttons"
            :check-dept-no="checkDeptNo"
            @uploadSuccess="getList"
          >
          </button-list>
          <lui-button type="primary" @click="handlerDel">手工删除</lui-button>
          <lui-button type="primary" @click="handlerAdd">手工添加</lui-button>
        </div>
      </div>
      <div class="container-table">
        <div class="container-table-cont">
          <lui-table
            v-loading="LoadingTable"
            :data="tableData"
            border
            style="width: 100%"
            @selection-change="handleSelectionChange">
            <template slot="empty">
              <showEmptyImage></showEmptyImage>
            </template>
            <lui-table-column
              fixed="left"
              align="center"
              type="selection"
              width="50"
              show-overflow-tooltip>
            </lui-table-column>

            <lui-table-column
              prop="deptNo"
              label="事业部编码"
              min-width="170"
              show-overflow-tooltip>
            </lui-table-column>

            <lui-table-column
              prop="deptName"
              label="事业部名称"
              min-width="170"
              show-overflow-tooltip>
            </lui-table-column>

            <lui-table-column
              prop="nodeNo"
              label="库节点编码"
              min-width="170"
              show-overflow-tooltip>
            </lui-table-column>

            <lui-table-column
              prop="nodeName"
              label="库节点名称"
              min-width="170"
              show-overflow-tooltip>
            </lui-table-column>

            <lui-table-column
              prop="alwaysFull"
              label="是否全类目"
              min-width="170">
              <template v-slot="{row}">
                <span v-if="row.alwaysFull">是</span>
                <span v-else>否</span>
              </template>
            </lui-table-column>

            <lui-table-column
              prop="updateUser"
              label="修改人"
              min-width="170"
              show-overflow-tooltip>
            </lui-table-column>

            <lui-table-column
              prop="updateTime"
              width="170"
              label="修改时间"
              show-overflow-tooltip>
            </lui-table-column>

            <lui-table-column
              fixed="right"
              width="120"
              align="center"
              label="操作">
              <template v-slot="{row}">
                <div class="table-button">
                  <lui-button type="text" @click="handlerDetails(row)">详情</lui-button>
                  <lui-button type="text" @click="handlerEdit(row)">编辑</lui-button>
                  <!-- <span class="table-look" @click="handlerDetails(row)">详情</span>
                  <span class="table-look" @click="handlerEdit(row)">编辑</span> -->
                </div>
              </template>
            </lui-table-column>
          </lui-table>
        </div>
        <div v-show="tableData.length>0" class="knowledge-pagination">
          <lui-pagination
            background
            :current-page.sync="pageNum"
            :page-sizes="[10, 20, 50, 70, 100]"
            layout="total, prev, pager, next, sizes, jumper"
            :total="totals"
            @current-change="handleSizeChange"
            @size-change="sizeChange">
          </lui-pagination>
        </div>
      </div>
    </div>

    <!-- 添加、编辑 -->
    <lui-dialog
      :visible.sync="centerDialogVisible"
      width="90%"
      top="10vh"
      :close-on-click-modal="false"
      custom-class="dialog_mask"
      :title="stateTitle"
      @close="closeDialog('ruleForm')">
      <lui-form
        ref="ruleForm"
        :model="ruleForm"
        :rules="rules"
        label-width="100px"
        class="demo-ruleForm">

        <lui-form-item
          label="事业部"
          prop="deptNo">
          <lui-select
            v-model="ruleForm.deptNo"
            style="width: 100%;"
            placeholder="请选择事业部"
            :disabled="disabledEdit"
            @change="handlerSelectDeptNo">
            <lui-option
              v-for="(item,index) in deptNoList"
              :key="index"
              :label="item.deptName"
              :value="item.deptNo">
            </lui-option>
          </lui-select>
        </lui-form-item>

        <lui-form-item
          label="库节点"
          prop="nodeNoList">
          <lui-select
            v-if="disabledEdit"
            v-model="ruleForm.nodeNoLists"
            style="width: 100%;"
            :disabled="disabledEdit">
            <lui-option
              v-for="item in libraryList"
              :key="item.id"
              :label="item.nodeName"
              :value="item.nodeNo">
            </lui-option>
          </lui-select>
          <lui-select
            v-if="!disabledEdit"
            ref="selectblur"
            v-model="ruleForm.nodeNoList"
            multiple
            style="width: 100%;"
            :disabled="disabledEdit"
            collapse-tags
            placeholder="请选择库节点"
            @change="handleDeptNoSelectAll"
            @remove-tag="removeTag">
            <lui-option
              v-for="item in libraryList"
              :key="item.id"
              :label="item.nodeName"
              :value="item.nodeNo">
            </lui-option>
          </lui-select>
        </lui-form-item>

        <lui-form-item
          label="是否全品类"
          prop="isradio">
          <lui-radio-group v-model="ruleForm.isradio">
            <lui-radio label="是"></lui-radio>
            <lui-radio label="否"></lui-radio>
          </lui-radio-group>
        </lui-form-item>

        <!-- <lui-form-item
          label="维度"
          prop="dimension">
          <lui-select
            v-model="ruleForm.dimension"
            style="width: 100%;"
            placeholder="请选择维度"
            @change="handleDimension">
            <lui-option
              v-for="item in dimensionList"
              :key="item.code"
              :label="item.name"
              :value="item.code">
            </lui-option>
          </lui-select>
        </lui-form-item> -->
        
        <lui-form-item
          label="渠道"
          prop="saleChannel">
          <lui-select
            v-model="ruleForm.saleChannel"
            style="width: 100%;"
            placeholder="请选择渠道">
            <lui-option
              v-for="item in channelTypeList"
              :key="item.code"
              :label="item.name"
              :value="item.code">
            </lui-option>
          </lui-select>
        </lui-form-item>

        <lui-form-item
          label="类目选择"
          prop="cate3IdList">
          <lui-cascader
            v-model="ruleForm.cate3IdList"
            placeholder="请选择商品类目"
            :options="commodityList"
            style="width: 100%;"
            :props="optionProps"
            :show-all-levels="false"
            collapse-tags
            clearable>
          </lui-cascader>
        </lui-form-item>

        <!-- 商品穿梭框 -->
        <div class="ruleForm-content">
          <div class="content-title">商品选择</div>
          <div class="content-left">
            <div class="left-title">
              <span v-if="popupShow1" @click="handleRetract(1)"><i class="lui-icon-arrow-cycle-down" style="transform: rotate(180deg);cursor: pointer;"></i></span>
              <span v-else @click="handleRetract(1)"><i class="lui-icon-arrow-cycle-down"></i></span>
              <span>商品列表</span>
            </div>
            <div class="left-main">
              <div v-show="popupShow1">
               
                <lui-form-item
                  label-width="110px"
                  label="商品编码">
                  <lui-input
                    v-model.trim="leftCondition.goodsNo"
                    clearable
                    style="width: 100%;"
                    placeholder="请输入搜索商品编码">
                  </lui-input>
                </lui-form-item>

                <lui-form-item
                  label-width="110px"
                  label="商品名称">
                  <lui-input
                    v-model.trim="leftCondition.goodsName"
                    clearable
                    style="width: 100%;"
                    placeholder="请输入搜索商品名称">
                  </lui-input>
                </lui-form-item>

                <lui-row :gutter="20">
                  <lui-col :span="24" style="text-align: right;margin-bottom: 20px;">
                    <lui-button @click="handleAddRest(1)">重置</lui-button>
                    <lui-button type="primary" @click="handleQueryLeft(1)">查询</lui-button>
                  </lui-col>
                </lui-row>
              </div>

              <lui-table
                ref="multipleTable"
                :data="leftTableDate"
                style="width: 100%"
                @selection-change="handleLeftSelect">
                <lui-table-column
                  align="center"
                  type="selection"
                  :selectable="checkSelectable"
                  width="50">
                </lui-table-column>

                <lui-table-column
                  prop="goodsNo"
                  label="商品编码"
                  show-overflow-tooltip>
                </lui-table-column>

                <lui-table-column
                  prop="goodsName"
                  label="商品名称"
                  show-overflow-tooltip>
                </lui-table-column>
              </lui-table>

              <div v-show="leftTableDate.length>0" style="margin: 15px 0" class="knowledge-pagination">
                <lui-pagination
                  background
                  :current-page.sync="leftCondition.pageNum"
                  layout="total, prev, pager, next"
                  :total="leftCondition.totals"
                  @current-change="handleLeftSizeChange">
                </lui-pagination>
              </div>
            </div>
          </div>
          <div class="content-cont">
            <span class="lui-icon-arrow-right" @click="handleCopyRight(1)"></span>
            <span class="lui-icon-arrow-left" @click="handleCopyRight(2)"></span>
          </div>
          <div class="content-right">
            <div class="left-title">
              <span v-if="popupShow2" @click="handleRetract(2)"><i class="lui-icon-arrow-cycle-down" style="transform: rotate(180deg);cursor: pointer;"></i></span>
              <span v-else @click="handleRetract(2)"><i class="lui-icon-arrow-cycle-down"></i></span>
              <span>已选商品列表</span>
            </div>
            <div class="left-main">
              <div v-show="popupShow2">

                <lui-form-item
                  label-width="110px"
                  label="商品编码">
                  <lui-input
                    v-model.trim="rightCondition.goodsNo"
                    clearable
                    style="width: 100%;"
                    placeholder="请输入搜索商品编码">
                  </lui-input>
                </lui-form-item>

                <lui-form-item
                  label-width="110px"
                  label="商品名称">
                  <lui-input
                    v-model.trim="rightCondition.goodsName"
                    clearable
                    style="width: 100%;"
                    placeholder="请输入搜索商品名称">
                  </lui-input>
                </lui-form-item>

                <lui-row :gutter="20">
                  <lui-col :span="24" style="text-align: right;margin-bottom: 20px;">
                    <lui-button @click="handleAddRest(2)">重置</lui-button>
                    <lui-button type="primary" @click="handleQueryLeft(2)">查询</lui-button>
                  </lui-col>
                </lui-row>
              </div>

              <lui-table
                :data="rightTableDate"
                style="width: 100%"
                @selection-change="handleAddSelect">
                <lui-table-column
                  fixed="left"
                  align="center"
                  type="selection"
                  width="50">
                </lui-table-column>

                <lui-table-column
                  prop="goodsNo"
                  label="商品编码"
                  show-overflow-tooltip>
                </lui-table-column>

                <lui-table-column
                  prop="goodsName"
                  label="商品名称"
                  show-overflow-tooltip>
                </lui-table-column>

              </lui-table>
              <div v-show="rightTableDateLsit.length>0" style="margin: 15px 0" class="knowledge-pagination">
                <lui-pagination
                  background
                  :current-page.sync="rightCondition.pageNum"
                  layout="slot, prev, pager, next"
                  :total="rightTableTotal"
                  @current-change="handleRightSizeChange">
                  <span class="lui-pagination__total">共 {{ rightTableTotal }} 条</span>
                </lui-pagination>
              </div>
            </div>
          </div>
        </div>

      </lui-form>
     
      <span slot="footer" class="dialog-footer">
        <lui-button :loading="buttonLoading" @click="resetForm('ruleForm')">取 消</lui-button>
        <lui-button :loading="buttonLoading" type="primary" @click="submitForm('ruleForm')">{{ buttonLoading?'提交中':'确 定' }}</lui-button>
      </span>
    </lui-dialog>

    <!-- 详情 -->
    <lui-dialog
      :visible.sync="detailDialogVisible"
      width="98%"
      top="5vh"
      :close-on-click-modal="false"
      custom-class="dialog_mask"
      title="明细查看">
      <lui-table
        v-loading="detailsLoadingTable"
        :data="detailsTableData"
        border
        size="small"
        style="width: 100%">
        <template slot="empty">
          <showEmptyImage></showEmptyImage>
        </template>
        <lui-table-column
          fixed="left"
          prop="sellerNo"
          min-width="140"
          label="商家编码"
          show-overflow-tooltip>
        </lui-table-column>

        <lui-table-column
          prop="sellerName"
          fixed="left"
          label="商家名称"
          min-width="150"
          show-overflow-tooltip>
        </lui-table-column>

        <lui-table-column
          prop="deptNo"
          label="事业部编码"
          min-width="140"
          show-overflow-tooltip>
        </lui-table-column>

        <lui-table-column
          prop="deptName"
          label="事业部名称"
          min-width="140"
          show-overflow-tooltip>
        </lui-table-column>

        <lui-table-column
          prop="nodeNo"
          label="库节点编码"
          min-width="140"
          show-overflow-tooltip>
        </lui-table-column>

        <lui-table-column
          prop="nodeName"
          label="库节点名称"
          min-width="140"
          show-overflow-tooltip>
        </lui-table-column>

        <lui-table-column
          prop="nodeTypeDesc"
          label="库节点类型"
          min-width="140"
          show-overflow-tooltip>
        </lui-table-column>

        <lui-table-column
          prop="goodsNo"
          label="商品编码"
          min-width="140"
          show-overflow-tooltip>
        </lui-table-column>

        <lui-table-column
          prop="goodsName"
          label="商品名称"
          min-width="140"
          show-overflow-tooltip>
        </lui-table-column>

        <lui-table-column
          prop="cate1Id"
          label="商品一级类目ID"
          min-width="140"
          show-overflow-tooltip>
        </lui-table-column>

        <lui-table-column
          prop="cate1Name"
          label="商品一级类目名称"
          min-width="140"
          show-overflow-tooltip>
        </lui-table-column>

        <lui-table-column
          prop="cate2Id"
          label="商品二级类目ID"
          min-width="140"
          show-overflow-tooltip>
        </lui-table-column>

        <lui-table-column
          prop="cate2Name"
          label="商品二级类目名称"
          min-width="140"
          show-overflow-tooltip>
        </lui-table-column>

        <lui-table-column
          prop="cate3Id"
          label="商品三级类目ID"
          min-width="140"
          show-overflow-tooltip>
        </lui-table-column>

        <lui-table-column
          prop="cate3Name"
          label="商品三级类目名称"
          min-width="140"
          show-overflow-tooltip>
        </lui-table-column>

        <lui-table-column
          prop="createUser"
          label="创建人"
          min-width="140"
          show-overflow-tooltip>
        </lui-table-column>

        <lui-table-column
          prop="createTime"
          label="创建时间"
          min-width="140"
          show-overflow-tooltip>
        </lui-table-column>

        <lui-table-column
          prop="updateUser"
          label="修改人"
          min-width="140"
          show-overflow-tooltip>
        </lui-table-column>

        <lui-table-column
          prop="updateTime"
          label="修改时间"
          min-width="140"
          show-overflow-tooltip>
        </lui-table-column>
      </lui-table>
      <div v-show="detailsTableData.length>0" class="knowledge-pagination">
        <lui-pagination
          background
          :current-page.sync="detailsList.pageNum"
          :page-sizes="[10, 20, 50, 70, 100]"
          layout="total, prev, pager, next, sizes, jumper"
          :total="detailsTotals"
          @current-change="handleDetailsSizeChange"
          @size-change="detailsSizeChange">
        </lui-pagination>
      </div>
      <span slot="footer" class="dialog-footer">
        <lui-button @click="resetDetalisForm('ruleForm')">取 消</lui-button>
        <lui-button type="primary" @click="downloadDetails('ruleForm')">下载数据</lui-button>
      </span>
    </lui-dialog>
  </div>
</template>
<script>
import Api from '@/api'
import showEmptyImage from '@/components/common/showEmptyImage/index.vue'
import http from '@/lib/http'
import { exportExcel } from '@/utils/downloadRequest'
import ButtonList from '@/views/common/ButtonList'
const buttons = {
  upload: {
    noAsync: true,
    maxM: 10,
    uploadtips: '只能上传xlsx文件，文件大小不超过10M',
    uploadConfig: {
      uploadActionUrl: http.baseContextUrl + 'nodeConfig/upload'
    },
    templateUrl: http.baseContextUrl + 'nodeConfig/templateDownload'

  }
  // fileName: 'userInfoFile'
}
export default {
  name: 'configure.veu',
  components: {
    showEmptyImage,
    ButtonList
  },
  data() {
    return {
      buttons, //批量上传数据
      checkDeptNo: true, //默认false表示不上传事业部
      baseURL: http.baseContextUrl,
      isradioShow: true,
      commodityList: [],
      optionProps: {
        expandTrigger: 'hover',
        multiple: true,
        collapseTags: true,
        value: 'cateId',
        label: 'cateName',
        children: 'children'
      },
      count: '', //数据列表数字
      deptNo: '', //事业部
      deptName: '',
      nodeNo: '',
      cate3Id: [], //商品分类
      tableData: [],
      LoadingTable: false, //表格数据加载
      totals: 0,
      pageNum: 1, //页
      pageSize: 10, //条数
      deptNoList: [], //事业部列表
      libraryList: [], //库节点列表
      getlibraryList: [], //页面库节点
      channelTypeList: [], //销售渠道
      multipleSelection: [], //全选事件
      buttonLoading: false, //提交loading
      //---------------------------------------------------详情
      detailDialogVisible: false,
      detailsTableData: [],
      detailsLoadingTable: false,
      detailsRow: {},
      detailsTotals: 0,
      detailsList: {
        alwaysFull: true,
        cate3IdList: '',
        deptNo: '',
        nodeNo: '',
        pageNum: 1,
        pageSize: 10
      },
      //---------------------------------------------------新增、编辑条件
      disabledEdit: false,
      centerDialogVisible: false,
      stateTitle: '添加库节点商品管理',
      ruleForm: {
        isradio: '', //是否全类目
        deptNo: '', //事业部编码
        nodeNoList: [], //库节点
        cate3IdList: [], //商品类目
        saleChannel: ''//销售渠道
      },
      rules: {
        isradio: [{ required: true, message: '请选择是否全品类', trigger: ['blur', 'change'] }],
        deptNo: [{ required: true, message: '请选择事业部', trigger: ['blur', 'change'] }],
        nodeNoList: [{ required: true, message: '请选择库节点', trigger: ['blur', 'change'] }],
        // cate3IdList: [{ required: true, message: '请选择商品类目', trigger: ['blur', 'change'] }],
        saleChannel: [{ required: true, message: '请选择渠道', trigger: ['blur', 'change'] }]
      },
      newOrgData: [], // 勾选改变产生的旧数据
      BaseGoodsInfoList: [], //供应商列表获取
      buttonQuery: true,
      popupShow1: true,
      popupShow2: true,
      leftTableDate: [], //左数据列表
      leftCondition: {
        goodsNo: '',
        goodsName: '', //商品名称
        totals: 0, //总条数
        pageNum: 1, //页
        pageSize: 10 //条数
      },
      multipleRightSelection: [], //全选反选
      rightTableDate: [], //右数据列表
      rightTableDateLsit: [], //右数据列表
      rightCondition: {
        goodsNo: '',
        goodsName: '', //商品名称
        totals: 0, //总条数
        pageNum: 1, //页
        pageSize: 10 //条数
      },
      rightTableTotal: 0,
      goodsInfos: []
    }
  },

  watch: {
    'ruleForm.isradio'(newVal, oldVal) {
      console.log(newVal, 'ruleForm.isradio')
      if (newVal === '是') {
        this.isradioShow = false
        this.ruleForm.alwaysFull = true
      } else if (newVal === '否') {
        this.isradioShow = true
        this.ruleForm.alwaysFull = false
      } else {
        this.isradioShow = true
      }
    }
  },
  mounted() {
    this.getList() //列表页获取
    this.queryDept() //获取事业部
    this.getChannelTypeList() //获取销售渠道列表
    this.dropDownGoodsCate() //商品分类
  },
  methods: {
    //维度选择
    handleDimension(val) {
      console.log(val, '维度')
      if (val === 0) {
        this.ruleForm.cate3IdList = []  
      }
      if (val === 2) {
        this.ruleForm.cate3IdList = []
        this.getLeftList()
      } else {
        this.rightTableDate = []
        this.rightTableDateLsit = []
      }
    },
    //已选中置灰
    checkSelectable(row) {
      let mark = 0
      this.rightTableDateLsit.forEach((item) => {
        if (item.goodsNo === row.goodsNo) {
          mark = mark + 1
          return false
        }
      })
      return mark <= 0
    },
    //已选中勾选
    toggleSelection(rightTableData) {
      if (rightTableData) {
        this.leftTableDate.forEach((leftRow, index) => {
          const isHave = rightTableData.some(rightRow => rightRow.goodsNo === leftRow.goodsNo)
          this.$refs.multipleTable.toggleRowSelection(this.$refs.multipleTable.data[index], isHave)
        })
      } else {
        this.$refs.multipleTable.clearSelection()
      }
    },
    //新增左边表格数据
    getLeftList() {
      Api.BodCommodity.letList({
        pageSize: this.leftCondition.pageSize,
        pageNum: this.leftCondition.pageNum,
        deptNo: this.ruleForm.deptNo,
        goodsNo: this.leftCondition.goodsNo,
        goodsName: this.leftCondition.goodsName
      }).then(res => {
        if (res.success) {
          let leftTableDate = []
          res.data.forEach(item => {
            leftTableDate.push({ goodsNo: item.goodsNo, goodsName: item.goodsName })
          })
          this.leftTableDate = leftTableDate
          this.leftCondition.totals = res.total
          this.$nextTick(() => {
            this.toggleSelection(this.rightTableDateLsit)//选中置灰已选
          })
        } else {
          this.$showErrorMsg(res.errMessage)
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
      })
    },
    //重置
    handleAddRest(type) {
      if (type === 1) {
        this.leftCondition = {
          cate3Idst: '', //商品分类
          cate3Id: '', //商品分类ID
          goodsNo: '',
          goodsName: '', //商品名称
          totals: 0, //总条数
          pageNum: 1, //页
          pageSize: 10 //条数
        }
        this.getLeftList()
      } else {
        this.rightCondition = {
          cate3Idst: '', //商品分类
          cate3Id: '', //商品分类ID
          goodsNo: '',
          goodsName: '', //商品名称
          totals: 0, //总条数
          pageNum: 1, //页
          pageSize: 10 //条数
        }
        this.rightTableDate = this.rightTableDateLsit
        this.rightTableTotal = this.rightTableDateLsit.length
        // this.rightCondition.totals = this.rightTableDateLsit.length

        if (this.rightCondition.pageNum === 1) {
          this.rightTableDate = this.rightTableDateLsit.slice(0, this.rightCondition.pageSize)
        } else {
          this.rightTableDate = this.rightTableDateLsit.slice(this.rightCondition.pageSize * (this.rightCondition.pageNum - 1), this.rightCondition.pageSize * this.rightCondition.pageNum)
        }
      }
    },
    //新增查询列表
    handleQueryLeft(type) {
      if (type === 1) { //left
        this.getLeftList()
      } else { //right
        let temp = this.rightTableDateLsit
        if (this.rightCondition.goodsNo !== '') {
          this.rightTableDate = []
          for (let i = 0, size = temp.length; i < size; i++) {
            if (temp[i].goodsNo.toLowerCase().indexOf(this.rightCondition.goodsNo.toLowerCase()) !== -1) {
              this.rightTableDate.push(temp[i])
            }
          }
          temp = this.rightTableDate
        } else {
          this.rightTableDate = temp
        }

        if (this.rightCondition.goodsName !== '') {
          this.rightTableDate = []
          for (let i = 0, size = temp.length; i < size; i++) {
            if (temp[i].goodsName.toLowerCase().indexOf(this.rightCondition.goodsName.toLowerCase()) !== -1) {
              this.rightTableDate.push(temp[i])
            }
          }
          temp = this.rightTableDate
        } else {
          this.rightTableDate = temp
        }

        this.rightTableTotal = this.rightTableDate.length
        if (type !== 3) { //当不是点击分页查询时
          this.rightCondition.pageNum = 1
        } else {
          if (this.rightTableDate.length <= 10) {
            this.rightCondition.pageNum = 1
          }
        }
        if (this.rightCondition.pageNum === 1) {
          this.rightTableDate = this.rightTableDate.slice(0, this.rightCondition.pageSize)
        } else {
          this.rightTableDate = this.rightTableDate.slice(this.rightCondition.pageSize * (this.rightCondition.pageNum - 1), this.rightCondition.pageSize * this.rightCondition.pageNum)
        }
      }
    },
    //数据穿梭
    handleCopyRight(type) {
      if (type === 1) { //添加数据
        for (let i = 0; i < this.multipleLeftSelection.length; i++) {
          this.rightTableDateLsit.push(this.multipleLeftSelection[i])
        }
        for (let i = 0; i < this.rightTableDateLsit.length; i++) {
          for (let j = i + 1; j < this.rightTableDateLsit.length; j++) {
            if (this.rightTableDateLsit[i].goodsNo === this.rightTableDateLsit[j].goodsNo) {
              this.rightTableDateLsit.splice(j, 1)
              j--
            }
          }
        }
        this.rightTableTotal = this.rightTableDateLsit.length
        this.rightCondition.totals = this.rightTableDateLsit.length
        
        if (this.rightCondition.pageNum === 1) {
          this.rightTableDate = this.rightTableDateLsit.slice(0, this.rightCondition.pageSize)
        } else {
          this.rightTableDate = this.rightTableDateLsit.slice(this.rightCondition.pageSize * (this.rightCondition.pageNum - 1), this.rightCondition.pageSize * this.rightCondition.pageNum)
        }

      } else { //删除数据
        let array = []
        array = this.rightTableDateLsit
        for (let j = 0; j < this.multipleRightSelection.length; j++) {
          for (let i = 0; i < array.length; i++) {
            if (array[i].goodsNo === this.multipleRightSelection[j].goodsNo) {
              array.splice(i, 1)
            }
          }
        }
        this.rightTableDateLsit = array
        this.rightTableTotal = this.rightTableDateLsit.length
        this.rightCondition.totals = this.rightTableDateLsit.length

        this.rightTableDate = this.pagination(this.rightCondition.pageNum, this.rightCondition.pageSize, this.rightTableDateLsit)
        //当在删除最后一页全部数据时
        if (this.rightTableDate.length === 0 && this.rightCondition.pageNum > 1) {
          this.rightCondition.pageNum = this.rightCondition.pageNum - 1
          this.rightTableDate = this.pagination(this.rightCondition.pageNum, this.rightCondition.pageSize, this.rightTableDateLsit)
        }
        
      }
      //带查询条件
      this.handleQueryLeft(2)
      // this.goodsInfos = this.rightTableDateLsit
      this.$nextTick(() => {
        this.toggleSelection(this.rightTableDateLsit)//选中置灰已选
      })
    },
    //分页
    pagination(pageNo, pageSize, array) {
      console.log(pageNo, pageSize, array)
      let offset = (pageNo - 1) * pageSize
      return (offset + pageSize >= array.length) ? array.slice(offset, array.length) : array.slice(offset, offset + pageSize)
    },
    //全选反选
    handleLeftSelect(val) {
      this.multipleLeftSelection = val
    },
    //左边翻页-----根据页码变换
    handleLeftSizeChange(val) {
      this.leftCondition.pageNum = val
      this.getLeftList()
    },
    //右边全选反选
    handleAddSelect(val) {
      this.multipleRightSelection = val
    },
    //右边翻页-----根据页码变换
    handleRightSizeChange(val) {
      this.rightCondition.pageNum = val
      this.handleQueryLeft(3)
    },
    //显示隐藏搜索条件
    handleRetract(item) {
      switch (item) {
        case 1:
          this.popupShow1 = !this.popupShow1
          break
        case 2:
          this.popupShow2 = !this.popupShow2
          break
      }
    },
    //销售渠道列表
    getChannelTypeList() {
      Api.CommodityMent.getChannelTypeList().then((res) => {
        if (res.success) {
          this.channelTypeList = res.data
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
      })
    },
    //列表数字提示
    getNonConfigNum(val) {
      if (val) {
        Api.CommodityMent.getNonConfigNum({ deptNo: val }).then(res => {
          if (res.success) {
            this.count = res.data
          }
        }).catch((e) => {
          this.$showErrorMsg(e)
        })
      } else {
        this.count = ''
      }
    },
    //商品分类
    dropDownGoodsCate() {
      Api.CommodityMent.dropDownGoodsCate().then(res => {
        if (res.success) {
          this.commodityList = res.data
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
      })
    },
    //============================================================详情查看操作
    //详情查看
    handlerDetails(row) {
      this.LoadingTable = true
      Api.CommodityMent.getByNodeNo({
        deptNo: row.deptNo,
        nodeNo: row.nodeNo
      }).then(res => {
        if (res.success) {
          this.detailDialogVisible = true
          this.detailsRow = row
          this.detailsList = {
            alwaysFull: res.data.alwaysFull,
            cate3IdList: res.data.cate3IdList ? res.data.cate3IdList : [],
            deptNo: res.data.deptNo,
            nodeNo: res.data.nodeNo,
            pageNum: 1,
            pageSize: 10
          }
          this.getDetailsList(this.detailsList)
          this.LoadingTable = false
        } else {
          this.LoadingTable = false
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
        this.LoadingTable = false
      })
    },
    //详情列表
    getDetailsList(val) {
      this.detailsLoadingTable = true
      const params = {}
      params.alwaysFull = val.alwaysFull
      params.cate3IdList = val.cate3IdList
      params.deptNo = val.deptNo
      params.nodeNo = val.nodeNo
      params.pageNum = val.pageNum
      params.pageSize = val.pageSize
      Api.CommodityMent.listDetailPageByNodeNo(params).then(res => {
        if (res.success) {
          for (let i = 0; i < res.data.length; i++) {
            res.data[i].nodeNo = this.detailsRow.nodeNo
            res.data[i].nodeName = this.detailsRow.nodeName
            res.data[i].nodeTypeDesc = this.detailsRow.nodeTypeDesc
            res.data[i].nodeType = this.detailsRow.nodeType
          }
          this.detailsTableData = res.data
          this.detailsTotals = res.total
          this.detailsLoadingTable = false
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
      })
    },
    //关闭详情弹窗
    resetDetalisForm() {
      this.detailDialogVisible = false
    },
    //详情下载数据
    downloadDetails() {
      const params = {}
      params.deptNo = this.detailsList.deptNo
      params.nodeNo = this.detailsList.nodeNo
      params.nodeName = this.detailsRow.nodeName
      params.nodeType = this.detailsRow.nodeType
      params.alwaysFull = this.detailsList.alwaysFull
      params.cate3IdList = this.detailsList.cate3IdList
      const actionUrl = this.baseURL + Api.CommodityMent.downloadDetail
      exportExcel(actionUrl, params)
    },
    //页码翻页
    handleDetailsSizeChange(val) {
      this.detailsList.pageNum = val
      this.getDetailsList(this.detailsList)
    },
    //条数翻页
    detailsSizeChange(val) {
      this.detailsList.pageSize = val
      this.getDetailsList(this.detailsList)
    },
    //==============================================>添加、编辑
    //编辑
    handlerEdit(row) {
      this.LoadingTable = true
      this.disabledEdit = true
      this.stateTitle = '编辑库节点商品管理'
      this.baseNodeInfo(row.deptNo)
      this.ruleForm.deptNo = row.deptNo
      this.leftCondition.pageNum = 1
      this.rightCondition.pageNum = 1
      this.leftCondition.goodsNo = ''
      this.leftCondition.goodsName = ''
      this.rightCondition.goodsNo = ''
      this.rightCondition.goodsName = ''

      Api.CommodityMent.getNodeConfigDetail({
        deptNo: row.deptNo,
        nodeNo: row.nodeNo
      }).then(res => {
        if (res.success) {
          this.centerDialogVisible = true
          this.getLeftList()
          this.ruleForm.isradio = res.data.alwaysFull ? '是' : '否'
          this.ruleForm.saleChannel = res.data.saleChannel
          this.ruleForm.nodeNoList[0] = res.data.nodeNo
          this.ruleForm.nodeNoLists = res.data.nodeNo
          if (res.data.nodeGoodsCateList) {
            const obj = []
            for (let i = 0; i < res.data.nodeGoodsCateList.length; i++) {
              let sum = []
              sum = [res.data.nodeGoodsCateList[i].cate1Id, res.data.nodeGoodsCateList[i].cate2Id, res.data.nodeGoodsCateList[i].cate3Id]
              obj.push(sum)
            }
            this.ruleForm.cate3IdList = obj
          } else {
            this.ruleForm.cate3IdList = []
          }
          this.rightTableDate = res.data.goodsInfos ? res.data.goodsInfos : []
          this.rightTableDateLsit = this.rightTableDate
          // this.rightCondition.totals = this.rightTableDateLsit.length
          // this.goodsInfos = this.rightTableDate
          this.rightTableTotal = this.rightTableDate.length
          if (this.rightCondition.pageNum === 1) {
            this.rightTableDate = this.rightTableDateLsit.slice(0, this.rightCondition.pageSize)
          } else {
            this.rightTableDate = this.rightTableDateLsit.slice(this.rightCondition.pageSize * (this.rightCondition.pageNum - 1), this.rightCondition.pageSize * this.rightCondition.pageNum)
          }
          this.LoadingTable = false
        } else {
          this.LoadingTable = false
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
        this.LoadingTable = false
      })
    },
    //打开新增弹窗
    handlerAdd() {
      this.centerDialogVisible = true
      this.disabledEdit = false
      this.stateTitle = '添加库节点商品管理'
      this.libraryList = []
      this.ruleForm.cate3IdList = []
      this.ruleForm.isradio = '是'
      this.ruleForm.deptNo = ''
      this.ruleForm.nodeNoList = []
      this.ruleForm.nodeNoLists = []
      this.leftCondition.goodsNo = ''
      this.leftCondition.goodsName = ''
      this.rightCondition.goodsNo = ''
      this.rightCondition.goodsName = ''
      this.ruleForm.saleChannel = ''
      this.rightTableDate = []
      this.rightTableDateLsit = []
      this.$nextTick(() => {
        this.$refs['ruleForm'].clearValidate()
        this.$refs.multipleTable.clearSelection()
      })
    },
    //新增提交
    submitForm(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          this.buttonLoading = true
          if (this.ruleForm.nodeNoList[0] === '全选') {
            this.ruleForm.nodeNoList.splice(0, 1)
          }
          const sum = []
          for (let i = 0; i < this.ruleForm.cate3IdList.length; i++) {
            sum.push(this.ruleForm.cate3IdList[i][2])
          }
          if (this.disabledEdit) { //编辑提交
            const params = {}
            params.alwaysFull = this.ruleForm.alwaysFull
            params.cate3IdList = sum
            params.deptNo = this.ruleForm.deptNo
            params.nodeNo = this.ruleForm.nodeNoList[0]
            params.saleChannel = this.ruleForm.saleChannel
            params.goodsInfos = this.rightTableDateLsit
         
            Api.CommodityMent.editNodeConfig(params).then(res => {
              if (res.success) {
                this.$showSuccessMsg('编辑成功')
                this.getList()
                this.buttonLoading = false
                this.centerDialogVisible = false
              } else {
                if (Number(this.libraryList.length) - Number(this.ruleForm.nodeNoList.length) === 1) {
                  this.ruleForm.nodeNoList.unshift('全选')
                }
                this.$showErrorMsg(res.errMessage)
                this.buttonLoading = false
              }
            }).catch((e) => {
              if (Number(this.libraryList.length) - Number(this.ruleForm.nodeNoList.length) === 1) {
                this.ruleForm.nodeNoList.unshift('全选')
              }
              this.$showErrorMsg(e)
              this.buttonLoading = false
            })
          } else { //新增提交
            const params = {}
            params.alwaysFull = this.ruleForm.alwaysFull
            params.cate3IdList = sum
            params.deptNo = this.ruleForm.deptNo
            params.nodeNoList = this.ruleForm.nodeNoList
            params.goodsInfos = this.rightTableDateLsit
            params.saleChannel = this.ruleForm.saleChannel
            Api.CommodityMent.addNodeConfig(params).then(res => {
              if (res.success) {
                this.$showSuccessMsg('新增成功')
                this.getList()
                this.buttonLoading = false
                this.centerDialogVisible = false

              } else {
                if (Number(this.libraryList.length) - Number(this.ruleForm.nodeNoList.length) === 1) {
                  this.ruleForm.nodeNoList.unshift('全选')
                }
                this.$showErrorMsg(res.errMessage)
                this.buttonLoading = false
              }
            }).catch((e) => {
              if (Number(this.libraryList.length) - Number(this.ruleForm.nodeNoList.length) === 1) {
                this.ruleForm.nodeNoList.unshift('全选')
              }
              this.$showErrorMsg(e)
              this.buttonLoading = false
            })
          }
        }
      })
    },
    //关闭弹窗
    closeDialog(type) {
      if (type) {
        this.libraryList = []
        this.ruleForm.nodeNoList = []
        this.ruleForm.nodeNoLists = ''
        this.ruleForm.cate3IdList = []
        this.ruleForm.isradio = null
        this.ruleForm.deptNo = ''
        this.$nextTick(() => {
          this.$refs['ruleForm'].clearValidate()
        })
      }
    },
    //取消新增弹窗
    resetForm(formName) {
      this.libraryList = []
      this.ruleForm.nodeNoList = []
      this.ruleForm.nodeNoLists = ''
      this.ruleForm.cate3IdList = []
      this.ruleForm.isradio = null
      this.ruleForm.deptNo = ''
      this.centerDialogVisible = false
      this.$nextTick(() => {
        this.$refs['ruleForm'].clearValidate()
      })


    },
    // 多选模式下移除tag时触发,val为移除的tag值
    removeTag(val) {
      if (val === '全选') {
        this.ruleForm.nodeNoList = []
      }
    },
    //新增全选反选
    handleDeptNoSelectAll(val) {
      var end = val[val.length - 1]
      //全选数据再反选使所有清空
      if (this.newOrgData.includes('全选') && !val.includes('全选') && val.length + 1 === this.libraryList.length) {
        val = []
        this.ruleForm.nodeNoList = []
      }
      //当所有数据都选择了使勾选上【全选】
      if (!val.includes('全选') && val.length + 1 === this.libraryList.length) {
        val.unshift('全选') //在val开头插入【全选】
        this.$refs.selectblur.blur()
      } else if (val.includes('全选') && val.length === 1) { //直接勾选【全选】
        val = []
        this.libraryList.map(item => {
          val.push(item.nodeNo)
        })
        this.$refs.selectblur.blur()
      } else if (val.includes('全选') && val.length - 1 < this.libraryList.length && end === '全选') {
      //点击选择其他元素后再选择【全选】
        val = []
        this.libraryList.map(item => {
          val.push(item.nodeNo)
        })
        this.$refs.selectblur.blur()
      } else if (val.includes('全选') && val.length - 1 < this.libraryList.length) {
        //全选后再点击取消掉其他元素
        val = val.filter(item => {
          return item !== '全选'
        })
      }
      // 赋值
      this.ruleForm.nodeNoList = val
      this.newOrgData = val
    },
    //新增事业部选择
    handlerSelectDeptNo(val) {
      this.baseNodeInfo(val)
      this.ruleForm.nodeNoList = []
      this.getLeftList()
    },
    //库节点列表
    baseNodeInfo(val) {
      Api.BodConfig.baseNodeInfo({
        deptNo: val
      }).then((res) => {
        if (res.success) {
          this.libraryList = res.data
          const obj = {
            id: '全选',
            nodeNo: '全选',
            nodeName: '全选'
          }
          this.libraryList.unshift(obj)
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
      })
    },
    //===================================================================>列表
    //全选反选
    handleSelectionChange(val) {
      this.multipleSelection = val
    },
    //手工删除
    handlerDel() {
      if (this.multipleSelection.length === 0) {
        this.$showErrorMsg('请选择删除数据')
        return
      }
      this.delete(this.multipleSelection)
    },
    //  删除方法
    delete(row) {
      this.$alert('<p style="font-size: 18px;color:#333">确认删除此条消息吗?</p><p style="font-size: 13px;color: #666">删除后，此条消息的相关内容信息将无法恢复</p>', '', {
        dangerouslyUseHTMLString: true,
        type: 'warning',
        center: true
      }).then(() => {
        Api.CommodityMent.deleteNodeConfig({ nodeConfigIdList: row }).then(res => {
          if (res.success) {
            this.$showSuccessMsg('删除成功')
            this.getList()

          } else {
            this.$showErrorMsg(res.errMessage)
          }
        }).catch((e) => {
          this.$showErrorMsg(e)
        })
      }).catch(() => {})
    },
    //查询列表
    handlerSerch() {
      const sum = []
      for (let i = 0; i < this.cate3Id.length; i++) {
        sum.push(this.cate3Id[i][2])
      }
      this.getList(sum)
    },
    //重置列表
    handlerReset() {
      this.getlibraryList = []
      this.cate3Id = []
      this.deptNo = ''
      this.deptName = ''
      this.nodeNo = []
      this.pageNum = 1
      this.pageSize = 10
      this.getList()
    },
    //数据列表
    getList(val) {
      this.LoadingTable = true
      const params = {}
      params.cate3IdList = val ? val : []
      params.deptNo = this.deptNo
      params.nodeNoList = this.nodeNo
      params.pageNum = this.pageNum
      params.pageSize = this.pageSize
      Api.CommodityMent.listPage(params).then(res => {
        if (res.success) {
          this.tableData = res.data
          this.totals = res.total
          this.LoadingTable = false
          if (this.deptNo !== '') {
            this.getNonConfigNum(this.deptNo)
          }
        } else {
          this.$showErrorMsg(res.errMessage)
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
        this.LoadingTable = false
      })
    },
    //批量下载
    download() {
      const sum = []
      for (let i = 0; i < this.cate3Id.length; i++) {
        sum.push(this.cate3Id[i][2])
      }
      const params = {}
      params.cate3IdList = sum
      params.deptNo = this.deptNo
      params.nodeNoList = this.nodeNo
      const actionUrl = this.baseURL + Api.CommodityMent.download
      exportExcel(actionUrl, params)
    },
    //分页条数改变
    sizeChange(val) {
      this.pageSize = val
      this.getList()
    },
    //翻页-----根据页码变换
    handleSizeChange(val) {
      this.pageNum = val
      this.getList()
    },
    //列表页获取库节点
    handlerSelectListDept(val) {
      // var obj = {} //多条件查找
      // obj = this.deptNoList.find(function(item) {
      //   return item.deptNo === val
      // })
      // this.deptName = obj.deptName
      this.getBaseNodeInfo(val)
      this.getNonConfigNum(val)
    },
    //页面库节点列表
    getBaseNodeInfo(val) {
      Api.BodConfig.baseNodeInfo({
        deptNo: val
      }).then((res) => {
        if (res.success) {
          this.getlibraryList = res.data
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
      })
    },
    //获取事业部编码
    queryDept() {
      Api.BodCommodity.queryDept().then(row => {
        if (row.success) {
          this.deptNoList = row.data
        } else {
          this.$showErrorMsg(row.errMessage)
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
      })
    }
  }
}
</script>

<style scoped lang="scss">
@import '@/assets/stylus/main';
.knowledge-pagination {
  width: 100%;
  /*margin-top: 73px;*/
  margin-top: 20px;
  text-align: right;

}
.configure{
  .configure-title{
    padding: 30px 30px;
    background: #ffffff;
    width: 100%;
    box-shadow: 2px 2px 7px 2px #ccc;
    border-radius: 0 0 4px 4px;
    .title-text{
      font-size: 16px;
      font-weight: 600;
    }
    .title-serch{
      width: 100%;
      .serch-left{
        display: flex;
        flex-wrap: wrap;
        .select-content{
          margin-top: 20px;
          .content-title{
            display: inline-block;
            width: 80px;
            text-align: right;
            margin-right: 10px;
            font-size: 14px;
            color: #333;
          }

          /deep/ .lui-tag--lightBorder.lui-tag--info:nth-child(1){
              display: flex;
              align-items: center;
              .lui-select__tags-text{
                 max-width: 75px;
                 white-space: nowrap;
                 text-overflow: ellipsis;
                 overflow: hidden;
              }
          }
         /deep/ .lui-cascader__tags .lui-tag:nth-child(1)>span {
              -webkit-box-flex: 1;
              -ms-flex: 1;
              flex: 1;
              // overflow: hidden;
              // text-overflow: ellipsis;
              // border: 1px solid red;
              max-width: 75px;
              white-space: nowrap;
              text-overflow: ellipsis;
              overflow: hidden;
          }

        }
      }
      .serch-right{
        margin-top: 20px;
        display: flex;
        align-items: flex-end;
        justify-content: flex-end;
      }
    }

  }
  .master-container{
    width: 100%;
    background: #ffffff;
    margin-top: 20px;
    border-radius: 4px;
    box-shadow: 2px 2px 7px 2px #ccc;
    .container-top{
      width: 100%;
      padding-top: 30px;
      padding-bottom: 30px;
      display: flex;
      justify-content: space-between;
      .container-top-left{
        .header-border{
          width: 3px;
          height: 13px;
          display: inline-block;
          margin-left: 20px;
          margin-right: 8px;
        }
        .header-title{
          font-weight: 600;
          font-size: 16px;
          color: #333;
        }
        .header-text{
          font-size: 14px;
          color: #666666;
          margin-left: 40px;
        }
      }
      .container-top-right{
        padding-right: 30px;
        .button-upload{
          position: relative;
          overflow: hidden;
          input{
            position: absolute;
            top: 0;
            bottom: 0;
            left: 0;
            right: 0;
            opacity: 0;
          }
        }
      }
    }
    .container-table{
      width: 100%;
      padding-left: 24px;
      padding-right: 24px;
      padding-bottom: 30px;
      .container-table-cont{
        min-height: 300px;
        .table-look{
          cursor: pointer;
          color: $--gl-blue;
          font-size: 14px;
          font-weight: 500;
        }
        .table-button{
          display: flex;
          justify-content: space-around;
        }
        .table-p {
          //display: inline-block;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
          cursor: pointer;
          padding-right: 15px;
          //border: 1px solid red;/**/
        }
      }
      .knowledge-pagination {
        width: 100%;
        /*margin-top: 73px;*/
        margin-top: 20px;
        text-align: right;
      }
    }
  }

  .ruleForm-content{
    border-radius: 4px;
    /*height: 300px;*/
    display: flex;
    .content-title{
      width: 100px;
      margin-right: 12px;
      text-align: right;
    }
    .content-left{
      width: calc(50% - 80px);
      border: 1px solid #D9D9D9;
      border-radius: 4px;
      .left-title{
        width: 100%;
        height: 40px;
        border-bottom: 1px solid #d9d9d9;
        display: flex;
        justify-content:space-between;
        align-items: center;
        span{
          padding: 0 15px
        }
      }
      .left-main{
        margin-top: 10px;
        padding: 0 12px;
        .table-p {
          //display: inline-block;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
          cursor: pointer;
          padding-right: 15px;
          //border: 1px solid red;/**/
        }
        .knowledge-pagination {
          width: 100%;
          margin-top: 10px;
          text-align: right;
        }
      }
    }
    .content-cont{
      width: 80px;
      position: relative;
      span{
        display: block;
        width: 32px;
        height: 32px;
        border-radius: 4px;
        font-size: 16px;
        background: rgba(0,0,0,0.04);
        color: rgba(0,0,0,0.15);
        border: 1px solid rgba(0,0,0,0.15);
        text-align: center;
        line-height: 32px;
        cursor: pointer;
        &:hover{
          background: #0D6CA2;
          color: #fff;
        }
      }
      span:nth-child(1){
        position: absolute;
        top: 50%;
        left: 50%;
        margin-top: -32px;
        margin-left: -16px;
      }
      span:nth-child(2){
        position: absolute;
        top: 50%;
        left: 50%;
        margin-top: 16px;
        margin-left: -16px;
      }
    }
    .content-right{
      border-radius: 4px;
      width: calc(50% - 80px);
      border: 1px solid #D9D9D9;
      .left-title{
        width: 100%;
        height: 40px;
        border-bottom: 1px solid #d9d9d9;
        display: flex;
        justify-content:space-between;
        align-items: center;
        span{
          padding: 0 15px
        }
      }
      .left-main{
        margin-top: 10px;
        padding: 0 12px;
        .table-p {
          //display: inline-block;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
          cursor: pointer;
          padding-right: 15px;
          //border: 1px solid red;/**/
        }
        .knowledge-pagination {
          width: 100%;
          margin-top: 10px;
          text-align: right;
        }
      }
    }
  }
}


</style>
