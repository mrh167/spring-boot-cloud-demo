<template>
  <div class="masterData">
    <div class="master-header">
      <lui-row>
        <lui-col :span="24" class="header-top"><span class="header-border"></span><span class="header-title">筛选项</span></lui-col>
      </lui-row>
      <lui-row>
        <lui-col :span="16" class="header-select header-select-one">
          <div class="select-content">
            <span class="content-title">事业部</span>
            <lui-select v-model="deptNo" clearable style="width: 220px;" placeholder="请选择事业部">
              <lui-option
                v-for="(item,key) in deptNoList"
                :key="key"
                :label="item.deptName"
                :value="item.deptNo+'&'+item.deptName">
              </lui-option>
            </lui-select>
          </div>
          <div class="select-content">
            <span class="content-title">供应商名称</span>
            <lui-autocomplete v-model.trim="supplierName" clearable :fetch-suggestions="querySearchAsync" placeholder="请输入供应商名称" :maxlength="50"></lui-autocomplete>
            <!-- <lui-select v-model="supplierNo" clearable style="width: 220px;" placeholder="请选择供应商" @change="handleBaseGoods">
              <lui-option
                v-for="(item,index) in BaseGoodsInfoList"
                :key="index"
                :label="item.supplierName"
                :value="item.supplierNo">
              </lui-option>
            </lui-select> -->
          </div>
        </lui-col>
        <lui-col :span="8" class="header-button">
          <lui-button type="primary" style="width: 80px;" @click="handleQuery">查询</lui-button>
          <lui-button style="width: 80px;" @click="handleRest">重置</lui-button>
        </lui-col>
      </lui-row>
    </div>

    <div class="master-container">
      <div class="container-top">
        <div class="container-top-left"><span class="header-border"></span><span class="header-title">数据列表</span></div>
        <div class="container-top-right">
          <lui-button type="primary" @click="download">批量下载</lui-button>
          <button-list
            v-if="getIsEclpForNodeAndSupplier"
            ref="buttons"
            :buttons="buttons"
            :configdept-no="deptNo.split('&')[0]"
            :configdept-name="deptNo.split('&')[1]"
            :check-dept-no="checkDeptNo"
            @uploadSuccess="getList"
          >
          </button-list>
          <lui-button v-if="getIsEclpForNodeAndSupplier" type="primary" @click="handleDeled">手工删除</lui-button>
          <lui-button v-if="getIsEclpForNodeAndSupplier" type="primary" @click="handleAdd()">手工添加</lui-button>
        </div>
      </div>

      <div class="container-table">
        <div class="container-table-cont">
          <lui-table
            v-loading="LoadingTable"
            :data="tableData"
            border
            style="width: 100%"
            @selection-change="handleSelectionChange">
            <template slot="empty">
              <showEmptyImage></showEmptyImage>
            </template>
            <lui-table-column
              fixed="left"
              align="center"
              type="selection"
              width="50">
            </lui-table-column>
            <lui-table-column
              prop="deptNo"
              min-width="180"
              label="事业部编码"
              show-overflow-tooltip>
            </lui-table-column>
            <lui-table-column
              prop="deptName"
              min-width="170"
              label="事业部名称">
              <template v-slot="{row}">
                <p class="table-p">{{ row.deptName }}</p>
              </template>
            </lui-table-column>
            <lui-table-column
              prop="sellerNo"
              min-width="180"
              label="商家编码"
              show-overflow-tooltip>
            </lui-table-column>
            <lui-table-column
              prop="supplierNo"
              min-width="180"
              label="供应商编码"
              show-overflow-tooltip>
            </lui-table-column>
            <lui-table-column
              prop="supplierName"
              min-width="180"
              label="供应商名称"
              show-overflow-tooltip>
            </lui-table-column>
            <lui-table-column
              prop="startTime"
              width="170"
              label="合同开始时间">
            </lui-table-column>
            <lui-table-column
              prop="endTime"
              width="170"
              label="合同结束时间">
            </lui-table-column>
            <lui-table-column
              prop="updateUser"
              width="170"
              label="修改人"
              show-overflow-tooltip>
            </lui-table-column>
            <lui-table-column
              prop="updateTime"
              width="170"
              label="修改时间">
            </lui-table-column>
            <lui-table-column
              fixed="right"
              align="center"
              width="100"
              label="操作">
              <template v-slot="{row}">
                <div class="table-button">
                  <lui-button type="text" @click="handleEdit(row,true)">查看</lui-button>
                  <lui-button v-if="getIsEclpForNodeAndSupplier" type="text" @click="handleEdit(row,false)">编辑</lui-button>
                </div>
              </template>
            </lui-table-column>
          </lui-table>
        </div>
        <div v-show="tableData.length>0" class="knowledge-pagination">
          <lui-pagination
            background
            :current-page.sync="pageNum"
            :page-sizes="[10, 20, 50, 70, 100]"
            layout="prev, pager, next, sizes, jumper"
            :total="totals"
            @current-change="handleSizeChange"
            @size-change="sizeChange"
          >
          </lui-pagination>
        </div>
      </div>
    </div>
    <lui-dialog
      :visible.sync="centerDialogVisible"
      width="50%"
      top="10vh"
      :close-on-click-modal="false"
      custom-class="dialog_mask"
      :title="stateTitle"
      @close="closeDialog('ruleForm')">
      <lui-form
        ref="ruleForm"
        :model="ruleForm"
        :rules="rules"
        label-width="140px"
        class="demo-ruleForm">
        <lui-form-item
          label="事业部"
          prop="deptNo">
          <lui-select v-model="ruleForm.deptNo" :disabled="disabledShow" style="width: 100%;" placeholder="请选择事业部" @change="handleDept">
            <lui-option
              v-for="item in deptNoList"
              :key="item.deptNo"
              :label="item.deptName"
              :value="item.deptNo">
            </lui-option>
          </lui-select>
        </lui-form-item>

        <lui-form-item
          label="供应商"
          prop="supplierName">
          <lui-input v-model="ruleForm.supplierName" :disabled="disabledLook" maxlength="100" placeholder="请输入供应商" @input="e => ruleForm.supplierName = specialForbid (e)"></lui-input>
        </lui-form-item>

        <lui-form-item
          label="供应商编码"
          prop="supplierNo">
          <lui-input v-model="ruleForm.supplierNo" maxlength="50" :disabled="disabledShow" placeholder="请输入供应商" @input="e => ruleForm.supplierNo = specialForbid (e)"></lui-input>
        </lui-form-item>

        <lui-form-item
          label="合同时间"
          prop="times">
          <lui-date-picker
            v-model="ruleForm.times"
            style="width: 100%;"
            type="datetimerange"
            :disabled="disabledLook"
            value-format="yyyy-MM-dd HH:mm:ss"
            range-separator="-"
            start-placeholder="开始日期"
            end-placeholder="结束日期"
            @change="timeChange">
          </lui-date-picker>
        </lui-form-item>
      </lui-form>
      <span slot="footer" class="dialog-footer">
        <lui-button @click="resetForm('ruleForm')">取 消</lui-button>

        <lui-button v-if="lookButShow" type="primary" :loading="buttonDisabled" @click="submitForm('ruleForm')">提 交</lui-button>
      </span>
    </lui-dialog>

    <lui-dialog
      class="error-dialog"
      title="删除失败"
      :visible.sync="dialogTableVisible"
      :close-on-click-modal="false">
      <div class="dialog-table-list">
        <div v-show="moreErr" style="color: red;font-size: 12px">异常太多，最多显示300条</div>
        <lui-table
          stripe
          size="mini"
          :data="gridData">
          <lui-table-column align="center" property="msg" label="异常原因">
            <template slot-scope="{row}">
              {{ row.msg }}
            </template>
          </lui-table-column>
        </lui-table>
      </div>
    </lui-dialog>

  </div>
</template>

<script>
import http from '@/lib/http'
import { exportExcel } from '@/utils/downloadRequest'
import ButtonList from '@/views/common/ButtonList'
import Api from '@/api'
import utils from '@/utils/utils'
import showEmptyImage from '@/components/common/showEmptyImage/index.vue'
import { mapGetters } from 'vuex'
const buttons = {
  upload: {
    noAsync: true,
    maxM: 10,
    uploadtips: '只能上传xlsx文件，文件大小不超过10M',
    uploadConfig: {
      uploadActionUrl: http.baseContextUrl + 'baseSupplierInfo/upload'
    },
    templateUrl: http.baseContextUrl + 'baseSupplierInfo/downloadTemplate'

  }
  // fileName: 'userInfoFile'
}
export default {
  name: 'index',
  components: {
    showEmptyImage,
    ButtonList
  },
  data() {
    return {
      gridData: [],
      moreErr: false,
      dialogTableVisible: false, //删除错误提示
      buttons,
      LoadingTable: false,
      baseURL: http.baseContextUrl,
      buttonDisabled: false,
      checkDeptNo: true, //默认false表示不上传事业部
      deptNo: '', //事业部
      supplierNo: '', //供应商
      supplierName: '', //供应商名称
      deptNoList: '', //事业部列表
      BaseGoodsInfoList: [], //供应商列表获取
      tableData: [], //列表数据
      multipleSelection: [],
      totals: 0,
      pageNum: 1, //页
      pageSize: 10, //条数
      centerDialogVisible: false,
      stateTitle: '添加供应商信息',
      stateShow: false, //判断新增、编辑状态
      disabledShow: false,
      lookButShow: false, //查看时隐藏提交按钮
      disabledLook: false,
      ruleForm: {
        deptNo: '', //事业部编码
        deptName: '', //事业部名称
        supplierNo: '',
        supplierName: '',
        startTime: '', //开始时间
        endTime: '', //结束时间
        times: '' //结束时间
      },
      rules: {
        deptNo: [{ required: true, message: '请选择事业部', trigger: ['blur', 'change'] }],
        supplierNo: [{ required: true, message: '请输入供应商编码', trigger: ['blur', 'change'] }],
        supplierName: [{ required: true, message: '请输入供应商名称', trigger: ['blur', 'change'] }],
        times: [{ required: true, message: '请选合同择时间', trigger: ['blur', 'change'] }]
      }
    }
  },
  computed: {
    ...mapGetters(['getIsEclpForNodeAndSupplier'])
  },
  mounted() {
    this.queryDept() //事业部
    this.baseSupplierInfo() //供应商获取
    this.getList() //列表获取
  },
  methods: {
    //模糊搜索
    querySearchAsync(queryString, cb) {
      Api.ConfigCenter.postKeywords({
        'displayFields': ['supplierNo', 'supplierName'], //返回字段
        'keyWords': ['supplierName'], //查询字段名称
        'rout': 'supplier', //供应商
        'value': this.supplierName //关键字
      }).then((res) => {
        if (res.success) {
          var results = res.data
          results.forEach(item => {
            item.value = item.supplierName
          })
          cb(results)
        }
      }).catch((e) => {
        console.error(e)
      })
    },
    //=======================================>编辑部分
    handleEdit(item, type) {
      this.$nextTick(() => {
        if (type) { //查看
          this.stateTitle = '查看供应商信息'
          this.lookButShow = false
        } else { //编辑
          this.stateTitle = '编辑供应商信息'
          this.lookButShow = true
        }
        this.disabledLook = type
        this.centerDialogVisible = true
        this.disabledShow = true
        this.stateShow = false
        const formData = new window.FormData()
        formData.append('id', item.id)
        Api.ConfigNetWork.get(formData).then(row => {
          if (row.success) {
            this.ruleForm = {
              id: row.data.id,
              deptNo: row.data.deptNo, //事业部编码
              deptName: row.data.deptName, //事业部名称
              supplierNo: row.data.supplierNo,
              supplierName: utils.htmlDecode(row.data.supplierName),
              startTime: row.data.startTime, //开始时间
              endTime: row.data.endTime, //结束时间
              times: [row.data.startTime, row.data.endTime] //结束时间
            }
          } else {
            this.$showErrorMsg(row.errMessage)
          }
        }).catch((e) => {
          this.$showErrorMsg(e)
        })
      })
    },
    //=======================================>新增部分
    handleAdd() {
      this.$nextTick(() => {
        this.stateTitle = '添加供应商信息'
        this.centerDialogVisible = true
        this.stateShow = true
        this.disabledShow = false
        this.lookButShow = true
        this.disabledLook = false
      })
    },
    // 提交
    submitForm(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          this.buttonDisabled = true
          if (this.stateShow) {
            this.$confirm('【供应商编码】 新增之后不可修改', '提示', {
              confirmButtonText: '确定',
              cancelButtonText: '取消',
              type: 'warning'
            }).then(() => {
              Api.ConfigNetWork.add(this.ruleForm).then(row => {
                if (row.success) {
                  this.$showSuccessMsg('新增成功')
                  this.buttonDisabled = false
                  this.$refs[formName].resetFields()
                  this.getList()
                  this.centerDialogVisible = false
                } else {
                  this.$showErrorMsg(row.errMessage)
                  this.buttonDisabled = false
                }
              }).catch((e) => {
                this.buttonDisabled = false
                this.$showErrorMsg(e)
              })
            }).catch(() => {
              this.buttonDisabled = false
              this.$message({
                type: 'info',
                message: '已取消新增'
              })
            })
          } else {
            Api.ConfigNetWork.edit(this.ruleForm).then(row => {
              if (row.success) {
                this.$showSuccessMsg('编辑成功')
                this.buttonDisabled = true
                this.$refs[formName].resetFields()
                this.getList()
                this.centerDialogVisible = false
              } else {
                this.buttonDisabled = false
                this.$showErrorMsg(row.errMessage)
              }
            }).catch((e) => {
              this.buttonDisabled = false
              this.$showErrorMsg(e)
            })
          }
        }
      })
    },
    //取消
    resetForm(formName) {
      this.ruleForm.times = '' //强制清空
      this.$refs[formName].resetFields()
      this.centerDialogVisible = false
      this.buttonDisabled = false
    },
    //关闭
    closeDialog(type) {
      if (type) {
        this.ruleForm.times = '' //强制清空
        this.$refs[type].resetFields()
        this.buttonDisabled = false
      }
    },
    handleDept(val) {
      var obj = {} //多条件查找
      obj = this.deptNoList.find(function(item) {
        return item.deptNo === val
      })
      this.ruleForm.deptName = obj.deptName
    },
    timeChange(val) {
      this.ruleForm.startTime = val[0]
      this.ruleForm.endTime = val[1]
    },
    //=======================================>查询部分
    //列表页获取事业部门编码
    /* handleSelectDep(val) {
      this.deptNo = val.split('&')[0]
    },*/
    //获取事业部编码
    queryDept() {
      Api.BaseGoodsInfo.queryDept().then(row => {
        if (row.success) {
          this.deptNoList = row.data
        } else {
          this.$showErrorMsg(row.errMessage)
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
      })
    },
    //筛选供应商赋值
    handleBaseGoods(val) {
      if (val) {
        var obj = {} //多条件查找
        obj = this.BaseGoodsInfoList.find(function(item) {
          return item.supplierNo === val
        })
        this.supplierName = obj.supplierName
      } else {
        this.supplierName = ''
      }
    },
    //供应商列表获取
    baseSupplierInfo() {
      Api.BaseGoodsInfo.baseSupplierInfo().then(row => {
        if (row.success) {
          this.BaseGoodsInfoList = row.data
        } else {
          this.$showErrorMsg(row.errMessage)
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
      })
    },
    //列表查询
    handleQuery() {
      this.getList()
    },
    //重置
    handleRest() {
      this.deptNo = '' //事业部
      this.supplierNo = '' //供应商
      this.supplierName = '' //供应商
      this.getList()
    },
    //============================================>table 部分
    //全选反选
    handleSelectionChange(val) {
      this.multipleSelection = val
    },
    //分页条数改变
    sizeChange(val) {
      this.pageSize = val
      this.getList()
    },
    //翻页-----根据页码变换
    handleSizeChange(val) {
      this.pageNum = val
      this.getList()
    },
    getList() { //列表
      this.LoadingTable = true
      const params = {}
      params.pageNum = this.pageNum
      params.pageSize = this.pageSize
      params.deptNo = this.deptNo.split('&')[0]
      params.supplierName = this.supplierName
      Api.ConfigNetWork.listPage(params).then(row => {
        if (row.success) {
          for (let i = 0; i < row.data.length; i++) {
            row.data[i].supplierName = utils.htmlDecode(row.data[i].supplierName)
          }
          this.tableData = row.data
          this.totals = row.total
          this.LoadingTable = false
        } else {
          this.$showErrorMsg(row.errMessage)
        }
      }).catch((e) => {
        this.LoadingTable = false
        this.$showErrorMsg(e)
      })
    },
    //下载模版
    downloadTemplate() {
      const actionUrl = this.baseURL + Api.ConfigNetWork.downloadTemplate
      exportExcel(actionUrl)
    },
    //批量下载
    download() {
      const param = {}
      param.deptNo = this.deptNo.split('&')[0]
      param.supplierName = this.supplierName
      const actionUrl = this.baseURL + Api.ConfigNetWork.download
      exportExcel(actionUrl, param)
    },
    //批量上传
    /* uploadFileDate(formData) {
      Api.ConfigNetWork.uploadFile(formData).then(row => {
        this.$showSuccessMsg('上传成功')
      }).catch((e) => {
        this.$showErrorMsg(e)
      })
    },*/
    //手工删除
    handleDeled() {
      if (this.multipleSelection.length === 0) {
        this.$showErrorMsg('请选择数据')
        return
      }
      const crrId = []
      for (let i = 0; i < this.multipleSelection.length; i++) {
        crrId.push(this.multipleSelection[i].id)
      }
      this.delete(crrId)
    },
    //  删除方法
    delete(row) {
      this.$alert('<p style="font-size: 18px;color:#333">确认删除此条消息吗?</p><p style="font-size: 13px;color: #666">删除后，此条消息的相关内容信息将无法恢复</p>', '', {
        dangerouslyUseHTMLString: true,
        type: 'warning',
        center: true
      }).then(() => {
        Api.ConfigNetWork.delete(row).then(row => {
          if (row.success) {
            if (row.data.successCount > 0) {
              this.getList()
            }
            if (row.data.errorCount > 0) {
              this.dialogTableVisible = true
              this.gridData = row.data.detaileds
              this.moreErr = row.data.detaileds.length > 300 ? true : false
            } else {
              this.$showSuccessMsg('删除成功')
              this.getList()
            }
          } else {
            this.$showErrorMsg(row.errMessage)
          }
        }).catch((e) => { this.$showErrorMsg(e) })
      }).catch(() => {})
    }
  }
}
</script>

<style scoped lang="scss">
@import '@/assets/stylus/main';
  .masterData{
    width: 100%;
    .master-header{
      width: 100%;
      background: #fff;
      padding-bottom: 30px;
      border-radius: 0 4px 4px 4px;
      box-shadow: 2px 2px 7px 2px #ccc;
      .header-top{
        display: flex;
        align-items: center;
        margin-top: 30px;
        margin-bottom: 20px;
        .header-border{
          width: 2px;
          height: 12px;
          background: $--gl-blue;
          display: inline-block;
          margin-left: 24px;
          margin-right: 6px;
        }
        .header-title{
          font-weight: 600;
          font-size: 16px;
          line-height: 16px;
          color: #333;
        }
      }
      .header-select{
        display: flex;
        .select-content{
          padding-left: 24px;
          .content-title{
            margin-right: 10px;
            font-size: 14px;
            color: #333;
          }
        }
      }
      .header-button{
        padding-right: 24px;
        display: flex;
        justify-content: flex-end ;
      }
    }
    .master-container{
      width: 100%;
      background: #ffffff;
      margin-top: 20px;
      border-radius: 4px;
      box-shadow: 2px 2px 7px 2px #ccc;
      .container-top{
        width: 100%;
        padding: 20px 0;
        display: flex;
        justify-content: space-between;
        .container-top-left{
          line-height: 32px;
          .header-border{
            width: 2px;
            height: 12px;
            background: $--gl-blue;
            display: inline-block;
            margin-left: 24px;
            margin-right: 8px;
          }
          .header-title{
            font-weight: 600;
            font-size: 16px;
            color: #333;
          }
        }
        .container-top-right{
          padding-right: 24px;
          .button-upload{
            position: relative;
            overflow: hidden;
            input{
              position: absolute;
              top: 0;
              bottom: 0;
              left: 0;
              right: 0;
              opacity: 0;
            }
          }
        }
      }
      .container-table{
        width: 100%;
        padding-left: 24px;
        padding-right: 24px;
        padding-bottom: 30px;
        .container-table-cont{
          min-height: 300px;
          .table-look{
            cursor: pointer;
            color: $--gl-blue;
            font-size: 14px;
            font-weight: 500;
          }
          .table-button{
            display: flex;
            justify-content: space-around;
          }
          .table-p {
            //display: inline-block;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            cursor: pointer;
            padding-right: 15px;
            //border: 1px solid red;/**/
          }
        }

        .knowledge-pagination {
          width: 100%;
          margin-top: 20px;
          text-align: right;
        }

      }
    }
    .demo-ruleForm{
      .popup-container{
        overflow: hidden;
        width: 100%;
        margin-bottom: 20px;
        border-radius: 4px;
        border: 1px solid #E8E8E8;
        transition: all 0.3s ease;
        .pupop-container-title{
          width: 100%;
          height: 48px;
          background: #fafafa;
          display: flex;
          justify-content: space-between;
          align-items: center;
          span:nth-child(1){
            padding-left: 20px;
          }
          span:nth-child(2){
            cursor: pointer;
            padding-right: 20px;
            i{
              color: #999;
            }
          }
        }
        .popup-container-main{
          border-top: 1px solid #E8E8E8;
          width: 100%;
          padding:20px  20px 0 20px;
        }
      }
    }
  }
</style>
