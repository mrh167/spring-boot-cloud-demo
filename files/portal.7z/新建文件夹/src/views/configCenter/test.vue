<template>
  <div id="longPressButton" class="oneproduct-morebusiness">
    <ul v-for="m in 12">
      <span style="margin-right:40px;color:green">{{ m }}月</span>
      <li v-for="d in days" style="display:inline-block;width:40px;height:40px;" @click="selectDate(m,d)"> <span v-if="m === 2 && (d === 30 || d === 31) || m === 4 && d === 31" style="background:red"> {{ d }}</span> <span v-else> {{ d }}</span> </li>
    </ul>
  </div>
</template>

<script>

export default {
  name: 'OneProductMoreBusiness',
  data() {
    return {
      days: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31]
    }
  },
  mounted() {
    window.addEventListener('keydown', (ev) => {
      console.log(ev, '========')
      if (this.sync) return
      if (this.activeId !== null) {
        this.draggingIdArr.push(this.activeId)
        this.$set(
          this.controlsArr[this.currenSelectEleSub].layoutRegions, 'enabled', true
        )
      }
      if (ev.keyCode === 17) {
        this.sync = true
      }
    })
    window.addEventListener('keyup', (ev) => {
      if (ev.keyCode === 17) {
        this.sync = false
      }
    })
  },
  methods: {
    
    selectDate(m, d) {
      console.log(m + '月' + d + '日')
    }
    
  }
}
</script>
<style lang="scss">
  .table-p {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    cursor: pointer;
    padding-right: 10px;
  }
  .oneproduct-morebusiness {
    .custom-item {
      .lui-date-editor .lui-range-separator {
        width: 12%;
      }
      .lui-input-number .lui-input__inner {
        -webkit-appearance: none;
        padding-left: 0;
        padding-right: 0;
        text-align: left;
      }
      .lui-input-number__decrease,
      .lui-input-number__increase {
        width: 16px;
      }
    }
    .lui-table__header {
      th:nth-of-type(10) {
        .cell {
          padding: 0;
          line-height: 0;
          div{
          line-height: 23px;
          }
        }
      }
    }
    .custom-table_row {
      td:nth-of-type(10) {
        padding: 0;
        .cell {
          padding-left: 0;
          .lui-row_wrap:last-of-type {
            .lui-row {
              border-bottom: 0 !important;
            }
          }
        }
      }
    }
  }
</style>
<style lang="scss" scoped>
@import '@/assets/stylus/main';
  .oneproduct-morebusiness {
    min-height: 600px;
    .header-title {
      font-size: 16px;
      font-weight: 600;
      color: #333333;
      letter-spacing: 0;
      line-height: 16px;
      .line {
        margin: 2px 6px 0 0;
        width: 2px;
        height: 12px;
        background: $--gl-blue;
        border-radius: 2px;
      }
    }
    .header {
      background: #fff;
      padding: 30px 24px;
      box-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.1);
      border-radius: 0 4px 4px 4px;
      .search-box {
        margin-top: 20px;
        display: flex;
        justify-content: space-between;
        .label {
          font-size: 14px;
          height: 32px;
          line-height: 32px;
          margin-right: 12px;
        }
        .lui-select,
        .lui-input {
          width: 250px;
        }
      }
    }
    .custom-table {
      margin-top: 20px;
      background: #fff;
      padding: 0 24px;
      box-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.1);
      border-radius: 4px;
      .table-header {
        display: flex;
        justify-content: space-between;
        padding: 20px 0;
        .header-title {
          height: 32px;
          line-height: 32px;
          .line {
            margin: 10px 6px 0 0;
          }
        }
      }
    }
    .footer {
      padding: 20px 0 30px 0;
      text-align: right;
    }
    .custom-dialog{
      .dialog-mask{
        width: 100%;
        height: 100%;
        position: absolute;
        top: 0;
        left: 0;
        background: rgba(0,0,0,.5);
        opacity: 0.5;
        z-index: 10;
      }
      .custom-header{
        height: 40px;
        line-height: 40px;
        padding: 0 12px;
        background: #f3f7fa;
        .label {
          float: left;
          color: #666666;
          font-size: 12px;
        }
      }
      .custom-item {
        padding: 8px 12px;
        border-bottom: 1px solid #e0e0e0;
        .lui-icon-remove-outline {
          cursor: pointer;
          width: 24px;
          margin-left: 24px;
          color: $--gl-blue;
          font-size: 17px;
          opacity: 0.5;
        }
        .add-factory {
          z-index: 10;
          width: 500px;
          max-height: 353px;
          overflow-y: auto;
          position: absolute;
          bottom: 34px;
          left: -318px;
          background: #fff;
          box-shadow: 0 0 10px 0 rgba(0, 0, 0, 0.1);
          border-radius: 4px;
          .dialog-footer {
            display: inline-block;
            padding: 10px 20px;
            width: 100%;
            text-align: right;
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
          }
        }
      }
      .add-suppliers {
        font-size: 14px;
        color: $--gl-blue;
        height: 48px;
        line-height: 48px;
        text-align: center;
        border-bottom: 1px solid #e0e0e0;
        span {
          cursor: pointer;
          user-select:none;
          -moz-user-select:none; /*火狐*/
          -webkit-user-select:none; /*webkit浏览器*/
          -ms-user-select:none; /*IE10*/
        }
      }
    }
  }
</style>
