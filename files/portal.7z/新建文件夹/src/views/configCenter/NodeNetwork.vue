<template>
  <div class="node-network">
    <div class="header">
      <div class="header-title">
        <div class="line left"></div>
        筛选项
      </div>
      <div class="search-box">
        <div class="header-left">
          <lui-form :inline="true">
            <lui-form-item label="事业部" class="cust-item">
              <lui-select
                v-model="deptNo"
                clearable
                value-key="deptNo"
                placeholder="请选择事业部">
                <lui-option
                  v-for="item in deptOptions"
                  :key="item.deptNo"
                  :value="item"
                  :label="item.deptName">
                </lui-option>
              </lui-select>
            </lui-form-item>
            <lui-form-item label="配出库节点类型" class="cust-item">
              <lui-select
                v-model="nodeType"
                clearable
                placeholder="请选择配出库节点类型">
                <lui-option
                  v-for="item in nodeTypeOpt"
                  :key="item.code"
                  :label="item.name"
                  :value="item.code">
                </lui-option>
              </lui-select>
            </lui-form-item>
            <lui-form-item label="配出库节点">
              <lui-autocomplete v-model.trim="parentNode" :fetch-suggestions="querySearchAsync" placeholder="请输入配出库节点" :maxlength="50"></lui-autocomplete>
              <!-- <lui-input
                v-model.trim="parentNode"
                placeholder="请输入配出库节点"
                clearable>
              </lui-input> -->
            </lui-form-item>
          </lui-form>
        </div>
        <div class="header-right">
          <lui-button
            v-waves
            type="primary"
            @click="query">查询</lui-button>
          <lui-button
            v-waves
            @click="handleRest">重置</lui-button>
        </div>
      </div>
    </div>
    <div class="custom-table">
      <div class="table-header">
        <div class="header-title">
          <div class="line left"></div>
          数据列表
        </div>
        <div>
          <lui-button
            v-waves
            type="primary"
            @click="downloadClick">批量下载</lui-button>
          <button-list
            ref="buttons"
            :buttons="buttons"
            :configdept-no="deptNo.deptNo"
            :configdept-name="deptNo.deptName"
            :check-dept-no="checkDeptNo"
            @uploadSuccess="postListPage">
          </button-list>
          <lui-button
            v-waves
            type="primary"
            @click="deleteWarehouseRelation">手工删除</lui-button>
          <lui-button
            v-waves
            type="primary"
            @click="handleAdd()">手工添加</lui-button>
        </div>
      </div>
      <lui-table
        v-loading="LoadingTable"
        :data="tableData"
        border
        row-class-name="custom-table_row"
        style="width: 100%"
        @selection-change="handleSelectionChange">
        <template slot="empty">
          <showEmptyImage></showEmptyImage>
        </template>
        <lui-table-column
          type="selection"
          fixed="left"
          align="center"
          width="50">
        </lui-table-column>
        <lui-table-column
          prop="deptNo"
          label="事业部编码"
          show-overflow-tooltip
          min-width="170">
        </lui-table-column>
        <lui-table-column
          prop="deptName"
          label="事业部名称"
          show-overflow-tooltip
          min-width="170">
        </lui-table-column>
        <lui-table-column
          prop="sellerNo"
          show-overflow-tooltip
          label="商家编码"
          min-width="170">
        </lui-table-column>
        <lui-table-column
          prop="parentNodeName"
          label="配出库节点名称"
          show-overflow-tooltip
          min-width="170">
        </lui-table-column>
        <lui-table-column
          prop="parentNodeType"
          show-overflow-tooltip
          label="配出库节点类型"
          min-width="170">
          <template slot-scope="scope">
            <span>{{ formatNodeName(scope.row.parentNodeType) }}</span>
            <!-- <span v-if="row.parentNodeType == 1">供应商（工厂）</span>
            <span v-if="row.parentNodeType == 2">区域仓</span>
            <span v-if="row.parentNodeType == 3">前置仓</span>
            <span v-if="row.parentNodeType == 4">门店</span>
            <span v-if="row.parentNodeType == 5">中央仓</span>
            <span v-if="row.parentNodeType == 6">销售门店</span>
            <span v-if="row.parentNodeType == 7">非销售门店</span>
            <span v-if="row.parentNodeType == 8">虚拟工厂</span>
            <span v-if="row.parentNodeType == 9">虚拟CDC</span> -->
          </template>
        </lui-table-column>
        <lui-table-column
          prop="maxOutRate"
          label="最大可配出比"
          show-overflow-tooltip
          min-width="170">
        </lui-table-column>
        <lui-table-column
          prop="minStockInventory"
          label="最小周转天数"
          show-overflow-tooltip
          min-width="110">
        </lui-table-column>
        <lui-table-column
          prop="allocationTypeName"
          label="分配策略"
          show-overflow-tooltip
          min-width="110">
        </lui-table-column>

        <lui-table-column
          prop="maxReserveRatio"
          label="最大库存预留比例"
          show-overflow-tooltip
          min-width="150">
        </lui-table-column>
        <lui-table-column
          prop="isNationwideTurnover"
          show-overflow-tooltip
          label="是否全国周转"
          min-width="110">
          <template v-slot="{row}">
            <span>{{ row.isNationwideTurnover ? '是' : '否' }}</span>
          </template>
        </lui-table-column>
    
        <lui-table-column
          prop=""
          fixed="right"
          width="100"
          label="操作">
          <template slot-scope="{row}">
            <lui-popover
              placement="right"
              width="650"
              :popper-class="nodeList.length > 8 ? 'custom-popover' : ''"
              trigger="click">
              <lui-table :data="nodeList">
                <lui-table-column min-width="120" property="nodeName" label="配入库节点名称"></lui-table-column>
                <lui-table-column min-width="120" property="nodeType" label="配入库节点类型">
                  <template slot-scope="scope">
                    <span>{{ formatNodeName(scope.row.nodeType) }}</span>
                  </template>
                </lui-table-column>
                <lui-table-column min-width="70" property="priorityLevel" label="优先级" align="center">
                  <template slot-scope="scope">
                    <span>{{ scope.row.priorityLevel ? scope.row.priorityLevel : '--' }}</span>
                  </template>
                </lui-table-column>
                <lui-table-column min-width="100" property="updateUser" label="修改人"></lui-table-column>
                <lui-table-column min-width="160" property="updateTime" label="修改时间"></lui-table-column>
              </lui-table>
              <lui-button slot="reference" type="text" @click="getDetails(row)">详情</lui-button>
            </lui-popover>
            <lui-button type="text" style="margin-left: 10px;" @click="handleEdit(row)">编辑</lui-button>
          </template>
        </lui-table-column>
      </lui-table>
      <div class="footer">
        <lui-pagination
          v-show="tableData.length>0"
          background
          :page-size="pageSize"
          :current-page="pageNum"
          :page-sizes="[10, 20, 50, 70, 100]"
          layout=" prev, pager, next, sizes, jumper"
          :total="total"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange">
        </lui-pagination>
      </div>
      <lui-dialog
        :title="isEdit ? '编辑库节点网络配置' : '添加库节点网络配置'"
        class="custom-dialog"
        :close-on-click-modal="false"
        :visible.sync="dialogVisible"
        width="700px">
        <div v-if="dialogMask" class="dialog-mask"></div>
        <lui-form ref="ruleForm" :model="ruleForm" :rules="rules">
          <lui-form-item label="事业部" prop="deptNo" label-width="136px">
            <lui-select
              v-model="ruleForm.deptNo"
              :disabled="isEdit"
              style="width:100%"
              placeholder="请选择事业部"
              @change="changeSelectDept">
              <lui-option
                v-for="item in deptOptions"
                :key="item.id"
                :label="item.deptName"
                :value="item.deptNo">
              </lui-option>
            </lui-select>
          </lui-form-item>
          <lui-form-item label="配出库节点" prop="parentNodeNo" label-width="136px">
            <lui-select
              v-model="ruleForm.parentNodeNo"
              :disabled="isEdit"
              style="width:100%"
              placeholder="请选择配出库节点"
              value-key="nodeNo"
              @change="changeSelectParentNode">
              <lui-option
                v-for="(item,i) in parentNodeOpt"
                :key="i"
                :label="item.nodeName"
                :value="item">
              </lui-option>
            </lui-select>
          </lui-form-item>
          <lui-form-item label="是否上游生产数据" style="width:50%;display:inline-block" prop="allowedAllocation" label-width="136px">
            <lui-select
              v-model="ruleForm.allowedAllocation"
              placeholder="请选择是否上游生产数据">
              <lui-option
                v-for="(item, index) in allowedAllocationOpt"
                :key="index"
                :label="item.label"
                :value="item.value">
              </lui-option>
            </lui-select>
          </lui-form-item>
          <lui-form-item label="分配规则" style="width:50%;display:inline-block" prop="allocationType" label-width="136px">
            <lui-select
              v-model="ruleForm.allocationType"
              placeholder="请选择分配规则"
              @change="changeRules">
              <lui-option
                v-for="(item, index) in allocationTypeOpt"
                :key="index"
                :label="item.name"
                :value="item.code">
              </lui-option>
            </lui-select>
          </lui-form-item>
          <lui-form-item v-if="ruleForm.allocationType === 5" label="超100%分配" style="width:50%;display:inline-block" prop="is100Allot" label-width="136px">
            <lui-radio-group v-model="ruleForm.is100Allot" controls-position="right">
              <lui-radio :label="1" class="button_radio">是</lui-radio>
              <lui-radio :label="0" class="button_radio">否</lui-radio>
            </lui-radio-group>
          </lui-form-item>
          <lui-form-item label="最大可配出比" style="width:50%;display:inline-block" prop="maxOutRate" label-width="136px">
            <lui-input-number
              v-model.trim="ruleForm.maxOutRate"
              :min="0.01"
              :max="100"
              :precision="2"
              controls-position="right"
            >
            </lui-input-number>
          </lui-form-item>
          <lui-form-item label="最低周转天数" style="width:50%;display:inline-block" prop="minStockInventory" label-width="136px">
            <lui-input-number
              v-model.trim="ruleForm.minStockInventory"
              :min="0.01"
              :precision="2"
              controls-position="right"
            >
            </lui-input-number>
          </lui-form-item>

          <lui-form-item label="最大库存预留比例" style="width:50%;display:inline-block" prop="maxReserveRatio" label-width="136px">
            <lui-input-number
              v-model.trim="ruleForm.maxReserveRatio"
              :precision="2"
              :step="1"
              :max="100"
              :min="0"
              controls-position="right"
            >
            </lui-input-number>
          </lui-form-item>

          <lui-form-item label="是否全国周转" style="width:50%;display:inline-block" prop="isNationwideTurnover" label-width="136px">
            <lui-radio-group v-model="ruleForm.isNationwideTurnover" controls-position="right">
              <lui-radio :label="1" class="button_radio">是</lui-radio>
              <lui-radio :label="0" class="button_radio">否</lui-radio>
            </lui-radio-group>
          </lui-form-item>

          <lui-form-item
            label-width="">
            <span slot="label"><i style="color: #E1251B;margin-right: 4px;">*</i>是否启用最大可配出比分配规则</span>
            <lui-radio
              v-model="ruleForm.openRuleType"
              label="1">是</lui-radio>
            <lui-radio
              v-model="ruleForm.openRuleType"
              label="0">否</lui-radio>
          </lui-form-item>

          <div v-if="ruleForm.openRuleType === '1'">
            <lui-form-item label="对门店最大可分配占比" label-width="160px">
              <lui-input-number
                v-model.trim="ruleForm.shopRatio"
                :precision="2"
                :step="1"
                :max="100"
                :min="0"
                controls-position="right"
              >
              </lui-input-number>
            </lui-form-item>

            <lui-form-item label="对FDC最大可分配占比" label-width="160px">
              <lui-input-number
                v-model.trim="ruleForm.fdcRatio"
                :precision="2"
                :step="1"
                :max="100"
                :min="0"
                controls-position="right"
              >
              </lui-input-number>
            </lui-form-item>

            <lui-form-item label="对RDC最大可分配占比" label-width="160px">
              <lui-input-number
                v-model.trim="ruleForm.rdcRatio"
                :precision="2"
                :step="1"
                :max="100"
                :min="0"
                controls-position="right"
              >
              </lui-input-number>
            </lui-form-item>
          </div>

          <div>
            <div class="custom-header">
              <div class="label" style="width:240px;margin-left:19px">配入库节点</div>
              <div
                v-show="ruleForm.allocationType === 1"
                class="label"
                style="margin-left:90px">
                优先级
              </div>
              <div
                class="label"
                style="width:24px;position: absolute;right: 68px;">操作</div>
            </div>
            <draggable
              v-model="nodeList"
              :move="getdata"
              @update="datadragEnd">
              <div
                v-for="(item,index) in nodeList"
                :key="index"
                class="custom-item">
                <lui-select
                  v-model="item.nodeNo"
                  style="width:240px;margin-left:19px"
                  placeholder="请选择配入库节点"
                  @change="changeSelectNode"
                >
                  <lui-option
                    v-for="(obj, k) in options"
                    :key="k"
                    :label="obj.nodeName"
                    :disabled="obj.disabled"
                    :value="obj.nodeNo">
                  </lui-option>
                </lui-select>
                <div v-show="ruleForm.allocationType === 1" style="width:36px;text-align:center;display:inline-block;margin-left:90px;">{{ index + 1 }}</div>
                <div class="operation">
                  <lui-tooltip
                    popper-class="custom-tooltip"
                    effect="dark"
                    :visible-arrow="false"
                    content="上移"
                    placement="top">
                    <img class="moveup" src="@/assets/svg/moveup.svg" alt="" @click="moveUp(index, item)">
                  </lui-tooltip>
                  <lui-tooltip
                    popper-class="custom-tooltip"
                    effect="dark"
                    :visible-arrow="false"
                    content="删除"
                    placement="top">
                    <img class="remove" src="@/assets/svg/remove.svg" alt="" @click="removeNode(item,index)">
                  </lui-tooltip>
                </div>
              </div>
            </draggable>
            <div class="add-nodeList">
              <span @click="addNode">
                <i class="lui-icon-plus"></i> 增加配入库节点
              </span>
            </div>
          </div>

        </lui-form>
        <span
          slot="footer"
          class="dialog-footer">
          <lui-button @click="resetForm('ruleForm')">取 消</lui-button>
          <lui-button
            :disabled="buttonDisabled"
            :loading="buttonDisabled"
            type="primary"
            @click="submitForm('ruleForm')">{{ buttonDisabled ? '提交中' : '确 定' }} </lui-button>
        </span>
      </lui-dialog>
    </div>
    <lui-dialog
      class="error-dialog"
      title="删除失败"
      :visible.sync="dialogTableVisible"
      :close-on-click-modal="false">
      <div class="dialog-table-list">
        <div
          v-show="moreErr"
          style="color: red;font-size: 12px">异常太多，最多显示300条</div>
        <lui-table
          stripe
          size="mini"
          :data="gridData">
          <lui-table-column
            align="center"
            property="msg"
            label="异常原因">
            <template slot-scope="{row}">
              {{ row.msg }}
            </template>
          </lui-table-column>
        </lui-table>
      </div>
    </lui-dialog>
  </div>
</template>

<script>
import draggable from 'vuedraggable'
import Api from '@/api/index'
import Http from '@/lib/http'
import { exportExcel } from '@/utils/downloadRequest'
import ButtonList from '@/views/common/ButtonList'
import showEmptyImage from '@/components/common/showEmptyImage/index.vue'

const buttons = {
  upload: {
    noAsync: true,
    maxM: 10,
    uploadtips: '只能上传xlsx文件，文件大小不超过10M。',
    uploadtipsadd: '',
    uploadConfig: {
      uploadActionUrl: Http.baseContextUrl + 'warehouseRelation/batchUpload'
    },
    templateUrl: Http.baseContextUrl + 'warehouseRelation/downloadTemplate'
  }
  // fileName: 'userInfoFile'
}

export default {
  name: 'NodeNetwork',
  components: {
    ButtonList,
    showEmptyImage,
    draggable
  },
  data() {
    return {
      gridData: [],
      moreErr: false,
      dialogTableVisible: false, //删除错误提示
      buttons,
      isEclp: false,
      buttonDisabled: false,
      LoadingTable: false,
      checkDeptNo: true, //默认false表示不上传事业部
      dialogVisible: false,
      dialogMask: false,
      isEdit: false,
      baseURL: Http.baseContextUrl,
      options: [],
      deptNo: '',
      parentNode: '',
      deptOptions: [],
      factoryValue: '',
      factoryOptions: [],
      tableData: [],
      total: 0,
      pageSize: 10,
      pageNum: 1,
      id: '',
      ruleForm: {
        deptNo: '',
        parentNodeNo: '',
        maxOutRate: 0.01,
        minStockInventory: 0.01,
        allowedAllocation: '',
        allocationType: '',
        maxReserveRatio: null,
        isNationwideTurnover: 0,
        openRuleType: '0',
        shopRatio: '',
        fdcRatio: '',
        rdcRatio: '',
        is100Allot: 0
      },
      nodeType: '',
      nodeTypeOpt: [],
      parentNodeOpt: [],
      allowedAllocationOpt: [
        {
          value: 1,
          label: '是'
        },
        {
          value: 0,
          label: '否'
        }
      ],
      allocationTypeOpt: [
        {
          code: 1,
          name: '优先级'
        },
        {
          code: 2,
          name: '配比'
        },
        {
          code: 3,
          name: '未来可售天数'
        }],
      strategyType: '1',
      rules: {
        deptNo: [
          { required: true, message: '请选择事业部', trigger: 'change' }
        ],
        parentNodeNo: [
          { required: true, message: '请选择配出库节点', trigger: 'change' }
        ],
        allowedAllocation: [
          { required: true, message: '请选择是否上游生产数据', trigger: 'change' }
        ],
        allocationType: [
          { required: true, message: '请选择分配规则', trigger: 'change' }
        ],
        maxOutRate: [
          { required: true, message: '最大可配出比不能为空', trigger: 'change' }
        ],
        minStockInventory: [
          { required: true, message: '最低周转天数不能为空', trigger: 'change' }
        ],
        maxReserveRatio: [
          { required: false, message: '最大库存预留比例(0-100) %', trigger: 'change' }
        ],
        isNationwideTurnover: [
          { required: true, message: '是否全国周转', trigger: 'change' }
        ],
        is100Allot: [
          { required: true, message: '请选择超100%分配', trigger: 'change' }
        ]
      },
      multipleSelection: [],
      nodeList: [], //库节点
      nodes: [], //库节点副本
      nodeTypeList: []
    }
  },
  mounted() {
    this.postListPage()
    this.queryDept()//事业部列表
    this.panelData()//库节点类型
    this.postConstantRules()//分配规则
  },
  methods: {
    formatNodeName(nodeType) {
      let nodeName = ''
      for (let i in this.nodeTypeList) {
        if (nodeType === this.nodeTypeList[i].code) {
          nodeName = this.nodeTypeList[i].name
          break
        }
      }
      return nodeName
    },
    //模糊搜索
    querySearchAsync(queryString, cb) {
      Api.ConfigCenter.postKeywords({
        'displayFields': ['parentNodeNo', 'parentNodeName'], //返回字段
        'keyWords': ['parentNodeName'], //查询字段名称
        'rout': 'nodeNetwork',
        'value': this.parentNode //关键字
      }).then((res) => {
        if (res.success) {
          var results = res.data
          results.forEach(item => {
            item.value = item.parentNodeName
          })
          cb(results)
        }
      }).catch((e) => {
        console.error(e)
      })
    },
    //选择分配规则
    changeRules(val) {
      if (val !== 1) { //清空优先级
        this.nodeList.forEach(item => {
          item.priorityLevel = ''
        })
      }
      if (val !== 5) {
        this.ruleForm.is100Allot = ''
      }
    },
    moveUp(index, item) {
      //在上一项插入该项
      this.nodeList.splice(index - 1, 0, (this.nodeList[index]))
      //删除后一项
      this.nodeList.splice(index + 1, 1)
      if (index === 0) {
        this.$showErrorMsg('到顶啦！')
      }
    },
    getdata(evt) {
      //这里evt后续的内容根据具体的定义变量而定
    },
    datadragEnd(evt) {
    },
    query() {
      this.pageNum = 1
      this.postListPage()
    },
    handleRest() {
      this.deptNo = ''
      this.nodeType = ''
      this.parentNode = ''
      this.postListPage()
    },
    panelData() {
      Api.BasicInfo.constantNodeType().then(row => {
        if (row.success) {
          this.nodeTypeList = row.data
          row.data.forEach(item => {
            if (item.code !== 4) { //去掉门店
              this.nodeTypeOpt.push(item)
            }
          })
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
      })
    },
    changeSelectDept() {
      //选择事业部时清空内容
      this.ruleForm.parentNodeNo = ''
      this.nodeList = []
      this.postNodeList()
      this.postParentNodeList()
    },
    changeSelectParentNode(val) {
      //选择配出库节点时重置配入库节点
      this.nodeList = []
      //根据事业部和配出库类型查询配入库节点下拉选
      // this.postNodeList({ deptNo: val.deptNo }, val.nodeType)
    },
    //选择库节点 已选库节点置灰校验
    changeSelectNode() {
      for (var i in this.options) {
        for (var j in this.nodeList) {
          if (this.nodeList[j].nodeNo === this.options[i].nodeNo) {
            this.options[i].disabled = true
            break
          } else {
            this.options[i].disabled = false
          }
        }
      }
    },
    removeNode(item, index) {
      this.nodeList.splice(index, 1)
      this.changeSelectNode()//校验已选置灰
    },
    addNode() {
      this.$refs['ruleForm'].validate((valid) => {
        if (valid) {
          this.nodeList.push({
            nodeNo: '',
            priorityLevel: 0
          })
        }
      })
      this.nodes = JSON.parse(JSON.stringify(this.nodeList))
      this.changeSelectNode()//校验已选置灰
    },
    handleSelectionChange(val) {
      const selectData = val
      this.multipleSelection = []
      selectData.forEach(item => {
        this.multipleSelection.push({
          'deptNo': item.deptNo,
          'parentNodeNo': item.parentNodeNo
        })
      })
    },
    //库节点分配规则
    postConstantRules() {
      Api.NodeNetwork.postConstantRules().then((res) => {
        if (res.success) {
          this.allocationTypeOpt = res.data
        } else {
          this.$showErrorMsg(res.errMessage)
        }
      }).catch((e) => {
        console.log(e)
      })
    },
    //==========================================================>查看详情
    getDetails(row) {
      Api.NodeNetwork.getDetails(
        { 'deptNo': row.deptNo, 'parentNodeNo': row.parentNodeNo }
      ).then((res) => {
        if (res.success) {
          this.nodeList = res.data.nodeList
        } else {
          this.$showErrorMsg(res.errMessage)
        }
      }).catch((e) => {
        console.error(e)
      })
    },
    deleteWarehouseRelation() {
      if (!this.multipleSelection.length) {
        this.$message.error('请选择数据')
        return
      }
      this.$alert('<p style="font-size: 18px;color:#333">确认删除此条消息吗?</p><p style="font-size: 13px;color: #666">删除后，此条消息的相关内容信息将无法恢复</p>', '', {
        dangerouslyUseHTMLString: true,
        type: 'warning',
        center: true
      }).then(() => {
        this.LoadingTable = true
        Api.NodeNetwork.deleteWarehouseRelation(
          { delList: this.multipleSelection }
        ).then((res) => {
          if (res.success) {
            this.$showSuccessMsg('删除成功')
            this.postListPage()
          }
        }).catch((e) => {
          this.LoadingTable = false
          this.$showErrorMsg(e)
        })
      }).catch(() => {
        this.LoadingTable = false
      })
    },
    handleAdd() {
      this.id = ''
      this.isEdit = false
      this.options = []
      this.nodeList = []
      this.parentNodeOpt = []
      this.ruleForm.deptNo = ''
      this.ruleForm.parentNodeNo = ''
      this.ruleForm.allowedAllocation = ''
      this.ruleForm.allocationType = ''
      this.ruleForm.maxOutRate = 0.01
      this.ruleForm.minStockInventory = 0.01
      this.ruleForm.maxReserveRatio = null
      this.ruleForm.isNationwideTurnover = null
      this.ruleForm.isNationwideTurnover = 0
      this.ruleForm.openRuleType = '0'
      this.ruleForm.shopRatio = 0
      this.ruleForm.fdcRatio = 0
      this.ruleForm.rdcRatio = 0
      this.ruleForm.is100Allot = ''
      this.dialogVisible = true
      this.$nextTick(() => {
        this.$refs['ruleForm'].clearValidate()
      })
    },
    handleEdit(row) {
      this.nodeList = []
      if (row) {
        this.id = row.id
        this.getDetails(row)//查看库节点
        this.isEdit = true
        this.ruleForm.deptNo = row.deptNo
        this.ruleForm.parentNodeNo = { nodeNo: row.parentNodeNo, nodeName: row.parentNodeName, nodeType: row.parentNodeType, deptNo: row.deptNo }
        this.ruleForm.allowedAllocation = row.allowedAllocation
        this.ruleForm.allocationType = row.allocationType
        this.ruleForm.maxOutRate = row.maxOutRate
        this.ruleForm.minStockInventory = row.minStockInventory
        this.ruleForm.isNationwideTurnover = row.isNationwideTurnover
        this.ruleForm.maxReserveRatio = row.maxReserveRatio
        this.ruleForm.openRuleType = row.openRuleType + ''
        this.ruleForm.shopRatio = row.shopRatio
        this.ruleForm.fdcRatio = row.fdcRatio
        this.ruleForm.rdcRatio = row.rdcRatio
        this.ruleForm.is100Allot = row.is100Allot
        this.dialogVisible = true
        this.postNodeList()
        this.postOutNodes()//配出库节点
        this.$nextTick(() => {
          this.$refs['ruleForm'].clearValidate()
        })
      }
    },
    //查询列表
    postListPage() {
      this.LoadingTable = true
      Api.NodeNetwork.postListPage(
        {
          deptNos: this.deptNo.deptNo ? [this.deptNo.deptNo] : [],
          parentNode: this.parentNode,
          parentNodeType: this.nodeType,
          pageNum: this.pageNum,
          pageSize: this.pageSize
        }
      ).then((res) => {
        if (res.success) {
          this.tableData = res.data
          this.total = res.total
          this.LoadingTable = false
        } else {
          this.$showErrorMsg(res.errMessage)
          this.LoadingTable = false
        }
      }).catch((e) => {
        this.LoadingTable = false
        this.$showErrorMsg(e)
      })
    },
    //配出库节点添加，过滤掉已添加
    postParentNodeList() {
      Api.NodeNetwork.postParentNodeList({
        deptNo: this.ruleForm.deptNo
      }).then((res) => {
        if (res.success) {
          this.parentNodeOpt = []
          if (res.data) {
            res.data.forEach(item => {
              this.parentNodeOpt.push({ nodeNo: item.nodeNo, nodeName: item.nodeName, nodeType: item.nodeType, deptNo: item.deptNo })
            })
          }
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
      })
    },
    downloadClick() {
      const multipleSelection = []
      this.tableData.forEach(item => {
        multipleSelection.push({
          deptNo: item.deptNo,
          parentNodeNo: item.parentNodeNo
        })
      })
      const actionUrl = `${this.baseURL}warehouseRelation/download`
      const params = { delList: multipleSelection }
      exportExcel(actionUrl, params)
    },
    //添加
    createWarehouseRelation() {
      this.nodeList.forEach((item, index) => {
        item.priorityLevel = index + 1
      })
      const formData = {
        'allocationType': this.ruleForm.allocationType,
        'allowedAllocation': this.ruleForm.allowedAllocation,
        'deptNo': this.ruleForm.deptNo,
        'maxOutRate': this.ruleForm.maxOutRate,
        'minStockInventory': this.ruleForm.minStockInventory,
        'nodeList': this.nodeList,
        'parentNodeNo': this.ruleForm.parentNodeNo.nodeNo,
        'maxReserveRatio': this.ruleForm.maxReserveRatio,
        'isNationwideTurnover': this.ruleForm.isNationwideTurnover,
        'openRuleType': this.ruleForm.openRuleType,
        'shopRatio': this.ruleForm.shopRatio,
        'fdcRatio': this.ruleForm.fdcRatio,
        'rdcRatio': this.ruleForm.rdcRatio,
        'is100Allot': this.ruleForm.is100Allot
      }
      Api.NodeNetwork.createWarehouseRelation(formData).then((res) => {
        if (res.success) {
          this.dialogVisible = false
          this.buttonDisabled = false
          this.postListPage()
          this.$message({
            type: 'success',
            message: '添加成功'
          })
        } else {
          this.buttonDisabled = false
          this.$message.error(res.errMessage)
        }
      }).catch((e) => {
        this.buttonDisabled = false
        this.$showErrorMsg(e)
      })
    },
    //编辑
    editWarehouseRelation() {
      this.nodeList.forEach((item, index) => {
        item.priorityLevel = index + 1
      })
      const formData = {
        'allocationType': this.ruleForm.allocationType,
        'allowedAllocation': this.ruleForm.allowedAllocation,
        'deptNo': this.ruleForm.deptNo,
        'maxOutRate': this.ruleForm.maxOutRate,
        'minStockInventory': this.ruleForm.minStockInventory,
        'nodeList': this.nodeList,
        'parentNodeNo': this.ruleForm.parentNodeNo.nodeNo,
        'maxReserveRatio': this.ruleForm.maxReserveRatio,
        'isNationwideTurnover': this.ruleForm.isNationwideTurnover,
        'openRuleType': this.ruleForm.openRuleType,
        'shopRatio': this.ruleForm.shopRatio,
        'fdcRatio': this.ruleForm.fdcRatio,
        'rdcRatio': this.ruleForm.rdcRatio,
        'is100Allot': this.ruleForm.is100Allot
      }
      Api.NodeNetwork.editWarehouseRelation(formData).then((res) => {
        if (res.success) {
          this.dialogVisible = false
          this.buttonDisabled = false
          this.postListPage()
          this.$message({
            type: 'success',
            message: '编辑成功'
          })
        } else {
          this.buttonDisabled = false
          this.$message.error(res.errMessage)
        }
      }).catch((e) => {
        this.buttonDisabled = false
        this.$showErrorMsg(e)
      })
    },
    //配出库节点回显
    postOutNodes() {
      Api.BasicInfo.postList({ deptNo: this.ruleForm.deptNo }).then((res) => {
        if (res.success) {
          this.parentNodeOpt = []
          res.data.forEach(item => {
            this.parentNodeOpt.push({ nodeNo: item.nodeNo, nodeName: item.nodeName, nodeType: item.nodeType })
          })
        }
      }).catch((e) => {
        console.error(e)
      })
    },
    //配入库节点列表
    postNodeList() {
      //1.工厂 2.区域仓 3.前置仓 4.门店 5.中央仓
      Api.BasicInfo.postList({ deptNo: this.ruleForm.deptNo }).then((res) => {
        if (res.success) {
          // const arrOpt = []
          this.options = []
          res.data.forEach(item => { //配入不包括工厂，配出不包括门店
            if (item.nodeType !== 1) {
              // item.disabled = true
              this.options.push(item)
            }
          })
          // arrOpt.forEach(el => {
          //   if (type === 1) { //配出为工厂时可选：区域仓 前置仓 门店 中央仓
          //     this.options = arrOpt
          //   } else if (type === 2 && (el.nodeType === 3 || el.nodeType === 4)) { //配出为区域仓时可选：前置仓 门店
          //     this.options.push(el)
          //   } else if (type === 3 && el.nodeType === 4) { //配出为前置仓时可选：门店
          //     this.options.push(el)
          //   } else if (type === 5 && el.nodeType !== 5) { //配出为中央仓时可选：区域仓 前置仓 门店
          //     this.options.push(el)
          //   }
          // })
          this.changeSelectNode()//校验已选置灰
        }
      }).catch((e) => {
        console.error(e)
      })
    },
    //事业部列表
    queryDept() {
      Api.BaseGoodsInfo.queryDept().then((res) => {
        if (res.success) {
          this.deptOptions = res.data
        }
      }).catch((e) => {
        console.error(e)
      })
    },
    handleSizeChange(val) {
      this.pageSize = val
      this.postListPage()
    },
    handleCurrentChange(val) {
      this.pageNum = val
      this.postListPage()
    },
    //校验库节点
    checkoutNodes() {
      if (!this.nodeList.length) {
        this.$showErrorMsg('库节点不能为空')
        return false
      }
      for (let j = 0; j < this.nodeList.length; j++) {
        if (!this.nodeList[j].nodeNo) {
          this.$showErrorMsg('库节点不能为空')
          return false
        }
      }
     
      if (this.ruleForm.openRuleType === '1') {
        let sum = this.ruleForm.shopRatio + this.ruleForm.fdcRatio + this.ruleForm.rdcRatio
        if (sum > 100) {
          this.$showErrorMsg('门店+FDC+RDC最大可分配占比总和不能大于100')
          return false
        }
      } else {
        this.ruleForm.shopRatio = 0
        this.ruleForm.fdcRatio = 0
        this.ruleForm.rdcRatio = 0
      }
      return true
    },
    //提交
    submitForm(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          if (!this.checkoutNodes()) {
            return
          }
          this.buttonDisabled = true
          if (this.isEdit) {
            this.editWarehouseRelation()
          } else {
            this.createWarehouseRelation()
          }
        } else {
          this.buttonDisabled = false
          return false
        }
      })
    },
    //重置表单
    resetForm(formName) {
      this.dialogVisible = false
      this.$refs[formName].resetFields()
    }
  }
}
</script>
<style lang="scss">
.custom-popover{
  height: 500px;
  overflow-y: auto;
}
.table-p {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  cursor: pointer;
  padding-right: 10px;
}
.node-network {
  .custom-item {
    &:hover{
      cursor: pointer;
      background: #FFFFFF;
      box-shadow: 0 1px 6px 0 rgba(0,0,0,0.20);
    }
    .lui-date-editor .lui-range-separator {
      width: 12%;
    }
    .lui-input-number .lui-input__inner {
      -webkit-appearance: none;
      padding-left: 0;
      padding-right: 0;
      text-align: left;
    }
    .lui-input-number__decrease,
    .lui-input-number__increase {
      width: 16px;
    }
  }
}
</style>
<style lang="scss" scoped>
@import '@/assets/stylus/main';
.node-network {
  min-height: 600px;
  .header-title {
    font-size: 16px;
    font-weight: 600;
    color: #333333;
    letter-spacing: 0;
    line-height: 16px;
    .line {
      margin: 2px 6px 0 0;
      width: 2px;
      height: 12px;
      background: $--gl-blue;
      border-radius: 2px;
    }
  }
  .header {
    background: #fff;
    padding: 30px 24px;
    box-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.1);
    border-radius: 0 4px 4px 4px;
    .search-box {
      margin-top: 20px;
      display: flex;
      justify-content: space-between;
      .header-left{
        width: calc(100% - 130px);
      }
      .cust-item{
        margin-right: 24px;
      }
      .label {
        font-size: 14px;
        height: 32px;
        line-height: 32px;
        margin-right: 12px;
      }
      .lui-select,
      .lui-input {
        width: 190px;
      }
    }
  }
  .custom-table {
    margin-top: 20px;
    background: #fff;
    padding: 0 24px;
    box-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.1);
    border-radius: 4px;
    .table-header {
      display: flex;
      justify-content: space-between;
      padding: 20px 0;
      .header-title {
        height: 32px;
        line-height: 32px;
        .line {
          margin: 10px 6px 0 0;
        }
      }
    }
  }
  .footer {
    padding: 20px 0 30px 0;
    text-align: right;
  }
  .custom-dialog{
    .lui-input-number{
      width: 100%;
    }
    .dialog-mask{
      width: 100%;
      height: 100%;
      position: absolute;
      top: 0;
      left: 0;
      background: rgba(0,0,0,.5);
      opacity: 0.5;
      z-index: 10;
    }
    .custom-header{
      height: 40px;
      line-height: 40px;
      padding: 0 12px;
      background: #f3f7fa;
      .label {
        float: left;
        color: #666666;
        font-size: 12px;
      }
    }
    .custom-item {
      position: relative;
      padding: 8px 12px;
      border-bottom: 1px solid #e0e0e0;
      img{
        width: 17px;
        height: 17px;
      }
      .remove{
        margin-left: 12px;
      }
      .operation{
        display: inline-block;
        position: absolute;
        right: 45px;
        line-height: 32px;
      }
    }
    .add-nodeList {
      font-size: 14px;
      color: $--gl-blue;
      height: 48px;
      line-height: 48px;
      text-align: center;
      border-bottom: 1px solid #e0e0e0;
      span {
        cursor: pointer;
      }
    }
  }
}
</style>
