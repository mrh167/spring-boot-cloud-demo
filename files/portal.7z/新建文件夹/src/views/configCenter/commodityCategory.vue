<template>
  <div class="commodity-category">
    <div class="header">
      <div class="header-title">
        <div class="line left"></div>
        筛选项
      </div>
      <div class="search-box">
        <div class="header-left">
          <div class="label left">
            商品分类
          </div>
          <lui-cascader
            v-if="isCascade"
            ref="cascaderAddr"
            v-model="cate3Idst"
            clearable
            show-overflow-tooltip
            placeholder="请选择商品分类"
            :props="propList"
            @change="handleSelectCate"
          ></lui-cascader>
        </div>
        <div class="header-right">
          <lui-button v-waves type="primary" @click="query">查询</lui-button>
          <lui-button @click="handleRest">重置</lui-button>
        </div>
      </div>
    </div>
    <div class="custom-table">
      <div class="table-header">
        <div class="header-title">
          <div class="line left"></div>
          数据列表
        </div>
        <div>
          <lui-button type="primary" @click="downloadClick">批量下载</lui-button>
          <!-- <lui-button type="primary" @click="uploadClick">批量上传</lui-button> -->
          <button-list
            v-if="getIsEclp"
            ref="buttons"
            :buttons="buttons"
            @uploadSuccess="postListPage"
          >
          </button-list>
          <lui-button v-if="getIsEclp" type="primary" @click="postDeleteBaseGoodsCate">手工删除</lui-button>
          <lui-button v-if="getIsEclp" type="primary" @click="handleOperation('add')">手工添加</lui-button>
        </div>
      </div>
      <lui-table
        v-loading="LoadingTable"
        border
        :data="tableData"
        style="width: 100%"
        @selection-change="handleSelectionChange"
      >
        <template slot="empty">
          <showEmptyImage></showEmptyImage>
        </template>
        <lui-table-column
          type="selection"
          align="center"
          width="50">
        </lui-table-column>
        <lui-table-column
          prop="sellerNo"
          show-overflow-tooltip
          label="商家编码"
          min-width="160">
        </lui-table-column>
        <lui-table-column
          prop="sellerName"
          show-overflow-tooltip
          label="商家名称"
          min-width="160">
        </lui-table-column>
        <lui-table-column
          prop="cate1Id"
          show-overflow-tooltip
          label="一级类目ID"
          min-width="160">
        </lui-table-column>
        <lui-table-column
          prop="cate1Name"
          show-overflow-tooltip
          label="一级类目名称"
          min-width="160">
        </lui-table-column>
        <lui-table-column
          prop="cate2Id"
          show-overflow-tooltip
          label="二级类目ID"
          min-width="160">
        </lui-table-column>
        <lui-table-column
          prop="cate2Name"
          show-overflow-tooltip
          label="二级类目名称"
          min-width="160">
        </lui-table-column>
        <lui-table-column
          prop="cate3Id"
          show-overflow-tooltip
          label="三级类目ID"
          min-width="160">
        </lui-table-column>
        <lui-table-column
          prop="cate3Name"
          show-overflow-tooltip
          label="三级类目名称"
          min-width="160">
        </lui-table-column>
        <lui-table-column
          v-if="getIsEclp"
          width="80"
          label="操作">
          <template slot-scope="{row}">
            <lui-button type="text" @click="handleOperation('edit',row)">编辑</lui-button>
          </template>
        </lui-table-column>
      </lui-table>
      <div v-show="tableData.length>0" class="footer">
        <lui-pagination
          v-show="tableData.length>0"
          background
          :page-size="pageSize"
          :current-page="pageNum"
          :page-sizes="[10, 20, 50, 70, 100]"
          layout=" prev, pager, next, sizes, jumper"
          :total="total"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange">
        </lui-pagination>
      </div>
      <lui-dialog
        :title="isDisabled ? '编辑类目信息' : '新增类目信息'"
        :close-on-click-modal="false"
        :visible.sync="dialogVisible"
        width="640px">
        <lui-form ref="ruleForm" :model="ruleForm" :rules="rules" label-width="120px">
          <lui-form-item label="一级类目ID" prop="cate1Id">
            <lui-autocomplete v-model.trim="ruleForm.cate1Id" placeholder="请输入一级类目ID" :fetch-suggestions="querySearchAsync" :maxlength="30" :disabled="isDisabled" @select="handleSelect"></lui-autocomplete>
          </lui-form-item>
          <lui-form-item label="一级类目名称" prop="cate1Name">
            <lui-input v-model.trim="ruleForm.cate1Name" placeholder="请输入一级类目名称" :disabled="ruleForm.cate1NameIsEdit" :maxlength="30"></lui-input>
          </lui-form-item>
          <lui-form-item label="二级类目ID" prop="cate2Id">
            <lui-autocomplete v-model.trim="ruleForm.cate2Id" placeholder="请输入二级类目ID" :maxlength="30" :disabled="isDisabled" :fetch-suggestions="querySearchAsync1" @select="handleSelect1"></lui-autocomplete>
          </lui-form-item>
          <lui-form-item label="二级类目名称" prop="cate2Name">
            <lui-input v-model.trim="ruleForm.cate2Name" placeholder="请输入二级类目名称" :disabled="ruleForm.cate2NameIsEdit" :maxlength="30"></lui-input>
          </lui-form-item>
          <lui-form-item label="三级类目ID" prop="cate3Id">
            <lui-input v-model.trim="ruleForm.cate3Id" placeholder="请输入三级类目ID" :maxlength="30" :disabled="isDisabled"></lui-input>
          </lui-form-item>
          <lui-form-item label="三级类目名称" prop="cate3Name">
            <lui-input v-model.trim="ruleForm.cate3Name" placeholder="请输入三级类目名称" :maxlength="30"></lui-input>
          </lui-form-item>
        </lui-form>
        <span slot="footer" class="dialog-footer">
          <lui-button @click="resetForm('ruleForm')">取 消</lui-button>
          <lui-button type="primary" :disabled="buttonDisabled" :loading="buttonDisabled" @click="submitForm('ruleForm')">{{ buttonDisabled ? '提交中' : '确 定' }}</lui-button>
        </span>
      </lui-dialog>

      <lui-dialog
        class="error-dialog"
        title="删除失败"
        :visible.sync="dialogTableVisible"
        :close-on-click-modal="false">
        <div class="dialog-table-list">
          <div v-show="moreErr" style="color: red;font-size: 12px">异常太多，最多显示300条</div>
          <lui-table
            stripe
            size="mini"
            :data="gridData">
            <lui-table-column align="center" property="msg" label="异常原因">
              <template slot-scope="{row}">
                {{ row.msg }}
              </template>
            </lui-table-column>
          </lui-table>
        </div>
      </lui-dialog>
    </div>
  </div>
</template>

<script>
import Api from '@/api/index'
import Http from '@/lib/http'
import { exportExcel } from '@/utils/downloadRequest'
import ButtonList from '@/views/common/ButtonList'
import showEmptyImage from '@/components/common/showEmptyImage/index.vue'
import { mapGetters } from 'vuex'

const buttons = {
  upload: {
    noAsync: true,
    maxM: 10,
    uploadtips: '只能上传xlsx文件，文件大小不超过10M',
    uploadConfig: {
      uploadActionUrl: Http.baseContextUrl + 'baseGoodsCate/upload'
    },
    templateUrl: Http.baseContextUrl + 'baseGoodsCate/downloadTemplate'
  }
  // fileName: 'userInfoFile'
}

export default {
  name: 'CommodityCategory',
  components: {
    ButtonList,
    showEmptyImage
  },
  data() {
    return {
      isCascade: true,
      gridData: [],
      moreErr: false,
      dialogTableVisible: false, //删除错误提示
      propList: {
        lazy: true,
        async lazyLoad(node, resolve) {
          setTimeout(() => {
            if (node.level === 0) {
              Api.BaseGoodsInfo.category().then(res => {
                const cities = res.data.map((value, i) => ({
                  value: value.cate1Id,
                  label: value.cate1Name,
                  leaf: node.level >= 2 //控制几级数据
                }))
                // 通过调用resolve将子节点数据返回，通知组件数据加载完成
                resolve(cities)
              }).catch((e) => {
                console.error(e)
              })
            }

            if (node.level === 1) {
              Api.BaseGoodsInfo.category({
                cate1Id: node.value
              }).then(res => {
                const cities = res.data.map((value, i) => ({
                  value: value.cate2Id,
                  label: value.cate2Name,
                  leaf: node.level >= 2 //控制几级数据
                }))
                // 通过调用resolve将子节点数据返回，通知组件数据加载完成
                resolve(cities)
              }).catch((e) => {
                console.error(e)
              })
            }
            if (node.level === 2) {
              Api.BaseGoodsInfo.category({
                cate1Id: node.path[0],
                cate2Id: node.path[1]
              }).then(res => {
                const cities = res.data.map((value, i) => ({
                  value: value.cate3Id,
                  label: value.cate3Name,
                  leaf: node.level >= 2 //控制几级数据
                }))
                // 通过调用resolve将子节点数据返回，通知组件数据加载完成
                resolve(cities)
              }).catch((e) => {
                console.error(e)
              })
            }
          }, 300)
        }
      },
      buttons,
      isEclp: false,
      cate3Id: '',
      cate3Idst: '', //三级分类ID
      LoadingTable: false,
      isUploadModalShow: false, //上传模态窗
      baseURL: Http.baseContextUrl,
      multipleSelection: [],
      restaurants: [],
      timeout: null,
      dialogVisible: false,
      isDisabled: false,
      buttonDisabled: false,
      state: '',
      value: '',
      checkDeptNo: true, //默认false表示不上传事业部
      options: [],
      tableData: [],
      total: 0,
      pageSize: 10,
      pageNum: 1,
      ruleForm: {
        id: '',
        cate1Id: '',
        cate1Name: '',
        cate1NameIsEdit: false,
        cate2Id: '',
        cate2Name: '',
        cate2NameIsEdit: false,
        cate3Id: '',
        cate3Name: ''
      },
      rules: {
        cate1Id: [
          { required: true, message: '请输入一级类目ID', trigger: 'change' },
          { pattern: /^[a-zA-Z0-9()（）]+$/, message: '只允许输入英文+数字+中英文括号' }
        ],
        cate1Name: [
          { required: true, message: '请输入一级类目名称', trigger: 'change' }
        ],
        cate2Id: [
          { required: true, message: '请输入二级类目ID', trigger: 'change' },
          { pattern: /^[a-zA-Z0-9()（）]+$/, message: '只允许输入英文+数字+中英文括号' }
        ],
        cate2Name: [
          { required: true, message: '请输入二级类目名称', trigger: 'change' }
        ],
        cate3Id: [
          { required: true, message: '请输入三级类目ID', trigger: 'blur' },
          { pattern: /^[a-zA-Z0-9()（）]+$/, message: '只允许输入英文+数字+中英文括号' }
        ],
        cate3Name: [
          { required: true, message: '请输入三级类目名称', trigger: 'blur' }
        ]
      }
    }
  },
  computed: {
    ...mapGetters(['getIsEclp'])
  },
  mounted() {
    this.postListPage()
  },
  methods: {
    query() {
      this.pageNum = 1
      this.postListPage()
    },
    //商品分类
    handleSelectCate(val) {
      console.log(val)
      this.cate3Id = this.cate3Idst[2]
    },
    handleRest() {
      this.cate3Idst = ''
      this.cate3Id = '' //三级分类ID
      this.postListPage()
    },
    downloadClick() {
      const actionUrl = `${this.baseURL}baseGoodsCate/download`
      exportExcel(actionUrl, { cate3Id: this.cate3Id })
    },
    handleSelectionChange(val) {
      const selectData = val
      this.multipleSelection = []
      selectData.forEach(item => {
        this.multipleSelection.push(item.id)
      })
    },
    loadAll() {
      Api.ConfigCenter.postListLike({
        cate1Id: this.ruleForm.cate1Id,
        cate2Id: this.ruleForm.cate2Id
      }).then((res) => {
        if (res.success) {
          this.restaurants = res.data
          this.restaurants.forEach(item => {
            item.value = item.cate1Id
          })
        }
      }).catch((e) => {
        console.log(e)
      })
    },
    handleSelect(item) {
      this.ruleForm.cate1Name = item.cate1Name
      this.ruleForm.cate1NameIsEdit = true
    },
    handleSelect1(item) {
      this.ruleForm.cate2Name = item.cate2Name
      this.ruleForm.cate2NameIsEdit = true
    },
    querySearchAsync(queryString, cb) {
      Api.ConfigCenter.postListLike({
        level: 1,
        cate1Id: this.ruleForm.cate1Id,
        cate2Id: ''
      }).then((res) => {
        if (res.success) {
          this.restaurants = res.data
          this.restaurants.forEach(item => {
            item.value = item.cate1Id
          })
          var restaurants = this.restaurants
          var results = queryString ? restaurants.filter(this.createStateFilter(queryString)) : restaurants
          // clearTimeout(this.timeout)
          // this.timeout = setTimeout(() => {
          cb(results)
          // }, 3000 * Math.random())
          if (res.data && res.data.length) {
            this.restaurants.forEach(item => {
              if (this.ruleForm.cate1Id === item.value) {
                this.ruleForm.cate1Name = item.cate1Name
                this.ruleForm.cate1NameIsEdit = true
              } else {
                this.ruleForm.cate1NameIsEdit = false
              }
            })
          } else {
            this.ruleForm.cate1NameIsEdit = false
          }
          // console.log(this.restaurants)
        }
      }).catch((e) => {
        console.log(e)
      })
    },
    querySearchAsync1(queryString, cb) {
      Api.ConfigCenter.postListLike({
        level: 2,
        cate1Id: this.ruleForm.cate1Id,
        cate2Id: this.ruleForm.cate2Id
      }).then((res) => {
        if (res.success) {
          this.restaurants = res.data
          this.restaurants.forEach(item => {
            item.value = item.cate2Id
          })
          var restaurants = this.restaurants
          var results = queryString ? restaurants.filter(this.createStateFilter(queryString)) : restaurants
          // clearTimeout(this.timeout)
          // this.timeout = setTimeout(() => {
          cb(results)
          // }, 3000 * Math.random())
          if (res.data && res.data.length) {
            this.restaurants.forEach(item => {
              if (this.ruleForm.cate2Id === item.value) {
                this.ruleForm.cate2Name = item.cate2Name
                this.ruleForm.cate2NameIsEdit = true
              } else {
                this.ruleForm.cate2NameIsEdit = false
              }
            })
          } else {
            this.ruleForm.cate2NameIsEdit = false
          }
        }
      }).catch((e) => {
        console.log(e)
      })
    },
    createStateFilter(queryString) {
      return (state) => {
        return (state.value.toLowerCase().indexOf(queryString.toLowerCase()) === 0)
      }
    },
    handleOperation(state, row) {
      this.state = state
      this.isDisabled = false
      this.dialogVisible = true
      this.ruleForm.cate1NameIsEdit = false
      this.ruleForm.cate2NameIsEdit = false
      this.ruleForm.id = ''
      this.ruleForm.cate1Id = ''
      this.ruleForm.cate1Name = ''
      this.ruleForm.cate2Id = ''
      this.ruleForm.cate2Name = ''
      this.ruleForm.cate3Id = ''
      this.ruleForm.cate3Name = ''
      this.$nextTick(() => {
        this.$refs['ruleForm'].clearValidate()
      })
      if (row) {
        console.log(row)
        this.ruleForm.id = row.id
        this.isDisabled = true
        this.ruleForm.cate1Id = row.cate1Id
        this.ruleForm.cate1Name = row.cate1Name
        this.ruleForm.cate2Id = row.cate2Id
        this.ruleForm.cate2Name = row.cate2Name
        this.ruleForm.cate3Id = row.cate3Id
        this.ruleForm.cate3Name = row.cate3Name
      }
    },
    postListPage() {
      this.LoadingTable = true
      Api.ConfigCenter.postListPage({
        cate3Id: this.cate3Id,
        pageNum: this.pageNum,
        pageSize: this.pageSize
      }).then((res) => {
        if (res.success) {
          this.tableData = res.data
          this.total = res.total
          this.LoadingTable = false
        } else {
          this.LoadingTable = false
        }
      }).catch((e) => {
        console.log(e)
        this.LoadingTable = false
      })
    },
    postDeleteBaseGoodsCate() {
      if (!this.multipleSelection.length) {
        this.$showErrorMsg('请选择数据')
        return
      }
      this.$alert('<p style="font-size: 18px;color:#333">确认删除此条消息吗?</p><p style="font-size: 13px;color: #666">删除后，此条消息的相关内容信息将无法恢复</p>', '', {
        dangerouslyUseHTMLString: true,
        type: 'warning',
        center: true
      }).then(() => {
        this.isCascade = false
        Api.ConfigCenter.postDeleteBaseGoodsCate(
          this.multipleSelection
        ).then((res) => {
          if (res.success) {
            this.isCascade = true
            if (res.data.successCount > 0) {
              this.postListPage()
            }
            if (res.data.errorCount > 0) {
              this.dialogTableVisible = true
              this.gridData = res.data.detaileds
              this.moreErr = res.data.detaileds.length > 300 ? true : false
            } else {
              this.isCascade = true
              this.$showSuccessMsg('删除成功')
              this.postListPage()
            }
          } else {
            this.isCascade = true
            this.$showErrorMsg(res.errMessage)
          }
        }).catch((e) => {
          this.$showErrorMsg(e)
        })
      }).catch(() => {})
    },
    postAddBaseGoodsCate() {
      this.isCascade = false
      Api.ConfigCenter.postAddBaseGoodsCate(
        {
          'cate1Id': this.ruleForm.cate1Id,
          'cate1Name': this.ruleForm.cate1Name,
          'cate2Id': this.ruleForm.cate2Id,
          'cate2Name': this.ruleForm.cate2Name,
          'cate3Id': this.ruleForm.cate3Id,
          'cate3Name': this.ruleForm.cate3Name
        }
      ).then((res) => {
        if (res.success) {
          this.dialogVisible = false
          this.buttonDisabled = false
          this.isCascade = true
          this.postListPage()
          this.$message({
            type: 'success',
            message: '提交成功'
          })
        } else {
          this.isCascade = true
          this.buttonDisabled = false
          this.$message({
            type: 'error',
            message: res.errMessage
          })
        }
      }).catch((e) => {
        this.isCascade = true
        this.buttonDisabled = false
        this.$showErrorMsg(e)
      })
    },
    postEditBaseGoodsCate() {
      this.isCascade = false
      Api.ConfigCenter.postEditBaseGoodsCate(
        {
          'id': this.ruleForm.id,
          'cate1Id': this.ruleForm.cate1Id,
          'cate1Name': this.ruleForm.cate1Name,
          'cate2Id': this.ruleForm.cate2Id,
          'cate2Name': this.ruleForm.cate2Name,
          'cate3Id': this.ruleForm.cate3Id,
          'cate3Name': this.ruleForm.cate3Name
        }
      ).then((res) => {
        if (res.success) {
          this.isCascade = true
          this.dialogVisible = false
          this.buttonDisabled = false
          this.postListPage()
          this.$message({
            type: 'success',
            message: '提交成功'
          })
        } else {
          this.isCascade = true
          this.buttonDisabled = false
          this.$message({
            type: 'error',
            message: res.errMessage
          })
        }
      }).catch((e) => {
        this.isCascade = true
        this.buttonDisabled = false
        this.$showErrorMsg(e)
      })
    },
    handleSizeChange(val) {
      this.pageSize = val
      this.postListPage()
      // console.log(`每页 ${val} 条`)
    },
    handleCurrentChange(val) {
      this.pageNum = val
      this.postListPage()
      // console.log(`当前页: ${val}`)
    },
    submitForm(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          if (this.state === 'add') {
            this.$confirm('【商品分类】ID新增之后不可修改', '提示', {
              confirmButtonText: '确定',
              cancelButtonText: '取消',
              type: 'warning'
            }).then(() => {
              this.buttonDisabled = true
              this.postAddBaseGoodsCate()
            }).catch(() => {
              this.buttonDisabled = false
              this.$message({
                type: 'info',
                message: '已取消新增'
              })
            })
          } else {
            this.buttonDisabled = true
            this.postEditBaseGoodsCate()
          }
        } else {
          return false
        }
      })
    },
    resetForm(formName) {
      this.dialogVisible = false
      this.buttonDisabled = false
      this.$refs[formName].resetFields()
    }
  }
}
</script>

<style lang="scss" scoped>
@import '@/assets/stylus/main';
.commodity-category {
  min-height: 600px;
   .header-title {
      font-size: 16px;
      font-weight: 600;
      color: #333333;
      letter-spacing: 0;
      line-height: 16px;
      .line {
        margin: 2px 6px 0 0;
        width: 2px;
        height: 12px;
        background: $--gl-blue;
        border-radius: 2px;
      }
    }
  .header {
    background: #fff;
    padding: 30px 24px;
    box-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.1);
    border-radius: 0 4px 4px 4px;
    .search-box {
      margin-top: 20px;
      display: flex;
      justify-content: space-between;
      .label {
        font-size: 14px;
        height: 32px;
        line-height: 32px;
        margin-right: 12px;
      }
      .lui-select {
        width: 250px;
      }
    }
  }
  .lui-autocomplete {
    width: 100%;
  }
  .custom-table {
    margin-top: 20px;
    background: #fff;
    padding: 0 24px;
    box-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.1);
    border-radius: 4px;
    .table-header{
      display: flex;
      justify-content: space-between;
      padding: 20px 0;
      .header-title{
        height: 32px;
        line-height: 32px;
        .line{
          margin: 10px 6px 0 0;
        }
      }
    }
  }
  .footer {
    padding: 20px 0 30px 0;
    text-align: right;
  }
}
</style>
