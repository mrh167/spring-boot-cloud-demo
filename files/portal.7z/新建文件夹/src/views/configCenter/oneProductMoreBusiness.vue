<template>
  <div class="oneproduct-morebusiness">
    <div class="header">
      <div class="header-title">
        <div class="line left"></div>
        筛选项
      </div>
      <div class="search-box">
        <div class="header-left">
          <div class="left">
            <div class="label left">
              事业部
            </div>
            <lui-select
              v-model="dept"
              clearable
              value-key="deptNo"
              placeholder="请选择事业部">
              <lui-option
                v-for="item in deptOptions"
                :key="item.deptNo"
                :label="item.deptName"
                :value="item">
              </lui-option>
            </lui-select>
          </div>
          <div
            class="left"
            style="margin-left:38px;">
            <div class="label left">
              商品编码
            </div>
            <lui-input
              v-model.trim="goodsNo"
              placeholder="请输入商品编码"
              clearable></lui-input>
          </div>
        </div>
        <div class="header-right">
          <lui-button
            v-waves
            type="primary"
            @click="query">查询</lui-button>
          <lui-button
            v-waves
            @click="handleRest">重置</lui-button>
        </div>
      </div>
    </div>
    <div class="custom-table">
      <div class="table-header">
        <div class="header-title">
          <div class="line left"></div>
          数据列表
        </div>
        <div>
          <lui-button
            v-waves
            type="primary"
            @click="downloadClick">批量下载</lui-button>
          <button-list
            ref="buttons"
            :buttons="buttons"
            :configdept-no="dept.deptNo"
            :configdept-name="dept.deptName"
            :check-dept-no="checkDeptNo"
            @uploadSuccess="postListPage">
          </button-list>
          <lui-button
            v-waves
            type="primary"
            @click="postDeleteGoodsMoreStore">手工删除</lui-button>
          <lui-button
            v-waves
            type="primary"
            @click="handleAdd()">手工添加</lui-button>
        </div>
      </div>
      <lui-table
        v-loading="LoadingTable"
        :data="tableData"
        border
        row-class-name="custom-table_row"
        style="width: 100%"
        @selection-change="handleSelectionChange">
        <template slot="empty">
          <showEmptyImage></showEmptyImage>
        </template>
        <lui-table-column
          type="selection"
          fixed="left"
          align="center"
          width="50">
        </lui-table-column>
        <lui-table-column
          prop="sellerNo"
          label="商家编码"
          show-overflow-tooltip
          width="160">
        </lui-table-column>
        <lui-table-column
          prop="sellerName"
          label="商家名称"
          min-width="160"
          show-overflow-tooltip>
        </lui-table-column>
        <lui-table-column
          prop="deptNo"
          label="事业部编码"
          min-width="160"
          show-overflow-tooltip>
        </lui-table-column>
        <lui-table-column
          prop="deptName"
          label="事业部名称"
          min-width="160"
          show-overflow-tooltip>
        </lui-table-column>
        <lui-table-column
          prop="libraryNodeNo"
          label="库节点编码"
          min-width="100"
          show-overflow-tooltip>
        </lui-table-column>
        <lui-table-column
          prop="libraryNodeName"
          label="库节点名称"
          min-width="160"
          show-overflow-tooltip>
        </lui-table-column>
        <lui-table-column
          prop="goodsNo"
          label="商品编码"
          min-width="100">
          <template v-slot="{row}">
            <lui-tooltip
              class="item"
              effect="dark"
              :content="row.goodsNo"
              placement="bottom">
              <p class="table-p">{{ row.goodsNo }}</p>
            </lui-tooltip>
          </template>
        </lui-table-column>
        <lui-table-column
          prop="goodsName"
          label="商品名称"
          min-width="160">
          <template v-slot="{row}">
            <lui-tooltip
              class="item"
              effect="dark"
              :content="row.goodsName"
              placement="bottom">
              <p class="table-p">{{ row.goodsName }}</p>
            </lui-tooltip>
          </template>
        </lui-table-column>
        <lui-table-column
          label="供应商名称 供应商优先级 供应商配比 工厂分配规则"
          width="500">
          <template slot="header">
            <lui-row style="width:500px;padding:0">
              <lui-col :span="6">供应商名称</lui-col>
              <lui-col :span="6">供应商优先级</lui-col>
              <lui-col :span="6">供应商配比</lui-col>
              <lui-col :span="6">工厂分配规则</lui-col>
            </lui-row>
          </template>
          <template slot-scope="scope">
            <div
              v-for="(item,index) in scope.row.suppliers"
              :key="index"
              class="lui-row_wrap">
              <lui-row style="width:500px;border-bottom: 1px solid #EAEAEA">
                <lui-col
                  :span="6"
                  class="table-p"
                  style="height:46px;line-height:46px;padding-left: 10px;">
                  <lui-tooltip
                    class="item"
                    effect="dark"
                    :content="item.supplierName"
                    placement="bottom">
                    <p class="table-p">{{ item.supplierName }}</p>
                  </lui-tooltip>
                </lui-col>
                <lui-col
                  :span="6"
                  class="table-p"
                  style="height:46px;line-height:46px;padding-left: 10px;">{{ item.level ? item.level : '--' }}</lui-col>
                <lui-col
                  :span="6"
                  class="table-p"
                  style="height:46px;line-height:46px;padding-left: 10px;">{{ item.rate ? item.rate: '--' }}</lui-col>
                <lui-col
                  :span="6"
                  class="table-p"
                  style="height:46px;line-height:46px;padding-left: 10px;">
                  <lui-popover
                    placement="top-end"
                    width="460"
                    visible-arrow="true"
                    trigger="hover">
                    <lui-table :data="item.nodes">
                      <lui-table-column
                        width="50"
                        type="index"
                        label="序号"></lui-table-column>
                      <lui-table-column
                        min-width="260"
                        prop="nodeName"
                        label="工厂名称">
                        <template v-slot="{row}">
                          <lui-tooltip
                            class="item"
                            effect="dark"
                            :content="row.nodeName"
                            placement="bottom">
                            <p class="table-p">{{ row.nodeName }}</p>
                          </lui-tooltip>
                        </template>
                      </lui-table-column>
                      <lui-table-column
                        min-width="70"
                        prop="level"
                        label="优先级">
                        <template slot-scope="{row}">
                          <span>{{ row.level?row.level:'--' }}</span>
                        </template>
                      </lui-table-column>
                      <lui-table-column
                        min-width="50"
                        label="配比">
                        <template slot-scope="{row}">
                          <span>{{ row.rate?row.rate:'--' }}</span>
                        </template>
                      </lui-table-column>
                    </lui-table>
                    <lui-button
                      slot="reference"
                      type="text">详情</lui-button>
                  </lui-popover>
                </lui-col>
              </lui-row>
            </div>
          </template>
        </lui-table-column>
        <lui-table-column
          prop="updateUser"
          label="修改人">
        </lui-table-column>
        <lui-table-column
          prop="updateTime"
          label="修改时间"
          min-width="160">
        </lui-table-column>
        <lui-table-column
          prop=""
          fixed="right"
          width="80"
          label="操作">
          <template slot-scope="{row}">
            <lui-button
              type="text"
              @click="handleEdit(row)">编辑</lui-button>
          </template>
        </lui-table-column>
      </lui-table>
      <div class="footer">
        <lui-pagination
          v-show="tableData.length>0"
          background
          :page-size="pageSize"
          :current-page="pageNum"
          :page-sizes="[10, 20, 50, 70, 100]"
          layout=" prev, pager, next, sizes, jumper"
          :total="total"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange">
        </lui-pagination>
      </div>
      <lui-dialog
        :title="isEdit ? '编辑供应商网络配置' : '添加供应商网络配置'"
        class="custom-dialog"
        :close-on-click-modal="false"
        :visible.sync="dialogVisible"
        width="865px">
        <div v-if="dialogMask" class="dialog-mask"></div>
        <lui-form ref="ruleForm" :model="ruleForm" :rules="rules">
          <lui-form-item label="事业部" prop="deptValue" label-width="126px">
            <lui-select
              v-model="ruleForm.deptValue"
              value-key="deptNo"
              :disabled="isEdit"
              filterable
              style="width:100%"
              placeholder="请选择事业部"
              @change="changeSelectDept">
              <lui-option
                v-for="item in deptOptions"
                :key="item.deptNo"
                :label="item.deptName"
                :value="item">
              </lui-option>
            </lui-select>
          </lui-form-item>
          <lui-form-item
            label="商品名称"
            prop="goodsValue"
            label-width="126px">
            <lui-select
              v-model="ruleForm.goodsValue"
              value-key="goodsNo"
              :disabled="isEdit"
              filterable
              remote
              reserve-keyword
              :remote-method="remoteMethod"
              style="width:100%"
              placeholder="请搜索选择商品名称">
              <lui-option
                v-for="item in goodsOptions"
                :key="item.goodsNo"
                :label="item.goodsName"
                :value="item">
              </lui-option>
            </lui-select>
          </lui-form-item>
          <lui-form-item
            label="库节点"
            prop="node"
            label-width="126px">
            <lui-select
              v-model="ruleForm.node"
              :disabled="isEdit"
              filterable
              clearable
              style="width:100%"
              value-key="nodeNo"
              placeholder="请选择库节点">
              <lui-option
                v-for="item in nodeOptions"
                :key="item.nodeNo"
                :label="item.nodeName"
                :value="item">
              </lui-option>
            </lui-select>
          </lui-form-item>
          <lui-form-item
            label-width="126px">
            <span slot="label"><i style="color: #E1251B;margin-right: 4px;">*</i>供应商使用策略</span>
            <lui-radio
              v-model="strategyType"
              label="1"
              @change="changeStrategyType">按优先级</lui-radio>
            <lui-radio
              v-model="strategyType"
              label="2"
              @change="changeStrategyType">按配比</lui-radio>
          </lui-form-item>
          <lui-form-item
            v-if="strategyType === '1'"
            label-width="126px">
            <span slot="label"><i style="color: #E1251B;margin-right: 4px;">*</i>策略分配规则</span>
            <lui-radio
              v-model="supplierRuleType"
              label="1">现货库存</lui-radio>
          </lui-form-item>
          <div>
            <div class="custom-header">
              <div class="label">序号</div>
              <div
                class="label"
                style="width:240px;margin-left:19px">供应商名称</div>
              <div
                class="label"
                style="width:250px;margin-left:24px">供应商使用时间段</div>
              <div
                class="label"
                style="width:55px;margin-left:24px;text-align: center;">
                {{ strategyType === '1' ? '优先级' :'配比%' }}
                <lui-tooltip
                  v-if="strategyType === '2'"
                  popper-class="custom-tooltip"
                  effect="dark"
                  visible-arrow="false"
                  content="配比之和应等于100%"
                  placement="bottom">
                  <i class="lui-icon-help"></i>
                </lui-tooltip>
              </div>
              <div
                class="label"
                style="width:72px;margin-left:32px">工厂分配规则</div>
              <div
                class="label"
                style="width:24px;margin-left:24px">操作</div>
            </div>
            <draggable
              v-model="suppliers"
              :move="getdata"
              @update="datadragEnd">
              <div
                v-for="(item,index) in suppliers"
                :key="index"
                class="custom-item">
                <div style="width:24px;text-align:center;display: inline-block;">{{ index+1 }}</div>
                <lui-select
                  v-model="item.value"
                  value-key="supplierNo"
                  style="width:240px;margin-left:19px"
                  placeholder="请选择供应商名称"
                  @change="((val)=>{changeSelect(val, index)})">
                  <lui-option
                    v-for="obj in item.options"
                    :key="obj.supplierNo"
                    :label="obj.supplierName"
                    :disabled="obj.disabled"
                    :value="obj">
                  </lui-option>
                </lui-select>
                <lui-date-picker
                  v-model="item.startEndTime"
                  disabled
                  style="width:250px;margin-left:24px"
                  type="daterange"
                  format="yyyy/MM/dd"
                  value-format="yyyy-MM-dd"
                  range-separator="至"
                  start-placeholder="开始日期"
                  end-placeholder="结束日期">
                </lui-date-picker>
                <span v-if="strategyType === '1'" style="width:55px;text-align:center;display: inline-block;margin-left:24px">{{ index+1 }}</span>
                <lui-input-number
                  v-if="strategyType === '2'"
                  v-model.trim="item.rate"
                  :min="1"
                  :max="100"
                  :precision="2"
                  :step="0.1"
                  controls-position="right"
                  style="width:55px;text-align:center;display: inline-block;margin-left:24px"></lui-input-number>
                <div style="position: relative;display: inline-block;">
                  <lui-button
                    type="text"
                    style="width:72px;margin-left:32px;text-align:left;"
                    @click="handleConfig(item)">设置</lui-button>
                  <div
                    v-if="item.visible"
                    class="add-factory">
                    <div style="padding:20px 16px 0">
                      <lui-form-item>
                        <span slot="label"><i style="color: #E1251B;margin-right: 4px;">*</i>工厂使用策略</span>
                        <lui-radio
                          v-model="item.factoryRadio"
                          label="1"
                          @change="((val)=>{selectRadio(val, item)})">按优先级</lui-radio>
                        <lui-radio
                          v-model="item.factoryRadio"
                          label="2"
                          @change="((val)=>{selectRadio(val, item)})">按配比</lui-radio>
                      </lui-form-item>
                      <lui-form-item
                        v-if="item.factoryRadio === '1'">
                        <span slot="label"><i style="color: #E1251B;margin-right: 4px;">*</i>策略分配规则</span>
                        <lui-radio
                          v-model="item.factoryRuleType"
                          label="1">现货库存</lui-radio>
                      </lui-form-item>
                      <div class="custom-header">
                        <div class="label">序号</div>
                        <div
                          class="label"
                          style="width:240px;margin-left:19px">工厂</div>
                        <div
                          class="label"
                          style="width:55px;margin-left:24px;text-align:center;">
                          {{ item.factoryRadio === '1' ? '优先级' :'配比%' }}
                          <lui-tooltip
                            v-if="item.factoryRadio === '2'"
                            popper-class="custom-tooltip"
                            effect="dark"
                            visible-arrow="false"
                            content="配比之和应等于100%"
                            placement="bottom">
                            <i class="lui-icon-help"></i>
                          </lui-tooltip>
                        </div>
                        <div
                          class="label"
                          style="width:24px;margin-left:24px">操作</div>
                      </div>
                      <draggable
                        v-model="item.nodes"
                        :move="getdata"
                        @update="datadragEnd">
                        <div
                          v-for="(ite,ind) in item.nodes"
                          :key="ind"
                          class="custom-item">
                          <div style="width:24px;text-align:center;display: inline-block;">{{ ind+1 }}</div>
                          <lui-select
                            v-model="item.nodes[ind].value"
                            value-key="nodeNo"
                            filterable
                            style="width:240px;margin-left:19px"
                            placeholder="请选择库节点"
                            @change="changeSelectFactory">
                            <lui-option
                              v-for="(i,j) in item.nodes[ind].options"
                              :key="j"
                              :label="i.nodeName"
                              :value="i">
                            </lui-option>
                          </lui-select>
                          <span v-if="item.factoryRadio === '1'" style="width:55px;text-align:center;display: inline-block;margin-left:24px">{{ ind+1 }}</span>
                          <lui-input-number
                            v-if="item.factoryRadio === '2'"
                            v-model.trim="ite.rate"
                            :min="1"
                            :max="100"
                            :precision="2"
                            :step="0.1"
                            controls-position="right"
                            style="width:55px;text-align:center;display: inline-block;margin-left:24px"></lui-input-number>
                          <i
                            class="lui-icon-remove-outline"
                            @click="removeFactory(item,ind)"></i>
                        </div>
                      </draggable>
                      <div class="add-suppliers">
                        <span @click="addFactory(item)">
                          <i class="lui-icon-plus"></i> 增加工厂
                        </span>
                      </div>
                    </div>
                    <span
                      slot="footer"
                      class="dialog-footer">
                      <lui-button
                        size="mini"
                        @click="cancelFactory(item)">取 消</lui-button>
                      <lui-button
                        size="mini"
                        type="primary"
                        @click="confirmFactory(item)">确 定</lui-button>
                    </span>
                  </div>
                </div>
                <i
                  class="lui-icon-remove-outline"
                  @click="removeSuppliers(item,index)"></i>
              </div>
            </draggable>
            <div class="add-suppliers">
              <span @click="addSuppliers">
                <i class="lui-icon-plus"></i> 增加供应商
              </span>
            </div>
          </div>

        </lui-form>
        <span
          slot="footer"
          class="dialog-footer">
          <lui-button @click="resetForm('ruleForm')">取 消</lui-button>
          <lui-button
            :disabled="buttonDisabled"
            :loading="buttonDisabled"
            type="primary"
            @click="submitForm('ruleForm')">{{ buttonDisabled ? '提交中' : '确 定' }} </lui-button>
        </span>
      </lui-dialog>
    </div>
    <lui-dialog
      class="error-dialog"
      title="删除失败"
      :visible.sync="dialogTableVisible"
      :close-on-click-modal="false">
      <div class="dialog-table-list">
        <div
          v-show="moreErr"
          style="color: red;font-size: 12px">异常太多，最多显示300条</div>
        <lui-table
          stripe
          size="mini"
          :data="gridData">
          <lui-table-column
            align="center"
            property="msg"
            label="异常原因">
            <template slot-scope="{row}">
              {{ row.msg }}
            </template>
          </lui-table-column>
        </lui-table>
      </div>
    </lui-dialog>
  </div>
</template>

<script>
import Api from '@/api/index'
import Http from '@/lib/http'
import draggable from 'vuedraggable'
import { exportExcel } from '@/utils/downloadRequest'
import ButtonList from '@/views/common/ButtonList'
import showEmptyImage from '@/components/common/showEmptyImage/index.vue'

const buttons = {
  upload: {
    noAsync: true,
    maxM: 10,
    uploadtips: '只能上传xlsx文件，文件大小不超过10M。',
    uploadtipsadd: '若该商品无记录，则追加；若该商品有记录,则覆盖。',
    uploadConfig: {
      uploadActionUrl: Http.baseContextUrl + 'goodsMoreStore/batchUpload'
    },
    templateUrl: Http.baseContextUrl + 'goodsMoreStore/downloadTemplate'
  }
  // fileName: 'userInfoFile'
}

export default {
  name: 'OneProductMoreBusiness',
  components: {
    ButtonList,
    showEmptyImage,
    draggable
  },
  data() {
    return {
      gridData: [],
      moreErr: false,
      dialogTableVisible: false, //删除错误提示
      buttons,
      isEclp: false,
      buttonDisabled: false,
      LoadingTable: false,
      checkDeptNo: true, //默认false表示不上传事业部
      dialogVisible: false,
      dialogMask: false,
      isEdit: false,
      baseURL: Http.baseContextUrl,
      options: [],
      dept: '',
      goodsNo: '',
      deptOptions: [],
      goodsOptions: [],
      factoryValue: '',
      factoryOptions: [],
      tableData: [],
      total: 0,
      pageSize: 10,
      pageNum: 1,
      id: '',
      ruleForm: {
        deptValue: {}, //事业部列表
        goodsValue: {}, //商品列表
        node: {} //库节点列表
      },
      nodeOptions: [],
      strategyType: '1',
      supplierRuleType: '1',
      rules: {
        deptValue: [
          { required: true, message: '请选择事业部', trigger: 'change' }
        ],
        goodsValue: [
          { required: true, message: '请搜索选择商品名称', trigger: 'change' }
        ]
        // node: [
        //   { required: true, message: '请选择库节点', trigger: 'change' }
        // ]
      },
      multipleSelection: [],
      suppliers: [
        // {
        //   value: '',
        //   options: [],
        //   startEndTime: '',
        //   level: '',
        //   rate: '',
        //   supplierNo: '',
        //   supplierName: '',
        //   visible: false,
        //   strategyType: '',
        //   factoryRadio: '1',
        //   deptName: '',
        //   deptNo: '',
        //   goodsName: '',
        //   goodsNo: '',
        //   isvGoodsNo: '',
        //   mainSupplierNo: '',
        //   nodes: [
        //     {
        //       strategyType: '',
        //       value: '',
        //       options: [],
        //       nodeName: '',
        //       nodeNo: '',
        //       level: '',
        //       rate: ''
        //     }
        //   ]
        // }
      ],
      nodes: []
    }
  },
  mounted() {
    this.postListPage()
    this.queryDept()
  },
  methods: {
    //选择供应商,已选供应商置灰校验
    changeSelectNode() {
      for (var j in this.suppliers) {
        for (var i in this.suppliers[j].options) {
          console.log(this.suppliers[j], 444)
          console.log(this.suppliers[j].value, this.suppliers[j].options[i], '对比')
          if (this.suppliers[j].value.supplierNo === this.suppliers[j].options[i].supplierNo) {
            this.suppliers[j].options[i].disabled = true
            break
          } else {
            this.suppliers[j].options[i].disabled = false
          }
        }  
      }
    },
    changeStrategyType(val) {
      if (val === '1') {
        this.supplierRuleType = '1'
      } else {
        this.supplierRuleType = '0'
      }
      console.log(val, this.supplierRuleType, '测试')
    },
    getdata(evt) {
      //这里evt后续的内容根据具体的定义变量而定
    },
    datadragEnd(evt) {
    },
    query() {
      this.pageNum = 1
      this.postListPage()
    },
    handleRest() {
      this.deptNo = ''
      this.goodsNo = ''
      this.postListPage()
    },
    handleConfig(item) {
      if (!item.value) {
        this.$showErrorMsg('请选择供应商名称')
        return
      }
      this.dialogMask = true
      item.nodes = JSON.parse(JSON.stringify(item.nodes))
      this.nodes = JSON.parse(JSON.stringify(item.nodes))
      item.visible = true
      this.postList({//根据事业部、供应商获取工厂列表
        deptNo: this.ruleForm.deptValue.deptNo,
        supplierNo: item.value.supplierNo,
        nodeType: [1, 8]
      })
    },
    //模糊查询，最多返回300条
    remoteMethod(query) {
      this.ruleForm.goodsValue.goodsName
      if (query !== '') {
        Api.oneProductMoreBusiness.postBaseGoodsInfo({
          'deptNo': this.ruleForm.deptValue.deptNo,
          'goodsName': query,
          'goodsNo': '',
          'isMoreBusiness': 0
        }).then((res) => {
          if (res.success) {
            this.goodsOptions = res.data
            console.log(this.goodsOptions)
          }
        }).catch((e) => {
          console.log(e)
        })
      } else {
        this.goodsOptions = []
      }
    },
    //查询库节点(不包括工厂) 1.工厂 2.区域仓 3.前置仓 4.门店 5.中央仓
    postNodes() {
      Api.BasicInfo.postList({ deptNo: this.ruleForm.deptValue.deptNo }).then((res) => {
        if (res.success) {
          this.nodeOptions = []
          res.data.forEach(item => {
            if (item.nodeType !== 1 && item.nodeType !== 8) {
              this.nodeOptions.push(item)
            }
          })
        }
      }).catch((e) => {
        console.error(e)
      })
    },
    changeSelectFactory(val) {
      this.$forceUpdate()
    },
    changeSelectDept() {
      //选择事业部时清空内容
      this.ruleForm.goodsValue = ''
      this.ruleForm.node = ''
      this.suppliers = []
      this.postNodes()
      this.baseSupplierInfo({
        deptNo: this.ruleForm.deptValue.deptNo
      })
      this.postBaseGoodsInfo({
        deptNo: this.ruleForm.deptValue.deptNo,
        isMoreBusiness: 0
      })
    },
    changeSelect(val, index) {
      const startTime = val.startTime.substr(0, 10)
      const endTime = val.endTime.substr(0, 10)
      this.suppliers[index].startEndTime = [startTime, endTime]
      this.suppliers[index].nodes.forEach(item => {
        item.value = ''
      })
      // this.changeSelectNode()
      // this.$forceUpdate()
      // console.log(val)
    },
    removeFactory(item, index) {
      item.nodes.splice(index, 1)
    },
    removeSuppliers(item, index) {
      this.suppliers.splice(index, 1)
    },
    addFactory(item) {
      item.nodes.push({
        strategyType: '',
        value: '',
        options: this.factoryOptions,
        nodeName: '',
        nodeNo: '',
        level: '',
        rate: ''
      })
    },
    addSuppliers() {
      this.$refs['ruleForm'].validate((valid) => {
        if (valid) {
          this.suppliers.push({
            value: '',
            options: this.options,
            startEndTime: '',
            level: '',
            rate: '',
            supplierNo: '',
            supplierName: '',
            visible: false,
            strategyType: '',
            factoryRadio: '1',
            factoryRuleType: '1',
            deptName: '',
            deptNo: '',
            goodsName: '',
            goodsNo: '',
            isvGoodsNo: '',
            id: '',
            goodsKeyId: '',
            mainSupplierNo: '',
            nodes: []
          })
        }
      })
    },
    handleSelectionChange(val) {
      const selectData = val
      this.multipleSelection = []
      selectData.forEach(item => {
        this.multipleSelection.push(item.id)
      })
    },
    handleAdd() {
      this.id = ''
      this.isEdit = false
      this.suppliers = []
      this.options = []
      this.ruleForm.node = ''
      this.ruleForm.deptValue = ''
      this.ruleForm.goodsValue = ''
      this.nodeOptions = []
      this.goodsOptions = []
      this.dialogVisible = true
      this.$nextTick(() => {
        this.$refs['ruleForm'].clearValidate()
      })
    },
    handleEdit(row) {
      this.id = ''
      this.isEdit = false
      this.suppliers = []
      this.ruleForm.node = ''
      this.ruleForm.deptValue = ''
      this.ruleForm.goodsValue = ''
      this.goodsOptions = []
      this.nodeOptions = []
      if (row) {
        console.log(row)
        this.id = row.id
        this.getDetails()
        this.isEdit = true
        // this.dialogVisible = true
        this.ruleForm.deptValue = { deptNo: row.deptNo, deptName: row.deptName }
        // this.postBaseGoodsInfo({
        //   deptNo: this.ruleForm.deptValue.deptNo
        // })
        this.goodsOptions = [{ goodsNo: row.goodsNo, goodsName: row.goodsName, isvGoodsNo: row.isvGoodsNo }]
        this.ruleForm.goodsValue = { goodsNo: row.goodsNo, goodsName: row.goodsName, isvGoodsNo: row.isvGoodsNo }
        // this.postNodes()
      }
      // console.log(this.suppliers)
    },
    //==========================================================>查看详情
    getDetails() {
      const formData = new FormData()// FormData 对象
      formData.append('id', this.id)// 文件对象
      Api.oneProductMoreBusiness.getDetails(formData).then((res) => {
        if (res.success) {
          this.suppliers = res.data.suppliers
          this.nodeOptions = [{ nodeNo: res.data.nodeNo, nodeName: res.data.nodeName }]
          this.ruleForm.node = { nodeNo: res.data.nodeNo, nodeName: res.data.nodeName }
          this.suppliers.forEach(item => {
            this.strategyType = item.strategyType + ''
            if (this.strategyType === '1') {
              this.supplierRuleType = '1'
            } else {
              this.supplierRuleType = '0'
            }
            item.options = this.options
            // item.options = [{ supplierNo: item.supplierNo, supplierName: item.supplierName, startTime: item.startTime, endTime: item.endTime }]
            this.$set(item, 'visible', false)
            item.value = { supplierNo: item.supplierNo, supplierName: item.supplierName, startTime: item.startTime, endTime: item.endTime }
            item.startEndTime = [item.startTime.substr(0, 10), item.endTime.substr(0, 10)]
            item.nodes.forEach(val => {
              val.options = this.factoryOptions
              val.value = { nodeNo: val.nodeNo, nodeName: val.nodeName }
              this.$set(item, 'factoryRadio', val.strategyType + '')
              if (val.strategyType === 1) {
                item.factoryRuleType = '1'
              } else {
                item.factoryRuleType = '0'
              }
            })
          })
          this.suppliers = JSON.parse(JSON.stringify(this.suppliers))
          console.log(this.suppliers)
          this.baseSupplierInfo({
            deptNo: this.ruleForm.deptValue.deptNo
          })
          this.dialogVisible = true
          this.$nextTick(() => {
            this.$refs['ruleForm'].clearValidate()
          })
        } else {
          this.$showErrorMsg(res.errMessage)
        }
      }).catch((e) => {
        console.log(e)
        this.$showErrorMsg(e)
      })
    },
    postDeleteGoodsMoreStore() {
      if (!this.multipleSelection.length) {
        this.$message.error('请选择数据')
        return
      }
      this.$alert('<p style="font-size: 18px;color:#333">确认删除此条消息吗?</p><p style="font-size: 13px;color: #666">删除后，此条消息的相关内容信息将无法恢复</p>', '', {
        dangerouslyUseHTMLString: true,
        type: 'warning',
        center: true
      }).then(() => {
        this.LoadingTable = true
        Api.oneProductMoreBusiness.postDeleteGoodsMoreStore(
          this.multipleSelection
        ).then((res) => {
          if (res.success) {
            if (res.data.successCount > 0) {
              this.postListPage()
            }
            if (res.data.errorCount > 0) {
              this.dialogTableVisible = true
              this.gridData = res.data.detaileds
              this.moreErr = res.data.detaileds.length > 300 ? true : false
            } else {
              this.$showSuccessMsg('删除成功')
              this.postListPage()
            }
          } else {
            this.LoadingTable = false
            this.$message.error('删除失败，请稍后再试')
          }
        }).catch((e) => {
          this.LoadingTable = false
          this.$showErrorMsg(e)
        })
      }).catch(() => {
        this.LoadingTable = false
      })
    },
    //选择工厂使用策略
    selectRadio(val, item) {
      if (val === '1') {
        this.$set(item, 'factoryRuleType', '1')
      } else {
        this.$set(item, 'factoryRuleType', '0')
      }
      console.log(val, item, '工厂分配策略')
    },
    //查询列表
    postListPage() {
      this.LoadingTable = true
      Api.oneProductMoreBusiness.postListPage(
        {
          deptNo: this.dept.deptNo,
          goodsNo: this.goodsNo,
          sellerName: '',
          pageNum: this.pageNum,
          pageSize: this.pageSize
        }
      ).then((res) => {
        if (res.success) {
          this.tableData = res.data
          this.total = res.total
          this.LoadingTable = false
        } else {
          this.$showErrorMsg(res.errMessage)
          this.LoadingTable = false
        }
      }).catch((e) => {
        this.LoadingTable = false
        this.$showErrorMsg(e)
      })
    },
    downloadClick() {
      const actionUrl = `${this.baseURL}goodsMoreStore/download`
      const params = {
        deptNo: this.dept.deptNo,
        goodsNo: this.goodsNo
      }
      exportExcel(actionUrl, params)
    },
    //添加&编辑
    saveGoodsMoreStore(formData) {
      Api.oneProductMoreBusiness.saveGoodsMoreStore(formData).then((res) => {
        if (res.success) {
          this.dialogVisible = false
          this.buttonDisabled = false
          this.postListPage()
          const tips = this.isEdit ? '编辑成功' : '添加成功'
          this.$message({
            type: 'success',
            message: tips
          })
        } else {
          this.buttonDisabled = false
          this.$message.error(res.errMessage)
        }
      }).catch((e) => {
        this.buttonDisabled = false
        this.$showErrorMsg(e)
      })
    },
    //工厂列表
    postList(params) {
      Api.BasicInfo.postList(params).then((res) => {
        if (res.success) {
          this.factoryOptions = res.data
          this.suppliers.forEach(item => {
            item.nodes.forEach(val => {
              val.options = res.data
            })
          })
        }
      }).catch((e) => {
        console.error(e)
      })
    },
    //事业部列表
    queryDept() {
      Api.BaseGoodsInfo.queryDept({}).then((res) => {
        if (res.success) {
          this.deptOptions = res.data
        }
      }).catch((e) => {
        console.error(e)
      })
    },
    //商品列表
    postBaseGoodsInfo(params) {
      Api.oneProductMoreBusiness.postBaseGoodsInfo(params).then((res) => {
        if (res.success) {
          this.goodsOptions = res.data
        }
      }).catch((e) => {
        console.error(e)
      })
    },
    //供应商列表
    baseSupplierInfo(params) {
      Api.BaseGoodsInfo.baseSupplierInfo(params).then((res) => {
        if (res.success) {
          this.options = res.data
          this.suppliers.forEach(item => {
            item.options = res.data
          })
        }
      }).catch((e) => {
        console.error(e)
      })
    },
    handleSizeChange(val) {
      this.pageSize = val
      this.postListPage()
    },
    handleCurrentChange(val) {
      this.pageNum = val
      this.postListPage()
    },
    //供应商数据组装
    formatSuppliers() {
      const suppliers = JSON.parse(JSON.stringify(this.suppliers))
      suppliers.forEach((item, index) => {
        item.level = index + 1
        item.nodeNo = this.ruleForm.node.nodeNo
        item.nodeName = this.ruleForm.node.nodeName
        item.strategyType = this.strategyType
        item.supplierRuleType = this.supplierRuleType
        item.deptNo = this.ruleForm.deptValue.deptNo
        item.deptName = this.ruleForm.deptValue.deptName
        item.goodsNo = this.ruleForm.goodsValue.goodsNo
        item.goodsName = this.ruleForm.goodsValue.goodsName
        item.isvGoodsNo = this.ruleForm.goodsValue.isvGoodsNo
        item.supplierNo = item.value.supplierNo
        item.supplierName = item.value.supplierName
        delete item.options
        delete item.factoryRadio
        delete item.startEndTime
        delete item.value
        delete item.visible
        delete item.mapKey
        delete item.isMoreFactory
        delete item.startTime
        delete item.endTime

        item.nodes.forEach((val, i) => {
          val.level = i + 1
          val.factoryRuleType = item.factoryRuleType
          delete val.value
          delete val.options
          delete val.deptName
          delete val.deptNo
          delete val.goodsName
          delete val.goodsNo
          delete val.isvGoodsNo
          delete val.mapKey
          delete val.sellerName
          delete val.sellerNo
          delete val.supplierName
          delete val.supplierNo
        })
        delete item.factoryRuleType
      })
      return suppliers
    },
    //校验配比
    checkoutRate() {
      var sum = 0
      for (var i = 0; i < this.suppliers.length; i++) {
        sum += this.suppliers[i].rate
      }
      return sum
    },
    //校验供应商
    checkoutSuppliers() {
      if (!this.suppliers.length) {
        this.$showErrorMsg('供应商不能为空')
        return false
      }
      for (let j = 0; j < this.suppliers.length; j++) {
        if (!this.suppliers[j].value) {
          this.$showErrorMsg('供应商名称不能为空')
          return false
        }
        if (!this.suppliers[j].nodes.length) {
          this.$showErrorMsg('供应商[' + this.suppliers[j].value.supplierName + ']工厂必填')
          return false
        }
      }
      for (let i = 0; i < this.suppliers.length - 1; i++) {
        if (this.suppliers[i].value === this.suppliers[i + 1].value) {
          this.$showErrorMsg('供应商不能重复添加')
          return false
        }
      }
      return true
    },
    //提交
    submitForm(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          if (this.strategyType === '1') {
            if (!this.checkoutSuppliers()) {
              return
            }
          } else if (this.strategyType === '2') {
            if (this.checkoutRate() !== 100) {
              this.$showErrorMsg('供应商配比之和应等于100%')
              return
            }
          }
          this.buttonDisabled = true
          this.saveGoodsMoreStore(this.formatSuppliers())
        } else {
          return false
        }
      })
    },
    //重置表单
    resetForm(formName) {
      this.dialogVisible = false
      this.$refs[formName].resetFields()
      this.suppliers.forEach((item) => {
        item.visible = false
      })
    },
    //工厂校验
    checkoutFactory(nodes) {
      if (!nodes.length) {
        this.$showErrorMsg('工厂不能为空')
        return false
      }
      for (const j in nodes) {
        if (!nodes[j].value) {
          this.$showErrorMsg('请选择工厂')
          return false
        }
      }
      for (let i = 0; i < nodes.length - 1; i++) {
        if (nodes[i].value === nodes[i + 1].value) {
          this.$showErrorMsg('工厂不能重复添加')
          return false
        }
      }
      return true
    },
    //校验工厂配比
    checkoutFactoryRate(nodes) {
      let sum = 0
      for (let i = 0; i < nodes.length; i++) {
        sum += nodes[i].rate
      }
      // console.log('sum', sum, typeof (sum))
      return sum
    },
    //确定工厂
    confirmFactory(item) {
      item.nodes.forEach(el => {
        el.nodeNo = el.value.nodeNo
        el.nodeName = el.value.nodeName
        el.strategyType = item.factoryRadio
        el.factoryRuleType = item.factoryRuleType
      })
      if (item.factoryRadio === '1') {
        this.checkoutFactory(item.nodes)
        if (!this.checkoutFactory(item.nodes)) {
          return
        }
      } else if (item.factoryRadio === '2') {
        if (this.checkoutFactoryRate(item.nodes) !== 100) {
          this.$showErrorMsg('工厂配比之和应等于100%')
          return
        }
      }
      item.visible = false
      this.dialogMask = false
    },
    //取消工厂
    cancelFactory(item) {
      item.nodes = this.nodes
      item.visible = false
      this.dialogMask = false
    }
  }
}
</script>
<style lang="scss">
  .table-p {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    cursor: pointer;
    padding-right: 10px;
  }
  .oneproduct-morebusiness {
    .custom-item {
      .lui-date-editor .lui-range-separator {
        width: 12%;
      }
      .lui-input-number .lui-input__inner {
        -webkit-appearance: none;
        padding-left: 0;
        padding-right: 0;
        text-align: left;
      }
      .lui-input-number__decrease,
      .lui-input-number__increase {
        width: 16px;
      }
    }
    .lui-table__header {
      th:nth-of-type(10) {
        .cell {
          padding: 0;
          line-height: 0;
          div{
          line-height: 23px;
          }
        }
      }
    }
    .custom-table_row {
      td:nth-of-type(10) {
        padding: 0;
        .cell {
          padding-left: 0;
          .lui-row_wrap:last-of-type {
            .lui-row {
              border-bottom: 0 !important;
            }
          }
        }
      }
    }
  }
</style>
<style lang="scss" scoped>
@import '@/assets/stylus/main';
  .oneproduct-morebusiness {
    min-height: 600px;
    .header-title {
      font-size: 16px;
      font-weight: 600;
      color: #333333;
      letter-spacing: 0;
      line-height: 16px;
      .line {
        margin: 2px 6px 0 0;
        width: 2px;
        height: 12px;
        background: $--gl-blue;
        border-radius: 2px;
      }
    }
    .header {
      background: #fff;
      padding: 30px 24px;
      box-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.1);
      border-radius: 0 4px 4px 4px;
      .search-box {
        margin-top: 20px;
        display: flex;
        justify-content: space-between;
        .label {
          font-size: 14px;
          height: 32px;
          line-height: 32px;
          margin-right: 12px;
        }
        .lui-select,
        .lui-input {
          width: 250px;
        }
      }
    }
    .custom-table {
      margin-top: 20px;
      background: #fff;
      padding: 0 24px;
      box-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.1);
      border-radius: 4px;
      .table-header {
        display: flex;
        justify-content: space-between;
        padding: 20px 0;
        .header-title {
          height: 32px;
          line-height: 32px;
          .line {
            margin: 10px 6px 0 0;
          }
        }
      }
    }
    .footer {
      padding: 20px 0 30px 0;
      text-align: right;
    }
    .custom-dialog{
      .dialog-mask{
        width: 100%;
        height: 100%;
        position: absolute;
        top: 0;
        left: 0;
        background: rgba(0,0,0,.5);
        opacity: 0.5;
        z-index: 10;
      }
      .custom-header{
        height: 40px;
        line-height: 40px;
        padding: 0 12px;
        background: #f3f7fa;
        .label {
          float: left;
          color: #666666;
          font-size: 12px;
        }
      }
      .custom-item {
        padding: 8px 12px;
        border-bottom: 1px solid #e0e0e0;
        .lui-icon-remove-outline {
          cursor: pointer;
          width: 24px;
          margin-left: 24px;
          color: $--gl-blue;
          font-size: 17px;
          opacity: 0.5;
        }
        .add-factory {
          z-index: 10;
          width: 500px;
          max-height: 353px;
          overflow-y: auto;
          position: absolute;
          bottom: 34px;
          left: -318px;
          background: #fff;
          box-shadow: 0 0 10px 0 rgba(0, 0, 0, 0.1);
          border-radius: 4px;
          .dialog-footer {
            display: inline-block;
            padding: 10px 20px;
            width: 100%;
            text-align: right;
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
          }
        }
      }
      .add-suppliers {
        font-size: 14px;
        color: $--gl-blue;
        height: 48px;
        line-height: 48px;
        text-align: center;
        border-bottom: 1px solid #e0e0e0;
        span {
          cursor: pointer;
          user-select:none;
          -moz-user-select:none; /*火狐*/
          -webkit-user-select:none; /*webkit浏览器*/
          -ms-user-select:none; /*IE10*/
        }
      }
    }
  }
</style>
