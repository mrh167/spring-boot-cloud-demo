<template>
  <div class="masterData">
    <div class="master-header">
      <lui-row>
        <lui-col :span="24" class="header-top"><span class="header-border"></span><span class="header-title">筛选项</span></lui-col>
      </lui-row>
      <lui-row>
        <lui-col :span="20" class="header-select header-select-one">
          <div class="select-content">
            <span class="content-title">事业部</span>
            <lui-select v-model="deptNo" clearable style="width: 180px;" placeholder="请选择事业部">
              <lui-option
                v-for="item in deptNoList"
                :key="item.deptNo"
                :label="item.deptName"
                :value="item.deptNo+'&'+item.deptName">
              </lui-option>
            </lui-select>
          </div>

          <div class="select-content">
            <span class="content-title">库节点</span>
            <lui-autocomplete v-model.trim="panel" clearable :fetch-suggestions="querySearchAsync" placeholder="请输入库节点名称" :maxlength="50"></lui-autocomplete>
            <!-- <lui-input v-model="panel" clearable style="width: 180px;" placeholder="请输入库节点"></lui-input> -->
          </div>

          <div class="select-content">
            <span class="content-title">库节点类型</span>
            <lui-select v-model="PanelType" clearable style="width: 180px;" placeholder="请选择库节点类型" @change="handleSelectPanelType">
              <lui-option
                v-for="item in nodeTypeList"
                :key="item.code"
                :label="item.name"
                :value="item.code">
              </lui-option>
            </lui-select>
          </div>

          <div class="select-content">
            <span class="content-title">是否可用</span>
            <lui-select v-model="status" clearable style="width: 180px;" placeholder="请选择是否可用">
              <lui-option label="是" value="1"></lui-option>
              <lui-option label="否" value="0"></lui-option>
            </lui-select>
          </div>
        </lui-col>
        <lui-col :span="4" class="header-button">
          <lui-button type="primary" style="width: 80px;" @click="handleQuery">查询</lui-button>
          <lui-button style="width: 80px;" @click="handleRest">重置</lui-button>
        </lui-col>
      </lui-row>
    </div>
    <div class="master-container">
      <div class="container-top">
        <div class="container-top-left"><span class="header-border"></span><span class="header-title">数据</span></div>
        <div class="container-top-right">
          <lui-button type="primary" @click="download">批量下载</lui-button>
          <button-list
            v-if="getIsEclpForNodeAndSupplier"
            ref="buttons"
            :buttons="buttons"
            :configdept-no="deptNo.split('&')[0]"
            :configdept-name="deptNo.split('&')[1]"
            :check-dept-no="checkDeptNo"
            @uploadSuccess="getList"
          >
          </button-list>
          <lui-button v-if="getIsEclpForNodeAndSupplier" type="primary" @click="handleDeled">手工删除</lui-button>
          <lui-button v-if="getIsEclpForNodeAndSupplier" type="primary" @click="handleAdd">手工添加</lui-button>
        </div>
      </div>

      <div class="container-table">
        <div class="container-table-cont">
          <lui-table
            v-loading="LoadingTable"
            :data="tableData"
            border
            style="width: 100%"
            @selection-change="handleSelectionChange">
            <template slot="empty">
              <showEmptyImage></showEmptyImage>
            </template>
            <lui-table-column
              fixed="left"
              align="center"
              type="selection"
              width="50">
            </lui-table-column>
            <lui-table-column
              prop="deptNo"
              min-width="170"
              label="事业部编码"
              show-overflow-tooltips>
            </lui-table-column>
            <lui-table-column
              prop="deptName"
              min-width="160"
              label="事业部名称"
              show-overflow-tooltip>
            </lui-table-column>
            <lui-table-column
              prop="sellerNo"
              min-width="160"
              label="商家编码"
              show-overflow-tooltip>
            </lui-table-column>
            <lui-table-column
              prop="nodeNo"
              min-width="160"
              label="库节点编码"
              show-overflow-tooltip>
            </lui-table-column>
            <lui-table-column
              prop="nodeName"
              min-width="160"
              label="库节点名称"
              show-overflow-tooltip>
            </lui-table-column>
            <lui-table-column
              width="140"
              label="库节点类型">
              <template v-slot="{row}">
                <div v-for="(item,index) in nodeTypeList" :key="index">
                  <p v-if="row.nodeType===item.code" class="table-p">{{ item.name }}</p>
                </div>
              </template>
            </lui-table-column>
            <lui-table-column
              width="100"
              align="center"
              prop="isSale"
              label="是否可用">
              <template v-slot="{row}">
                <lui-tag v-if="row.status===1" type="success" size="small">正常</lui-tag>
                <lui-tag v-else type="danger" size="small">禁用</lui-tag>
              </template>
            </lui-table-column>
            <lui-table-column
              v-if="getIsEclpForNodeAndSupplier"
              width="100"
              align="center"
              label="是否显示">
              <template v-slot="{row}">
                <lui-switch
                  v-model="row.statusSwitch"
                  active-circle-class="1"
                  active-color="rgba(60,110,240,.2)"
                  inactive-color="rgba(142,145,152,.2)"
                  @change="setIfShowClick(row)">
                </lui-switch>
              </template>
            </lui-table-column>
            <lui-table-column
              prop="provinceName"
              width="100"
              label="省">
            </lui-table-column>
            <lui-table-column
              prop="cityName"
              width="130"
              label="市">
            </lui-table-column>
            <lui-table-column
              prop="updateUser"
              width="130"
              label="修改人">
            </lui-table-column>
            <lui-table-column
              prop="updateTime"
              width="160"
              label="修改时间">
            </lui-table-column>
            <lui-table-column
              fixed="right"
              align="center"
              width="100"
              label="操作">
              <template v-slot="{row}">
                <div class="table-button">
                  <lui-button type="text" @click="handleEdit(row,true)">查看</lui-button>
                  <lui-button v-if="getIsEclpForNodeAndSupplier" type="text" @click="handleEdit(row,false)">编辑</lui-button>
                </div>
              </template>
            </lui-table-column>
          </lui-table>
        </div>
        <div v-show="tableData.length>0" class="knowledge-pagination">
          <lui-pagination
            background
            :current-page.sync="pageNum"
            :page-sizes="[10, 20, 50, 70, 100]"
            layout="prev, pager, next, sizes, jumper"
            :total="totals"
            @current-change="handleSizeChange"
            @size-change="sizeChange"
          >
          </lui-pagination>
        </div>
      </div>

      <lui-dialog
        :visible.sync="centerDialogVisible"
        width="50%"
        top="10vh"
        :close-on-click-modal="false"
        custom-class="dialog_mask"
        :title="stateTitle"
        @close="closeDialog('ruleForm')">
        <lui-form
          ref="ruleForm"
          :model="ruleForm"
          :rules="rules"
          label-width="140px"
          class="demo-ruleForm">

          <!-- <lui-form-item
            label="商家名称"
            prop="sellerName">
            <lui-input
              v-model.trim="ruleForm.sellerName"
              maxlength="50"
              :disabled="disabledEdit"
              placeholder="请输入商家名称"
            >
            </lui-input>
          </lui-form-item> -->

          <lui-form-item
            label="事业部"
            prop="deptNo">
            <lui-select
              v-model="ruleForm.deptNo"
              :disabled="disabledEdit"
              style="width: 100%;"
              placeholder="请选择事业部"
              @change="handleDept">
              <lui-option
                v-for="item in deptNoList"
                :key="item.deptNo"
                :label="item.deptName"
                :value="item.deptNo">
              </lui-option>
            </lui-select>
          </lui-form-item>

          <lui-form-item
            label="库节点编码"
            prop="nodeNo">
            <lui-input
              v-model="ruleForm.nodeNo"
              maxlength="50"
              :disabled="disabledEdit"
              placeholder="请输入库节点编码"
              @input="e => ruleForm.nodeNo = specialForbid (e)">
            </lui-input>
          </lui-form-item>

          <lui-form-item
            label="库节点类型"
            prop="nodeType">
            <lui-select
              v-model="ruleForm.nodeType"
              :disabled="disabledType"
              style="width: 100%;"
              placeholder="请选择库节点类型"
              @change="handleSelectPanelTypeAdd">
              <lui-option
                v-for="item in nodeTypeList"
                :key="item.code"
                :label="item.name"
                :value="item.code">
              </lui-option>
            </lui-select>
          </lui-form-item>

          <lui-form-item
            v-if="ruleForm.nodeType === 4"
            label="库节点等级"
            prop="shopLevel">
            <lui-select
              v-model="ruleForm.shopLevel"
              :disabled="disabledType"
              style="width: 100%;"
              placeholder="请选择库节点等级">
              <lui-option
                v-for="item in nodeLevelList"
                :key="item.code"
                :label="item.name"
                :value="item.code">
              </lui-option>
            </lui-select>
          </lui-form-item>

          <lui-form-item
            label="库节点名称"
            prop="nodeName">
            <lui-input
              v-model="ruleForm.nodeName"
              :disabled="disabledLook"
              maxlength="100"
              placeholder="请输入库节点名称"
              @input="e => ruleForm.nodeName = specialForbid (e)">
            </lui-input>
          </lui-form-item>

          <lui-form-item
            v-if="supplierNameShow"
            label="供应商"
            prop="supplierName"
            :rules="{
              required: true, message: '请选择供应商', trigger: ['blur', 'change']
            }">
            <lui-select
              v-model="ruleForm.supplierName"
              :disabled="disabledType"
              style="width: 100%;"
              placeholder="请选择供应商"
              @change="handleBaseGoods">
              <lui-option
                v-for="(item,index) in BaseGoodsInfoList"
                :key="index"
                :label="item.supplierName"
                :value="item.supplierNo">
              </lui-option>
            </lui-select>
          </lui-form-item>

          <lui-form-item
            label="商家库节点编码"
            prop="isvNodeNo">
            <lui-input
              v-model="ruleForm.isvNodeNo"
              :disabled="disabledEdit"
              maxlength="50"
              placeholder="请输入库节点商家编码"
              @input="e => ruleForm.isvNodeNo = specialForbid (e)">
            </lui-input>
          </lui-form-item>
          <div v-if="ruleForm.nodeType === 8 || ruleForm.nodeType === 9">
            <lui-form-item
              label="映射仓编码"
              prop="mappingNodeNo">
              <lui-input
                v-model.trim="ruleForm.mappingNodeNo"
                :disabled="disabledLook"
                maxlength="50"
                placeholder="请输入映射仓编码"
              >
              </lui-input>
            </lui-form-item>  

            <lui-form-item
              label="库存获取"
              prop="stockObtain"
              :rules="ruleForm.mappingNodeNo ? rules.stockObtain:[{ required: false, message: '请选择库存获取', trigger: ['change'] }]">
              <lui-radio-group v-model="ruleForm.stockObtain" :disabled="disabledLook">
                <lui-radio :label="0" class="button_radio">不映射库存</lui-radio>
                <lui-radio :label="1" class="button_radio">映射最大可配出库存</lui-radio>
              </lui-radio-group>
            </lui-form-item>  

            <lui-form-item
              label="使用场景"
              prop="useScene"
              :rules="ruleForm.mappingNodeNo ? rules.useScene:[{ required: false, message: '请选择使用场景', trigger: ['change'] }]">
              <lui-radio-group v-model="ruleForm.useScene" :disabled="disabledLook">
                <lui-radio :label="0" class="button_radio">采购</lui-radio>
                <lui-radio :label="1" class="button_radio">补货</lui-radio>
              </lui-radio-group>
            </lui-form-item> 
          </div>
 
          <lui-form-item
            label="区域"
            prop="region">
            <lui-input
              v-model="ruleForm.region"
              :disabled="disabledLook"
              maxlength="50"
              placeholder="请输入库区域">
            </lui-input>

            <!-- <lui-select
              v-model="ruleForm.region"
              :disabled="disabledLook"
              style="width: 100%;"
              placeholder="请选择库区域"
              @change="handleSelectPanelTypeAdd">
              <lui-option
                v-for="item in regionList"
                :key="item.code"
                :label="item.name"
                :value="item.code">
              </lui-option>
            </lui-select> -->
          </lui-form-item>


          <lui-form-item
            v-if="showCitry"
            label="省市"
            prop="provinceName">
            <div v-if="!disabledLook">
              <lui-cascader
                ref="cascader"
                v-model="provinceList"
                style="width: 100%;position: relative"
                :props="propList"
                @change="handleSelectCateAdd"
              ></lui-cascader>
              <span v-if="spanShow" style="background:#fff;position: absolute;top: 2px;bottom: 2px;left: 12px;z-index: 999;color: #000">{{ provinceListName }}</span>
            </div>
            <div v-else>
              <lui-input v-model="provinceListName" :disabled="disabledLook"></lui-input>
            </div>
          </lui-form-item>


          <lui-form-item
            label="是否可用"
            prop="status">
            <lui-radio-group v-model="ruleForm.status" :disabled="disabledLook">
              <lui-radio :label="1" class="button_radio">是</lui-radio>
              <lui-radio :label="0" class="button_radio">否</lui-radio>
            </lui-radio-group>
          </lui-form-item>
        </lui-form>
        <span slot="footer" class="dialog-footer">
          <lui-button @click="resetForm('ruleForm')">取 消</lui-button>
          <lui-button v-if="disabledButton" type="primary" :loading="buttonDisabled" @click="submitForm('ruleForm')">提 交</lui-button>
        </span>
      </lui-dialog>

      <lui-dialog
        class="error-dialog"
        title="删除失败"
        :visible.sync="dialogTableVisible"
        :close-on-click-modal="false">
        <div class="dialog-table-list">
          <div v-show="moreErr" style="color: red;font-size: 12px">异常太多，最多显示300条</div>
          <lui-table
            stripe
            size="mini"
            :data="gridData">
            <lui-table-column align="center" property="msg" label="异常原因">
              <template slot-scope="{row}">
                {{ row.msg }}
              </template>
            </lui-table-column>
          </lui-table>
        </div>
      </lui-dialog>

    </div>
  </div>
</template>

<script>
import http from '@/lib/http'
import { exportExcel } from '@/utils/downloadRequest'
import Api from '@/api'
import ButtonList from '@/views/common/ButtonList'
import utils from '@/utils/utils.js'
import showEmptyImage from '@/components/common/showEmptyImage/index.vue'
import { mapGetters } from 'vuex'
var provinceName = ''
const buttons = {
  upload: {
    noAsync: true,
    maxM: 10,
    uploadtips: '只能上传xlsx文件，文件大小不超过10M',
    uploadConfig: {
      uploadActionUrl: http.baseContextUrl + 'baseNodeInfo/batchUpload'
    },
    templateUrl: http.baseContextUrl + 'baseNodeInfo/downloadTemplate'

  }
  // fileName: 'userInfoFile'
}
export default {
  name: 'index',
  components: {
    showEmptyImage,
    ButtonList
  },
  data() {
    return {
      regionList: [
        {
          code: 1,
          name: '东北'
        },
        {
          code: 2,
          name: '华北'
        },
        {
          code: 3,
          name: '华中'
        },
        {
          code: 4,
          name: '华东'
        },
        {
          code: 5,
          name: '华南'
        },
        {
          code: 6,
          name: '西北'
        },
        {
          code: 7,
          name: '西南'
        },
        {
          code: 8,
          name: '其他'
        }
      ],
      nodeLevelList: [ //库节点等级列表
        {
          code: 1,
          name: 'A类'
        },
        {
          code: 2,
          name: 'B类'
        },
        {
          code: 3,
          name: 'C类'
        },
        {
          code: 4,
          name: 'D类'
        },
        {
          code: 5,
          name: '旗舰店'
        }
      ],
      gridData: [],
      moreErr: false,
      dialogTableVisible: false, //删除错误提示
      disabledButton: false, //提交按钮显示隐藏
      disabledEdit: false, //编码禁用
      disabledType: false, //类型为工厂则禁用库节点类型
      disabledLook: false, //类型为工厂则禁用库节点类型
      buttons, //批量上传数据
      checkDeptNo: true, //默认false表示不上传事业部
      LoadingTable: false,
      showCitry: false, //多次调用====>利用v-if特性 每次打开重新调用省市组件
      spanShow: false, //省市回显====>利用v-if特性 编辑时显示回调内容
      provinceList: [], //当前省市插件选中会回显
      provinceListName: '', //编辑时省市内容回显
      buttonDisabled: false, //提交按钮加载
      stateTitle: '新增库节点',
      centerDialogVisible: false,
      baseURL: http.baseContextUrl,
      deptNo: '', //事业部
      deptNoList: '', //事业部列表
      panel: '', //库节点
      PanelType: '', //库节点类型
      nodeTypeList: '', //库节点数据列表
      status: '', //是否显示
      totals: 0,
      pageNum: 1, //页
      pageSize: 10, //条数
      tableData: [],
      multipleSelection: [],
      stateShow: false, //新增编辑状态值
      ruleForm: {
        deptNo: '', //事业部
        deptName: '', //事业部名称
        nodeNo: '', //库节点编码
        nodeName: '', //库节点名称
        nodeType: '', //库节点类型
        shopLevel: '', //库节点等级
        isvNodeNo: '', //商家库节点编码
        supplierNo: '', //供应商编码
        supplierName: '', //供应商名称
        provinceName: '', //省名称
        provinceCode: '', //省编码
        cityName: '', //市名称
        status: '',
        region: '', //区域
        cityCode: '', //市编码
        mappingNodeNo: '', //映射仓编码
        useScene: '', //使用场景
        stockObtain: '' //库存获取
      },
      rules: {
        // sellerName: [{ required: true, message: '请输入商家名称', trigger: ['blur', 'change'] }],
        deptNo: [{ required: true, message: '请选择事业部', trigger: ['blur', 'change'] }],
        region: [{ required: false, message: '请输入区域', trigger: ['blur', 'change'] }],
        nodeNo: [{ required: true, message: '请输入库节点编码', trigger: ['blur', 'change'] }],
        nodeType: [{ required: true, message: '请选择库节点类型', trigger: ['blur', 'change'] }],
        nodeName: [{ required: true, message: '请输入库节点名称', trigger: ['blur', 'change'] }],
        isvNodeNo: [{ required: true, message: '请输入商家库节点编码', trigger: ['blur', 'change'] }],
        // provinceName: [{ required: true, message: '请选择省市区', trigger: ['blur', 'change'] }],
        status: [{ required: true, message: '请选择是否可用', trigger: ['blur', 'change'] }],
        // mappingNodeNo: [{ required: true, message: '请输入映射仓编码', trigger: ['blur', 'change'] }],
        useScene: [{ required: true, message: '请选择使用场景', trigger: ['change'] }],
        stockObtain: [{ required: true, message: '请选择库存获取', trigger: ['change'] }]
        // shopLevel: [{ required: true, message: '请选择库节点等级', trigger: ['blur', 'change'] }]
      },
      ruleFromcate3Id: [],
      BaseGoodsInfoList: [],
      supplierNameShow: false, //供应商是否显示
      propList: {
        lazy: true,
        lazyLoad(node, resolve) {
          setTimeout(() => {
            if (node.level === 0) {
              Api.BasicInfo.jdAddress().then(res => {
                const cities = res.data.map((value, i) => ({
                  value: value.code,
                  label: value.name,
                  leaf: node.level >= 1 //控制几级数据
                }))
                // 通过调用resolve将子节点数据返回，通知组件数据加载完成
                resolve(cities)
              }).catch((e) => {
                this.$showErrorMsg(e)
              })
            }
            if (node.level === 1) {
              const formData = new window.FormData()
              formData.append('province', node.data.value)
              provinceName = node.data.label
              Api.BasicInfo.jdAddress(formData).then(res => {
                const cities = res.data.map((value, i) => ({
                  value: value.code,
                  label: value.name,
                  leaf: node.level >= 1 //控制几级数据
                }))
                // 通过调用resolve将子节点数据返回，通知组件数据加载完成
                resolve(cities)
              }).catch((e) => {
                this.$showErrorMsg(e)
              })
            }
            if (node.level === 2) {
              const formData = new window.FormData()
              formData.append('city', node.data.value)
              Api.BasicInfo.jdAddress(formData).then(res => {
                const cities = res.data.map((value, i) => ({
                  value: value.code,
                  label: value.name,
                  leaf: node.level >= 2 //控制几级数据
                }))
                // 通过调用resolve将子节点数据返回，通知组件数据加载完成
                resolve(cities)
              }).catch((e) => {
                this.$showErrorMsg(e)
              })
            }
          }, 300)
        }
      }
    }
  },
  computed: {
    ...mapGetters(['getIsEclpForNodeAndSupplier'])
  },
  mounted() {
    this.queryDept() //获取事业部编码
    this.panelData() //获取事业部编码
    this.getList() //列表页
    this.getShopLevel()//库节点等级

  },
  methods: {
    // specialForbid(e) {
    //   console.log(e, '*-*-*-')
    // },
    getShopLevel() {
      Api.BasicInfo.getShopLevel().then((res) => {
        if (res.success) {
          this.nodeLevelList = res.data
        }
      }).catch((e) => {
        console.log(e)
      })
    },
    //模糊搜索
    querySearchAsync(queryString, cb) {
      Api.ConfigCenter.postKeywords({
        'displayFields': ['nodeNo', 'nodeName'],
        'keyWords': ['nodeName'],
        'rout': 'node',
        'value': this.panel
      }).then((res) => {
        if (res.success) {
          var results = res.data
          results.forEach(item => {
            item.value = item.nodeName
          })
          cb(results)
        }
      }).catch((e) => {
        console.error(e)
      })
    },
    //==================================>编辑
    handleEdit(item, type) {
      this.$nextTick(() => {
        if (type) { //查看
          this.stateTitle = '查看库节点基础信息'
          this.disabledButton = false
        } else { //编辑
          this.stateTitle = '编辑库节点基础信息'
          this.disabledButton = true
        }
        this.disabledLook = type
        this.disabledType = false
        this.disabledEdit = true
        this.stateShow = false
        this.centerDialogVisible = true
        this.supplierNameShow = false
        this.provinceList = []
        this.showCitry = true
        const formData = new window.FormData()
        console.log(item,'777')
        formData.append('id', item.id)
        Api.BasicInfo.getDetails(formData).then(row => {
          if (row.success) {
            if (row.data.nodeType === 1 || row.data.nodeType === 8) { //判断供应商是否显示
              this.supplierNameShow = true
              this.disabledType = true
            } else {
              if (type) { //查看
                this.disabledType = true
              }
            }
            this.spanShow = true
            this.provinceListName = row.data.provinceName ? row.data.provinceName + ' / ' + row.data.cityName : ''
            this.ruleForm = row.data
            this.ruleForm.nodeNo = utils.htmlDecode(this.ruleForm.nodeNo)
          } else {
            this.$showErrorMsg(row.errMessage)
          }
        }).catch((e) => {
          this.$showErrorMsg(e)
        })
      })
    },
    //==================================>新增
    handleAdd() {
      this.$nextTick(() => {
        this.disabledButton = true
        this.disabledEdit = false
        this.disabledLook = false
        this.stateShow = true
        this.disabledType = false
        this.supplierNameShow = false
        this.provinceList = []
        this.showCitry = true
        this.spanShow = false
        this.stateTitle = '新增库节点基础信息'
        this.ruleForm.nodeName = ''
        this.ruleForm.useScene = '' 
        this.ruleForm.stockObtain = ''
        this.ruleForm.shopLevel = ''
        this.ruleForm.mappingNodeNo = ''
        this.ruleForm.region = ''
        this.ruleForm.isvNodeNo = ''
        this.ruleForm.cityCode = ''
        this.ruleForm.cityName = ''
        this.ruleForm.provinceCode = ''
        this.ruleForm.provinceName = ''
        this.centerDialogVisible = true
      })
    },
    // 提交
    submitForm(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          this.buttonDisabled = true
          if (this.stateShow) {
            this.$confirm('【库节点编码】 新增之后不可修改', '提示', {
              confirmButtonText: '确定',
              cancelButtonText: '取消',
              type: 'warning'
            }).then(() => {
              Api.BasicInfo.infoAdd(this.ruleForm).then(row => {
                if (row.success) {
                  this.$showSuccessMsg('新增成功')
                  this.buttonDisabled = false
                  this.centerDialogVisible = false
                  this.showCitry = false
                  this.$refs[formName].resetFields()
                  this.getList()
                } else {
                  this.buttonDisabled = false
                  this.$showErrorMsg(row.errMessage)
                }
              }).catch((e) => {
                this.buttonDisabled = false
                this.$showErrorMsg(e)
              })
            }).catch(() => {
              this.buttonDisabled = false
              this.$message({
                type: 'info',
                message: '已取消新增'
              })
            })
          } else {
            Api.BasicInfo.infoEdit(this.ruleForm).then(row => {
              if (row.success) {
                this.$showSuccessMsg('编辑成功')
                this.$refs[formName].resetFields()
                this.buttonDisabled = false
                this.centerDialogVisible = false
                this.showCitry = false
                this.getList()
              } else {
                this.buttonDisabled = false
                this.$showErrorMsg(row.errMessage)
              }


            }).catch((e) => {
              this.buttonDisabled = false
              this.$showErrorMsg(e)
            })
          }
        }
      })
    },
    //取消
    resetForm(formName) {
      this.$refs[formName].resetFields()
      this.centerDialogVisible = false
      this.showCitry = false
      this.spanShow = false
      this.buttonDisabled = false
    },
    //关闭
    closeDialog(type) {
      if (type) {
        this.$refs[type].resetFields()
        this.buttonDisabled = false
      }
    },
    //省市区选择
    handleSelectCateAdd(val) {
      const nodesObj = this.$refs['cascader'].getCheckedNodes() //获取当前选中节点内容
      this.ruleForm.provinceCode = val[0].toString()
      this.ruleForm.cityCode = val[1].toString()
      this.ruleForm.provinceName = provinceName
      this.ruleForm.cityName = nodesObj[0].label
      this.spanShow = false
    },
    handleDept(val) { //事业部选择
      var obj = {} //多条件查找
      obj = this.deptNoList.find(function(item) {
        return item.deptNo === val
      })
      this.ruleForm.deptName = obj.deptName
      if (this.ruleForm.nodeType === 1 || this.ruleForm.nodeType === 8) { //供应商显示
        this.supplierNameShow = true
        this.baseSupplierInfo(val) //供应商列表
      }

    },
    //新增选择供应商赋值
    handleBaseGoods(val) {
      var obj = {} //多条件查找
      obj = this.BaseGoodsInfoList.find(function(item) {
        return item.supplierNo === val
      })
      this.ruleForm.supplierNo = obj.supplierNo
      this.ruleForm.supplierName = obj.supplierName
    },
    //供应商列表获取
    baseSupplierInfo(deptNo) {
      Api.BaseGoodsInfo.baseSupplierInfo({ deptNo: deptNo }).then(row => {
        if (row.success) {
          this.BaseGoodsInfoList = row.data
        } else {
          this.$showErrorMsg(row.errMessage)
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
      })
    },
    //库节点类型
    handleSelectPanelTypeAdd(val) {
      // console.log(val, 'oooo')
      if (val === 1 || val === 8) { // 供应商判断是否显示
        if (this.ruleForm.deptNo) {
          this.supplierNameShow = true
          this.baseSupplierInfo(this.ruleForm.deptNo) //供应商列表
        }
      } else {
        this.supplierNameShow = false
        this.ruleForm.supplierName = ''
        this.ruleForm.supplierNo = ''
      }
      if (val === 4) {
        this.ruleForm.mappingNodeNo = ''
        this.ruleForm.stockObtain = ''
        this.ruleForm.useScene = ''
      }
      if (val === 8 || val === 9) {
        this.ruleForm.shopLevel = ''
      }
    },
    //==================================>列表方法

    //是否显示
    setIfShowClick(row) {
      const params = {}
      params.id = row.id
      params.status = row.statusSwitch ? 1 : 0
      Api.BasicInfo.editShow(params).then((row) => {
        if (row.success) {
          this.getList()
        } else {
          this.$showErrorMsg(row.errMessage)
        }

      }).catch((e) => {
        this.getList()
        this.$showErrorMsg(e)
      })
    },
    //手工删除
    handleDeled() {
      if (this.multipleSelection.length === 0) {
        this.$showErrorMsg('请选择数据')
        return
      }
      const crrId = []
      for (let i = 0; i < this.multipleSelection.length; i++) {
        crrId.push(this.multipleSelection[i].id)
      }
      this.delete(crrId)
    },
    //  删除方法
    delete(row) {
      this.$alert('<p style="font-size: 18px;color:#333">确认删除此条消息吗?</p><p style="font-size: 13px;color: #666">删除后，此条消息的相关内容信息将无法恢复</p>', '', {
        dangerouslyUseHTMLString: true,
        type: 'warning',
        center: true
      }).then(() => {
        Api.BasicInfo.delete(row).then(row => {
          if (row.success) {
            if (row.data.successCount > 0) {
              this.getList()
            }
            if (row.data.errorCount > 0) {
              this.dialogTableVisible = true
              this.gridData = row.data.detaileds
              this.moreErr = row.data.detaileds.length > 300 ? true : false
            } else {
              this.$showSuccessMsg('删除成功')
              this.getList()
            }
          } else {
            this.$showErrorMsg(row.errMessage)
          }
        }).catch((e) => { this.$showErrorMsg(e) })
      }).catch(() => {})
    },
    //批量上传
    uploadFileDate(event) {
      const formData = new window.FormData()
      formData.append('file', event.target.files[0], event.target.files[0].name)
      Api.BasicInfo.batchUpload(formData).then(row => {
        this.$showSuccessMsg('上传成功')
        this.$refs.uploadFileDate.value = null //小件补货
      }).catch((e) => {
        this.$showErrorMsg(e)
        this.$refs.uploadFileDate.value = null //小件补货
      })
    },
    //批量下载
    download() {
      const param = {}
      param.deptNo = this.deptNo.split('&')[0]
      param.nodeName = this.panel
      param.nodeType = this.PanelType
      param.status = this.status
      const actionUrl = this.baseURL + Api.BasicInfo.download
      exportExcel(actionUrl, param)
    },
    //下载模版
    downloadTemplate() {
      const actionUrl = this.baseURL + Api.BasicInfo.downloadTemplate
      exportExcel(actionUrl)
    },
    //获取事业部编码
    queryDept() {
      Api.BaseGoodsInfo.queryDept().then(row => {
        if (row.success) {
          this.deptNoList = row.data
        } else {
          this.$showErrorMsg(row.errMessage)
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
      })
    }, //获取事业部编码
    panelData() {
      Api.BasicInfo.constantNodeType().then(row => {
        if (row.success) {
          this.nodeTypeList = row.data
        } else {
          this.$showErrorMsg(row.errMessage)
        }
      }).catch((e) => {})
    },
    //列表页获取事业部门编码
    /*handleSelectDep(val) {
      this.deptNo = val.split('&')[0]
    },*/
    //列表页获取事业部门编码
    handleSelectPanelType(val) {
      this.PanelType = val
    },

    //列表查询
    handleQuery() {
      this.getList()
    },
    //重置
    handleRest() {
      this.deptNo = '' //事业部
      this.panel = ''
      this.PanelType = ''
      this.status = ''
      this.getList()
    },

    getList() { //列表
      this.LoadingTable = true
      const params = {}
      params.pageNum = this.pageNum
      params.pageSize = this.pageSize
      params.deptNo = this.deptNo.split('&')[0]
      params.nodeName = this.panel
      params.nodeType = this.PanelType
      params.status = this.status
      Api.BasicInfo.listPage(params).then(row => {
        if (row.success) {
          for (let i = 0; i < row.data.length; i++) {
            row.data[i].nodeNo = utils.htmlDecode(row.data[i].nodeNo)
            if (row.data[i].status) {
              row.data[i].status = 1
              row.data[i].statusSwitch = true
            } else {
              row.data[i].status = 0
              row.data[i].statusSwitch = false
            }
          }
          this.tableData = row.data
          this.totals = row.total
          this.LoadingTable = false
        } else {
          this.$showErrorMsg(row.errMessage)
        }
      }).catch((e) => {
        this.LoadingTable = false
        this.$showErrorMsg(e)
      })
    },
    //分页条数改变
    sizeChange(val) {
      this.pageSize = val
      this.getList()
    },
    //翻页-----根据页码变换
    handleSizeChange(val) {
      this.pageNum = val
      this.getList()
    },
    //全选反选
    handleSelectionChange(val) {
      this.multipleSelection = val
    }
  }
}
</script>

<style scoped lang="scss">
@import '@/assets/stylus/main';
  .masterData{
    width: 100%;
    .master-header{
      width: 100%;
      background: #fff;
      padding-bottom: 30px;
      border-radius: 0 4px 4px 4px;
      box-shadow: 2px 2px 7px 2px #ccc;
      .header-top{
        display: flex;
        align-items: center;
        margin-top: 30px;
        margin-bottom: 20px;
        .header-border{
          width: 2px;
          height: 12px;
          background: $--gl-blue;
          display: inline-block;
          margin-left: 24px;
          margin-right: 6px;
        }
        .header-title{
          font-weight: 600;
          font-size: 16px;
          line-height: 16px;
          color: #333;
        }
      }
      .header-select{
        display: flex;
        .select-content{
          padding-left: 24px;
          .content-title{
            margin-right: 10px;
            font-size: 14px;
            color: #333;
          }
        }
      }
      .header-button{
        padding-right: 24px;
        display: flex;
        justify-content: flex-end ;
      }
    }
    .master-container{
      width: 100%;
      background: #ffffff;
      margin-top: 20px;
      border-radius: 4px;
      box-shadow: 2px 2px 7px 2px #ccc;
      .container-top{
        width: 100%;
        padding: 20px 0;
        display: flex;
        justify-content: space-between;
        .container-top-left{
          line-height: 32px;
          .header-border{
            width: 2px;
            height: 12px;
            background: $--gl-blue;
            display: inline-block;
            margin-left: 24px;
            margin-right: 8px;
          }
          .header-title{
            font-weight: 600;
            font-size: 16px;
            color: #333;
          }
        }
        .container-top-right{
          padding-right: 24px;
          .button-upload{
            position: relative;
            overflow: hidden;
            input{
              position: absolute;
              top: 0;
              bottom: 0;
              left: 0;
              right: 0;
              opacity: 0;
            }
          }
        }
      }
      .container-table{
        width: 100%;
        padding-left: 24px;
        padding-right: 24px;
        padding-bottom: 30px;
        .container-table-cont{
          min-height: 300px;
          .table-look{
            cursor: pointer;
            color: $--gl-blue;
            font-size: 14px;
            font-weight: 500;
          }
          .table-button{
            display: flex;
            justify-content: space-around;
          }
          .table-p {
            //display: inline-block;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            cursor: pointer;
            padding-right: 15px;
            //border: 1px solid red;/**/
          }
        }

        .knowledge-pagination {
          width: 100%;
          margin-top: 20px;
          text-align: right;
        }

      }
    }
    .demo-ruleForm{
      .popup-container{
        overflow: hidden;
        width: 100%;
        margin-bottom: 20px;
        border-radius: 4px;
        border: 1px solid #E8E8E8;
        transition: all 0.3s ease;
        .pupop-container-title{
          width: 100%;
          height: 48px;
          background: #fafafa;
          display: flex;
          justify-content: space-between;
          align-items: center;
          span:nth-child(1){
            padding-left: 20px;
          }
          span:nth-child(2){
            cursor: pointer;
            padding-right: 20px;
            i{
              color: #999;
            }
          }
        }
        .popup-container-main{
          border-top: 1px solid #E8E8E8;
          width: 100%;
          padding:20px  20px 0 20px;
        }
      }
    }
  }
</style>
