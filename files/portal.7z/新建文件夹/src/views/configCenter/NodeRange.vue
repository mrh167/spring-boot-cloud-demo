<template>
  <div class="node-range">
    <div class="header">
      <div class="header-title">
        <div class="line left"></div>
        筛选项
      </div>
      <div class="search-box">
        <div class="header-left">
          <lui-form :inline="true">
            <lui-form-item label="事业部" class="cust-item">
              <lui-select
                v-model="searchForm.dept"
                clearable
                value-key="deptNo"
                placeholder="请选择事业部"
                @change="handleSelectDept">
                <lui-option
                  v-for="item in deptOptions"
                  :key="item.deptNo"
                  :label="item.deptName"
                  :value="item">
                </lui-option>
              </lui-select>
            </lui-form-item>
            <lui-form-item label="省市" class="cust-item">
              <lui-cascader
                v-model="searchForm.cityCode"
                clearable
                placeholder="请选择省市"
                :props="{children:'cityCos'}"
                :options="cityOpt"
                :show-all-levels="false">
              </lui-cascader>
            </lui-form-item>
            <lui-form-item label="库节点" class="cust-item">
              <lui-autocomplete v-model.trim="searchForm.nodeNos" :fetch-suggestions="querySearchAsync" placeholder="请输入库节点名称" :maxlength="50"></lui-autocomplete>
              <!-- <lui-input
                v-model.trim="searchForm.nodeNos"
                placeholder="请输入库节点"
                clearable>
              </lui-input> -->
            </lui-form-item>
            <lui-form-item label="优先级">
              <lui-select
                v-model="searchForm.priority"
                clearable
                placeholder="请选择优先级"
                @focus="handleFocusPriority">
                <lui-option
                  v-for="(item, index) in priorityOpt"
                  :key="index"
                  :label="item"
                  :value="item">
                </lui-option>
              </lui-select>
            </lui-form-item>
          </lui-form>
        </div>
        <div class="header-right">
          <lui-button
            v-waves
            type="primary"
            @click="query">查询</lui-button>
          <lui-button
            v-waves
            @click="handleRest">重置</lui-button>
        </div>
      </div>
    </div>
    <div class="custom-table">
      <div class="table-header">
        <div class="header-title">
          <div class="line left"></div>
          <span class="sp1">数据列表</span>
          <span v-if="noNodeCity" class="sp2"> <i class="lui-icon-warning-outline"></i> {{ noNodeCity.noConfiguredCityCount }}个城市未配置覆盖库节点，{{ noNodeCity.noConfiguredNodeCount }}个库节点未配置履约城市并设置优先级为1。</span>
        </div>
        <div>
          <lui-button
            v-waves
            type="primary"
            @click="downloadClick">批量下载</lui-button>
          <button-list
            ref="buttons"
            :buttons="buttons"
            :configdept-no="searchForm.dept.deptNo"
            :configdept-name="searchForm.dept.deptName"
            :check-dept-no="checkDeptNo"
            @uploadSuccess="postListPage">
          </button-list>
          <lui-button
            v-waves
            type="primary"
            @click="postDeleteBaseNodePriority">手工删除</lui-button>
          <lui-button
            v-waves
            type="primary"
            @click="handleAdd()">手工添加</lui-button>
        </div>
      </div>
      <lui-table
        v-loading="LoadingTable"
        :data="tableData"
        border
        row-class-name="custom-table_row"
        style="width: 100%"
        @selection-change="handleSelectionChange">
        <template slot="empty">
          <showEmptyImage></showEmptyImage>
        </template>
        <lui-table-column
          type="selection"
          fixed="left"
          align="center"
          width="50">
        </lui-table-column>
        <lui-table-column
          prop="deptNo"
          label="事业部编码"
          min-width="160">
        </lui-table-column>
        <lui-table-column
          prop="deptName"
          label="事业部名称"
          min-width="160">
        </lui-table-column>
        <lui-table-column
          prop="provinceName"
          label="省/直辖市"
          min-width="100">
        </lui-table-column>
        <lui-table-column
          prop="provinceCode"
          label="省ID"
          min-width="">
        </lui-table-column>
        <lui-table-column
          prop="cityName"
          label="城市"
          min-width="100">
        </lui-table-column>
        <lui-table-column
          prop="cityCode"
          label="城市ID"
          min-width="">
        </lui-table-column>
        <lui-table-column
          label=""
          width="500">
          <template slot="header">
            <lui-row style="width:500px;padding:0">
              <lui-col :span="8">库节点名称</lui-col>
              <lui-col :span="6">库节点编码</lui-col>
              <lui-col :span="6">库节点类型</lui-col>
              <lui-col :span="4">优先级</lui-col>
            </lui-row>
          </template>
          <template slot-scope="scope">
            <div
              v-for="(item,index) in scope.row.bodies"
              :key="index"
              class="lui-row_wrap">
              <lui-row style="width:500px;border-bottom: 1px solid #EAEAEA">
                <lui-col
                  :span="8"
                  class="table-p"
                  style="height:46px;line-height:46px;padding-left: 10px;">
                  <lui-tooltip
                    class="item"
                    effect="dark"
                    :content="item.nodeName"
                    placement="bottom">
                    <p class="table-p">{{ item.nodeName }}</p>
                  </lui-tooltip>
                </lui-col>
                <lui-col
                  :span="6"
                  class="table-p"
                  style="height:46px;line-height:46px;padding-left: 10px;">
                  <lui-tooltip
                    class="item"
                    effect="dark"
                    :content="item.nodeNo"
                    placement="bottom">
                    <p class="table-p">{{ item.nodeNo }}</p>
                  </lui-tooltip>
                </lui-col>
                <lui-col
                  :span="6"
                  class="table-p"
                  style="height:46px;line-height:46px;padding-left: 10px;">
                  <span>{{ formatNodeName(item.nodeType) }}</span>
                  <!-- <span v-if="item.nodeType == 1">供应商（工厂）</span>
                  <span v-if="item.nodeType == 2">区域仓</span>
                  <span v-if="item.nodeType == 3">前置仓</span>
                  <span v-if="item.nodeType == 4">门店</span>
                  <span v-if="item.nodeType == 5">中央仓</span> -->
                </lui-col>
                <lui-col
                  :span="4"
                  class="table-p"
                  style="height:46px;line-height:46px;padding-left: 10px;">
                  {{ item.priority }}
                </lui-col>
              </lui-row>
            </div>
          </template>
        </lui-table-column>

        <lui-table-column
          prop=""
          fixed="right"
          width="80"
          label="操作">
          <template slot-scope="{row}">
            <lui-button
              type="text"
              @click="handleEdit(row)">编辑</lui-button>
          </template>
        </lui-table-column>
      </lui-table>
      <div class="footer">
        <lui-pagination
          v-show="tableData.length>0"
          background
          :page-size="pageSize"
          :current-page="pageNum"
          :page-sizes="[10, 20, 50, 70, 100]"
          layout=" prev, pager, next, sizes, jumper"
          :total="total"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange">
        </lui-pagination>
      </div>
      <lui-dialog
        title="库节点覆盖范围配置"
        class="custom-dialog"
        :close-on-click-modal="false"
        :visible.sync="dialogVisible"
        width="640px">
        <div v-if="step === 1">
          <lui-form ref="ruleForm" :model="ruleForm" :rules="rules">
            <lui-form-item label="事业部" prop="dept" label-width="70px">
              <lui-select
                v-model="ruleForm.dept"
                value-key="deptNo"
                :disabled="isEdit"
                style="width:100%"
                placeholder="请选择事业部"
                @change="changeSelectDept">
                <lui-option
                  v-for="item in deptOptions"
                  :key="item.deptNo"
                  :label="item.deptName"
                  :value="item">
                </lui-option>
              </lui-select>
            </lui-form-item>
          </lui-form>
          <div class="cascade-panel">
            <div class="custom-cascade" style="border-right: 1px solid #E0E0E0;">
              <div class="cascade-header">
                <lui-checkbox v-model="checkAll" :indeterminate="isIndeterminate" @change="handleCheckAllChange"></lui-checkbox>
                <div class="checkbox-label"><span>省/直辖市（{{ provinceLength }}）</span><span class="clear_x" @click="handleCheckAllChange(false)">清空</span></div>
              </div>
              <div class="cascade-body">
                <lui-checkbox-group v-model="checkedCities" @change="handleCheckedCitiesChange">
                  <lui-checkbox v-for="city in cities" :key="city.provinceId" :label="city">{{ city.provinceName }} <i class="lui-icon-arrow-right"></i></lui-checkbox>
                </lui-checkbox-group>
              </div>
            </div>
            <div class="custom-cascade">
              <div class="cascade-header">
                <lui-checkbox v-model="checkAllCity" :indeterminate="isIndeterminateCity" @change="handleCheckAllCityChange"></lui-checkbox>
                <div class="checkbox-label"><span>城市（{{ cityLength }}）</span><span class="clear_x" @click="handleCheckAllCityChange(false)">清空</span></div>
              </div>
              <div class="cascade-body">
                <lui-checkbox-group v-model="checkedCitieList" @change="handleCheckedCityChange">
                  <lui-checkbox v-for="city in citieList" :key="city.cityId" :label="city" :disabled="city.disabled">{{ city.cityName }}</lui-checkbox>
                </lui-checkbox-group>
              </div>
            </div>
          </div>
        </div>
        <div v-if="step === 2">
          <div class="dialog-title">
            <div class="line left"></div>
            配置仓库履约优先级
          </div>
          <div class="desc">优先级为该区域下单仓库的优先级，数值越小优先级越高（优先级不能重复）</div>
          <lui-form v-if="isEdit" ref="ruleForm" :model="ruleForm" :rules="rules">
            <lui-form-item label="事业部" prop="dept" label-width="90px">
              <lui-select
                v-model="ruleForm.dept"
                value-key="deptNo"
                :disabled="true"
                style="width:100%"
                placeholder="请选择事业部"
                @change="changeSelectDept">
                <lui-option
                  v-for="item in deptOptions"
                  :key="item.deptNo"
                  :label="item.deptName"
                  :value="item">
                </lui-option>
              </lui-select>
            </lui-form-item>
          </lui-form>
          <div class="custom-header">
            <div class="label" style="width:240px;margin-left:19px;">配入库节点</div>
            <div
              v-show="ruleForm.allocationType!=2"
              class="label"
              style="margin-left:90px">
              优先级
            </div>
            <div
              class="label"
              style="width:24px;position: absolute;right: 68px;">操作</div>
          </div>
          <draggable
            v-model="nodeList"
            :move="getdata"
            @update="datadragEnd">
            <div
              v-for="(item,index) in nodeList"
              :key="index"
              class="custom-item">
              <!-- @change="changeSelectNode" -->
              <div style="display:inline-block;width:240px;height:32px;margin-left:19px;float:left;">
                <lui-cascader
                  v-if="isCascader"
                  v-model="item.nodes"
                  :props="{value:'nodeNo',label:'nodeName'}"
                  :options="cascaderOpt"
                  placeholder="请选择库节点"
                  :show-all-levels="false"
                >
                </lui-cascader>
              </div>
              <div style="width:36px;height: 32px;line-height: 32px;text-align:center;display:inline-block;margin-left:90px;">{{ index + 1 }}  </div>
              <div class="operation">
                <lui-tooltip
                  popper-class="custom-tooltip"
                  effect="dark"
                  :visible-arrow="false"
                  content="上移"
                  placement="top">
                  <img class="moveup" src="@/assets/svg/moveup.svg" alt="" @click="moveUp(index, item)">
                </lui-tooltip>
                <lui-tooltip
                  popper-class="custom-tooltip"
                  effect="dark"
                  :visible-arrow="false"
                  content="删除"
                  placement="top">
                  <img class="remove" src="@/assets/svg/remove.svg" alt="" @click="removeNode(item,index)">
                </lui-tooltip>
              </div>
            </div>
          </draggable>
          <div class="add-nodeList">
            <span @click="addNode">
              <i class="lui-icon-plus"></i> 增加履约库节点
            </span>
          </div>
        </div>
        <span
          slot="footer"
          class="dialog-footer">
          <lui-button v-if="step === 1 || isEdit" @click="resetForm('ruleForm')">取 消</lui-button>
          <lui-button v-if="step !== 1 && !isEdit" @click="goBack()">返 回</lui-button>
          <lui-button
            v-if="step !== 1"
            :disabled="buttonDisabled"
            :loading="buttonDisabled"
            type="primary"
            @click="submitForm('ruleForm')">{{ buttonDisabled ? '提交中' : '确 定' }} </lui-button>
          <lui-button v-if="step === 1" type="primary" @click="handleConfigNode">配置仓库</lui-button>
        </span>
      </lui-dialog>
    </div>
    <lui-dialog
      class="error-dialog"
      title="删除失败"
      :visible.sync="dialogTableVisible"
      :close-on-click-modal="false">
      <div class="dialog-table-list">
        <div
          v-show="moreErr"
          style="color: red;font-size: 12px">异常太多，最多显示300条</div>
        <lui-table
          stripe
          size="mini"
          :data="gridData">
          <lui-table-column
            align="center"
            property="msg"
            label="异常原因">
            <template slot-scope="{row}">
              {{ row.msg }}
            </template>
          </lui-table-column>
        </lui-table>
      </div>
    </lui-dialog>
  </div>
</template>

<script>
import draggable from 'vuedraggable'
import Api from '@/api/index'
import Http from '@/lib/http'
import { exportExcel } from '@/utils/downloadRequest'
import ButtonList from '@/views/common/ButtonList'
import showEmptyImage from '@/components/common/showEmptyImage/index.vue'

const buttons = {
  upload: {
    noAsync: true,
    maxM: 10,
    uploadtips: '只能上传xlsx文件，文件大小不超过10M。',
    uploadtipsadd: '',
    uploadConfig: {
      uploadActionUrl: Http.baseContextUrl + 'baseNodePriority/batchUpload'
    },
    templateUrl: Http.baseContextUrl + 'baseNodePriority/downloadTemplate'
  }
  // fileName: 'userInfoFile'
}
export default {
  name: 'NodeRange',
  components: {
    ButtonList,
    showEmptyImage,
    draggable
  },
  data() {
    return {
      cityOpt: [],
      gridData: [],
      moreErr: false,
      dialogTableVisible: false, //删除错误提示
      buttons,
      isEclp: false,
      buttonDisabled: false,
      LoadingTable: false,
      checkDeptNo: true, //默认false表示不上传事业部
      dialogVisible: false,
      dialogMask: false,
      isEdit: false,
      baseURL: Http.baseContextUrl,
      // options: [],
      deptNo: '',
      deptOptions: [],
      addressOpt: [],
      tableData: [],
      total: 0,
      pageSize: 10,
      pageNum: 1,
      id: '',
      step: 1,
      ruleForm: {
        dept: ''
      },
      rules: {
        dept: [
          { required: true, message: '请选择事业部', trigger: 'change' }
        ]
      },
      multipleSelection: [],
      nodeList: [],
      nodes: [],
      checkAll: false,
      checkedCities: [],
      cities: [],
      isIndeterminate: true,
      cityOptions: [],
      citieList: [],
      checkAllCity: false,
      checkedCitieList: [],
      isIndeterminateCity: true,
      cityOptionsCity: [], //暂存已选中城市
      selectCityList: [],
      provinceLength: 0,
      cityLength: 0,
      cityIds: [],
      searchForm: {
        dept: '',
        cityCode: '',
        nodeNos: '',
        priority: ''
      },
      priorityOpt: [], //优先级下拉选
      cascaderOpt: [],
      noNodeCity: '', //未覆盖库节点城市
      cityList: [],
      isCascader: false,
      nodeTypeList: []
    }
  },
  watch: {
    checkedCities(newProv, old) {
      this.provinceLength = newProv.length
    },
    checkedCitieList(newCity, old) {
      this.cityLength = newCity.length
    }
  },
  mounted() {
    this.postListPage()
    this.queryDept()//事业部列表
    this.getAllAddress()//查询所有省市
    this.panelData()
  },
  methods: {
    formatNodeName(nodeType) {
      let nodeName = ''
      for (let i in this.nodeTypeList) {
        if (nodeType === this.nodeTypeList[i].code) {
          nodeName = this.nodeTypeList[i].name
          break
        }
      }
      return nodeName
    },
    //库节点类型
    panelData() {
      Api.BasicInfo.constantNodeType().then(row => {
        if (row.success) {
          this.nodeTypeList = row.data
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
      })
    },
    //模糊搜索
    querySearchAsync(queryString, cb) {
      Api.ConfigCenter.postKeywords({
        'displayFields': ['nodeNo', 'nodeName'], //返回字段
        'keyWords': ['nodeName'], //查询字段名称
        'rout': 'nodeRange',
        'value': this.searchForm.nodeNos //关键字
      }).then((res) => {
        if (res.success) {
          var results = res.data
          results.forEach(item => {
            item.value = item.nodeName
          })
          cb(results)
        }
      }).catch((e) => {
        console.error(e)
      })
    },
    handleCheckAllChange(val) { //选中所有省
      this.checkedCities = val ? this.cityOptions : []
      this.isIndeterminate = false
      this.cityLength = 0
      this.citieList = [] //清空市选中
      this.checkedCitieList = []
      this.provinceLength = 0 //选中省的数量
      if (val) {
        this.provinceLength = this.cities.length
        this.cities.forEach(item => {
          if (item.cityCos) {
            this.citieList.push(...item.cityCos)
          }
        })
        this.cityOptionsCity = this.citieList
      }
    },
    handleCheckedCitiesChange(value) { //单个选中省
      const checkedCount = value.length
      this.checkAll = checkedCount === this.cities.length
      this.isIndeterminate = checkedCount > 0 && checkedCount < this.cities.length
      this.citieList = []
      this.provinceLength = value.length
      value.forEach(item => {
        if (item.cityCos) {
          this.citieList.push(...item.cityCos)
        }
      })
      this.cityOptionsCity = this.citieList
    },
    handleCheckAllCityChange(val) { //选中所有市
      this.checkedCitieList = val ? this.cityOptionsCity : []
      this.selectCityList = val ? this.cityOptionsCity : []
      this.isIndeterminateCity = false
      this.cityLength = 0
      if (val) {
        this.cityLength = this.citieList.length
        this.cityOptionsCity.forEach(item => {
          this.cityIds.push(item.cityId) //查询库节点列表使用
        })
      }
    },
    handleCheckedCityChange(value) { //单个选中市
      const checkedCount = value.length
      this.checkAllCity = checkedCount === this.citieList.length
      this.isIndeterminateCity = checkedCount > 0 && checkedCount < this.citieList.length
      this.cityLength = value.length
      this.selectCityList = value //选中的城市
    },
    //解决级联回显问题
    resetCascader() {
      this.isCascader = false
      setTimeout(() => {
        this.isCascader = true
      }, 0)
    },
    moveUp(index, item) {
      //在上一项插入该项
      this.nodeList.splice(index - 1, 0, (this.nodeList[index]))
      //删除后一项
      this.nodeList.splice(index + 1, 1)
      this.resetCascader()
      if (index === 0) {
        this.$showErrorMsg('到顶啦！')
      }
    },
    getdata(evt) {
      //这里evt后续的内容根据具体的定义变量而定
    },
    datadragEnd(evt) {
      this.resetCascader()
    },
    query() {
      this.pageNum = 1
      this.postListPage()
    },
    handleRest() {
      this.searchForm.cityCode = '' //市id
      this.searchForm.dept = ''
      this.searchForm.priority = ''
      this.searchForm.nodeNos = ''
      this.postListPage()
    },
    changeSelectDept(val) { //选择事业部时清空内容
      this.nodeList = []//清空库节点
      this.cities = []//清空省选项
      this.citieList = []//清空市选项
      this.checkedCities = []//清空已选中省
      this.checkedCitieList = []//清空已选中市
      this.postAllCityNoCover()//查询已配置城市
    },
    //选择库节点 已选库节点置灰校验
    changeSelectNode() {
      for (var i in this.cascaderOpt) {
        for (var j in this.nodeList) {
          if (this.nodeList[j].nodes[0] === this.cascaderOpt[i].nodeNo) {
            for (var k in this.cascaderOpt[i].children) {
              this.cascaderOpt[i].children[k].disabled = false
              if (this.nodeList[j].nodes[1] === this.cascaderOpt[i].children[k].nodeNo) {
                this.$set(this.cascaderOpt[i].children[k], 'disabled', true)
                break
              }
            }
          }
        }
      }
    },
    removeNode(item, index) {
      this.nodeList.splice(index, 1)
    },
    addNode() {
      this.nodeList.push({
        nodeName: '',
        nodeNo: '',
        nodeType: 0,
        priority: 0,
        nodes: []
      })
    },
    handleSelectionChange(val) {
      this.multipleSelection = []
      val.forEach(item => {
        item.bodies.forEach(el => {
          this.multipleSelection.push({ cityCode: el.cityCode, deptNo: el.deptNo })
        })
      })
    },
    //查询未配置覆盖库节点
    postNoNodeCity() {
      Api.NodeRange.postNoNodeCity({
        deptNo: this.searchForm.dept ? this.searchForm.dept.deptNo : ''
      }).then((res) => {
        if (res.success) {
          this.noNodeCity = res.data
        }
      }).catch((e) => {
        console.error(e)
      })
    },
    //查询已配置库节点城市
    postAllCityNoCover() {
      Api.NodeRange.postAllCityNoCover({ deptNo: this.ruleForm.dept.deptNo }).then((res) => {
        if (res.success) {
          this.cityList = []
          this.cities = res.data.provinceCos //省下拉选项
          this.cityOptions = res.data.provinceCos //省下拉选备份
        }
      }).catch((e) => {
        console.error(e)
      })
    },
    //获取全部省市(查询时用)
    getAllAddress() {
      Api.NodeRange.getAllAddress().then((res) => {
        if (res.success) {
          this.cityOpt = res.data.provinceCos
          this.cityOpt.forEach(item => {
            item.value = item.provinceId //统一格式
            item.label = item.provinceName
            item.cityCos.forEach(el => {
              el.value = el.cityId //统一格式
              el.label = el.cityName
            })
          })
        }
      }).catch((e) => {
        console.error(e)
      })
    },
    //=========================================================>根据事业部获取库节点
    postNodesByDept() {
      Api.NodeRange.postNodesByDept(
        { 'deptNo': this.ruleForm.dept.deptNo }
      ).then((res) => {
        if (res.success) {
          this.cascaderOpt = res.data
          this.cascaderOpt.forEach((item) => {
            item.nodeNo = item.nodeTypeValue //字段必须跟子节点一样才能显示
            item.nodeName = item.nodeType //字段必须跟子节点一样才能显示
          })
        }
      }).catch((e) => {
        console.error(e)
      })
    },
    handleFocusPriority(val) {
      if (!this.searchForm.dept) {
        this.priorityOpt = []
        this.$showErrorMsg('请选择事业部')
      }
    },
    //=========================================================>根据事业部获取优先级下拉选
    handleSelectDept() {
      this.searchForm.priority = ''
      Api.NodeRange.postPriority(
        { 'deptNo': this.searchForm.dept.deptNo }
      ).then((res) => {
        if (res.success) {
          this.priorityOpt = res.data
        }
      }).catch((e) => {
        console.error(e)
      })
    },
    //==========================================================>删除库节点
    postDeleteBaseNodePriority() {
      if (!this.multipleSelection.length) {
        this.$message.error('请选择数据')
        return
      }
      this.$alert('<p style="font-size: 18px;color:#333">确认删除此条消息吗?</p><p style="font-size: 13px;color: #666">删除后，此条消息的相关内容信息将无法恢复</p>', '', {
        dangerouslyUseHTMLString: true,
        type: 'warning',
        center: true
      }).then(() => {
        this.LoadingTable = true
        Api.NodeRange.postDeleteBaseNodePriority({
          baseNodeDelParamCo: this.multipleSelection
        }).then((res) => {
          if (res.success) {
            this.postListPage()
            this.LoadingTable = false
          }
        }).catch((e) => {
          this.LoadingTable = false
          this.$showErrorMsg(e)
        })
      }).catch(() => {
        this.LoadingTable = false
      })
    },
    //添加
    handleAdd() {
      this.id = ''
      this.isEdit = false
      this.cities = [] //清空省选项
      this.citieList = []//清空市选项
      this.checkedCities = []//清空已选中省
      this.checkedCitieList = []//清空已选中市
      this.nodeList = []
      this.step = 1
      this.ruleForm.dept = ''
      this.dialogVisible = true
      this.$nextTick(() => {
        this.$refs['ruleForm'].clearValidate()
      })
    },
    //编辑
    handleEdit(row) {
      this.id = row.id
      this.isEdit = true
      this.ruleForm.dept = { deptNo: row.deptNo, deptName: row.deptName }
      this.step = 2
      this.postNodesByDept()//根据事业部获取库节点
      this.nodeList = JSON.parse(JSON.stringify(row.bodies))//避免更改原数据
      this.nodeList.forEach(item => {
        item.nodes = []
        this.$set(item.nodes, 0, item.nodeType)
        this.$set(item.nodes, 1, item.nodeNo)
      })
      this.resetCascader()
      this.dialogVisible = true
      this.selectCityList = [{//所选省市编辑时用
        'cityId': row.cityCode,
        'cityName': row.cityName,
        'provinceId': row.provinceCode,
        'provinceName': row.provinceName
      }]
    },
    //获取获取库节点列表
    handleConfigNode() {
      this.$refs['ruleForm'].validate((valid) => {
        if (valid) {
          const cityCos = [] //删除上次已选中的城市
          this.checkedCitieList.forEach(val => {
            if (!val.disabled) {
              cityCos.push(val)
            }
          })
          if (!cityCos.length) {
            this.$showErrorMsg('请勾选城市')
            return
          }
          this.postNodesByDept()//查询事业部下库节点
          this.resetCascader()
          this.step = 2
        }
      })
    },
    goBack() {
      this.step = 1
    },
    //查询列表
    postListPage() {
      this.LoadingTable = true
      Api.NodeRange.postListPage(
        {
          cityCode: this.searchForm.cityCode ? this.searchForm.cityCode[1] : '', //市id
          deptNo: this.searchForm.dept ? this.searchForm.dept.deptNo : '',
          priority: this.searchForm.priority,
          provinceCode: this.searchForm.cityCode ? this.searchForm.cityCode[0] : '', //省id
          nodeNos: this.searchForm.nodeNos ? [this.searchForm.nodeNos] : [],
          pageNum: this.pageNum,
          pageSize: this.pageSize
        }
      ).then((res) => {
        if (res.success) {
          this.tableData = res.data
          this.total = res.total
          this.LoadingTable = false
          this.postNoNodeCity()
        } else {
          this.$showErrorMsg(res.errMessage)
          this.LoadingTable = false
        }
      }).catch((e) => {
        this.LoadingTable = false
        this.$showErrorMsg(e)
      })
    },
    downloadClick() {
      const actionUrl = `${this.baseURL}baseNodePriority/download`
      const params = {
        cityCode: this.searchForm.cityCode ? this.searchForm.cityCode[1] : '', //市id
        deptNo: this.searchForm.dept ? this.searchForm.dept.deptNo : '',
        priority: this.searchForm.priority,
        provinceCode: this.searchForm.cityCode ? this.searchForm.cityCode[0] : '', //省id
        nodeNos: this.searchForm.nodeNos ? [this.searchForm.nodeNos] : [],
        pageNum: this.pageNum,
        pageSize: this.pageSize
      }
      exportExcel(actionUrl, params)
    },
    //添加
    saveBaseNodePriority(nodeList, cityCos) {
      const formData = {
        'baseNodePriorities': nodeList,
        'cityCos': cityCos,
        'deptName': this.ruleForm.dept.deptName,
        'deptNo': this.ruleForm.dept.deptNo
      }
      Api.NodeRange.saveBaseNodePriority(formData).then((res) => {
        if (res.success) {
          this.dialogVisible = false
          this.buttonDisabled = false
          this.postListPage()
          this.$message({
            type: 'success',
            message: '添加成功'
          })
        }
      }).catch((e) => {
        this.buttonDisabled = false
        this.$showErrorMsg(e)
      })
    },
    //编辑
    editBaseNodePriority(nodeList, cityCos) {
      const formData = {
        'baseNodePriorities': nodeList,
        'cityCos': cityCos,
        'deptName': this.ruleForm.dept.deptName,
        'deptNo': this.ruleForm.dept.deptNo
      }
      Api.NodeRange.editBaseNodePriority(formData).then((res) => {
        if (res.success) {
          this.dialogVisible = false
          this.buttonDisabled = false
          this.postListPage()
          this.$message({
            type: 'success',
            message: '编辑成功'
          })
        }
      }).catch((e) => {
        this.buttonDisabled = false
        this.$showErrorMsg(e)
      })
    },
    //事业部列表
    queryDept() {
      Api.BaseGoodsInfo.queryDept().then((res) => {
        if (res.success) {
          this.deptOptions = res.data
        }
      }).catch((e) => {
        console.error(e)
      })
    },
    handleSizeChange(val) {
      this.pageSize = val
      this.postListPage()
    },
    handleCurrentChange(val) {
      this.pageNum = val
      this.postListPage()
    },
    //校验库节点
    checkoutNodes() {
      if (!this.nodeList.length) {
        this.$showErrorMsg('库节点不能为空')
        return false
      }
      for (let j = 0; j < this.nodeList.length; j++) {
        if (!this.nodeList[j].value) {
          this.$showErrorMsg('库节点不能为空')
          return false
        }
      }
      for (let i = 0; i < this.nodeList.length - 1; i++) {
        if (this.nodeList[i].value.nodeNo === this.nodeList[i + 1].value.nodeNo) {
          this.$showErrorMsg('库节点不能重复添加')
          return false
        }
      }
      return true
    },
    //通过id查询对象
    getCascaderObj(nodeNo, opt) {
      for (var itm of opt) {
        if (itm.nodeNo === nodeNo) {
          opt = itm
          return itm
        }
      }
      return null
    },
    //提交
    submitForm(formName) {
      this.nodeList.forEach(item => {
        this.cascaderOpt.forEach(el => {
          if (item.nodes[0] === el.nodeNo) { //对比库节点类型
            item.value = this.getCascaderObj(item.nodes[1], el.children)
          }
        })
      })
      if (!this.checkoutNodes()) {
        return
      }
      const nodeList = JSON.parse(JSON.stringify(this.nodeList)) //深拷贝一份，避免删除node属性后回显不了
      nodeList.forEach((item, index) => {
        item.priority = index + 1
        item.nodeName = item.value.nodeName
        item.nodeNo = item.value.nodeNo
        item.nodeType = item.value.nodeType
        delete item.nodes
        delete item.value
      })
      const cityCos = [] //删除上次已选中的城市
      this.selectCityList.forEach(val => {
        if (!val.disabled) {
          cityCos.push(val)
        }
      })
      this.buttonDisabled = true
      if (this.isEdit) {
        this.editBaseNodePriority(nodeList, cityCos)
      } else {
        this.saveBaseNodePriority(nodeList, cityCos)
      }
    },
    //重置表单
    resetForm(formName) {
      this.dialogVisible = false
      this.$refs[formName].resetFields()
    }
  }
}
</script>
<style lang="scss">
.table-p {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  cursor: pointer;
  padding-right: 10px;
}
.node-range {
  .custom-item {
    &:hover{
      cursor: pointer;
      background: #FFFFFF;
      box-shadow: 0 1px 6px 0 rgba(0,0,0,0.20);
    }
    .lui-date-editor .lui-range-separator {
      width: 12%;
    }
    .lui-input-number .lui-input__inner {
      -webkit-appearance: none;
      padding-left: 0;
      padding-right: 0;
      text-align: left;
    }
    .lui-input-number__decrease,
    .lui-input-number__increase {
      width: 16px;
    }
  }
  .lui-table__header {
    th:nth-of-type(8) {
      .cell {
        padding: 0;
        line-height: 0;
        div{
          line-height: 23px;
        }
      }
    }
  }
  .custom-table_row {
    td:nth-of-type(8) {
      padding: 0;
      .cell {
        padding-left: 0;
        .lui-row_wrap:last-of-type {
          .lui-row {
            border-bottom: 0 !important;
          }
        }
      }
    }
  }
}
</style>
<style lang="scss" scoped>
@import '@/assets/stylus/main';
.node-range {
  min-height: 600px;
  .header-title {
    font-size: 16px;
    font-weight: 600;
    color: #333333;
    letter-spacing: 0;
    line-height: 16px;
    .line {
      margin: 2px 6px 0 0;
      width: 2px;
      height: 12px;
      background: $--gl-blue;
      border-radius: 2px;
    }
  }
  .header {
    background: #fff;
    padding: 30px 24px;
    box-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.1);
    border-radius: 0 4px 4px 4px;
    .search-box {
      margin-top: 20px;
      display: flex;
      justify-content: space-between;
      .header-left{
        width: calc(100% - 130px);
      }
      .cust-item{
        margin-right: 24px;
      }
      .label {
        font-size: 14px;
        height: 32px;
        line-height: 32px;
        margin-right: 12px;
      }
      .lui-select,
      .lui-input , .lui-cascader {
        width: 180px;
      }
    }
  }
  .custom-table {
    margin-top: 20px;
    background: #fff;
    padding: 0 24px;
    box-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.1);
    border-radius: 4px;
    .table-header {
      display: flex;
      justify-content: space-between;
      padding: 20px 0;
      .header-title {
        height: 32px;
        line-height: 32px;
        .line {
          margin: 10px 6px 0 0;
        }
        .sp2{
          margin-left:24px;
          font-size: 14px;
          color: #666666;
          font-weight: normal;
          i{margin-right: 8px;}
        }
      }
    }
  }
  .footer {
    padding: 20px 0 30px 0;
    text-align: right;
  }
  .custom-dialog{
    .lui-input-number{
      width: 100%;
    }
    .cascade-panel{
      display: flex;
      background: #FFFFFF;
      border: 1px solid #E0E0E0;
      border-radius: 4px;
      .custom-cascade{
        width: 50%;
        .cascade-header{
          height: 32px;
          line-height: 32px;
          padding: 0 24px 0 16px;
          font-size: 12px;
          color: #333333;
          background: rgba(13,108,162,0.05);
          .checkbox-label{
            padding-left: 10px;
            font-size: 12px;
            color: #333333;
            width: calc(100% - 14px);
            display: inline-flex;
            justify-content: space-between;
            .clear_x{
              cursor: pointer;
              color: $--gl-blue;
            }
          }
        }
        .cascade-body{
            height: 400px;
            overflow-y: auto;
           .lui-checkbox{
            height: 32px;
            line-height: 32px;
            padding: 0 24px 0 16px;
            margin-right: 0;
            display: block;
            &:hover{
              background: rgba(13,108,162,0.10);
            }
            .lui-icon-arrow-right{
              line-height: 32px;
              position: absolute;
              top: 0;
              right: 24px;
            }
          }
        }
      }
    }
    .dialog-title{
      font-size: 14px;
      font-weight: 600;
      color: #333333;
      letter-spacing: 0;
      line-height: 14px;
      .line {
        margin-right: 6px;
        width: 2px;
        height: 12px;
        background: $--gl-blue;
        border-radius: 2px;
      }
    }
    .desc{
      margin:10px 0 20px 6px;
      font-size: 12px;
      color: #999999;
      line-height: 12px;
    }
    .custom-header{
      height: 40px;
      line-height: 40px;
      padding: 0 12px;
      background: #f3f7fa;
      .label {
        float: left;
        color: #666666;
        font-size: 12px;
      }
    }
    .custom-item {
      position: relative;
      padding: 8px 12px;
      border-bottom: 1px solid #e0e0e0;
      .lui-cascader{
        width: 240px;
      }
      img{
        width: 17px;
        height: 17px;
      }
      .remove{
        margin-left: 12px;
      }
      .operation{
        display: inline-block;
        position: absolute;
        right: 45px;
        line-height: 32px;
      }
    }
    .add-nodeList {
      font-size: 14px;
      color: $--gl-blue;
      height: 48px;
      line-height: 48px;
      text-align: center;
      border-bottom: 1px solid #e0e0e0;
      span {
        cursor: pointer;
      }
    }
  }
}
</style>
