<template>
  <div class="inventory-data">
    <div class="header">
      <div class="header-title">
        <div class="line left"></div>
        筛选项
      </div>
      <div class="search-box">
        <div class="header-left">
          <lui-form :inline="true" label-width="100px">
            <lui-form-item label="事业部" class="cust-item">
              <lui-select
                v-model="searchForm.dept"
                clearable
                filterable
                value-key="deptNo"
                placeholder="请选择事业部">
                <lui-option
                  v-for="item in deptOptions"
                  :key="item.deptNo"
                  :label="item.deptName"
                  :value="item">
                </lui-option>
              </lui-select>
            </lui-form-item>
            <lui-form-item label="订单号" class="cust-item">
              <lui-input
                v-model.trim="searchForm.bizNo"
                placeholder="请输入订单号"
                clearable>
              </lui-input>
            </lui-form-item>
            <lui-form-item label="三级分类名称" class="cust-item">
              <lui-cascader
                v-if="isCascade"
                ref="cascaderAddr"
                v-model="cate3Idst"
                clearable
                placeholder="请选择三级分类名称"
                :props="propList"
                @change="handleSelectCate"
              ></lui-cascader>
            </lui-form-item>
            <lui-form-item label="商品名称" class="cust-item">
              <lui-input
                v-model.trim="searchForm.goodsName"
                placeholder="请输入商品名称/编码"
                clearable>
              </lui-input>
            </lui-form-item>
            <lui-form-item label="商家商品编码" class="cust-item">
              <lui-input
                v-model.trim="searchForm.isvGoodsNo"
                placeholder="请输入商家商品编码"
                clearable>
              </lui-input>
            </lui-form-item>
            <lui-form-item label="门店名称" class="cust-item">
              <lui-input
                v-model.trim="searchForm.nodeName"
                placeholder="请输入门店名称/编码"
                clearable>
              </lui-input>
            </lui-form-item>
            <lui-form-item label="订单日期" class="cust-item">
              <lui-date-picker
                v-model="searchForm.startEndTime"
                type="daterange"
                range-separator="至"
                start-placeholder="开始日期"
                end-placeholder="结束日期"
                :picker-options="pickerOptions"
                value-format="yyyy-MM-dd 00:00:00">
              </lui-date-picker>
            </lui-form-item>
          </lui-form>
        </div>
        <div class="header-right">
          <lui-button
            v-waves
            type="primary"
            @click="query">查询</lui-button>
          <lui-button
            v-waves
            @click="handleReset">重置</lui-button>
        </div>
      </div>
    </div>
    <div class="custom-table">
      <div class="table-header">
        <div class="header-title">
          <div class="line left"></div>
          <span class="sp1">数据列表</span>
        </div>
        <div>
          <lui-button
            v-waves
            type="primary"
            @click="downloadClick">批量下载</lui-button>
          <button-list
            ref="buttons"
            :buttons="buttons"
            :is-dyson="isDyson"
            :dyson-middle-id="dysonMiddleId"
            :configdept-no="searchForm.dept.deptNo"
            :check-dept-no="checkDeptNo"
            @uploadSuccess="postListPage">
          </button-list>
          <lui-button
            v-waves
            type="primary"
            @click="postDeleteDysonStoresOrder">手工删除</lui-button>
        </div>
      </div>
      <lui-table
        v-loading="loadingTable"
        :data="tableData"
        border
        row-class-name="custom-table_row"
        style="width: 100%"
        @selection-change="handleSelectionChange">
        <template slot="empty">
          <showEmptyImage></showEmptyImage>
        </template>
        <lui-table-column
          type="selection"
          fixed="left"
          align="center"
          width="50">
        </lui-table-column>
        <lui-table-column
          prop="deptNo"
          label="事业部编码"
          show-overflow-tooltip
          min-width="160">
        </lui-table-column>
        <lui-table-column
          prop="deptName"
          label="事业部名称"
          show-overflow-tooltip
          min-width="160">
        </lui-table-column>
        <lui-table-column
          prop="sellerNo"
          label="商家编码"
          show-overflow-tooltip
          min-width="160">
        </lui-table-column>
        <lui-table-column
          prop="sellerName"
          label="商家名称"
          show-overflow-tooltip
          min-width="160">
        </lui-table-column>
        <lui-table-column
          prop="nodeNo"
          label="门店编码"
          show-overflow-tooltip
          min-width="100">
        </lui-table-column>
        <lui-table-column
          prop="nodeName"
          label="门店名称"
          show-overflow-tooltip
          min-width="160">
        </lui-table-column>
        <lui-table-column
          prop="bizNo"
          label="订单号"
          show-overflow-tooltip
          min-width="160">
        </lui-table-column>
        <lui-table-column
          prop="opDate"
          label="订单日期"
          min-width="160">
        </lui-table-column>
        <lui-table-column
          prop="cate3Name"
          label="商品三级分类名称"
          show-overflow-tooltip
          min-width="140">
        </lui-table-column>
        <lui-table-column
          prop="goodsNo"
          label="商品编码"
          show-overflow-tooltip
          min-width="100">
        </lui-table-column>
        <lui-table-column
          prop="isvGoodsNo"
          label="商家商品编码"
          show-overflow-tooltip
          min-width="110">
        </lui-table-column>
        <lui-table-column
          prop="goodsName"
          label="商品名称"
          show-overflow-tooltip
          min-width="100">
        </lui-table-column>
        <lui-table-column
          prop="goodsNum"
          label="商品数量"
          min-width="">
        </lui-table-column>
        <lui-table-column
          prop="updateUser"
          label="修改人"
          show-overflow-tooltip
          min-width="100">
        </lui-table-column>
        <lui-table-column
          prop="updateTime"
          label="修改日期"
          min-width="160">
        </lui-table-column>
      </lui-table>
      <div class="footer">
        <lui-pagination
          v-show="tableData.length>0"
          background
          :page-size="pageSize"
          :current-page="pageNum"
          :page-sizes="[10, 20, 50, 70, 100]"
          layout="slot, prev, pager, next, sizes, jumper"
          :total="total"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange">
          <span class="lui-pagination__total">共 {{ count }} 条</span>
        </lui-pagination>
      </div>
    </div>
  </div>
</template>

<script>
import Api from '@/api/index'
import Http from '@/lib/http'
import { exportExcel } from '@/utils/downloadRequest'
import ButtonList from '@/views/common/ButtonList'
import showEmptyImage from '@/components/common/showEmptyImage/index.vue'

const buttons = {
  upload: {
    noAsync: true, //为ture时允许添加参数
    maxM: 10, //上传限制10M
    uploadtips: '只能上传xlsx文件，文件大小不超过10M。', //上传页面提示
    uploadtipsadd: '', //扩展性提示字段
    //上传接口地址
    uploadConfig: {
      uploadActionUrl: Http.baseContextUrl + 'dysonStoresOrder/batchUpload'
    },
    //下载模板地址
    templateUrl: Http.baseContextUrl + 'dysonStoresOrder/downloadTemplate'
  }
}
export default {
  name: 'inventoryData',
  components: {
    ButtonList,
    showEmptyImage
  },
  data() {
    return {
      isDyson: true,
      dysonMiddleId: '', //当覆盖成功后，状态改为已覆盖
      cate3Idst: '', //级联选择器绑定的值
      isCascade: true,
      buttons,
      loadingTable: false,
      checkDeptNo: true, //默认false表示不上传事业部
      baseURL: Http.baseContextUrl,
      deptOptions: [],
      tableData: [],
      total: 0, //当前显示条数
      count: 0, //实际总条数
      pageSize: 10,
      pageNum: 1,
      multipleSelection: [],
      searchForm: {
        dept: '',
        bizNo: '',
        cate3Id: '',
        goodsName: '',
        nodeName: '',
        isvGoodsNo: '',
        startEndTime: ''
      },
      //校验查询日期截止到今天
      pickerOptions: {
        disabledDate(time) {
          return time.getTime() > Date.now() - 8.64e6
        }
      },
      propList: {
        lazy: true,
        async lazyLoad(node, resolve) {
          setTimeout(() => {
            if (node.level === 0) {
              Api.BaseGoodsInfo.category().then(res => {
                const cities = res.data.map((value, i) => ({
                  value: value.cate1Id,
                  label: value.cate1Name,
                  leaf: node.level >= 2 //控制几级数据
                }))
                // 通过调用resolve将子节点数据返回，通知组件数据加载完成
                resolve(cities)
              }).catch((e) => {
                console.error(e)
              })
            }

            if (node.level === 1) {
              Api.BaseGoodsInfo.category({
                cate1Id: node.value
              }).then(res => {
                const cities = res.data.map((value, i) => ({
                  value: value.cate2Id,
                  label: value.cate2Name,
                  leaf: node.level >= 2 //控制几级数据
                }))
                // 通过调用resolve将子节点数据返回，通知组件数据加载完成
                resolve(cities)
              }).catch((e) => {
                console.error(e)
              })
            }
            if (node.level === 2) {
              Api.BaseGoodsInfo.category({
                cate1Id: node.path[0],
                cate2Id: node.path[1]
              }).then(res => {
                const cities = res.data.map((value, i) => ({
                  value: value.cate3Id,
                  label: value.cate3Name,
                  leaf: node.level >= 2 //控制几级数据
                }))
                // 通过调用resolve将子节点数据返回，通知组件数据加载完成
                resolve(cities)
              }).catch((e) => {
                console.error(e)
              })
            }
          }, 300)
        }
      }
    }
  },
  mounted() {
    this.postListPage()
    this.queryDept()
  },
  methods: {
    //列表查询
    query() {
      this.pageNum = 1
      this.postListPage()
    },
    //商品分类级联
    handleSelectCate(val) {
      this.searchForm.cate3Id = this.cate3Idst[2]
    },
    //重置查询条件
    handleReset() {
      this.searchForm.goodsName = ''
      this.searchForm.dept = ''
      this.searchForm.bizNo = ''
      this.searchForm.nodeName = ''
      this.searchForm.isvGoodsNo = ''
      this.cate3Idst = ''
      this.searchForm.cate3Id = ''
      this.searchForm.startEndTime = ''
      this.postListPage()
    },
    //选中数据
    handleSelectionChange(val) {
      this.multipleSelection = []
      val.forEach(item => {
        this.multipleSelection.push(item.uniqueKey)
      })
    },
    //覆盖数据
    postOverlay(middleId) {
      this.$alert('<p style="font-size: 18px;color:#333">确认覆盖此条记录吗?</p>', '', {
        dangerouslyUseHTMLString: true,
        type: 'warning',
        center: true
      }).then(() => {
        Api.SalesData.postOverlay({ 'middleId': middleId }).then((res) => {
          if (res.success) {
            this.dysonMiddleId = middleId
            this.postListPage()
            this.$message({
              message: '操作成功',
              type: 'success'
            })
          }
        }).catch((e) => {
          console.log(e)
        })
      }).catch((e) => {
        console.log(e)
      })
    },
    //删除数据
    postDeleteDysonStoresOrder() {
      if (!this.multipleSelection.length) {
        this.$message.error('请选择数据')
        return
      }
      this.$alert('<p style="font-size: 18px;color:#333">确认删除此条记录吗?</p>', '', {
        dangerouslyUseHTMLString: true,
        type: 'warning',
        center: true
      }).then(() => {
        this.loadingTable = true
        Api.SalesData.postDeleteDysonStoresOrder({
          keys: this.multipleSelection
        }).then((res) => {
          if (res.success) {
            this.postListPage()
            this.loadingTable = false
          }
        }).catch((e) => {
          this.loadingTable = false
          this.$showErrorMsg(e)
        })
      }).catch(() => {
        this.loadingTable = false
      })
    },
    //查询列表
    postListPage() {
      this.loadingTable = true
      Api.SalesData.postListPage(
        {
          'pageNum': this.pageNum,
          'pageSize': this.pageSize,
          'deptNo': this.searchForm.dept ? this.searchForm.dept.deptNo : '',
          'bizNo': this.searchForm.bizNo,
          'goodsName': this.searchForm.goodsName,
          'nodeName': this.searchForm.nodeName,
          'cate3Id': this.searchForm.cate3Id,
          'isvGoodsNo': this.searchForm.isvGoodsNo,
          'startTime': this.searchForm.startEndTime ? this.searchForm.startEndTime[0] : '',
          'endTime': this.searchForm.startEndTime ? this.searchForm.startEndTime[1] : ''
        }
      ).then((res) => {
        if (res.success && res.data) {
          this.tableData = res.data
          this.total = res.total
          this.count = res.count
          this.loadingTable = false
        } else {
          this.$showErrorMsg(res.errMessage)
          this.loadingTable = false
        }
      }).catch((e) => {
        this.loadingTable = false
        this.$showErrorMsg(e)
        console.log(e)
      })
    },
    //下载方法
    downloadClick() {
      const actionUrl = `${this.baseURL}dysonStoresOrder/download`
      const params = {
        'deptNo': this.searchForm.dept ? this.searchForm.dept.deptNo : '',
        'bizNo': this.searchForm.bizNo,
        'goodsName': this.searchForm.goodsName,
        'nodeName': this.searchForm.nodeName,
        'cate3Id': this.searchForm.cate3Id,
        'isvGoodsNo': this.searchForm.isvGoodsNo,
        'startTime': this.searchForm.startEndTime ? this.searchForm.startEndTime[0] : '',
        'endTime': this.searchForm.startEndTime ? this.searchForm.startEndTime[1] : ''
      }
      exportExcel(actionUrl, params)
    },
    //查询事业部列表
    queryDept() {
      Api.BaseGoodsInfo.queryDept().then((res) => {
        if (res.success) {
          this.deptOptions = res.data
        }
      }).catch((e) => {
        console.log(e)
      })
    },
    //改变列表条数
    handleSizeChange(val) {
      this.pageSize = val
      this.postListPage()
    },
    //改变列表页数
    handleCurrentChange(val) {
      this.pageNum = val
      this.postListPage()
    }
  }
}
</script>
<style lang="scss">
.inventory-data {
  .lui-date-editor .lui-range-separator {
    width: 12%;
  }
}
</style>
<style lang="scss" scoped>
@import '@/assets/stylus/main';
.inventory-data {
  min-height: 600px;
  .header-title {
    font-size: 16px;
    font-weight: 600;
    color: #333333;
    letter-spacing: 0;
    line-height: 16px;
    .line {
      margin: 2px 6px 0 0;
      width: 2px;
      height: 12px;
      background: $--gl-blue;
      border-radius: 2px;
    }
  }
  .header {
    background: #fff;
    padding: 30px 24px;
    box-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.1);
    border-radius: 0 4px 4px 4px;
    .search-box {
      margin-top: 20px;
      .header-left{
        width: calc(100% - 130px);
      }
      .header-right{
        text-align: right;
      }
      .cust-item{
        margin-right: 24px;
      }
      .label {
        font-size: 14px;
        height: 32px;
        line-height: 32px;
        margin-right: 12px;
      }
      .lui-select,
      .lui-input , .lui-cascader {
        width: 180px;
      }
    }
  }
  .custom-table {
    margin-top: 20px;
    background: #fff;
    padding: 0 24px;
    box-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.1);
    border-radius: 4px;
    .table-header {
      display: flex;
      justify-content: space-between;
      padding: 20px 0;
      .header-title {
        height: 32px;
        line-height: 32px;
        .line {
          margin: 10px 6px 0 0;
        }
        .sp2{
          margin-left:24px;
          font-size: 14px;
          color: #666666;
          font-weight: normal;
          i{margin-right: 8px;}
        }
      }
    }
  }
  .footer {
    padding: 20px 0 30px 0;
    text-align: right;
  }
}
</style>
