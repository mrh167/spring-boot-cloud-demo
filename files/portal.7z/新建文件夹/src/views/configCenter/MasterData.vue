<template>
  <div class="masterData">
    <div class="master-header">
      <lui-row>
        <lui-col :span="24" class="header-top">
          <span class="header-border"></span>
          <span class="header-title">筛选项</span>
        </lui-col>
      </lui-row>
      <lui-row>
        <lui-col
          :span="18"
          class="header-select header-select-one">
          <div class="select-content">
            <span class="content-title">事业部</span>
            <lui-select
              v-model="deptNo"
              clearable
              style="width: 220px;"
              placeholder="请选择事业部"
            >
              <lui-option
                v-for="(item,index) in deptNoList"
                :key="index"
                :label="item.deptName"
                :value="item.deptNo+'&'+item.deptName">
              </lui-option>
            </lui-select>
          </div>
          <div class="select-content">
            <span class="content-title">商品编码</span>
            <lui-input
              v-model="goodsNo"
              style="width: 220px;"
              clearable
              placeholder="请输入商品编码">
            </lui-input>
          </div>
          <div class="select-content">
            <span class="content-title">商品分类</span>
            <lui-cascader
              ref="cascaderAddr"
              v-model="cate3Idst"
              clearable
              style="width: 220px;"
              placeholder="请选择商品分类"
              :props="propList"
              @change="handleSelectCate"
            ></lui-cascader>
          </div>
        </lui-col>
        <lui-col :span="6" class="header-button">
          <lui-button type="primary" style="width: 80px;" @click="handleQuery">查询</lui-button>
          <lui-button style="width: 80px;" @click="handleRest">重置</lui-button>
        </lui-col>
      </lui-row>
    </div>
    <div class="master-container">
      <div class="container-top">
        <div class="container-top-left">
          <span class="header-border"></span>
          <span class="header-title">数据</span>
        </div>
        <div class="container-top-right">
          <lui-button type="primary" @click="download">批量下载</lui-button>
          <button-list
            v-if="getIsEclp"
            ref="buttons"
            :buttons="buttons"
            :configdept-no="deptNo.split('&')[0]"
            :configdept-name="deptNo.split('&')[1]"
            :check-dept-no="checkDeptNo"
            @uploadSuccess="getList"
          >
          </button-list>
          <lui-button v-if="getIsEclp" type="primary" @click="handleDeled">手工删除</lui-button>
          <lui-button v-if="getIsEclp" type="primary" @click="handleAdd">手工添加</lui-button>
        </div>
      </div>

      <div class="container-table">
        <div class="container-table-cont">
          <lui-table
            v-loading="LoadingTable"
            :data="tableData"
            border
            style="width: 100%"
            @selection-change="handleSelectionChange">
            <template slot="empty">
              <showEmptyImage></showEmptyImage>
            </template>
            <lui-table-column
              align="center"
              fixed="left"
              type="selection"
              width="50">
            </lui-table-column>
            <lui-table-column
              prop="deptNo"
              min-width="170"
              label="事业部编码"
              show-overflow-tooltip>
            </lui-table-column>
            <lui-table-column
              prop="deptName"
              min-width="170"
              label="事业部名称">
              <template v-slot="{row}">
                <p class="table-p">{{ row.deptName }}</p>
              </template>
            </lui-table-column>
            <lui-table-column
              prop="sellerNo"
              label="商家编码"
              min-width="170"
              show-overflow-tooltip>
            </lui-table-column>
            <lui-table-column
              prop="goodsNo"
              label="商品编码"
              min-width="170"
              show-overflow-tooltip>
            </lui-table-column>
            <lui-table-column
              prop="goodsName"
              min-width="170"
              label="商品名称"
              show-overflow-tooltip>
            </lui-table-column>
            <lui-table-column
              min-width="250"
              label="商品类目"
              prop="cateName"
              show-overflow-tooltip>
              <!-- <template v-slot="{row}">
                <p v-if="row.cate1Id!==''&&row.cate1Id!==null" class="table-p">{{ row.cateName }}</p>
                <p v-else></p>
              </template> -->
            </lui-table-column>
            <lui-table-column
              width="80"
              prop="isSale"
              align="center"
              label="是否在售">
              <template v-slot="{row}">
                <lui-tag v-if="row.isSale===1" type="success" size="small">是</lui-tag>
                <lui-tag v-else type="danger" size="small">否</lui-tag>
              </template>
            </lui-table-column>
            <lui-table-column
              prop="updateUser"
              width="130"
              label="修改人"
              show-overflow-tooltip>
            </lui-table-column>
            <lui-table-column
              prop="updateTime"
              width="160"
              label="修改时间">
            </lui-table-column>
            <lui-table-column
              fixed="right"
              width="100"
              align="center"
              label="操作">
              <template v-slot="{row}">
                <div class="table-button">
                  <lui-button type="text" @click="handleEdit(row,true)">查看</lui-button>
                  <lui-button v-if="getIsEclp" type="text" @click="handleEdit(row,false)">编辑</lui-button>
                </div>
              </template>
            </lui-table-column>
          </lui-table>
        </div>
        <div v-show="tableData.length>0" class="knowledge-pagination">
          <lui-pagination
            background
            :current-page.sync="pageNum"
            :page-sizes="[10, 20, 50, 70, 100]"
            layout="prev, pager, next, sizes, jumper"
            :total="totals"
            @current-change="handleSizeChange"
            @size-change="sizeChange">
          </lui-pagination>
        </div>
      </div>
    </div>
    <!--  新增 ======= 编辑 =======查看 -->
    <lui-dialog
      v-if="centerDialogVisible"
      :visible.sync="centerDialogVisible"
      width="77%"
      top="10vh"
      :close-on-click-modal="false"
      class="dialog_mask"
      :title="stateTitle"
      @close="closeDialog('ruleForm')">
      <lui-form
        ref="ruleForm"
        :model="ruleForm"
        :rules="rules"
        label-width="110px"
        class="demo-ruleForm">
        <div class="popup-container">
          <div class="pupop-container-title">
            <span>商品基本信息</span>
            <span @click="popupShow1 = !popupShow1">
              <i :class="popupShow1 ? 'lui-icon-arrow-cycle-up' : 'lui-icon-arrow-cycle-down-solid'"></i>
            </span>
          </div>
          <lui-collapse-transition>
            <div v-show="popupShow1" class="popup-container-main">
              <lui-row :gutter="20">
                <lui-col :span="12">
                  <lui-form-item
                    label="事业部"
                    prop="deptNo">
                    <lui-select
                      v-model="ruleForm.deptNo"
                      :disabled="disabledShow"
                      style="width: 100%;"
                      placeholder="请选择事业部"
                      @change="handleDept">
                      <lui-option
                        v-for="(item,index) in deptNoList"
                        :key="index"
                        :label="item.deptName"
                        :value="item.deptNo">
                      </lui-option>
                    </lui-select>
                  </lui-form-item>
                </lui-col>
                <lui-col v-if="lookButShow" :span="12">
                  <lui-form-item
                    v-if="showCitry"
                    label="商品分类"
                    prop="cate3Id">
                    <lui-cascader
                      v-model="ruleFromcate3Id"
                      :disabled="disabledShow"
                      placeholder="请选择商品分类"
                      style="width: 100%"
                      :props="propList"
                      @change="handleSelectCateAdd"
                    ></lui-cascader>
                  </lui-form-item>
                </lui-col>
                <lui-col v-if="!lookButShow" :span="12">
                  <lui-form-item
                    label="商品分类"
                    prop="cate3Id">
                    <lui-input
                      v-model="cateIdName"
                      :disabled="disabledEdit">
                    </lui-input>
                  </lui-form-item>
                </lui-col>
              </lui-row>
              <lui-row :gutter="20">
                <lui-col :span="12">
                  <lui-form-item
                    label="商品编码"
                    prop="goodsNo">
                    <lui-input
                      v-model="ruleForm.goodsNo"
                      :disabled="disabledEdit"
                      placeholder="请输入商品编码"
                      maxlength="30"
                      @input="e => ruleForm.goodsNo = specialForbid (e)">
                    </lui-input>
                  </lui-form-item>
                </lui-col>
                <lui-col :span="12">
                  <lui-form-item
                    label="商品名称"
                    prop="goodsName">
                    <lui-input
                      v-model="ruleForm.goodsName"
                      :disabled="disabledShow"
                      maxlength="100"
                      placeholder="请输入商品名称"
                      @input="e => ruleForm.goodsName = specialForbid (e)">
                    </lui-input>
                  </lui-form-item>
                </lui-col>
              </lui-row>
              <lui-row :gutter="20">
                <lui-col :span="12">
                  <lui-form-item
                    label="品牌名称"
                    prop="brandName">
                    <lui-input
                      v-model="ruleForm.brandName"
                      :disabled="disabledShow"
                      placeholder="请输入品牌"
                      maxlength="100"
                      @input="e => ruleForm.brandName = specialForbid (e)">
                    </lui-input>
                  </lui-form-item>
                </lui-col>
                <lui-col :span="12">
                  <lui-form-item
                    label="品牌编码"
                    prop="brandNo">
                    <lui-input
                      v-model="ruleForm.brandNo"
                      :disabled="disabledShow"
                      maxlength="50"
                      placeholder="请输入品牌"
                      @input="e => ruleForm.brandNo = specialForbid (e)">
                    </lui-input>
                  </lui-form-item>
                </lui-col>
              </lui-row>
              <lui-row :gutter="20">
                <lui-col :span="12">
                  <lui-form-item
                    label="商品类型"
                    prop="goodsType">
                    <lui-select
                      v-model="ruleForm.goodsType"
                      :disabled="disabledShow"
                      style="width: 100%;"
                      placeholder="请选择商品类型">
                      <lui-option
                        v-for="(item,index) in goodsTypeList"
                        :key="index"
                        :label="item.name"
                        :value="item.code">
                      </lui-option>
                    </lui-select>
                  </lui-form-item>
                </lui-col>
                <lui-col :span="12">
                  <lui-form-item
                    label="系列"
                    prop="series">
                    <lui-input
                      v-model="ruleForm.series"
                      :disabled="disabledShow"
                      maxlength="255"
                      placeholder="请输入商品系列"
                      @input="e => ruleForm.series = specialForbid (e)">
                    </lui-input>
                  </lui-form-item>
                </lui-col>
              </lui-row>
              <lui-row :gutter="20">
                <lui-col :span="12">
                  <lui-form-item
                    label="商品码"
                    prop="itemNumber">
                    <lui-input
                      v-model="ruleForm.itemNumber"
                      :disabled="disabledShow"
                      maxlength="20"
                      placeholder="请输入商品码"
                      @input="e => ruleForm.itemNumber = specialForbid (e)">
                    </lui-input>
                  </lui-form-item>
                </lui-col>
                <lui-col :span="12">
                  <lui-form-item
                    label="金额band"
                    prop="amwayAmountBand">
                    <lui-input
                      v-model="ruleForm.amwayAmountBand"
                      :disabled="disabledShow"
                      maxlength="20"
                      placeholder="请输入金额band"
                      @input="e => ruleForm.amwayAmountBand = specialForbid (e)">
                    </lui-input>
                  </lui-form-item>
                </lui-col>
              </lui-row>
              <lui-row :gutter="20">
                <lui-col :span="12">
                  <lui-form-item
                    label="提货点"
                    prop="pickUpPoint">
                    <lui-input
                      v-model="ruleForm.pickUpPoint"
                      :disabled="disabledShow"
                      maxlength="10"
                      placeholder="请输入提货点"
                      @input="e => ruleForm.pickUpPoint = specialForbid (e)">
                    </lui-input>
                  </lui-form-item>
                </lui-col>
                <lui-col :span="12">
                </lui-col>
              </lui-row>
            </div>
          </lui-collapse-transition>
        </div>

        <div class="popup-container">
          <div class="pupop-container-title">
            <span>运营属性信息</span>
            <span @click="popupShow2 = !popupShow2">
              <i :class="popupShow2 ? 'lui-icon-arrow-cycle-up' : 'lui-icon-arrow-cycle-down-solid'"></i>
            </span>
          </div>
          <lui-collapse-transition>
            <div v-show="popupShow2" class="popup-container-main">
              <lui-row :gutter="20">
                <lui-col :span="12">
                  <lui-form-item
                    label="商家商品编码"
                    prop="isvGoodsNo">
                    <lui-input
                      v-model="ruleForm.isvGoodsNo"
                      :disabled="disabledEdit"
                      maxlength="100"
                      placeholder="请输入商家商品编码"
                      @input="e => ruleForm.isvGoodsNo = specialForbid (e)">
                    </lui-input>
                  </lui-form-item>
                </lui-col>
                <lui-col :span="12">
                  <lui-form-item
                    label="销售渠道"
                    prop="channel">
                    <lui-select
                      v-model="ruleForm.channel"
                      :disabled="disabledShow"
                      style="width: 100%;"
                      placeholder="请选择销售渠道">
                      <lui-option
                        v-for="item in channelList"
                        :key="item.code"
                        :label="item.name"
                        :value="item.code">
                      </lui-option>
                    </lui-select>
                  </lui-form-item>
                </lui-col>
              </lui-row>
              <lui-row :gutter="20">
                <lui-col :span="12">
                  <lui-form-item
                    label="上线时间"
                    prop="startDate">
                    <lui-date-picker
                      v-model="ruleForm.startDate"
                      :disabled="disabledShow"
                      style="width: 100%;"
                      value-format="yyyy-MM-dd HH:mm:ss"
                      type="datetime"
                      :picker-options="ruleForm.pickerBeginDateBefore"
                      placeholder="请选择上线时间"
                      @change="handleStartTime">
                    </lui-date-picker>
                  </lui-form-item>
                </lui-col>
                <lui-col :span="12">
                  <lui-form-item
                    label="预计下线时间"
                    prop="predictEndDate">
                    <lui-date-picker
                      v-model="ruleForm.predictEndDate"
                      :disabled="disabledShow"
                      style="width: 100%;"
                      value-format="yyyy-MM-dd HH:mm:ss"
                      type="datetime"
                      :picker-options="ruleForm.pickerBeginDateAfter"
                      placeholder="请选择预计下线时间"
                      @change="handleEndTime">
                    </lui-date-picker>
                  </lui-form-item>
                </lui-col>
              </lui-row>
              <lui-row :gutter="20">
                <lui-col :span="12">
                  <lui-form-item
                    label="首次入库时间"
                    prop="firstEntryTime">
                    <lui-date-picker
                      v-model="ruleForm.firstEntryTime"
                      :disabled="disabledShow"
                      value-format="yyyy-MM-dd HH:mm:ss"
                      style="width: 100%;"
                      type="datetime"
                      placeholder="请选择首次入库时间">
                    </lui-date-picker>
                  </lui-form-item>
                </lui-col>
                <lui-col :span="12">
                  <lui-form-item
                    label="停产时间"
                    prop="downtime">
                    <lui-date-picker
                      v-model="ruleForm.downtime"
                      :disabled="disabledShow"
                      value-format="yyyy-MM-dd HH:mm:ss"
                      style="width: 100%;"
                      type="datetime"
                      placeholder="请选择停产时间">
                    </lui-date-picker>
                  </lui-form-item>
                </lui-col>
              </lui-row>
              <lui-row :gutter="20">
                <lui-col :span="12">
                  <lui-form-item
                    label="季节"
                    prop="season">
                    <lui-select
                      v-model="seasonArray"
                      :disabled="disabledShow"
                      style="width: 100%;"
                      multiple
                      placeholder="请选择季节"
                      @change="handleSeason">
                      <lui-option
                        v-for="row in seasonList"
                        :key="row.code"
                        :label="row.name"
                        :value="row.code">
                      </lui-option>
                    </lui-select>
                  </lui-form-item>
                </lui-col>
                <lui-col :span="12">
                  <lui-form-item
                    label="生命周期"
                    prop="lifeCycle">
                    <lui-select
                      v-model="ruleForm.lifeCycle"
                      :disabled="disabledShow"
                      style="width: 100%;"
                      placeholder="请选择生命周期">
                      <lui-option
                        v-for="items in lifeCycleList"
                        :key="items.code"
                        :label="items.name"
                        :value="items.code">
                      </lui-option>
                    </lui-select>
                  </lui-form-item>
                </lui-col>
              </lui-row>
              <lui-row :gutter="20">
                <lui-col :span="12">
                  <lui-form-item
                    label="是否在售"
                    prop="isSale">
                    <lui-radio-group v-model="ruleForm.isSale" :disabled="disabledShow">
                      <lui-radio :label="1" class="button_radio">是</lui-radio>
                      <lui-radio :label="0" class="button_radio">否</lui-radio>
                    </lui-radio-group>
                  </lui-form-item>
                </lui-col>
              </lui-row>
            </div>
          </lui-collapse-transition>
        </div>

        <div class="popup-container">
          <div class="pupop-container-title">
            <span>采购属性信息</span>
            <span @click="popupShow3 = !popupShow3">
              <i :class="popupShow3 ? 'lui-icon-arrow-cycle-up' : 'lui-icon-arrow-cycle-down-solid'"></i>
            </span>
          </div>
          <lui-collapse-transition>
            <div v-show="popupShow3" class="popup-container-main">
              <lui-row :gutter="20">
                <lui-col :span="12">
                  <lui-form-item
                    label="供应商"
                    prop="supplierNo">
                    <lui-select
                      v-model="ruleForm.supplierNo"
                      :disabled="disabledShow"
                      style="width: 100%;"
                      placeholder="请选择供应商"
                      clearable
                      @change="handleBaseGoods">
                      <lui-option
                        v-for="(item,index) in BaseGoodsInfoList"
                        :key="index"
                        :label="item.supplierName"
                        :value="item.supplierNo">
                      </lui-option>
                    </lui-select>
                  </lui-form-item>
                </lui-col>
                <lui-col :span="12">
                  <lui-form-item
                    label="所属公司"
                    prop="company">
                    <lui-input v-model="ruleForm.company" maxlength="20" :disabled="disabledShow" placeholder="请输入所属公司"></lui-input>
                  </lui-form-item>
                </lui-col>
              </lui-row>
              <lui-row :gutter="20">
                <lui-col :span="12">
                  <lui-form-item
                    label="箱规"
                    prop="cartonSpec">
                    <lui-input v-model="ruleForm.cartonSpec" maxlength="10" :disabled="disabledShow" placeholder="请输入箱规"></lui-input>
                  </lui-form-item>
                </lui-col>
                <lui-col :span="12">
                  <lui-form-item
                    label="板规"
                    prop="palletCount">
                    <lui-input v-model="ruleForm.palletCount" :disabled="disabledShow" placeholder="请输入板规"></lui-input>
                  </lui-form-item>
                </lui-col>
              </lui-row>
              <lui-row :gutter="20">
                <lui-col :span="12">
                  <lui-form-item
                    label="金额"
                    prop="price">
                    <lui-input v-model="ruleForm.price" maxlength="16" :disabled="disabledShow" placeholder="请输入金额"></lui-input>
                  </lui-form-item>
                </lui-col>
                <lui-col :span="12">
                  <lui-form-item
                    label="采购单价"
                    prop="purchasePrice">
                    <lui-input v-model="ruleForm.purchasePrice" maxlength="13" :disabled="disabledShow" placeholder="请输入采购单价"></lui-input>
                  </lui-form-item>
                </lui-col>
              </lui-row>

              <lui-row :gutter="20">
                <lui-col :span="8">
                  <lui-form-item
                    label="是否紧急采购"
                    prop="isRushOrder">
                    <lui-radio-group v-model="ruleForm.isRushOrder" :disabled="disabledShow">
                      <lui-radio :label="1" class="button_radio">是</lui-radio>
                      <lui-radio :label="0" class="button_radio">否</lui-radio>
                    </lui-radio-group>
                  </lui-form-item>
                </lui-col>
                <lui-col v-if="isMoreBusinessShow" :span="8">
                  <lui-form-item
                    label="是否一品多商"
                    prop="isMoreBusiness">
                    <lui-radio-group
                      v-model="ruleForm.isMoreBusiness"
                      :disabled="disabledShow">
                      <lui-radio :label="1" class="button_radio">是</lui-radio>
                      <lui-radio :label="0" class="button_radio">否</lui-radio>
                    </lui-radio-group>
                  </lui-form-item>
                </lui-col>
                <lui-col :span="8">
                  <lui-form-item
                    label="是否外采"
                    prop="isOutside">
                    <lui-radio-group v-model="ruleForm.isOutside" :disabled="disabledShow">
                      <lui-radio :label="1" class="button_radio">是</lui-radio>
                      <lui-radio :label="0" class="button_radio">否</lui-radio>
                    </lui-radio-group>
                  </lui-form-item>
                </lui-col>
              </lui-row>
            </div>
          </lui-collapse-transition>
        </div>

        <div class="popup-container">
          <div class="pupop-container-title">
            <span>仓储属性信息</span>
            <span @click="popupShow4 = !popupShow4">
              <i :class="popupShow4 ? 'lui-icon-arrow-cycle-up' : 'lui-icon-arrow-cycle-down-solid'"></i>
            </span>
          </div>
          <lui-collapse-transition>
            <div v-show="popupShow4" class="popup-container-main">
              <lui-row :gutter="20">
                <lui-col :span="8">
                  <lui-form-item
                    label="是否恒温"
                    prop="isTemperature">
                    <lui-radio-group v-model="ruleForm.isTemperature" :disabled="disabledShow">
                      <lui-radio :label="1" class="button_radio">是</lui-radio>
                      <lui-radio :label="0" class="button_radio">否</lui-radio>
                    </lui-radio-group>
                  </lui-form-item>
                </lui-col>
                <lui-col :span="8">
                  <lui-form-item
                    label="运输危险品"
                    prop="isDangerous">
                    <!-- <lui-radio-group v-model="ruleForm.isDangerous" :disabled="disabledShow">
                      <lui-radio :label="1" class="button_radio">是</lui-radio>
                      <lui-radio :label="0" class="button_radio">否</lui-radio>
                    </lui-radio-group> -->
                    <lui-select
                      v-model="ruleForm.isDangerous"
                      :disabled="disabledShow"
                      style="width: 100%;"
                      clearable
                      placeholder="请选择">
                      <lui-option
                        v-for="(item,index) in dangerousList"
                        :key="index"
                        :label="item.name"
                        :value="item.code">
                      </lui-option>
                    </lui-select>
                  </lui-form-item>
                </lui-col>
                <lui-col :span="8">
                  <lui-form-item
                    label="保质期"
                    prop="expirationDate">
                    <lui-input v-model="ruleForm.expirationDate" maxlength="10" :disabled="disabledShow" placeholder="请输入保质期天数"></lui-input>
                  </lui-form-item>
                </lui-col>
              </lui-row>
              <lui-row :gutter="20">
                <lui-col :span="8">
                  <lui-form-item
                    label="长"
                    prop="length">
                    <!-- <lui-input v-model="ruleForm.length" maxlength="16" :disabled="disabledShow" placeholder="请输入长"></lui-input> -->
                    <lui-input-number
                      v-model.trim="ruleForm.length"
                      placeholder="请输入长"
                      style="width:100%;"
                      :min="0"
                      :max="9999999999999"
                      :precision="2"
                      :disabled="disabledShow"
                      :controls="false">
                    </lui-input-number>
                  </lui-form-item>
                </lui-col>
                <lui-col :span="8">
                  <lui-form-item
                    label="宽"
                    prop="width">
                    <!-- <lui-input v-model="ruleForm.width" maxlength="16" :disabled="disabledShow" placeholder="请输入宽"></lui-input> -->
                    <lui-input-number
                      v-model.trim="ruleForm.width"
                      placeholder="请输入宽"
                      style="width:100%;"
                      :min="0"
                      :max="9999999999999"
                      :precision="2"
                      :disabled="disabledShow"
                      :controls="false">
                    </lui-input-number>
                  </lui-form-item>
                </lui-col>
                <lui-col :span="8">
                  <lui-form-item
                    label="高"
                    prop="height">
                    <!-- <lui-input v-model="ruleForm.height" maxlength="16" :disabled="disabledShow" placeholder="高"></lui-input> -->
                    <lui-input-number
                      v-model.trim="ruleForm.height"
                      placeholder="请输入高"
                      style="width:100%;"
                      :min="0"
                      :max="9999999999999"
                      :precision="2"
                      :disabled="disabledShow"
                      :controls="false">
                    </lui-input-number>
                  </lui-form-item>
                </lui-col>
              </lui-row>
              <lui-row :gutter="20">
                <lui-col :span="8">
                  <lui-form-item
                    label="体积"
                    prop="volume">
                    <!-- <lui-input v-model="ruleForm.volume" maxlength="16" :disabled="disabledShow" placeholder="请输入体积"></lui-input> -->
                    <lui-input-number
                      v-model.trim="ruleForm.volume"
                      placeholder="请输入体积"
                      style="width:100%;"
                      :min="0"
                      :max="999999999"
                      :precision="6"
                      :disabled="disabledShow"
                      :controls="false">
                    </lui-input-number>
                  </lui-form-item>
                </lui-col>
                <lui-col :span="8">
                  <lui-form-item
                    label="毛重"
                    prop="gross">
                    <!-- <lui-input v-model="ruleForm.gross" maxlength="16" :disabled="disabledShow" placeholder="请输入毛重"></lui-input> -->
                    <lui-input-number
                      v-model.trim="ruleForm.gross"
                      placeholder="请输入毛重"
                      style="width:100%;"
                      :min="0"
                      :max="999999999999"
                      :precision="3"
                      :disabled="disabledShow"
                      :controls="false">
                    </lui-input-number>
                  </lui-form-item>
                </lui-col>
                <lui-col :span="8">
                  <lui-form-item
                    label="净重"
                    prop="net">
                    <!-- <lui-input v-model="ruleForm.net" maxlength="16" :disabled="disabledShow" placeholder="请输入净重"></lui-input> -->
                    <lui-input-number
                      v-model.trim="ruleForm.net"
                      placeholder="请输入净重"
                      style="width:100%;"
                      :min="0"
                      :max="999999999999"
                      :precision="3"
                      :disabled="disabledShow"
                      :controls="false">
                    </lui-input-number>
                  </lui-form-item>
                </lui-col>
              </lui-row>
            </div>
          </lui-collapse-transition>
        </div>

        <div class="popup-container">
          <div class="pupop-container-title">
            <span>汽后行业个性化字段</span>
            <span @click="popupShow5 = !popupShow5">
              <i :class="popupShow5 ? 'lui-icon-arrow-cycle-up' : 'lui-icon-arrow-cycle-down-solid'"></i>
            </span>
          </div>
          <lui-collapse-transition>
            <div v-show="popupShow5" class="popup-container-main">
              <lui-row :gutter="20">
                <lui-col :span="12">
                  <lui-form-item
                    label="在保率"
                    prop="warrantyRate">
                    <lui-input-number
                      v-model.trim="ruleForm.warrantyRate"
                      placeholder="请输入在保率"
                      style="width:100%;"
                      :min="0"
                      :max="100"
                      :precision="2"
                      controls-position="right"
                      :disabled="disabledShow"
                      :controls="false">
                    </lui-input-number>
                  </lui-form-item>
                </lui-col>
                <lui-col :span="12">
                  <lui-form-item
                    label="维修率"
                    prop="serviceRate">
                    <lui-input-number
                      v-model.trim="ruleForm.serviceRate"
                      placeholder="请输入维修率"
                      style="width:100%;"
                      :min="0"
                      :max="100"
                      :precision="2"
                      controls-position="right"
                      :disabled="disabledShow"
                      :controls="false">
                    </lui-input-number>
                  </lui-form-item>
                </lui-col>
              </lui-row>
              <lui-row :gutter="20">
                <lui-col :span="12">
                  <lui-form-item
                    label="整车保有量"
                    prop="vehicleOwnership">
                    <lui-input v-model="ruleForm.vehicleOwnership" maxlength="8" :disabled="disabledShow" placeholder="请输入整车保有量"></lui-input>
                  </lui-form-item>
                </lui-col>
                <lui-col :span="12">
                  <lui-form-item
                    label="车型"
                    prop="vehicleModel">
                    <lui-input
                      v-model="ruleForm.vehicleModel"
                      maxlength="20"
                      :disabled="disabledShow"
                      placeholder="请输入车型"
                      @input="e => ruleForm.vehicleModel = specialForbid (e)">
                    </lui-input>
                  </lui-form-item>
                </lui-col>
              </lui-row>
              <lui-row :gutter="20">
                <lui-col :span="12">
                  <lui-form-item
                    label="生产件"
                    prop="production">
                    <lui-input
                      v-model="ruleForm.production"
                      :disabled="disabledShow"
                      placeholder="请输入生产件"
                      maxlength="10"
                      @input="e => ruleForm.production = specialForbid (e)">
                    </lui-input>
                  </lui-form-item>
                </lui-col>
                <lui-col :span="12">
                  <lui-form-item
                    label="关联量"
                    prop="associated">
                    <lui-input
                      v-model="ruleForm.associated"
                      :disabled="disabledShow"
                      maxlength="10"
                      placeholder="请输入关联量"
                      @input="e => ruleForm.associated = specialForbid (e)">
                    </lui-input>
                  </lui-form-item>
                </lui-col>
              </lui-row>
              <lui-row :gutter="20">
                <lui-col :span="12">
                  <lui-form-item
                    label="配件等级"
                    prop="partsLevel">
                    <lui-input
                      v-model="ruleForm.partsLevel"
                      :disabled="disabledShow"
                      placeholder="请输入配件等级"
                      maxlength="10"
                      @input="e => ruleForm.partsLevel = specialForbid (e)">
                    </lui-input>
                  </lui-form-item>
                </lui-col>
                <lui-col :span="12">
                  <lui-form-item
                    label="车间需求归类"
                    prop="workshopCateg">
                    <lui-input
                      v-model="ruleForm.workshopCateg"
                      :disabled="disabledShow"
                      maxlength="100"
                      placeholder="请输入车间需求归类"
                      @input="e => ruleForm.workshopCateg = specialForbid (e)">
                    </lui-input>
                  </lui-form-item>
                </lui-col>
              </lui-row>
              <lui-row :gutter="20">
                <lui-col :span="12">
                  <lui-form-item
                    label="发货方"
                    prop="supplyBy">
                    <lui-input
                      v-model="ruleForm.supplyBy"
                      :disabled="disabledShow"
                      placeholder="请输入发货方"
                      maxlength="100"
                      @input="e => ruleForm.supplyBy = specialForbid (e)">
                    </lui-input>
                  </lui-form-item>
                </lui-col>
                <lui-col :span="12">
                  <lui-form-item
                    label="供应策略"
                    prop="supplyStrategy">
                    <lui-input
                      v-model="ruleForm.supplyStrategy"
                      :disabled="disabledShow"
                      maxlength="100"
                      placeholder="请输入供应策略"
                      @input="e => ruleForm.supplyStrategy = specialForbid (e)">
                    </lui-input>
                  </lui-form-item>
                </lui-col>
              </lui-row>
              <lui-row :gutter="20">
                <lui-col :span="12">
                  <lui-form-item
                    label="是否直接门店"
                    prop="isDirect">
                    <lui-radio-group v-model="ruleForm.isDirect" :disabled="disabledShow">
                      <lui-radio :label="1" class="button_radio">是</lui-radio>
                      <lui-radio :label="0" class="button_radio">否</lui-radio>
                    </lui-radio-group>
                  </lui-form-item>
                </lui-col>
                <lui-col :span="12">
                  <lui-form-item
                    label="活动影响"
                    prop="campaign">
                    <lui-input
                      v-model="ruleForm.campaign"
                      :disabled="disabledShow"
                      maxlength="100"
                      placeholder="请输入活动影响"
                      @input="e => ruleForm.campaign = specialForbid (e)">
                    </lui-input>
                  </lui-form-item>
                </lui-col>
              </lui-row>
            </div>
          </lui-collapse-transition>
        </div>
      </lui-form>
      <span slot="footer" class="dialog-footer">
        <lui-button @click="resetForm('ruleForm')">取 消</lui-button>
        <lui-button v-if="editButShow" :loading="buttonDisabled" @click="handlePreservation('ruleForm')">保 存</lui-button>
        <lui-button v-if="lookButShow" type="primary" :loading="buttonDisabled" @click="submitForm('ruleForm')">提 交</lui-button>
      </span>
    </lui-dialog>

    <lui-dialog
      class="error-dialog"
      title="删除失败"
      :visible.sync="dialogTableVisible"
      :close-on-click-modal="false">
      <div class="dialog-table-list">
        <div v-show="moreErr" style="color: red;font-size: 12px">异常太多，最多显示300条</div>
        <lui-table
          stripe
          size="mini"
          :data="gridData">
          <lui-table-column align="center" property="msg" label="异常原因">
            <template slot-scope="{row}">
              {{ row.msg }}
            </template>
          </lui-table-column>
        </lui-table>
      </div>
    </lui-dialog>
  </div>
</template>

<script>
import http from '@/lib/http'
import { exportExcel } from '@/utils/downloadRequest'
import ButtonList from '@/views/common/ButtonList'
import Api from '@/api'
import utils from '@/utils/utils'
import showEmptyImage from '@/components/common/showEmptyImage/index.vue'
import { mapGetters } from 'vuex'
import $ from 'jquery'

const buttons = {
  upload: {
    noAsync: true,
    maxM: 10,
    uploadtips: '只能上传xlsx文件，文件大小不超过10M',
    uploadConfig: {
      uploadActionUrl: http.baseContextUrl + 'baseGoodsInfo/upload'
    },
    templateUrl: http.baseContextUrl + 'baseGoodsInfo/downloadTemplate'
  }
}
export default {
  name: 'index',
  components: {
    showEmptyImage,
    ButtonList
  },
  data() {
    return {
      gridData: [],
      moreErr: false,
      dialogTableVisible: false, //删除错误提示
      buttons,
      checkDeptNo: true, //默认false表示不上传事业部
      baseURL: http.baseContextUrl,
      disabledEdit: false,
      lookButShow: false,
      editButShow: false,
      LoadingTable: false,
      cateIdName: '',
      isMoreBusinessShow: false, //一品多商新增隐藏
      centerDialogVisible: false, //新增==编辑弹窗
      ruleFromcate3Id: [], //商品分类
      buttonDisabled: false,
      disabledShow: false, //当是查看的时候禁用所有表单
      showCitry: false, //多次调用====>利用v-if特性 每次打开重新调用省市组件
      popupShow1: true,
      popupShow2: true,
      popupShow3: true,
      popupShow4: true,
      popupShow5: true,
      input: '',
      value: '',
      multipleSelection: [],
      channelList: [], //销售渠道
      goodsTypeList: [],
      seasonArray: [], //四季
      seasonList: [], //季节列表
      lifeCycleList: [], //生命周期
      BaseGoodsInfoList: [], //供应商列表
      dangerousList: [
        // { code: 0, name: '无效' },
        // { code: 1, name: '有效' },
        // { code: 2, name: '有限危险品' }
      ],
      tableData: [],
      cate3Id: '', //三级分类ID
      cate3Idst: '', //三级分类ID
      deptNo: '', //事业部编码
      deptNoList: [], //事业部列表
      goodsNo: '', //商品编码
      totals: 0,
      pageNum: 1, //页
      pageSize: 10, //条数
      stateShow: false, //新增编辑状态值
      stateTitle: '新增商品信息',
      nowTimeNew: '', //ajax获取时间
      ruleForm: {
        deptName: '', //商品基本信息-事业部
        deptNo: '',
        cate3Id: '', //商品分类
        goodsNo: '', //商品编码
        goodsName: '', //商品名称
        brandNo: '', //品牌ID
        brandName: '', //品牌名称
        series: '', //系列

        isvGoodsNo: '', //运营属性-商家编码
        channel: '', //渠道
        startDate: '', //上线时间
        pickerBeginDateBefore: {}, //上线时间
        predictEndDate: '', //下线时间
        pickerBeginDateAfter: {}, //下线时间
        firstEntryTime: '', //入库时间
        downtime: '', //停产时间
        season: '', //季节
        lifeCycle: '', //生命周期

        supplierName: '', //采购属性信息-供应商
        supplierNo: '', //供应商编号
        company: '', //所属公司
        cartonSpec: '', //箱规
        palletCount: '', //板规
        price: '', //金额
        purchasePrice: '', //采购单价
        isRushOrder: '', //是否紧急
        isSale: '', //是否在售
        isMoreBusiness: '', //一品多商
        isOutside: '', //是否外采

        isTemperature: '', //仓储信息-是否恒温
        isDangerous: '', //是否危险
        expirationDate: '', //保质期
        length: '', //长
        width: '', //宽
        height: '', //高
        volume: '', //体积
        gross: '', //毛重
        net: '', //净重

        goodsType: '', //气后行业-商品类型
        goodsId: '', //气后行业-商品ID
        warrantyRate: '', //在保率
        serviceRate: '', //维修率
        vehicleOwnership: '', //保有量
        vehicleModel: '', //车型
        production: '', //生产件
        associated: '', //关联量
        partsLevel: '', //配件等级
        priceWith: '', //价格带
        isDirect: '', //是否直接门店
        workshopCateg: '', //车间需求归类
        supplyBy: '', //发货方
        supplyStrategy: '', //供应策略
        campaign: '', //活动影响
        itemNumber: '', //商品码
        amwayAmountBand: '', //金额band
        pickUpPoint: ''//提货点
      },
      rules: {
        deptNo: [{ required: true, message: '请选择事业部', trigger: ['blur', 'change'] }],
        cate3Id: [{ required: true, message: '请选择商品分类', trigger: ['blur', 'change'] }],
        goodsNo: [{ required: true, message: '请输入商品编码', trigger: ['blur', 'change'] }],
        goodsName: [{ required: true, message: '请输入商品名称', trigger: ['blur', 'change'] }],
        brand: [{ required: true, message: '请输入商品品牌', trigger: ['blur', 'change'] }],
        isvGoodsNo: [{ required: true, message: '请输入商家商品编码', trigger: ['blur', 'change'] }],
        // isMoreBusiness: [{ required: true, message: '请选择', trigger: ['blur', 'change'] }],
        isRushOrder: [{ required: true, message: '请选择是否紧急采购', trigger: ['blur', 'change'] }],
        //金额数字类型输入控制
        // priceWith: [{ required: false, message: '请填写正确的价格带,保留两位小数', pattern: /(^[1-9]{1}[0-9]{0,9}$)|(^[0-9]*\.[0-9]{2}$)/ }],
        price: [{ required: false, message: '请填写正确的金额,保留两位小数', pattern: /^\+?(\d*\.\d{2})$/ }],
        purchasePrice: [{ required: false, message: '请填写正确的采购金额,保留两位小数', pattern: /^\+?(\d*\.\d{2})$/ }],
        // width: [{ required: false, message: '请填写正确的宽度,保留两位小数', pattern: /^\+?(\d*\.\d{2})$/ }],
        // volume: [{ required: false, message: '请填写正确的体积,保留六位小数', pattern: /^\+?(\d*\.\d{6})$/ }],
        // net: [{ required: false, message: '请填写正确的净重,保留三位小数', pattern: /^\+?(\d*\.\d{3})$/ }],
        // length: [{ required: false, message: '请填写正确的长度,保留两位小数', pattern: /^\+?(\d*\.\d{2})$/ }],
        // height: [{ required: false, message: '请填写正确的高度,保留两位小数', pattern: /^\+?(\d*\.\d{2})$/ }],
        // gross: [{ required: false, message: '请填写正确的毛重,保留三位小数', pattern: /^\+?(\d*\.\d{3})$/ }],
        palletCount: [{ required: false, message: '请填写正确的板规', pattern: /(^[1-9]{1}[0-9]*$)|(^[0-9]*\.[0-9]{1,2}$)/ }],
        //纯数字控制
        vehicleOwnership: [{ required: false, message: '请填写正确的整车保有量', pattern: /(^[1-9]{1}[0-9]*$)/ }],
        cartonSpec: [{ required: false, message: '请填写正确的箱规', pattern: /(^[1-9]{1}[0-9]*$)/ }],
        expirationDate: [{ required: false, message: '请填写正确的保质期天数', pattern: /(^[1-9]{1}[0-9]*$)/ }]
      }
    }
  },
  // created() {
  //   this.isEclp()
  // },
  computed: {
    ...mapGetters(['getIsEclp']),
    propList() {
      return {
        lazy: true,
        lazyLoad(node, resolve) {
          if (node) {
            if (node.level === 0) {
              Api.BaseGoodsInfo.category().then(res => {
                const cities = res.data.map((value) => ({
                  value: value.cate1Id,
                  label: value.cate1Name,
                  leaf: node.level >= 2 //控制几级数据
                }))
                // 通过调用resolve将子节点数据返回，通知组件数据加载完成
                resolve(cities)
              }).catch((e) => {
                this.$showErrorMsg(e)
              })
            }
            if (node.level === 1) {
              Api.BaseGoodsInfo.category({
                cate1Id: node.value
              }).then(res => {
                const cities = res.data.map((value) => ({
                  value: value.cate2Id,
                  label: value.cate2Name,
                  leaf: node.level >= 2 //控制几级数据
                }))
                // 通过调用resolve将子节点数据返回，通知组件数据加载完成
                resolve(cities)
              }).catch((e) => {
                this.$showErrorMsg(e)
              })
            }
            if (node.level === 2) {
              Api.BaseGoodsInfo.category({
                cate1Id: node.path[0],
                cate2Id: node.path[1]
              }).then(res => {
                const cities = res.data.map((value) => ({
                  value: value.cate3Id,
                  label: value.cate3Name,
                  leaf: node.level >= 2 //控制几级数据
                }))
                // 通过调用resolve将子节点数据返回，通知组件数据加载完成
                resolve(cities)
              }).catch((e) => {
                this.$showErrorMsg(e)
              })
            }
          } else {
            this.showCitry = false
            this.showCitry = true
          }
        }
      }
    }
  },
  created() {
    this.dataAjax()
  },
  mounted() {
    this.getList() //列表页加载
    this.queryDept() //事业部获取
    this.getDangerousList() //获取运输危险品列表
    this.channelType() //销售渠道
    this.goodsType() //商品类型
    this.lifeCycle() //生命周期
    this.season() //季节
  },
  methods: {
    dataAjax() { //获取当前时间
      const now = new Date($.ajax({ async: false }).getResponseHeader('Date'))
      this.nowTimeNew = now.getTime()
    },
    //获取运输危险品列表
    getDangerousList() {
      Api.BaseGoodsInfo.dangerous().then(row => {
        if (row.success) {
          this.dangerousList = row.data
        } else {
          this.$showErrorMsg(row.errMessage)
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
      })
    },
    handleStartTime() {
      if (this.ruleForm.startDate !== '') {
        // this.ruleForm.pickerBeginDateBefore = {
        //   disabledDate: (time) => {
        //     var end = new Date(this.ruleForm.predictEndDate).getTime() //结束时间
        //     if (end) {
        //       return (time.getTime() > new Date(this.ruleForm.predictEndDate).getTime()) || (time.getTime() < (this.nowTimeNew - 8.64e7))
        //     } else {
        //       return (time.getTime() < (this.nowTimeNew - 8.64e7))
        //     }
        //   }
        // }

        //结束日期小于开始日期
        this.ruleForm.pickerBeginDateAfter = {
          disabledDate: (time) => {
            var start = new Date(this.ruleForm.startDate).getTime()
            if (start) {
              return time.getTime() < start
            }
          }
        }
      }
    },

    handleEndTime() { //结束时间
      if (this.ruleForm.predictEndDate !== '') {
        // //结束日期小于开始日期
        // this.ruleForm.pickerBeginDateAfter = {
        //   disabledDate: (time) => {
        //     var start = new Date(this.ruleForm.startDate).getTime()
        //     if (start) {
        //       return time.getTime() < start
        //     }
        //   }
        // }
        //开始日期小于结束日期
        this.ruleForm.pickerBeginDateBefore = {
          disabledDate: (time) => {
            var end = new Date(this.ruleForm.predictEndDate).getTime()
            if (end) {
              return (time.getTime() > new Date(this.ruleForm.predictEndDate).getTime())
            }
          }
        }
      }
    },
    //==========================================================>编辑<——>查看
    handleEdit(item, type) { //编辑
      if (type) { //查看
        this.isMoreBusinessShow = true
        this.lookButShow = false
        this.disabledShow = true
        this.stateTitle = '查看商品信息'
      } else { //编辑
        this.isMoreBusinessShow = false
        this.lookButShow = true
        this.disabledShow = false
        this.stateTitle = '编辑商品信息'
      }
      this.disabledEdit = true
      this.editButShow = false
      this.seasonArray = [] //季节清空
      this.ruleForm = {}
      this.showCitry = true
      this.ruleFromcate3Id = []
      this.stateShow = false
      this.baseSupplierInfo(item.deptNo)
      const formData = new window.FormData()
      formData.append('id', item.id)
      Api.BaseGoodsInfo.details(formData).then(row => {
        if (row.success) {
          row.data.pickerBeginDateBefore = {}
          row.data.pickerBeginDateAfter = {}
          const data = row.data
          this.ruleFromcate3Id = [data.cate1Id, data.cate2Id, data.cate3Id]
          this.ruleForm = data
          this.ruleForm.goodsName = utils.htmlDecode(data.goodsName)
          this.ruleForm.vehicleModel = data.vehicleModel ? utils.htmlDecode(data.vehicleModel) : ''
          this.ruleForm.workshopCateg = data.workshopCateg ? utils.htmlDecode(data.workshopCateg) : ''
          this.ruleForm.length = this.ruleForm.length ? this.ruleForm.length : undefined//长
          this.ruleForm.width = this.ruleForm.width ? this.ruleForm.width : undefined//宽
          this.ruleForm.height = this.ruleForm.height ? this.ruleForm.height : undefined//高
          this.ruleForm.volume = this.ruleForm.volume ? this.ruleForm.volume : undefined//体积
          this.ruleForm.gross = this.ruleForm.gross ? this.ruleForm.gross : undefined //毛重
          this.ruleForm.net = this.ruleForm.net ? this.ruleForm.net : undefined //净重
          this.ruleForm.warrantyRate = this.ruleForm.warrantyRate ? this.ruleForm.warrantyRate : undefined//在保率
          this.ruleForm.serviceRate = this.ruleForm.serviceRate ? this.ruleForm.serviceRate : undefined//维修率
          //查看时 商品分类显示
          if (!this.lookButShow) {
            this.cateIdName = data.cate1Name + ' / ' + data.cate2Name + ' / ' + data.cate3Name
          }
          if (data.season !== '') {
            let arr = []
            arr = data.season.split(',')
            if (arr[0] !== '') {
              for (let i = 0; i < arr.length; i++) {
                this.seasonArray.push(Number(arr[i]))
              }
            }
          }

          //开始日期小于结束日期
          this.ruleForm.pickerBeginDateBefore = {
            disabledDate: (time) => {
              var end = new Date(this.ruleForm.predictEndDate).getTime()
              if (end) {
                return (time.getTime() > new Date(this.ruleForm.predictEndDate).getTime())
              }
            }
          }

          //结束日期小于开始日期
          this.ruleForm.pickerBeginDateAfter = {
            disabledDate: (time) => {
              var start = new Date(this.ruleForm.startDate).getTime()
              if (start) {
                return time.getTime() < start
              }
            }
          }



          this.centerDialogVisible = true
        } else {
          this.$showErrorMsg(row.errMessage)
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
      })
    },
    //==========================================================>新增
    // 提交
    submitForm(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          this.buttonDisabled = true
          if (this.stateShow) { //新增
            let setName = '' //商家商品编码----非必填
            if (this.ruleForm.isvGoodsNo !== '') {
              setName = '【商家商品编码】'
            }
            this.$confirm('【商品编码】' + setName + ' 新增之后不可修改', '提示', {
              confirmButtonText: '确定',
              cancelButtonText: '取消',
              type: 'warning'
            }).then(() => {
              Api.BaseGoodsInfo.baseGoodsAdd(this.ruleForm).then(row => {
                if (row.success) {
                  if (this.ruleForm.PreservationData) {
                    localStorage.removeItem('ruleForm')
                  }
                  this.buttonDisabled = false
                  this.$showSuccessMsg('新增成功')
                  this.getList()
                  this.$refs[formName].resetFields()
                  this.ruleFromcate3Id = [] //清空商品分类
                  this.centerDialogVisible = false
                  this.showCitry = false
                } else {
                  this.buttonDisabled = false
                  this.$showErrorMsg(row.errMessage)
                }
              }).catch((e) => {
                this.buttonDisabled = false
                this.$showErrorMsg(e)
              })
            }).catch(() => {
              this.buttonDisabled = false
              this.$message({
                type: 'info',
                message: '已取消新增'
              })
            })
          } else { //编辑
            Api.BaseGoodsInfo.baseGoodsEdit(this.ruleForm).then(row => {
              if (row.success) {
                this.$showSuccessMsg('编辑成功')
                this.buttonDisabled = false
                this.getList()
                this.$refs[formName].resetFields()
                this.ruleFromcate3Id = [] //清空商品分类
                this.centerDialogVisible = false
                this.showCitry = false
              } else {
                this.buttonDisabled = false
                this.$showErrorMsg(row.errMessage)
              }
            }).catch((e) => {
              this.buttonDisabled = false
              this.$showErrorMsg(e)
            })
          }
        } else {
          this.$message.error('请完善信息！')
          return false
        }
      })
    },
    //数据保存
    handlePreservation(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          this.ruleForm.PreservationData = true //===>根据此字段判断此条数据是否为保存数据，如果为true 则为保存数据，当提交数据时为true则清空保存数据
          utils.setlocalStorage('ruleForm', this.ruleForm, 100)
          this.$refs[formName].resetFields()
          this.ruleFromcate3Id = [] //清空商品分类
          this.centerDialogVisible = false
          this.showCitry = false
          this.$showSuccessMsg('保存成功')
        }
      })
    },
    //取消
    resetForm(formName) {
      this.$refs[formName].resetFields()
      this.ruleFromcate3Id = []
      this.seasonArray = []
      this.centerDialogVisible = false
      this.showCitry = false
      this.buttonDisabled = false
    },
    //关闭弹窗
    closeDialog(type) {
      if (type) {
        this.$refs[type].resetFields()
        this.ruleFromcate3Id = []
        this.seasonArray = []
        this.centerDialogVisible = false
        this.showCitry = false
        this.buttonDisabled = false
      }
    },
    //手工添加
    handleAdd() {
      this.isMoreBusinessShow = false
      this.disabledEdit = false
      this.lookButShow = true
      this.editButShow = true
      this.buttonDisabled = false
      this.showCitry = true
      let listdata = {}
      listdata = JSON.parse(localStorage.getItem('ruleForm'))
      if (listdata != null) {
        this.ruleFromcate3Id = [listdata.value.cate1Id, listdata.value.cate2Id, listdata.value.cate3Id]
        if (listdata.value.season !== '') {
          let arr = []
          arr = listdata.value.season.split(',')
          for (let i = 0; i < arr.length; i++) {
            this.seasonArray.push(Number(arr[i]))
          }
        }
        this.ruleForm = listdata.value
        this.disabledShow = false
        this.stateShow = true //新增
        this.stateTitle = '新增商品信息'
        this.centerDialogVisible = true
      } else {
        this.disabledShow = false
        this.stateShow = true //新增
        this.stateTitle = '新增商品信息'
        this.ruleFromcate3Id = []
        this.centerDialogVisible = true
        this.seasonArray = [] //清空四季
        this.$nextTick(() => {
          this.$refs.ruleForm.clearValidate()
        })
        this.ruleForm = {
          deptName: '', //商品基本信息-事业部
          deptNo: '',
          cate3Id: '', //商品分类
          goodsNo: '', //商品编码
          goodsName: '', //商品名称
          brandNo: '', //品牌ID
          brandName: '', //品牌名称
          series: '', //系列

          isvGoodsNo: '', //运营属性-商家编码
          channel: '', //渠道
          pickerBeginDateBefore: {},
          pickerBeginDateAfter: {},
          startDate: '', //上线时间
          predictEndDate: '', //下线时间
          firstEntryTime: '', //入库时间
          downtime: '', //停产时间
          season: '', //季节
          lifeCycle: '', //生命周期

          supplierName: '', //采购属性信息-供应商
          supplierNo: '', //供应商编号
          company: '', //所属公司
          cartonSpec: '', //箱规
          palletCount: '', //板规
          price: '', //金额
          purchasePrice: '', //采购单价
          isRushOrder: '', //是否紧急
          isSale: '', //是否在售
          // isMoreBusiness: '', //一品多商
          isOutside: '', //是否对外

          isTemperature: '', //仓储信息-是否恒温
          isDangerous: '', //是否危险
          expirationDate: '', //保质期
          length: undefined, //长
          width: undefined, //宽
          height: undefined, //高
          volume: undefined, //体积
          gross: undefined, //毛重
          net: undefined, //净重

          goodsType: '', //气后行业-商品类型
          goodsId: '', //气后行业-商品ID
          warrantyRate: undefined, //在保率
          serviceRate: undefined, //维修率
          vehicleOwnership: '', //保有量
          vehicleModel: '', //车型
          production: '', //生产件
          associated: '', //关联量
          partsLevel: '', //配件等级
          priceWith: '', //价格带
          isDirect: '', //是否直接门店
          workshopCateg: '', //车间需求归类
          supplyBy: '', //发货方
          supplyStrategy: '', //供应策略
          campaign: '', //活动影响
          itemNumber: '', //商品码
          amwayAmountBand: '', //金额band
          pickUpPoint: ''//提货点
        }
      }

      //开始日期小于结束日期
      this.ruleForm.pickerBeginDateBefore = {
        disabledDate: (time) => {
          var end = new Date(this.ruleForm.predictEndDate).getTime()
          if (end) {
            return (time.getTime() > new Date(this.ruleForm.predictEndDate).getTime())
          }
        }
      }

      //结束日期小于开始日期
      this.ruleForm.pickerBeginDateAfter = {
        disabledDate: (time) => {
          var start = new Date(this.ruleForm.startDate).getTime()
          if (start) {
            return time.getTime() < start
          }
        }
      }
    },
    //选择供应商赋值
    handleBaseGoods(val) {
      if (val) {
        var obj = {} //多条件查找
        obj = this.BaseGoodsInfoList.find(function(item) {
          return item.supplierNo === val
        })
        this.ruleForm.supplierName = obj.supplierName
      }
    },
    //季节选择
    handleSeason(val) {
      var str = ''
      str = val.join(',')
      this.ruleForm.season = str
    },
    //商品分类选择
    handleSelectCateAdd(val) {
      this.ruleForm.cate3Id = val[2]
      this.ruleForm.cate2Id = val[1]
      this.ruleForm.cate1Id = val[0]
    },
    // 事业部
    handleDept(val) {
      var obj = {} //多条件查找
      obj = this.deptNoList.find(function(item) {
        return item.deptNo === val
      })
      this.ruleForm.deptName = obj.deptName
      this.baseSupplierInfo(this.ruleForm.deptNo)
    },
    //==========================================================>常量值设定
    //获取事业部编码
    queryDept() {
      Api.BaseGoodsInfo.queryDept().then(row => {
        if (row.success) {
          this.deptNoList = row.data
        } else {
          this.$showErrorMsg(row.errMessage)
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
      })
    },
    //供应商获取
    baseSupplierInfo(deptNo) {
      Api.BaseGoodsInfo.baseSupplierInfo({ deptNo: deptNo }).then(row => {
        if (row.success) {
          this.BaseGoodsInfoList = row.data
        } else {
          this.$showErrorMsg(row.errMessage)
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
      })
    },
    channelType() { //销售渠道
      Api.BaseGoodsInfo.channelType().then(row => {
        if (row.success) {
          this.channelList = row.data
        } else {
          this.$showErrorMsg(row.errMessage)
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
      })
    },
    goodsType() { //商品类型
      Api.BaseGoodsInfo.goodsType().then(row => {
        if (row.success) {
          this.goodsTypeList = row.data
        } else {
          this.$showErrorMsg(row.errMessage)
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
      })
    },
    lifeCycle() { //生命周期
      Api.BaseGoodsInfo.lifeCycle().then(row => {
        if (row.success) {
          this.lifeCycleList = row.data
        } else {
          this.$showErrorMsg(row.errMessage)
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
      })
    },
    season() { //季节
      Api.BaseGoodsInfo.season().then(row => {
        if (row.success) {
          this.seasonList = row.data
        } else {
          this.$showErrorMsg(row.errMessage)
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
      })
    },
    //==========================================================>列表操作
    getList() { //列表
      this.LoadingTable = true
      const params = {}
      params.pageNum = this.pageNum
      params.pageSize = this.pageSize
      params.cate3Id = this.cate3Id
      params.deptNo = this.deptNo.split('&')[0]
      params.goodsNo = this.goodsNo
      Api.BaseGoodsInfo.listPage(params).then(row => {
        if (row.success) {
          for (let i = 0; i < row.data.length; i++) {
            row.data[i].goodsName = utils.htmlDecode(row.data[i].goodsName)
            if (row.data[i].cate1Name) {
              row.data[i].cateName = row.data[i].cate1Name + ' / ' + row.data[i].cate2Name + ' / ' + row.data[i].cate3Name
            }
          }
          this.tableData = row.data
          this.totals = row.total
          this.LoadingTable = false
        } else {
          this.$showErrorMsg(row.errMessage)
          this.LoadingTable = false
        }
      }).catch((e) => {
        this.LoadingTable = false
        this.$showErrorMsg(e)
      })
    },
    //分页条数改变
    sizeChange(val) {
      this.pageSize = val
      this.getList()
    },
    //翻页-----根据页码变换
    handleSizeChange(val) {
      this.pageNum = val
      this.getList()
    },
    //全选反选
    handleSelectionChange(val) {
      this.multipleSelection = val
    },
    //商品分类
    handleSelectCate() {
      this.cate3Id = this.cate3Idst[2]
    },
    //列表查询
    handleQuery() {
      this.getList()
    },
    //重置
    handleRest() {
      this.cate3Idst = ''
      this.cate3Id = '' //三级分类ID
      this.deptNo = '' //事业部编码
      this.goodsNo = '' //商品编码
      this.getList()
    },
    //下载模版
    downloadTemplate() {
      const actionUrl = this.baseURL + Api.BaseGoodsInfo.downloadTemplate
      exportExcel(actionUrl)
    },
    //批量下载
    download() {
      const param = {}
      param.cate3Id = this.cate3Id
      param.deptNo = this.deptNo.split('&')[0]
      param.goodsNo = this.goodsNo
      const actionUrl = this.baseURL + Api.BaseGoodsInfo.download
      exportExcel(actionUrl, param)
    },
    //手工删除
    handleDeled() {
      if (this.multipleSelection.length === 0) {
        this.$showErrorMsg('请选择数据')
        return
      }
      const crrId = []
      for (let i = 0; i < this.multipleSelection.length; i++) {
        crrId.push(this.multipleSelection[i].id)
      }
      this.delete(crrId)
    },
    //  删除方法
    delete(row) {
      this.$alert('<p style="font-size: 18px;color:#333">确认删除此条消息吗?</p><p style="font-size: 13px;color: #666">删除后，此条消息的相关内容信息将无法恢复</p>', '', {
        dangerouslyUseHTMLString: true,
        type: 'warning',
        center: true
      }).then(() => {
        Api.BaseGoodsInfo.delete(row).then(row => {
          if (row.success) {
            if (row.data.successCount > 0) {
              this.getList()
            }
            if (row.data.errorCount > 0) {
              this.dialogTableVisible = true
              this.gridData = row.data.detaileds
              this.moreErr = row.data.detaileds.length > 300 ? true : false
            } else {
              this.$showSuccessMsg('删除成功')
              this.getList()
            }
          } else {
            this.$message.error(row.errMessage)
          }
        }).catch((e) => { this.$showErrorMsg(e) })
      }).catch(() => {})
    }
  }
}
</script>
<style lang="scss">
   .dialog_mask{
    .lui-input-number .lui-input__inner{
        text-align: left;
      }
    }
</style>
<style scoped lang="scss">
@import '@/assets/stylus/main';
  .masterData{
    width: 100%;
    .master-header{
      width: 100%;
      background: #fff;
      padding-bottom: 30px;
      border-radius: 0 4px 4px 4px;
      box-shadow: 2px 2px 7px 2px #ccc;
      .header-top{
        display: flex;
        align-items: center;
        margin-top: 30px;
        margin-bottom: 20px;
        .header-border{
          width: 2px;
          height: 12px;
          background: $--gl-blue;
          display: inline-block;
          margin-left: 24px;
          margin-right: 6px;
        }
        .header-title{
          font-weight: 600;
          font-size: 16px;
          line-height: 16px;
          color: #333;
        }
      }
      .header-select{
        display: flex;
        .select-content{
          padding-left: 24px;
          .content-title{
            margin-right: 10px;
            font-size: 14px;
            color: #333;
          }
        }
      }
      .header-button{
        padding-right: 24px;
        display: flex;
        justify-content: flex-end ;
      }
    }
    .master-container{
      width: 100%;
      background: #ffffff;
      margin-top: 20px;
      border-radius: 4px;
      box-shadow: 2px 2px 7px 2px #ccc;
      .container-top{
        width: 100%;
        padding: 20px 0;
        display: flex;
        justify-content: space-between;
        .container-top-left{
          line-height: 32px;
          .header-border{
            width: 2px;
            height: 12px;
            background: $--gl-blue;
            display: inline-block;
            margin-left: 24px;
            margin-right: 8px;
          }
          .header-title{
            font-weight: 600;
            font-size: 16px;
            color: #333;
          }
        }
        .container-top-right{
          padding-right: 24px;
          .button-upload{
            position: relative;
            overflow: hidden;
            input{
              position: absolute;
              top: 0;
              bottom: 0;
              left: 0;
              right: 0;
              opacity: 0;
            }
          }
        }
      }
      .container-table{
        width: 100%;
        padding-left: 24px;
        padding-right: 24px;
        padding-bottom: 30px;
        .container-table-cont{
          min-height: 300px;
          .table-look{
            cursor: pointer;
            color: $--gl-blue;
            font-size: 14px;
            font-weight: 500;
          }
          .table-button{
            display: flex;
            justify-content: space-around;
          }
          .table-p {
            //display: inline-block;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            cursor: pointer;
            padding-right: 15px;
            //border: 1px solid red;/**/
          }
        }

        .knowledge-pagination {
          width: 100%;
          /*margin-top: 73px;*/
          margin-top: 20px;
          text-align: right;
        }

      }
    }
    .demo-ruleForm{
      .popup-container{
        overflow: hidden;
        width: 100%;
        margin-bottom: 20px;
        border-radius: 4px;
        border: 1px solid #E8E8E8;
        transition: all 0.3s ease;
        .pupop-container-title{
          width: 100%;
          height: 48px;
          background: #fafafa;
          display: flex;
          justify-content: space-between;
          align-items: center;
          span:nth-child(1){
            padding-left: 20px;
          }
          span:nth-child(2){
            cursor: pointer;
            padding-right: 20px;
            i{
              color: #999;
            }
          }
        }
        .popup-container-main{
          border-top: 1px solid #E8E8E8;
          width: 100%;
          padding:20px  20px 0 20px;
        }
      }
    }
  }
</style>
