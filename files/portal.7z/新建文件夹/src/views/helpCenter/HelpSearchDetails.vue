<template>
  <div class="help-search">
    <div class="contentmenu"><span v-if="parentText" style="font-weight: 600;">{{ parentText }}<i class="lui-icon-arrow-right"></i></span>{{ title }}</div>
    <lui-row>
      <lui-col :span="24">
        <div v-dompurify-html="htmlData" class="contentHtml"></div>
      </lui-col>
    </lui-row>
  </div>
</template>

<script>
import Api from '@/api'
import utils from '../../utils/utils'
import { mapGetters } from 'vuex'
export default {
  name: 'HelpSearchDetails',
  data() {
    return {
      parentText: '',
      search: '',
      title: '',
      pid: '',
      htmlData: '',
      tableData: [],
      total: 0,
      pageNum: 1, //页
      pageSize: 3, //条数
      relatedDocuments: [
        { title: '竞品分析&市场调研' },
        { title: '营销技术已经在市场领域变得越来越重要' },
        { title: 'QQ音乐&网易云音乐&酷狗音乐竞品分析…' },
        { title: '海淘产品App竞品分析' },
        { title: '【基础界面】B.导航设计模式(Beta)' },
        { title: '海淘产品App竞品分析' },
        { title: '【基础界面】B.导航设计模式(Beta)' }
      ],
      keywords: [
        { title: '竞品分析' },
        { title: '市场' },
        { title: '海淘产品' },
        { title: '易用性' },
        { title: '信息呈现' },
        { title: '免费试用' },
        { title: '隔离效应' },
        { title: '眼动力' },
        { title: 'Preston Goodwin' }
      ]
    }
  },
  computed: {
    ...mapGetters(['getMenuParentId'])
  },
  watch: {
    $route() {
      this.getSearchHelpDetails()
    }
  },
  mounted() {
    this.getSearchHelpDetails()
  },
  methods: {
    getSearchHelpDetails() {
      Api.HelpCenter.getSearchHelpDetails({
        'id': this.$route.params.id
      }).then((res) => {
        if (res.data) {
          this.htmlData = utils.escape2Html(res.data.helpContent)
          this.title = res.data.label
          this.pid = res.data.pid
          if (this.pid) {
            this.getMenuParentId.forEach(item => {
              if (item.id === this.pid) {
                this.parentText = item.label
              }
            })
          } else {
            this.parentText = ''
          }
        }
      }).catch((e) => {
        console.error(e)
      })
    }
  }
}
</script>

<style lang="scss" scoped>
@import "@/assets/stylus/main.scss";
  .contentmenu{
    font-size: 14px;
    color: #333333;
    padding: 0 0 10px 30px;
    .lui-icon-arrow-right{
      margin: 0 5px;
    }
  }
  .contentHtml{
    font-size: 14px;
  }
.help-search {
  min-height: 500px;
  background: #fff;
  padding: 30px 0 26px;
  .lui-row {
    width: 80%;
    margin: 0 auto !important;
  }
  .header {
    width: 100%;
    margin: 0 auto;
    padding-bottom: 20px;
    /deep/ .lui-input__suffix {
      right: 0;
      background: $--gl-blue;
      .lui-input__icon {
        cursor: pointer;
        width: 30px;
      }
    }
    .no-data {
      margin-top: 12px;
      font-size: 13px;
      color: #999999;
    }
  }

  .lui-table {
    width: 80%;
    margin: 0 auto;
    /deep/ .cell {
      padding: 0;
    }
  }

  .lui-table__body {
    .lui-table__row {
      p {
        font-size: 16px;
        color: #333;
      }
      span {
        font-size: 14px;
        color: #666;
      }
    }
  }
  .pagination {
    width: 100%;
    margin-top: 73px;
    text-align: center;
  }
  .related-documents {
    margin-top: 50px;
    ul {
      padding: 0 24px;
      li {
        margin: 10px 0;
        font-size: 14px;
        cursor: pointer;
        color: #333333;
      }
    }
  }
  .keyword-recommendation {
    margin-top: 20px;
    ul {
      padding: 0 24px;
      li {
        cursor: pointer;
        margin: 10px 20px 10px 0;
        font-size: 14px;
        color: #333333;
        display: inline-block;
      }
    }
  }
  .item {
    border-radius: 4px;
    border: 1px solid #e0e0e0;
    .title {
      font-size: 16px;
      line-height: 46px;
      color: #333333;
      margin: 0 24px;
      border-bottom: 1px solid #e0e0e0;
      .line {
        width: 3px;
        height: 10px;
        margin-right: 4px;
        display: inline-block;
        background-image: linear-gradient(270deg, $--gl-hoverBlue 0%, $--gl-blue 100%);
        box-shadow: 0 5px 14px 0 rgba(0, 0, 0, 0.12);
        border-radius: 1.5px;
      }
    }
  }
}
</style>
