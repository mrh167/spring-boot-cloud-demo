<template>
  <div class="help-search">
    <lui-row>
      <lui-col :span="24">
        <div class="header">
          <lui-input
            v-model="search"
            placeholder="搜索范围为帮助中心">
            <i
              slot="suffix"
              class="lui-input__icon lui-icon-search"
              @click="postSearchHelp()"></i>
          </lui-input>
          <div
            v-show="tableData.length"
            class="no-data">共为您检索到{{ tableData.length }}条搜索结果</div>
          <div
            v-show="!tableData.length"
            class="no-data"></div>
        </div>
        <lui-table
          :data="tableData"
          :show-header="false"
          style="width: 100%">
          <lui-table-column
            prop=""
            label=""
            row-class-name="custom-row"
            width="">
            <template slot-scope="scope">
              <div @click="$router.push({name:'helpsearchdetails',params:{id:scope.row.id}})">
                <p v-dompurify-html="scope.row.label"></p>
                <span v-dompurify-html="scope.row.helpText"></span>
              </div>
            </template>
          </lui-table-column>
          <template slot="empty">
            <img
              class="data-pic"
              src="../../assets/img/nodata.png" />
            <p>搜索无结果</p>
          </template>
        </lui-table>

        <div class="pagination">
          <lui-pagination
            background
            :current-page.sync="pageNum"
            :page-sizes="[10, 20, 50, 70, 100]"
            layout="prev, pager, next, sizes, jumper"
            :total="total"
            @current-change="handleSizeChange">
          </lui-pagination>
        </div>
      </lui-col>
    </lui-row>

  </div>
</template>

<script>
import Api from '@/api'
import utils from '../../utils/utils'
export default {
  name: 'HelpSearch',
  beforeRouteEnter(to, from, next) { //顶通搜索跳进来时
    next(vm => {
      if (vm.$route.params.keyword) {
        vm.search = vm.$route.params.keyword
        vm.postSearchHelp()
      }
    })
  },
  props: {

  },
  data() {
    return {
      search: '',
      tableData: [],
      total: 0,
      pageNum: 1, //页
      pageSize: 3, //条数
      relatedDocuments: [
        { title: '竞品分析&市场调研' },
        { title: '营销技术已经在市场领域变得越来越重要' },
        { title: 'QQ音乐&网易云音乐&酷狗音乐竞品分析…' },
        { title: '海淘产品App竞品分析' },
        { title: '【基础界面】B.导航设计模式(Beta)' },
        { title: '海淘产品App竞品分析' },
        { title: '【基础界面】B.导航设计模式(Beta)' }
      ],
      keywords: [
        { title: '竞品分析' },
        { title: '市场' },
        { title: '海淘产品' },
        { title: '易用性' },
        { title: '信息呈现' },
        { title: '免费试用' },
        { title: '隔离效应' },
        { title: '眼动力' },
        { title: 'Preston Goodwin' }
      ]
    }
  },
  mounted() {

  },
  methods: {
    handleSizeChange(val) {
      this.pageNum = val
      this.postSearchHelp()
    },
    postSearchHelp() {
      this.listLoading = true
      Api.HelpCenter.postSearchHelp({
        'keyword': this.search,
        'pageNum': this.pageNum,
        'pageSize': this.pageSize
      }).then((res) => {
        this.tableData = res.data
        this.total = res.total
        this.tableData.forEach((row) => {
          row.label = utils.escape2Html(row.label)
          row.helpText = utils.escape2Html(row.helpText)
        })
        this.listLoading = false
      }).catch((e) => {
        console.error(e)
      })
    }
  }
}
</script>



<style lang="scss" scoped>
@import "@/assets/stylus/main.scss";
.help-search {
  min-height: 600px;
  background: #fff;
  padding: 30px 0 26px;
  .lui-row {
    width: 80%;
    margin: 0 auto !important;
  }
  .header {
    width: 100%;
    margin: 0 auto;
    padding-bottom: 20px;
    /deep/ .lui-input__suffix {
      right: 0;
      background: $--gl-blue;
      border-radius: 0 4px 4px 0;
      overflow: hidden;
      .lui-input__icon {
        cursor: pointer;
        width: 60px;
      }
    }
    .no-data {
      margin-top: 12px;
      font-size: 13px;
      color: #999999;
    }
  }

  .lui-table {
    width: 80%;
    margin: 0 auto;
    /deep/ .cell {
      padding: 0;
    }
  }

  .lui-table__body {
    .lui-table__row {
      p {
        font-size: 16px;
        color: #333;
      }
      span {
        font-size: 14px;
        color: #666;
        display: inline-block;
        width: 100%;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }
    }
  }
  .pagination {
    width: 100%;
    margin-top: 73px;
    text-align: center;
  }
  .related-documents {
    margin-top: 50px;
    ul {
      padding: 0 24px;
      li {
        margin: 10px 0;
        font-size: 14px;
        cursor: pointer;
        color: #333333;
      }
    }
  }
  .keyword-recommendation {
    margin-top: 20px;
    ul {
      padding: 0 24px;
      li {
        cursor: pointer;
        margin: 10px 20px 10px 0;
        font-size: 14px;
        color: #333333;
        display: inline-block;
      }
    }
  }
  .item {
    border-radius: 4px;
    border: 1px solid #e0e0e0;
    .title {
      font-size: 16px;
      line-height: 46px;
      color: #333333;
      margin: 0 24px;
      border-bottom: 1px solid #e0e0e0;
      .line {
        width: 3px;
        height: 10px;
        margin-right: 4px;
        display: inline-block;
        background-image: linear-gradient(270deg, #2284bf 0%, #0e6596 100%);
        box-shadow: 0 5px 14px 0 rgba(0, 0, 0, 0.12);
        border-radius: 1.5px;
      }
    }
  }
}
</style>
