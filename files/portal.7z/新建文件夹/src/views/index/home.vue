<template>
  <div
    v-loading="homeLoading"
    class="index">
    <lui-carousel
      v-if="broadcastListFlag"
      :interval="6000"
      style="margin-bottom:12px;border-radius:4px;min-width: 1186px;"
      height="32px"
      indicator-position="none"
      direction="vertical"
      arrow="always">
      <lui-carousel-item
        v-for="item in broadcastList"
        :key="item.id">
        <div>
          <i class="lui-alert__icon lui-icon-info"></i>
          <span @click="openLink(item.url)">{{ item.content }}</span>
          <i class="lui-alert__closebtn lui-icon-close" @click="close"></i>
        </div>
      </lui-carousel-item>
    </lui-carousel>
    <div class="main">
      <div class="home-left">
        <div class="left-summarize">
          <div class="summarize">
            <div
              v-for="(item,index) in dataList"
              :key="item.id"
              class="wrap"
              :class="{'active': changeIndex == item.id , 'active-width': dataList.length == 3}"
              @click="selectItem(item,index)">

              <div class="warp-span"></div>

              <div
                class="content"
                :class="{'active': changeIndex == item.id}">
                <div class="title" :class="{'active-title': changeIndex == item.id}">{{ item.name }}</div>
                <div class="item-wrap">
                  <div class="left" :class="{'left-width' : index == 0 || index == 1}">
                    <div class="item tips" :class="{'active-tips': userType === '2'}">{{ item.title }}
                      <lui-tooltip
                        popper-class="custom-tooltip"
                        effect="dark"
                        :visible-arrow="false"
                        :content="item.tips"
                        placement="bottom">
                        <i class="lui-icon-help"></i>
                      </lui-tooltip>
                    </div>
                    <div class="item number">
                      <lui-tooltip
                        effect="dark"
                        :visible-arrow="false"
                        content="查看详情"
                        placement="bottom">
                        <p :class="{'active-number': changeIndex == item.id}" @click="goPage(item)">{{ item.number }}</p>
                      </lui-tooltip>
                      <span>{{ item.type }}</span>
                    </div>
                    <div
                      class="item scale"
                      :class="{'active-scale-green': item.status > 0 ,'active-scale-red': item.status < 0 ,'active-scale-size': changeIndex == item.id }">{{ item.scale }}
                      <i v-if="item.status > 0" class="arrow-up"></i>
                      <i v-if="item.status < 0" class="arrow-down"></i>
                      <i v-if="item.status == 0" class="arrow-liedown"></i>
                    </div>
                  </div>
                  <div v-if="index == 2 || index == 3" class="line"></div>
                  <div v-if="index == 2 || index == 3" class="right">
                    <div class="item tips" :class="{'active-tips': userType === '2'}">{{ item.title1 }}
                      <lui-tooltip
                        popper-class="custom-tooltip"
                        effect="dark"
                        :visible-arrow="false"
                        :content="item.tips1"
                        placement="bottom">
                        <i class="lui-icon-help"></i>
                      </lui-tooltip>
                    </div>
                    <div class="item number">
                      <lui-tooltip
                        effect="dark"
                        :visible-arrow="false"
                        content="查看详情"
                        placement="bottom">
                        <p :class="{'active-number': changeIndex == item.id}" @click="goPage1(item)">{{ item.number1 }}</p>
                      </lui-tooltip>
                      <span>{{ item.type1 }}</span>
                    </div>
                    <div
                      class="item scale"
                      :class="{'active-scale-green': item.status1 > 0 ,'active-scale-red': item.status1 < 0 ,'active-scale-size': changeIndex == item.id }">{{ item.scale1 }}
                      <i v-if="item.status1 > 0" class="arrow-up"></i>
                      <i v-if="item.status1 < 0" class="arrow-down"></i>
                      <i v-if="item.status1 == 0" class="arrow-liedown"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

        </div>
        <div
          class="chart-wrap"
          :class="{'border-radius-left': changeIndex == 0 , 'border-radius-right':changeIndex == 3}">
          <operation-dynamics
            v-if="changeIndex == 0"
            :user-type="userType"
            @func="getChildData"
            @change-status="onChangeStatus">
          </operation-dynamics>
          <abnormal-alarm
            v-if="changeIndex == 1"
            @change-status="onChangeStatus">
          </abnormal-alarm>
          <health-inventory
            v-if="changeIndex == 2"
            @change-status="onChangeStatus">
          </health-inventory>
          <service-level
            v-if="changeIndex == 3"
            :user-type="userType"
            @change-status="onChangeStatus">
          </service-level>
        </div>
        <div ref="swiper" class="adsense">
          <lui-carousel
            :arrow="isSwiperShow"
            :interval="6000"
            indicator-position="none"
            :height="swiperWidth/9.9 + 'px'">
            <lui-carousel-item
              v-for="(item,index) in bannerList"
              :key="index">
              <img :src="item.picture" @click="openLink(item.url)">
            </lui-carousel-item>
          </lui-carousel>
        </div>
      </div>
      <todo-List> </todo-List>
    </div>
    <!-- 精准投放 -->
    <div
      v-if="dialogVisible"
      class="precise-delivery">
      <i
        class="lui-icon-close"
        @click="confirmaAcuratePut">
      </i>
      <img :src="accuratePut" @click="openLink(jumpUrl)">
    </div>
  </div>
</template>

<script>
import Api from '@/api'
import todoList from './components/todoList'
import operationDynamics from './components/operationDynamics'
import abnormalAlarm from './components/abnormalAlarm'
import healthInventory from './components/healthInventory'
import serviceLevel from './components/serviceLevel'
import utils from '@/utils/utils'
import { mapGetters } from 'vuex'
export default {

  computed: {
    ...mapGetters(['getVscSellerType'])
  },
  name: 'Home',
  components: {
    todoList,
    operationDynamics,
    abnormalAlarm,
    healthInventory,
    serviceLevel
  },
  data() {
    return {
      changeIndex: 0,
      isSwiperShow: 'never',
      homeLoading: false,
      inventoryHealth: {
        id: 2, name: '库存健康', title: '30天周转', number: '', disabled: false, type: '天', scale: '', tips: '历史30天在库件数/30天出库件数', title1: 'SKU断货率', number1: '', type1: '%', scale1: '', tips1: '昨日，断货SKU种类数/统计历史周期内总SKU种类数'
      },
      inventoryHealthUnit: {
        id: 2, name: '库存健康', title: '件数周转', number: '', disabled: false, type: '天', scale: '', tips: '可用库存/日均销量。其中日均销量为30天预测日均销量，件数周转非计费口径，任何口径周转均不作财务结算依据，以物流计费为主', title1: '现货率', number1: '', type1: '%', scale1: '', tips1: '有货商品数/总商品数，其中商品需同时满足以下条件：①只统计上柜 ②有货定义为全国可用库存大于0 ③剔除售完即止、虚拟品类、虚拟组套商品④近30天有动销'
      },
      dataList: [
        {
          id: 0, name: '运营动态', title: '今日下单量', number: '', disabled: true, type: '单', scale: '', tips: '统计时间内（今日0点至现在），仓配下单和纯配下单量总和，其中仓配下单量取ECLP接收的单量，含取消单；纯配下单量按运单创建时间，含取消单'
        },
        {
          id: 1, name: '异常预警', title: '近7日异常总单数', number: '', disabled: false, type: '单', scale: '', tips: '近7日，发生以下任一异常的运单量，发货异常、签收异常、超3天状态未更新或5天未妥投'
        },
        // {
        //   id: 2, name: '库存健康', title: '30天周转', number: '', type: '天', scale: '', tips: '历史30天在库件数/30天出库件数', title1: 'SKU断货率', number1: '', type1: '%', scale1: '', tips1: '断货SKU种类数/统计历史周期内总SKU种类数'
        // },
        {
          id: 3, name: '服务水平', title: '本地订单满足率', number: '', disabled: false, type: '%', scale: '', tips: '昨日，7天内各区域产生的订单中由本区域完成履约的订单数/同时期内各区域的订单总数；全国维度的本地订单满足率为各区域指标的均值', title1: '近7日平均妥投时长', number1: '', type1: '小时', scale1: '', tips1: '近7日，出库订单中完成妥投订单，从出库到妥投的单均时长'
        }
      ],
      dialogVisible: false,
      broadcastList: [],
      broadcastListFlag: false,
      bannerList: [],
      accuratePut: '', //精准投放src
      packageId: '',
      jumpUrl: '', //精准投放外链
      userType: '', //1.纯配 2.纯配+仓配
      todayView: {},
      swiperWidth: 1288
    }
  },
  created() {
    this.getHomePageUserType()//必须放在created里
  },
  mounted() {
    this.swiperWidth = this.$refs.swiper.clientWidth
    window.addEventListener('resize', () => {
      if (this.$refs.swiper) { //解决离开首页 控制台报错问题
        this.swiperWidth = this.$refs.swiper.clientWidth
      }
    })
    this.getBroadcastList()
    this.getBannerList()
    this.getFirstAccuratePut()
    this.getAbnormalWarn()
    // this.getTodayMonitor()
    this.getServiceLevel()
  },
  methods: {
    //确认投放
    confirmaAcuratePut() {
      Api.Home.getConfirmaAcuratePut({ 'packageId': this.packageId }).then((res) => {
        if (res.success) {
          this.dialogVisible = false
        }
      }).catch((e) => {
        console.error(e)
      })
    },
    //获取子组件运营动态传来的数据
    getChildData(data) {
      this.todayView = data
      this.dataList.forEach((item) => {
        if (item.id === 0) {
          item.status = this.todayView.todayOrderRatioDesc
          item.number = this.toThousands(this.todayView.todayOrder)
          item.scale = this.todayView.todayOrderRatio + '%'
        }
      })
    },
    //打开轮播图||小广播||精准投放外链
    openLink(url) {
      if (url) {
        window.open(url, '_blank')
      }
    },
    getTodayMonitor() { //运营动态大指标 + 今日监控中部指标
      Api.Home.getTodayMonitor('').then((res) => {
        this.todayView = res.data
        this.dataList.forEach((item) => {
          if (item.id === 0) {
            item.status = this.todayView.todayOrderRatioDesc
            item.number = this.toThousands(this.todayView.todayOrder)
            item.scale = this.todayView.todayOrderRatio + '%'
          }
        })
      }).catch((e) => {
        console.error(e)
      })
    },
    //异常报警大指标
    getAbnormalWarn() {
      Api.Home.getAbnormalWarn('').then((res) => {
        const homePageData = res.data
        this.dataList.forEach((item) => {
          if (item.id === 1) {
            item.status = homePageData.totalAbnormalRatioDesc
            item.number = this.toThousands(homePageData.totalAbnormal)
            item.scale = homePageData.totalAbnormalRatio + '%'
          }
        })
      }).catch((e) => {
        console.error(e)
      })
    },
    //库存健康大指标
    getInventoryHealth() {
      Api.Home.getInventoryHealth('').then((res) => {
        const homePageData = res.data
        this.dataList.forEach((item) => {
          if (item.id === 2) {
            item.status = homePageData.last30DayTurnoverRatioDesc
            item.status1 = homePageData.skuBreakRateRatioDesc
            item.number = this.toThousands(homePageData.last30DayTurnover)
            item.scale = homePageData.last30DayTurnoverRatio + '%'
            item.number1 = homePageData.skuBreakRate
            item.scale1 = homePageData.skuBreakRateRatio + '%'
          }
        })
      }).catch((e) => {
        console.error(e)
      })
    },
    //服务水平大指标
    getServiceLevel() {
      Api.Home.getServiceLevel('').then((res) => {
        const homePageData = res.data
        this.dataList.forEach((item) => {
          if (item.id === 3) {
            if (this.userType === '2') {
              item.status = homePageData.localEnoughRateRatioDesc
              item.status1 = homePageData.last7DaysProperlyRatioDesc
              item.number = homePageData.localEnoughRate
              item.number1 = this.toThousands(homePageData.last7DaysProperly)
              item.scale = homePageData.localEnoughRateRatio + '%'
              item.scale1 = homePageData.last7DaysProperlyRatio + '%'
            } else {
              item.title = '近7日平均妥投时长'
              item.title1 = '近7日妥投率'
              item.number = this.toThousands(homePageData.last7DaysProperly)
              item.number1 = homePageData.last7DayProperlyRate
              item.status = homePageData.last7DaysProperlyRatioDesc
              item.status1 = homePageData.last7DayProperlyRateRatioDesc
              item.tips = '近7日，出库订单中完成妥投订单，从出库到妥投的单均时长'
              item.tips1 = '近7日，妥投单量/出库单量'
              item.type = '小时'
              item.type1 = '%'
              item.scale = homePageData.last7DaysProperlyRatio + '%'
              item.scale1 = homePageData.last7DayProperlyRateRatio + '%'
            }
          }
        })
      }).catch((e) => {
        console.error(e)
      })
    },
    close() {
      this.broadcastListFlag = false
    },
    onChangeStatus(status) {
      this.homeLoading = status
    },
    selectItem(item, index) {
      this.changeIndex = item.id
      item.disabled = true
      this.dataList.forEach((el) => {
        if (el.id !== item.id) {
          el.disabled = false
        }
      })
      if (this.changeIndex === 1) {
        this.getAbnormalWarn()//实时更新异常预警大指标
      }
    },
    toThousands(num) {
      return (num || 0).toString().replace(/(\d)(?=(?:\d{3})+$)/g, '$1,')
    },
    goPage(item) {
      if (item.disabled) {
        if (item.id === 0) {
          this.$router.push('/realtimeTracking')//实时订单监控
        } else if (item.id === 1) {
          this.$router.push('/orderTime')//订单时效异常
        } else if (item.id === 2) {
          this.$router.push('/analysisInLibrary')//在库分析
        } else if (item.id === 3) {
          if (this.getVscSellerType === 1 || this.getVscSellerType === 2) {
            this.$router.push('/layoutDiagnosis')//布局诊断
          } else { //中小板
            if (this.userType === '2') { //1、纯配 2仓配
              this.$router.push('/layoutDiagnosis')//配送
            } else { 
              this.$router.push('/delivery')//配送
            }
          }
        }
      }
    },
    goPage1(item) {
      if (item.disabled) {
        if (item.id === 2) {
          this.$router.push('/stockDiagnosis')//库存诊断
        } else if (item.id === 3) {
          if (this.getVscSellerType === 1 || this.getVscSellerType === 2) {
            this.$router.push('/layoutDiagnosis')//布局诊断
          } else { //中小板
            if (this.userType === '2') { //1、纯配 2仓配
              this.$router.push('/delivery')//配送
            } else { 
              this.$router.push('/delivery')//配送
            }
          }
        }
      }
    },
    //获取用户类型
    getHomePageUserType() {
      Api.Home.getHomePageUserType('').then(res => {
        this.userType = res.data
        if (this.userType === '2') { //1.纯配 2.纯配+仓配
          if (this.getVscSellerType === 1 || this.getVscSellerType === 2) { //判断是不是诸葛账号
            this.dataList.splice(2, 0, this.inventoryHealth)//纯配+仓配时添加健康状态
            this.getInventoryHealth()
          } else { //诸葛
            this.dataList.splice(2, 0, this.inventoryHealthUnit)//纯配+仓配时添加健康状态
            this.getInventoryHealth()
          }
        }
      }).catch(e => {
        console.error(e)
      })
    },
    //获取轮播图
    getBannerList() {
      Api.Home.getBannerList({ position: '2' }).then(res => {
        if (res.success) {
          this.bannerList = res.data
          if (this.bannerList.length === 2) {
            this.bannerList = [...this.bannerList, ...this.bannerList]
          }

          if (this.bannerList.length > 1) {
            this.isSwiperShow = 'hover'
          }
        }
      }).catch(e => {
        console.error(e)
      })
    },
    //精准投放
    getFirstAccuratePut() {
      Api.Home.getFirstAccuratePut('').then(res => {
        if (res.data.length) {
          this.packageId = res.data[0].packageId
          this.accuratePut = res.data[0].putPreviewUrl
          this.dialogVisible = true
        }
      }).catch(e => {
        console.error(e)
      })
    },
    //小广播
    getBroadcastList() {
      Api.Home.getBroadcastList({ size: 3 }).then(res => {
        if (res.success) {
          this.broadcastList = res.data
          for (let i = 0; i < this.broadcastList.length; i++) {
            this.broadcastList[i].content = utils.htmlDecode(this.broadcastList[i].content)
          }
          if (this.broadcastList.length) {
            this.broadcastListFlag = true
          }
        }
      }).catch(e => {
        console.error(e)
      })
    }
  }
}
</script>
<style lang="scss">
.custom-tooltip {
  font-size: 12px;
  max-width: 200px !important;
}
</style>
<style lang="scss" scoped>
  @import "@/assets/stylus/main";
.index {
  width: 100%;
  height: 100%;
   .lui-carousel__item {
    background-color: rgba(14,101,150,0.10);
    .lui-icon-info{
      margin-left: 24px;
      margin-right: 12px;
      color: $--gl-blue;
    }
    span{
      cursor: pointer;
      line-height: 32px;
      color: #666;
      font-size: 14px;
    }
  }
  .lui-alert--info{
      background-color: rgba(14,101,150,0.10)!important;
  }
  .precise-delivery {
    position: fixed;
    left: 64px;
    bottom: 0;
    width: 25%;
    height: 30%;
    z-index: 100;
    img {
      width: 100%;
      height: 100%;
    }
    i {
      cursor: pointer;
      position: absolute;
      right: 5px;
      top: 5px;
      color: #b5b5b5;
      font-size: 12px;
    }
  }
  .main {
    display: flex;
  }
  .lui-alert {
    cursor: pointer;
    border-radius: 0;
    /deep/.lui-alert__icon {
      margin-left: 8px;
      color: $--gl-blue;
    }
    /deep/.lui-alert__title {
      color: #666;
      font-size: 14px;
    }
  }
  /deep/ .lui-alert__content {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  .home-left {
    width: 71%;
    min-width: 821px;
    display: flex;
    flex-direction: column;
    .chart-wrap {
      flex: 1;
      // height: 430px;
      background: #fff;
      border-radius: 0 0 4px 4px;
      box-shadow: 0 5px 14px 0 rgba(0, 0, 0, 0.12);
      .e-chart{
        width: 100%;
      }
    }
    .border-radius-left {
      // border-radius: 0 4px 4px 4px;
    }
    .border-radius-right {
      border-radius: 4px 0 4px 4px;
    }
  }
  .left-summarize{
     overflow: hidden;
     .summarize {
       display: flex;
       width: 100%;
       background: #f2f2f2;
       .active {
         z-index: 1;
         background: #fff !important;
       }
       .active-width{
         width: 33% !important;
       }
       .active-scale-green {
         color: #26a872 !important;
         // font-size: 18px !important;
       }
       .active-scale-red {
         color: #e1251b !important;
         // font-size: 18px !important;
       }
       .active-scale-size {
         font-size: 18px !important;
       }
       .wrap {
         display: flex;
         flex-direction: column;
         width: 25%;
         color: #666666;
         margin-left: 12px;
         border-radius: 8px 8px 0 0;
         background: #fff;
         padding-bottom: 10px;
         overflow: hidden;

         .title{
           font-size: 14px;
           width: 100%;
           height: 36px;
           line-height: 36px;
           text-align: center;
           // border-radius: 4px 0 6px 0;
           margin-bottom: 10px;
         }

         .scale {
           font-size: 14px;
           .iconfont {
             font-size: 14px;
           }
           .arrow-up {
               width: 9.2px;
               height: 9.8px;
               margin-left: 5px;
               display: inline-block;
               background: url(../../assets/img/green.png)no-repeat;
               background-size:100% 100%;
           }
           .arrow-down {
             width: 9.2px;
             height: 9.8px;
             margin-left: 5px;
             display: inline-block;
             background: url(../../assets/img/red.png) no-repeat;
             background-size:100% 100%;
           }
           .arrow-liedown {
             width: 10.8px;
             height: 9.2px;
             margin-left: 5px;
             display: inline-block;
             background: url(../../assets/img/black.png) no-repeat;
             background-size:100% 140%;
           }
         }
         .content {
           font-size: 12px;
           border-radius: 4px;
           background: #FFFFFF;
           &:hover {
             // border: 5px solid red;
             cursor: pointer;
             // background: rgba(14, 101, 150, 0.1);
             // box-shadow: 0 2px 6px 0 rgba(0, 0, 0, 0.29);
             color: #666666;
           }
         }
         .item-wrap {
           height: 100px;
           padding-bottom: 20px;
           // border: 1px solid red;
           .line{
             float: left;
             width: 1px;
             height: 28px;
             margin: 36px 0;
             background: #E0E0E0;
           }
           .left{
             float: left;
             width: calc(50% - 1px);
             // padding-left: 20px;
           }
           .left-width{
             width: 100%;
           }
           .right{
             float:right;
             width: 50%;
             // padding-left: 20px;
           }
           .active-tips{
             font-size: 8px;
           }
           .item {
             .lui-icon-help {
               margin-left: 5px;
             }
           }
           .number {
             p {

               display: inline-block;
               font-size: 24px;
               font-weight: 600;
               margin-right: 5px;
               &:hover {
                 color: $--gl-blue;
               }
             }
             .active-number{
               font-size: 28px;
                color: #002065;
             }
             span {
               font-size: 12px;
               color: #666666;
             }
           }
         }
       }

       .wrap:nth-child(1) {
         text-align: center;
         width: 18%;
         margin-left: 0;
         box-shadow: 0 2px 40px -10px rgba(26,85,243,0.70);
         .title{
           background-image: linear-gradient(270deg, rgba(33,130,240,0.15) 0%, rgba(33,130,240,0.4) 100%);
           color: #3C3F4D;
         }
         .active-title{
           color: #fff;
          background-image: linear-gradient(270deg, rgba(33,130,240,0.5) 0%, rgba(33,130,240,1) 100%);
         }
       }
       .wrap:nth-child(2) {
         width: 18%;
         text-align: center;
         box-shadow: 0 2px 40px -10px rgba(26,85,243,0.70);
         .title{
           background-image: linear-gradient(270deg, rgba(24,84,243,0.15) 3%, rgba(24,84,243,0.4) 100%);
           color: #3C3F4D;
         }
         .active-title{
           color: #fff;
           // background-image: linear-gradient(270deg, rgba(24,84,243,0.50) 3%, #1854F3 100%);
            background-image: linear-gradient(270deg, rgba(24,84,243,0.5) 3%, rgba(24,84,243,1) 100%);
         }
       }
       .wrap:nth-child(3) {
         text-align: center;
         width: 31%;
         box-shadow: 0 2px 40px -10px rgba(109,216,253,0.50);
         .title{
           background-image: linear-gradient(270deg, rgba(33,130,240,0.15) 0%, rgba(33,130,240,0.4) 100%);
           color: #3C3F4D;

         }
         .active-title{
           color: #fff;
           // background-image: linear-gradient(270deg, rgba(24,84,243,0.50) 3%, #1854F3 100%);
           background-image: linear-gradient(270deg, rgba(33,130,240,0.5) 0%, rgba(33,130,240,1) 100%);
         }
       }
       .wrap:nth-child(4) {
         text-align: center;
         width: 32%;
         box-shadow: 0 2px 40px -10px rgba(109,216,253,0.50);
         .title{
           background-image: linear-gradient(270deg, rgba(33,130,240,0.15) 0%, rgba(33,130,240,0.4) 100%);
           color: #3C3F4D;
         }
         .active-title{
           color: #fff;
           // background-image: linear-gradient(270deg, rgba(24,84,243,0.50) 3%, #1854F3 100%);
            background-image: linear-gradient(270deg, rgba(33,130,240,0.5) 0%, rgba(33,130,240,1) 100%);
         }
       }
     }

  }
  .adsense {
    margin-top: 12px;
    width: 100%;
    .lui-carousel__item{
      border-radius: 4px;
      background-color: transparent;
    }
    img {
      width: 100%;
      height: 100%;
    }
  }
  .home-footer {
    margin-top: 12px;
    display: flex;
    background: #eaebec;
    justify-content: space-between;
    align-items: center;
    .logo-bottom {
      width: 130px;
    }
    .lui-link {
      font-size: 14px;
      color: #999999;
      margin: 0 8px;
    }
    .record-info {
      padding-top: 5px;
      color: #999999;
    }
    span {
      font-size: 12px;
      color: #999999;
      margin: 0 8px;
    }
    .img-wrap {
      width: 25%;
      text-align: right;
      img {
        width: 20%;
        margin-left: 16px;
        text-align: right;
      }
      // img:nth-of-type(1) {
      //   width: 94px;
      //   height: 33px;
      // }
      // img:nth-of-type(2) {
      //   width: 89px;
      //   height: 33px;
      // }
      img:nth-of-type(3) {
        width: 14%;
      }
    }
  }
  .lui-carousel__container {
    height: 130px !important;
  }
  .lui-carousel__item h3 {
    color: #475669;
    font-size: 18px;
    opacity: 0.75;
    line-height: 100px;
    margin: 0;
  }
}
</style>
