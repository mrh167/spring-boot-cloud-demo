<template>
  <div class="e-chart">
    <div class="wrap">
      <div>
        <p class="p1">异常管控</p>
        <p class="p3">近7日异常总单数
          <lui-tooltip
            popper-class="custom-tooltip"
            effect="dark"
            :visible-arrow="false"
            content="近7日，发生以下任一异常的运单量，发货异常、签收异常、超3天状态未更新或5天未妥投"
            placement="bottom">
            <i class="lui-icon-help"></i>
          </lui-tooltip>
        </p>
        <p class="p2" @click="goPage()">{{ abnormalView.totalAbnormal }} <span>单</span></p>
      </div>
      <div
        ref="totalAbnormalBrokenLine"
        :style="{width: '100%', height: '350px'}"></div>
    </div>
    <div class="details-wrap">
      <div class="details">
        <div class="title">
          <p class="p1">近7日出库异常
            <lui-tooltip
              popper-class="custom-tooltip"
              effect="dark"
              :visible-arrow="false"
              content="近7日，出库时间超过下单时间24小时的单量，不包括妥投和拒收的订单"
              placement="bottom">
              <i class="lui-icon-help"></i>
            </lui-tooltip>
          </p>
          <p class="p2" @click="goPage()">{{ abnormalView.last7DaysOutWarehouseAbnormal }}<span>单</span></p>
        </div>
        <div
          ref="last7DaysOutWarehouseAbnormalBrokenLine"
          :style="{width: '100%', height: '100%'}"></div>
      </div>
      <div class="details">
        <div class="title">
          <p class="p1">近7日签收异常
            <lui-tooltip
              popper-class="custom-tooltip"
              effect="dark"
              :visible-arrow="false"
              content="近7日，妥投时间超过了站点验收24小时的单量，不包括妥投和拒收的订单"
              placement="bottom">
              <i class="lui-icon-help"></i>
            </lui-tooltip>
          </p>
          <p class="p2" @click="goPage()">{{ abnormalView.last7DaysSignAbnormal }}<span>单</span></p>
        </div>
        <div
          ref="last7DaysSignAbnormalBrokenLine"
          :style="{width: '100%', height: '100%' }"></div>
      </div>
      <div class="details">
        <div class="title">
          <p class="p1">近7日3日未更新
            <lui-tooltip
              popper-class="custom-tooltip"
              effect="dark"
              :visible-arrow="false"
              content="近7日，妥投时间超过了站点验收24小时的单量，不包括妥投和拒收的订单"
              placement="bottom">
              <i class="lui-icon-help"></i>
            </lui-tooltip>
          </p>
          <p class="p2" @click="goPage()">{{ abnormalView.last7DaysNotRenew3Days }}<span>单</span></p>
        </div>
        <div
          ref="last7DaysNotRenew3DaysBrokenLine"
          :style="{width: '100%', height: '100%'}"></div>
      </div>
      <div class="details">
        <div class="title">
          <p class="p1">近7日5日未妥投
            <lui-tooltip
              popper-class="custom-tooltip"
              effect="dark"
              :visible-arrow="false"
              content="近7日，妥投时间超过了站点验收24小时的单量，不包括妥投和拒收的订单"
              placement="bottom">
              <i class="lui-icon-help"></i>
            </lui-tooltip>
          </p>
          <p class="p2" @click="goPage()">{{ abnormalView.last7DaysNotProperly5Days }}<span>单</span></p>
        </div>
        <div
          ref="last7DaysNotProperly5DaysBrokenLine"
          :style="{width: '100%', height: '100%'}"></div>
      </div>
    </div>
  </div>
</template>

<script>
import Api from '@/api'
import echarts from 'echarts'
import utils from '@/utils/utils'
export default {
  name: 'AbnormalAlarm',
  // props: ['showAbnormalAlarm'],
  data() {
    return {
      abnormalView: {}, //异常警报全部概况
      totalAbnormalBrokenLine: [],
      totalAbnormalBrokenLineNumber: [],
      last7DaysNotRenew3DaysBrokenLine: [],
      last7DaysNotRenew3DaysBrokenLineNumber: [],
      last7DaysOutWarehouseAbnormalBrokenLine: [],
      last7DaysOutWarehouseAbnormalBrokenLineNumber: [],
      last7DaysSignAbnormalBrokenLine: [],
      last7DaysSignAbnormalBrokenLineNumber: [],
      last7DaysNotProperly5DaysBrokenLine: [],
      last7DaysNotProperly5DaysBrokenLineNumber: [],
      totalAbnormalBrokenLineExample: null,
      last7DaysNotRenew3DaysBrokenLineExample: null,
      last7DaysOutWarehouseAbnormalBrokenLineExample: null,
      last7DaysSignAbnormalBrokenLineExample: null,
      last7DaysNotProperly5DaysBrokenLineExample: null
    }
  },
  mounted() {
    this.getAbnormalWarn()
    window.addEventListener('resize', () => { //重新resize绘制，保持页面缩放
      this.$nextTick(() => {
        this.totalAbnormalBrokenLineExample && this.totalAbnormalBrokenLineExample.resize()
        this.last7DaysNotRenew3DaysBrokenLineExample && this.last7DaysNotRenew3DaysBrokenLineExample.resize()
        this.last7DaysOutWarehouseAbnormalBrokenLineExample && this.last7DaysOutWarehouseAbnormalBrokenLineExample.resize()
        this.last7DaysSignAbnormalBrokenLineExample && this.last7DaysSignAbnormalBrokenLineExample.resize()
        this.last7DaysNotProperly5DaysBrokenLineExample && this.last7DaysNotProperly5DaysBrokenLineExample.resize()
      })
    })
  },
  beforeDestroy() { //组件销毁前，释放实例
    echarts.dispose(this.totalAbnormalBrokenLineExample)
    this.totalAbnormalBrokenLineExample = null
    echarts.dispose(this.last7DaysNotRenew3DaysBrokenLineExample)
    this.last7DaysNotRenew3DaysBrokenLineExample = null
    echarts.dispose(this.last7DaysOutWarehouseAbnormalBrokenLineExample)
    this.last7DaysOutWarehouseAbnormalBrokenLineExample = null
    echarts.dispose(this.last7DaysSignAbnormalBrokenLineExample)
    this.last7DaysSignAbnormalBrokenLineExample = null
    echarts.dispose(this.last7DaysNotProperly5DaysBrokenLineExample)
    this.last7DaysNotProperly5DaysBrokenLineExample = null
  },
  methods: {
    goPage() {
      this.$router.push('/orderTime')
    },
    getAbnormalWarn() {
      this.totalAbnormalBrokenLineExample = echarts.init(this.$refs.totalAbnormalBrokenLine)
      this.last7DaysNotRenew3DaysBrokenLineExample = echarts.init(this.$refs.last7DaysNotRenew3DaysBrokenLine)
      this.last7DaysOutWarehouseAbnormalBrokenLineExample = echarts.init(this.$refs.last7DaysOutWarehouseAbnormalBrokenLine)
      this.last7DaysSignAbnormalBrokenLineExample = echarts.init(this.$refs.last7DaysSignAbnormalBrokenLine)
      this.last7DaysNotProperly5DaysBrokenLineExample = echarts.init(this.$refs.last7DaysNotProperly5DaysBrokenLine)
      this.totalAbnormalBrokenLineExample.showLoading({
        text: '数据加载中',
        color: '#2681B6',
        textColor: '#2681B6',
        maskColor: 'rgba(255, 255, 255, 0.9)'
      })
      this.last7DaysNotRenew3DaysBrokenLineExample.showLoading({
        text: '数据加载中',
        color: '#2681B6',
        textColor: '#2681B6',
        maskColor: 'rgba(255, 255, 255, 0.9)'
      })
      this.last7DaysOutWarehouseAbnormalBrokenLineExample.showLoading({
        text: '数据加载中',
        color: '#2681B6',
        textColor: '#2681B6',
        maskColor: 'rgba(255, 255, 255, 0.9)'
      })
      this.last7DaysSignAbnormalBrokenLineExample.showLoading({
        text: '数据加载中',
        color: '#2681B6',
        textColor: '#2681B6',
        maskColor: 'rgba(255, 255, 255, 0.9)'
      })
      this.last7DaysNotProperly5DaysBrokenLineExample.showLoading({
        text: '数据加载中',
        color: '#2681B6',
        textColor: '#2681B6',
        maskColor: 'rgba(255, 255, 255, 0.9)'
      })
      // this.$emit('change-status', true)
      Api.Home.abnormalWarngetAbnormalWarn('').then((res) => {
        const totalAbnormalBrokenLine = utils.formatEcharsArr(res.data.totalAbnormalBrokenLine)
        this.totalAbnormalBrokenLine = totalAbnormalBrokenLine.segment
        this.totalAbnormalBrokenLineNumber = totalAbnormalBrokenLine.number
        const last7DaysNotRenew3DaysBrokenLine = utils.formatEcharsArr(res.data.last7DaysNotRenew3DaysBrokenLine)
        this.last7DaysNotRenew3DaysBrokenLine = last7DaysNotRenew3DaysBrokenLine.segment
        this.last7DaysNotRenew3DaysBrokenLineNumber = last7DaysNotRenew3DaysBrokenLine.number
        const last7DaysOutWarehouseAbnormalBrokenLine = utils.formatEcharsArr(res.data.last7DaysOutWarehouseAbnormalBrokenLine)
        this.last7DaysOutWarehouseAbnormalBrokenLine = last7DaysOutWarehouseAbnormalBrokenLine.segment
        this.last7DaysOutWarehouseAbnormalBrokenLineNumber = last7DaysOutWarehouseAbnormalBrokenLine.number
        const last7DaysSignAbnormalBrokenLine = utils.formatEcharsArr(res.data.last7DaysSignAbnormalBrokenLine)
        this.last7DaysSignAbnormalBrokenLine = last7DaysSignAbnormalBrokenLine.segment
        this.last7DaysSignAbnormalBrokenLineNumber = last7DaysSignAbnormalBrokenLine.number
        const last7DaysNotProperly5DaysBrokenLine = utils.formatEcharsArr(res.data.last7DaysNotProperly5DaysBrokenLine)
        this.last7DaysNotProperly5DaysBrokenLine = last7DaysNotProperly5DaysBrokenLine.segment
        this.last7DaysNotProperly5DaysBrokenLineNumber = last7DaysNotProperly5DaysBrokenLine.number
        this.init()
      }).catch((e) => {
        console.error(e)
      })
      Api.Home.abnormalWarngetAbnormalView().then(row => {
        this.abnormalView = row.data
      }).catch((e) => {
        console.error(e)
      })
    },
    calMaxMin(arr) {
      var newArr = JSON.parse(JSON.stringify(arr))
      newArr.sort(function(a, b) {
        return a - b
      })
      var number = {
        max: '',
        min: ''
      }
      number.min = Math.floor(newArr[0] * 0.8)
      number.max = Math.ceil(newArr[newArr.length - 1] * 1.2)
      return number
    },
    init() {
      // const data1 = ['2016-10-4', '2016-10-5', '2016-10-6', '2016-10-7', '2016-10-8', '2016-10-9', '2016-10-10', '2016-10-11', '2016-10-12']
      // const data5 = [292, 320, 287, 194, 292, 280, 295, 321, 296]
      // const data6 = [296, 300, 297, 294, 262, 300, 275, 261, 286]
      const option = {
        animation: false,
        tooltip: {
          trigger: 'axis',
          transitionDuration: 0, //防止tooltip的抖动
          formatter(params) {
            return '<div style="font-size:14px;">' +
              params[0].name + '<br>' +
              "<div style='display:inline-block;line-height:20px'><div style='display:inline-block; width:10px;height:4px;background:#4C8FD3;margin-right:5px'></div></div>" +
              utils.tenThousand(params[0].value) +
            '</div>'
          }
        },
        xAxis: {
          show: false,
          boundaryGap: false,
          data: this.totalAbnormalBrokenLine,
          type: 'category',
          axisPointer: {
            type: 'line',
            snap: true,
            lineStyle: {
              color: '#fff',
              opacity: 0.5,
              width: 5
            },
            label: {
              show: false,
              backgroundColor: '#004E52'
            },
            handle: {
              show: false,
              color: '#004E52'
            }
          },
          axisTick: { //y轴刻度线
            show: false
          },
          splitLine: {//分割线
            show: true
          }
        },
        yAxis: {
          // min: this.calMaxMin(this.last7DaysNotProperly5DaysBrokenLineNumber).min,
          // max: this.calMaxMin(this.last7DaysNotProperly5DaysBrokenLineNumber).max,
          // interval: (this.calMaxMin(this.last7DaysNotProperly5DaysBrokenLineNumber).max - this.calMaxMin(this.last7DaysNotProperly5DaysBrokenLineNumber).min),
          interval: (utils.calMaxMin(this.totalAbnormalBrokenLineNumber).max - utils.calMaxMin(this.totalAbnormalBrokenLineNumber).min) / 5,
          min: utils.calMaxMin(this.totalAbnormalBrokenLineNumber).min,
          max: utils.calMaxMin(this.totalAbnormalBrokenLineNumber).max,
          type: 'value',
          axisTick: {
            inside: true,
            show: false
          },
          handle: {
            show: false,
            color: '#004E52'
          },
          axisLine: {
            show: false
          },
          splitLine: {
            show: true
          },
          axisLabel: {
            show: false,
            inside: true,
            formatter: '{value}\n'
          }
        },
        grid: {
          top: 40,
          left: 15,
          right: 15,
          height: 270
        },
        series: [
          {
            type: 'line',
            smooth: true,
            symbol: 'circle',
            symbolSize: 15,
            showSymbol: false, //控制原点
            sampling: 'average',
            itemStyle: {
              normal: {
                color: '#4C8FD3', //折点颜色
                borderColor: '#fff',
                borderWidth: 4,
                lineStyle: {
                  color: '#4C8FD3', //折线颜色
                  width: '2'
                }
              }
            },
            areaStyle: {
              color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                offset: 0,
                color: '#4C8FD3'
              }, {
                offset: 1,
                color: '#ffe'
              }])
            },
            data: this.totalAbnormalBrokenLineNumber
          }
        ]
      }
      const option1 = {
        animation: false,
        tooltip: {
          trigger: 'axis',
          transitionDuration: 0, //防止tooltip的抖动
          formatter(params) {
            return '<div style="font-size:14px;">' +
              params[0].name + '<br>' +
              "<div style='display:inline-block;line-height:20px'><div style='display:inline-block; width:10px;height:4px;background:#568DFF;margin-right:5px'></div></div>" +
              params[0].value + '  单' +
            '</div>'
          },
          axisPointer: {
            type: 'none'
          }
        },
        xAxis: {
          show: false,
          boundaryGap: false,
          data: this.last7DaysNotRenew3DaysBrokenLine,
          type: 'category',
          axisPointer: {
            snap: true,
            lineStyle: {
              color: '#568DFF',
              opacity: 0.5,
              width: 2
            },
            label: {
              show: false,
              backgroundColor: '#568DFF'
            },
            handle: {
              show: false,
              color: '#568DFF'
            }
          },
          axisTick: { //y轴刻度线
            show: false
          },
          splitLine: {//分割线
            show: false
          }
        },
        yAxis: {
          min: this.calMaxMin(this.last7DaysNotRenew3DaysBrokenLineNumber).min,
          max: this.calMaxMin(this.last7DaysNotRenew3DaysBrokenLineNumber).max,
          interval: (utils.calMaxMin(this.last7DaysNotRenew3DaysBrokenLineNumber).max - utils.calMaxMin(this.last7DaysNotRenew3DaysBrokenLineNumber).min) / 5,
          type: 'value',
          axisTick: {
            inside: false,
            show: false
          },
          handle: {
            show: false,
            color: '#568DFF'
          },
          axisLine: {
            show: false
          },
          splitLine: {
            show: false
          },
          axisLabel: {
            show: true,
            inside: false,
            formatter: '{value}\n'
          }
        },
        grid: {
          top: 0,
          left: 0,
          right: 10,
          height: 83
        },
        series: [
          {
            type: 'line',
            smooth: true,
            symbol: 'none',
            symbolSize: 5,
            showSymbol: false,
            sampling: 'average',
            itemStyle: {
              symbol: 'none',
              color: '#568DFF'
            },
            data: this.last7DaysNotRenew3DaysBrokenLineNumber
          }
        ]
      }
      const option2 = {
        animation: false,
        tooltip: {
          trigger: 'axis',
          transitionDuration: 0,
          formatter(params) {
            return '<div style="font-size:14px;">' +
              params[0].name + '<br>' +
              "<div style='display:inline-block;line-height:20px'><div style='display:inline-block; width:10px;height:4px;background:#568DFF;margin-right:5px'></div></div>" +
              params[0].value + '  单' +
            '</div>'
          },
          axisPointer: {
            type: 'none'
          }
        },
        xAxis: {
          show: false,
          boundaryGap: false,
          data: this.last7DaysOutWarehouseAbnormalBrokenLine,
          type: 'category',
          axisPointer: {
            snap: true,
            lineStyle: {
              color: '#568DFF',
              opacity: 0.5,
              width: 2
            },
            label: {
              show: false,
              formatter(params) {
                return echarts.format.formatTime('yyyy/MM/dd', params.value)
              },
              backgroundColor: '#568DFF'
            },
            handle: {
              show: false,
              color: '#568DFF'
            }
          },
          axisTick: { //y轴刻度线
            show: false
          },
          splitLine: {//分割线
            show: false
          }
        },
        yAxis: {
          min: this.calMaxMin(this.last7DaysOutWarehouseAbnormalBrokenLineNumber).min,
          max: this.calMaxMin(this.last7DaysOutWarehouseAbnormalBrokenLineNumber).max,
          interval: (utils.calMaxMin(this.last7DaysOutWarehouseAbnormalBrokenLineNumber).max - utils.calMaxMin(this.last7DaysOutWarehouseAbnormalBrokenLineNumber).min) / 5,
          type: 'value',
          axisTick: {
            inside: false,
            show: false
          },
          handle: {
            show: false,
            color: '#568DFF'
          },
          axisLine: {
            show: false
          },
          splitLine: {
            show: false
          },
          axisLabel: {
            show: false,
            inside: false,
            formatter: '{value}\n'
          }
        },
        grid: {
          top: 0,
          left: 0,
          right: 10,
          height: 83
        },
        series: [
          {
            type: 'line',
            smooth: true,
            symbol: 'none',
            symbolSize: 5,
            showSymbol: false,
            sampling: 'average',
            itemStyle: {
              symbol: 'none',
              color: '#568DFF'
            },
            data: this.last7DaysOutWarehouseAbnormalBrokenLineNumber
          }

        ]
      }
      const option3 = {
        animation: false,
        tooltip: {
          trigger: 'axis',
          transitionDuration: 0, //防止tooltip的抖动
          formatter(params) {
            return '<div style="font-size:14px;">' +
              params[0].name + '<br>' +
              "<div style='display:inline-block;line-height:20px'><div style='display:inline-block; width:10px;height:4px;background:#568DFF;margin-right:5px'></div></div>" +
              params[0].value + '  单' +
            '</div>'
          },
          axisPointer: {
            type: 'none'
          }
        },
        xAxis: {
          show: false,
          boundaryGap: false,
          data: this.last7DaysSignAbnormalBrokenLine,
          type: 'category',
          axisPointer: {
            snap: true,
            lineStyle: {
              color: '#568DFF',
              opacity: 0.5,
              width: 2
            },
            label: {
              show: false,
              backgroundColor: '#568DFF'
            },
            handle: {
              show: false,
              color: '#568DFF'
            }
          },
          axisTick: { //y轴刻度线
            show: false
          },
          splitLine: {//分割线
            show: false
          }
        },
        yAxis: {
          min: this.calMaxMin(this.last7DaysSignAbnormalBrokenLineNumber).min,
          max: this.calMaxMin(this.last7DaysSignAbnormalBrokenLineNumber).max,
          interval: (utils.calMaxMin(this.last7DaysSignAbnormalBrokenLineNumber).max - utils.calMaxMin(this.last7DaysSignAbnormalBrokenLineNumber).min) / 1,
          type: 'value',
          axisTick: {
            inside: false,
            show: false
          },
          handle: {
            show: false,
            color: '#568DFF'
          },
          axisLine: {
            show: false
          },
          splitLine: {
            show: false
          },
          axisLabel: {
            show: false,
            inside: false,
            formatter: '{value}\n'
          }
        },
        grid: {
          top: 0,
          left: 0,
          right: 10,
          height: 83
        },
        series: [
          {
            type: 'line',
            smooth: true,
            symbol: 'none',
            symbolSize: 5,
            showSymbol: false,
            sampling: 'average',
            itemStyle: {
              symbol: 'none',
              color: '#568DFF'
            },
            data: this.last7DaysSignAbnormalBrokenLineNumber
          }

        ]
      }
      const option4 = {
        animation: false,
        tooltip: {
          trigger: 'axis',
          transitionDuration: 0, //防止tooltip的抖动
          formatter(params) {
            return '<div style="font-size:14px;">' +
              params[0].name + '<br>' +
              "<div style='display:inline-block;line-height:20px'><div style='display:inline-block; width:10px;height:4px;background:#568DFF;margin-right:5px'></div></div>" +
              params[0].value + '  单' +
            '</div>'
          },
          axisPointer: {
            type: 'none'
          }
        },
        xAxis: {
          show: false,
          boundaryGap: false,
          data: this.last7DaysNotProperly5DaysBrokenLine,
          type: 'category',
          axisPointer: {
            snap: true,
            lineStyle: {
              color: '#568DFF',
              opacity: 0.5,
              width: 2
            },
            label: {
              show: false,
              backgroundColor: '#568DFF'
            },
            handle: {
              show: false,
              color: '#568DFF'
            }
          },
          axisTick: { //y轴刻度线
            show: false
          },
          splitLine: {//分割线
            show: false
          }
        },
        yAxis: {
          min: this.calMaxMin(this.last7DaysNotProperly5DaysBrokenLineNumber).min,
          max: this.calMaxMin(this.last7DaysNotProperly5DaysBrokenLineNumber).max,
          interval: (this.calMaxMin(this.last7DaysNotProperly5DaysBrokenLineNumber).max - this.calMaxMin(this.last7DaysNotProperly5DaysBrokenLineNumber).min),
          type: 'value',
          axisTick: {
            inside: false,
            show: false
          },
          handle: {
            show: false,
            color: '#568DFF'
          },
          axisLine: {
            show: false
          },
          splitLine: {
            show: false
          },
          axisLabel: {
            show: false,
            inside: false,
            formatter: '{value}\n'
          }
        },
        grid: {
          top: 0,
          left: 0,
          right: 10,
          height: 83
        },
        series: [
          {
            type: 'line',
            smooth: true,
            symbol: 'none',
            symbolSize: 5,
            showSymbol: false,
            sampling: 'average',
            itemStyle: {
              symbol: 'none',
              color: '#568DFF'
            },
            data: this.last7DaysNotProperly5DaysBrokenLineNumber
          }
        ]
      }
      this.totalAbnormalBrokenLineExample.setOption(option)
      this.last7DaysNotRenew3DaysBrokenLineExample.setOption(option1)
      this.last7DaysOutWarehouseAbnormalBrokenLineExample.setOption(option2)
      this.last7DaysSignAbnormalBrokenLineExample.setOption(option3)
      this.last7DaysNotProperly5DaysBrokenLineExample.setOption(option4)
      this.totalAbnormalBrokenLineExample.hideLoading()
      this.last7DaysNotRenew3DaysBrokenLineExample.hideLoading()
      this.last7DaysOutWarehouseAbnormalBrokenLineExample.hideLoading()
      this.last7DaysSignAbnormalBrokenLineExample.hideLoading()
      this.last7DaysNotProperly5DaysBrokenLineExample.hideLoading()
    }
  }
}
</script>

<style lang="scss" scoped>
@import '@/assets/stylus/main';
.e-chart {
  height: 100%;
  .wrap {
    float: left;
    width: 60%;
    height: 100%;
    .p1 {
      font-size: 12px;
      color: #333333;
      margin: 20px 0px 10px 15px;
    }
    .p2 {
      font-size: 20px;
      color: #333;
      margin-left: 15px;
        &:hover{
          color: $--gl-blue;
          cursor: pointer;
        }
      span {
        margin-left: 5px;
        font-size: 12px;
        color: #666666;
      }
    }
    .p3 {
      margin-left: 15px;
      font-size: 12px;
      color: #666666;
      .lui-icon-help {
        margin-left: 5px;
        cursor: pointer;
      }
    }
  }
  .details-wrap {
    float: left;
    padding: 20px 12px 0;
    width: 40%;
    height: 100%;
    border-left: 1px solid #e6e6e6;
  }
  .details {
    height: 88px;
    display: flex;
    box-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.1);
    border-radius: 4px;
    margin-bottom: 12px;
    .title {
      width: 135px;
      padding: 12px;
      .p1 {
        width: 108px;
      }
      .p2 {
        font-size: 20px;
        color: #333333;
         &:hover{
          color: $--gl-blue;
          cursor: pointer;
        }
        span {
          margin-left: 5px;
          font-size: 12px;
          color: #666666;
        }
      }
      p {
        font-size: 12px;
        color: #666666;
        i {
          margin-left: 5px;
          cursor: pointer;
        }
        span {
          font-size: 20px;
          color: #333333;
        }
      }
    }
  }
}
</style>
