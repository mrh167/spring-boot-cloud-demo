<template>
  <div class="e-chart">
    <div :style="{width: '56%', height: '100%',float: 'left'}">
      <div :style="{width: 'calc(100% - 110px)', height: '100%',float: 'left'}">
        <p class="p1">单量趋势图
          <lui-tooltip
            popper-class="custom-tooltip"
            effect="dark"
            :visible-arrow="false"
            content="统计时间内（今日0点至现在），仓配下单和纯配下单量总和，其中仓配下单量取ECLP接收的单量，含取消单；纯配下单量按运单创建时间，含取消单"
            placement="bottom">
            <i class="lui-icon-help"></i>
          </lui-tooltip></p>
        <div
          ref="todayYesterdayBrokenLine"
          :style="{width: '100%', height: '360px'}">
        </div>
      </div>
      <div
        class="text-wrap"
        :style="{width: '110px', height: '100%' , float: 'left'}">
        <div
          v-for="(item) in dataList"
          :key="item.id"
          class="item">
          <p class="title">{{ item.name }}
            <lui-tooltip
              popper-class="custom-tooltip"
              effect="dark"
              :visible-arrow="false"
              :content="item.tips"
              placement="bottom">
              <i class="lui-icon-help"></i>
            </lui-tooltip>
          </p>
          <p class="number">{{ item.number }} <span>单</span></p>
          <p
            class="scale"
            :class="{ 'active-green' :item.status > 0,'active-red':item.status < 0 }">{{ item.ratio+'%' }}
            <i v-if="item.status > 0" class="arrow-up"></i>
            <i v-if="item.status < 0" class="arrow-down"></i>
            <i v-if="item.status == 0" class="arrow-liedown"></i>
          </p>
        </div>
      </div>
    </div>
    <div v-if="userType === '2'" style="height: 100%">
      <div :style="{width: '22%', height: '100%',float: 'left', borderLeft:'1px solid #e6e6e6'}">
        <p class="p1">销售趋势及预测</p>
        <div
          ref="historyBrokenLine"
          :style="{width: '100%', height: '360px'}"></div>
      </div>
      <!-- <div class="line"></div> -->
      <div :style="{width: '22%', height: '100%',float: 'left', borderLeft:'1px dashed #e6e6e6'}">
        <p class="p2">
          <lui-tooltip
            popper-class="custom-tooltip"
            effect="dark"
            :visible-arrow="false"
            content="近7日历史销量（统计销售出库件数）趋势及未来7天销量趋势预估"
            placement="bottom">
            <i class="lui-icon-help"></i>
          </lui-tooltip>
        </p>
        <div
          ref="futureBrokenLine"
          style="z-index:1"
          :style="{width: '100%', height: '360px'}">
        </div>
        <div class="mask"><img src=""></div>
      </div>
    </div>
    <div v-if="userType === '1'" :style="{width: '44%', height: '100%',float: 'left'}">
      <p class="p1">揽收量趋势图
        <lui-tooltip
          popper-class="custom-tooltip"
          effect="dark"
          :visible-arrow="false"
          content="近14日历史揽收单量趋势"
          placement="bottom">
          <i class="lui-icon-help"></i>
        </lui-tooltip></p>
      <div
        ref="collectionTrend"
        :style="{width: '100%', height: '360px'}"></div>
    </div>
  </div>
</template>

<script>
import Api from '@/api'
import echarts from 'echarts'
import utils from '@/utils/utils'
export default {
  name: 'OperationDynamics',
  // props: ['userType'],
  props: {
    userType: {
      type: String,
      default: ''
    }
  },
  data() {
    return {
      todayView: {},
      dataList: [
        { id: 0, name: '今日出库量', number: '', ratio: '', tips: '统计时间内（今日0点至现在），仓配订单今日出库订单量总和，含取消单' },
        { id: 1, name: '今日拒收量', number: '', ratio: '', tips: '统计时间内（今日0点至现在），仓配订单订单和快递揽收订单的拒收单量（拒收时间）' },
        { id: 2, name: '今日退回量', number: '', ratio: '', tips: '统计时间内（今日0点至现在），仓配订单订单和快递揽收订单的退回单量（退回换单时间）' },
        { id: 3, name: '今日妥投量', number: '', ratio: '', tips: '统计时间内（今日0点至现在），仓配订单订单和快递揽收订单的妥投单量（含自提上架）' }
      ],
      todayBrokenLine: [],
      todayBrokenLineNumber: [],
      yesterdayBrokenLine: [],
      yesterdayBrokenLineNumber: [],
      historyBrokenLine: [],
      historyBrokenLineNumber: [],
      futureBrokenLine: [],
      futureBrokenLineNumber: [],
      collectedBrokenLine: [],
      collectedBrokenLineNumber: [],
      todayYesterdayBrokenLineExample: null,
      historyBrokenLineExample: null,
      futureBrokenLineExample: null,
      collectionTrendExample: null
    }
  },
  watch: {
    userType(val) {
      this.userType = val
      this.$nextTick(() => {
        if (this.userType === '2') {
          this.getWeekPredictionView()
        } else if (this.userType === '1') {
          this.getFlowDirection()
        }
      })
    }
  },
  mounted() {
    this.$nextTick(() => {
      this.getTodayMonitor()//今日监控中部指标
      this.getBrokenLine()//昨日今日折线
      if (this.userType === '2') {
        this.getWeekPredictionView()//本周预测历史销量
      } else if (this.userType === '1') {
        this.getFlowDirection()//揽收量折线
      }
      window.addEventListener('resize', () => {
        this.todayYesterdayBrokenLineExample && this.todayYesterdayBrokenLineExample.resize()
        this.historyBrokenLineExample && this.historyBrokenLineExample.resize()
        this.futureBrokenLineExample && this.futureBrokenLineExample.resize()
        this.collectionTrendExample && this.collectionTrendExample.resize()
      })
    })
  },
  beforeDestroy() { //组件销毁前，释放实例
    echarts.dispose(this.todayYesterdayBrokenLineExample)
    this.todayYesterdayBrokenLineExample = null
    if (this.userType === '1') {
      echarts.dispose(this.collectionTrendExample)
      this.collectionTrendExample = null
    } else if (this.userType === '2') {
      echarts.dispose(this.historyBrokenLineExample)
      this.historyBrokenLineExample = null
      echarts.dispose(this.futureBrokenLineExample)
      this.futureBrokenLineExample = null
    }
  },
  methods: {
    getFlowDirection() { //揽收量折线
      this.collectionTrendExample = echarts.init(this.$refs.collectionTrend)
      this.collectionTrendExample.showLoading({
        text: '数据加载中',
        color: '#2681B6',
        textColor: '#2681B6',
        maskColor: 'rgba(255, 255, 255, 0.9)'
      })
      Api.Home.getFlowDirection('').then((res) => {
        const data = res.data
        const collectedBrokenLine = utils.formatEcharsArr(data)
        this.collectedBrokenLine = collectedBrokenLine.segment
        this.collectedBrokenLineNumber = collectedBrokenLine.number
        this.getFlowDirectionEchars()
      }).catch((e) => {
        console.error(e)
      })
    },
    getTodayMonitor() { //运营动态大指标 + 今日监控中部指标
      Api.Home.getTodayMonitor('').then((res) => {
        this.todayView = res.data
        this.$emit('func', this.todayView)
        this.getTodayMonitorDetails()
      }).catch((e) => {
        console.error(e)
      })
    },
    getTodayMonitorDetails() { //今日监控中部指标
      this.dataList.forEach((item) => {
        if (item.id === 0) {
          if (this.userType === '1') {
            item.name = '今日出库/揽收量'
            item.tips = '统计时间内（今日0点至现在），仓配订单和纯配订单今日出库/揽收订单量总和，含取消单'
          }
          item.number = utils.toThousands(this.todayView.outWarehouse)
          item.ratio = this.todayView.outWarehouseRatio
          item.status = this.todayView.outWarehouseRatioDesc
        } else if (item.id === 1) {
          item.number = utils.toThousands(this.todayView.rejection)
          item.ratio = this.todayView.rejectionRatio
          item.status = this.todayView.rejectionRatioDesc
        } else if (item.id === 2) {
          item.number = utils.toThousands(this.todayView.returned)
          item.ratio = this.todayView.returnedRatio
          item.status = this.todayView.returnedRatioDesc
        } else if (item.id === 3) {
          item.number = utils.toThousands(this.todayView.properly)
          item.ratio = this.todayView.properlyRatio
          item.status = this.todayView.properlyRatioDesc
        }
      })
    },
    getWeekPredictionView() { //历史销量、本周预测折线
      this.historyBrokenLineExample = echarts.init(this.$refs.historyBrokenLine)
      this.futureBrokenLineExample = echarts.init(this.$refs.futureBrokenLine)
      this.historyBrokenLineExample.showLoading({
        text: '数据加载中',
        color: '#2681B6',
        textColor: '#2681B6',
        maskColor: 'rgba(255, 255, 255, 0.9)'
      })
      this.futureBrokenLineExample.showLoading({
        text: '数据加载中',
        color: '#2681B6',
        textColor: '#2681B6',
        maskColor: 'rgba(255, 255, 255, 0.9)'
      })
      Api.Home.getWeekPredictionView('').then((res) => {
        const data = res.data
        const historyBrokenLine = utils.formatEcharsArr(data.historyBrokenLine)
        this.historyBrokenLine = historyBrokenLine.segment
        this.historyBrokenLineNumber = historyBrokenLine.number
        const futureBrokenLine = utils.formatEcharsArr(data.futureBrokenLine)
        this.futureBrokenLine = futureBrokenLine.segment
        this.futureBrokenLineNumber = futureBrokenLine.number
        this.initEcharts()
      }).catch((e) => {
        console.error(e)
      })
    },
    getBrokenLine() { //今日昨日订单量折线
      this.todayYesterdayBrokenLineExample = echarts.init(this.$refs.todayYesterdayBrokenLine)
      this.todayYesterdayBrokenLineExample.showLoading({
        text: '数据加载中',
        color: '#2681B6',
        textColor: '#2681B6',
        maskColor: 'rgba(255, 255, 255, 0.9)'
      })
      Api.Home.getBrokenLine('').then((res) => {
        const data = res.data
        const todayBrokenLine = utils.formatEcharsArr(data.todayBrokenLine)//今日订单量
        this.todayBrokenLine = todayBrokenLine.segment
        this.todayBrokenLineNumber = todayBrokenLine.number
        const yesterdayBrokenLine = utils.formatEcharsArr(data.yesterdayBrokenLine)//昨日订单量
        this.yesterdayBrokenLine = yesterdayBrokenLine.segment
        this.yesterdayBrokenLineNumber = yesterdayBrokenLine.number
        this.getBrokenLineEchars()
      }).catch((e) => {
        console.error(e)
      })
    },
    open() {
      this.$alert('<div class="lui-message-box__status lui-icon-warning"></div><strong>您尚未开通【销量预测】产品服务，本次显示的预测值为历史28天平均结果。为提升预测准确率，建议您开通使用【销量预测】</strong><div> </div><div><a href="https://www.jd.com" target="_blank"> 前往开通</a></div>', '', {
        dangerouslyUseHTMLString: true, showConfirmButton: false, customClass: 'custom-alert' })
    },
    getFlowDirectionEchars() {
      const collectedBrokenLineOption = {
        animation: false,
        legend: [{
          top: 'bottom',
          left: '15',
          right: '5',
          data: ['揽收量'],
          color: '#859EDF',
          icon: 'rect',
          itemWidth: 12,
          itemHeight: 5
        }],
        tooltip: {
          trigger: 'axis',
          transitionDuration: 0,
          label: { show: false },
          formatter(params) {
            return '<div style="font-size:14px;">' +
              params[0].name + '<br>' +
              "<div style='display:inline-block;line-height:20px'><div style='display:inline-block; width:10px;height:4px;background:#859EDF;margin-right:5px'></div></div>" +
              params[0].value +
            '</div>'
          }
        },
        xAxis: {
          data: this.collectedBrokenLine,
          show: false,
          type: 'category',
          boundaryGap: false,
          axisPointer: {
            snap: true,
            lineStyle: {
              color: '#fff',
              opacity: 0.8,
              width: 5
            },
            label: {
              icon: 'rect',
              show: false,
              backgroundColor: '#004E52'
            },
            handle: {
              show: false,
              color: '#004E52'
            }
          },
          axisTick: { //y轴刻度线
            show: false
          },
          splitLine: {//分割线
            show: false
          }
        },
        yAxis: {
          type: 'value',
          axisTick: {
            inside: true,
            show: false
          },
          handle: {
            show: false,
            color: '#004E52'
          },
          axisLine: {
            show: false
          },
          splitLine: {
            show: true
          },
          axisLabel: {
            show: false,
            inside: true,
            formatter: '{value}\n'
          }
        },
        grid: {
          top: 40,
          left: 15,
          right: 15,
          height: 270
        },
        series: [
          {
            name: '揽收量',
            type: 'line',
            smooth: true,
            symbol: 'circle',
            symbolSize: 15,
            showSymbol: false,
            sampling: 'average',
            itemStyle: {
              normal: {
                color: '#859EDF', //折点颜色
                borderColor: '#fff',
                borderWidth: 4,
                lineStyle: {
                  color: '#859EDF', //折线颜色
                  width: '2'
                }
              }
            },
            areaStyle: {
              color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                offset: 0,
                color: '#859EDF'
              }, {
                offset: 1,
                color: '#ffe'
              }])
            },
            data: this.collectedBrokenLineNumber
          }
        ]
      }
      this.collectionTrendExample.setOption(collectedBrokenLineOption)
      this.collectionTrendExample.hideLoading()
    },
    getBrokenLineEchars() {
      var arr = [...this.todayBrokenLineNumber, ...this.yesterdayBrokenLineNumber]
      var min = utils.calMaxMin(arr).min
      var max = utils.calMaxMin(arr).max
      const option = {
        animation: false,
        legend: [{
          top: 'bottom',
          left: '15',
          right: '5',
          data: ['今日订单量'],
          color: '#4C8FD3',
          icon: 'rect',
          itemWidth: 12,
          itemHeight: 5
        },
        {
          top: 'bottom',
          left: '120',
          data: ['昨日下单量'],
          color: '#568DFF',
          icon: 'rect',
          itemWidth: 12,
          itemHeight: 5
        }
        ],
        tooltip: {
          trigger: 'axis',
          transitionDuration: 0,
          label: { show: false },
          formatter(params) {
            let dom = ''
            const colors = ["<div style='display:inline-block; width:10px;height:4px;background:#4C8FD3;margin-right:5px'></div>", "<div style='display:inline-block; width:10px;height:4px;background:#568DFF;margin-right:5px'></div>"]
            for (var i = 0; i < params.length; i++) {
              if (params[i].seriesName === '今日订单量') {
                if (params[i].data !== null) {
                  dom += "<div style='display:inline-block;line-height:20px'>" + colors[0] + utils.tenThousand(params[i].value) + '</div><br>'
                }
              } else if (params[i].seriesName === '昨日下单量') {
                dom += "<div style='display:inline-block;line-height:20px'>" + colors[1] + utils.tenThousand(params[i].value) + '</div><br>'
              }
            }
            return '<div style="font-size:14px;">' + params[0].name + ' 点<br>' + dom + '</div>'
          }
        },
        xAxis: {
          data: this.todayBrokenLine,
          // data: data1,
          show: false,
          type: 'category',
          boundaryGap: false,
          axisPointer: {
            snap: true,
            lineStyle: {
              color: '#fff',
              opacity: 0.8,
              width: 5
            },
            label: {
              icon: 'rect',
              show: false,
              backgroundColor: '#004E52'
            },
            handle: {
              show: false,
              color: '#004E52'
            }
          },
          axisTick: { //y轴刻度线
            show: false
          },
          splitLine: {//分割线
            show: false
          }
        },
        yAxis: {
          min: min,
          max: max,
          interval: (max - min) / 5,
          type: 'value',
          axisTick: {
            inside: true,
            show: false
          },
          handle: {
            show: false,
            color: '#004E52'
          },
          axisLine: {
            show: false
          },
          splitLine: {
            show: true
          },
          axisLabel: {
            show: false,
            inside: true,
            formatter: '{value}\n'
          }
        },
        grid: {
          top: 40,
          left: 15,
          right: 15,
          height: 270
        },
        series: [
          {
            name: '今日订单量',
            type: 'line',
            smooth: true,
            symbol: 'circle',
            symbolSize: 15,
            showSymbol: false,
            sampling: 'average',
            itemStyle: {
              normal: {
                color: '#4C8FD3', //折点颜色
                borderColor: '#fff',
                borderWidth: 4,
                lineStyle: {
                  color: '#4C8FD3', //折线颜色
                  width: '2'
                }
              }
            },
            areaStyle: {
              color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                offset: 0,
                color: '#4C8FD3'
              }, {
                offset: 1,
                color: '#ffe'
              }])
            },
            data: this.todayBrokenLineNumber
          },
          {
            name: '昨日下单量',
            type: 'line',
            smooth: true,
            symbol: 'circle',
            symbolSize: 15,
            showSymbol: false,
            sampling: 'average',
            itemStyle: {
              normal: {
                color: '#568DFF', //折点颜色
                borderColor: '#fff',
                borderWidth: 4,
                lineStyle: {
                  color: '#568DFF', //折线颜色
                  width: '2'
                }
              }
            },
            areaStyle: {
              color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                offset: 0,
                color: '#568DFF'
              }, {
                offset: 1,
                color: '#ffe'
              }])
            },
            data: this.yesterdayBrokenLineNumber
            // data: data6
          }
        ]
      }
      this.todayYesterdayBrokenLineExample.setOption(option)
      this.todayYesterdayBrokenLineExample.hideLoading()
    },
    initEcharts() {
      var arr = [...this.historyBrokenLineNumber, ...this.futureBrokenLineNumber]
      var min = utils.calMaxMin(arr).min
      var max = utils.calMaxMin(arr).max
     
      const option1 = {
        animation: false,
        legend: [{
          // top: 'bottom',
          left: '15',
          right: '5',
          bottom: '0',
          data: ['历史销量'],
          color: '#78C7E8',
          icon: 'rect',
          itemWidth: 12,
          itemHeight: 5
        }
        ],
        tooltip: {
          trigger: 'axis',
          transitionDuration: 0, //防止tooltip的抖动
          formatter(params) {
            return '<div style="font-size:14px;">' +
              params[0].name + '<br>' +
              "<div style='display:inline-block;line-height:10px'><span style='display:inline-block; width:10px;height:4px;background:#78C7E8;margin-right:5px'></span></div>" +
              utils.tenThousand(params[0].value) +
            '</div>'
          }
        },
        xAxis: {
          show: false,
          data: this.historyBrokenLine,
          type: 'category',
          boundaryGap: false,
          axisPointer: {
            snap: true,
            lineStyle: {
              color: '#fff',
              opacity: 0.8,
              width: 5
            },
            label: {
              show: false,
              backgroundColor: '#004E52'
            },
            handle: {
              show: false,
              color: '#004E52'
            }
          },
          axisTick: { //y轴刻度线
            show: false
          },
          splitLine: {//分割线
            show: true
          }
        },
        yAxis: {
          min: min,
          max: max,
          interval: (max - min) / 5,
          type: 'value',
          axisTick: {
            inside: true,
            show: false
          },
          handle: {
            show: false,
            color: '#004E52'
          },
          axisLine: {
            show: false
          },
          splitLine: {
            show: true
          },
          axisLabel: {
            show: false,
            inside: true,
            formatter: '{value}\n'
          }
        },
        grid: {
          top: 40,
          left: 15,
          right: 8,
          height: 270
        },
        series: [
          {
            name: '历史销量',
            type: 'line',
            smooth: true,
            symbol: 'circle',
            showSymbol: false,
            symbolSize: 15,
            sampling: 'average',
            itemStyle: {
              normal: {
                color: '#78C7E8', //折点颜色
                borderColor: '#fff',
                borderWidth: 4,
                lineStyle: {
                  color: '#78C7E8', //折线颜色
                  width: '2'
                }
              }
            },
            areaStyle: {
              color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                offset: 0,
                color: '#78C7E8'
              }, {
                offset: 1,
                color: '#ffe'
              }])
            },
            data: this.historyBrokenLineNumber
          }
        ]
      }
      const option2 = {
        animation: false,
        legend: [{
          top: 'bottom',
          right: '15',
          data: ['预测销量'],
          color: '#64CFAB',
          icon: 'rect',
          itemWidth: 12,
          itemHeight: 5
        }
        ],
        tooltip: {
          trigger: 'axis',
          transitionDuration: 0, //防止tooltip的抖动
          formatter(params) {
            return '<div style="font-size:14px;">' +
              params[0].name + '<br>' +
              "<div style='display:inline-block;line-height:10px'><span style='display:inline-block; width:10px;height:4px;background:#64CFAB;margin-right:5px'></span></div>" +
              utils.tenThousand(params[0].value) +
            '</div>'
          }
        },
        xAxis: {
          show: false,
          data: this.futureBrokenLine,
          type: 'category',
          boundaryGap: false,
          axisPointer: {
            snap: true,
            lineStyle: {
              color: '#fff',
              opacity: 0.8,
              width: 5
            },
            label: {
              show: false,
              backgroundColor: '#004E52'
            },
            handle: {
              show: false,
              color: '#004E52'
            }
          },

          axisTick: { //y轴刻度线
            show: false
          },
          splitLine: {//分割线
            show: true
          }
        },
        yAxis: {
          min: min,
          max: max,
          interval: (max - min) / 5,
          type: 'value',
          axisTick: {
            inside: true,
            show: false
          },
          handle: {
            show: false,
            color: '#004E52'
          },
          axisLine: {
            show: false
          },
          splitLine: {
            show: true
          },
          axisLabel: {
            show: false,
            inside: true,
            formatter: '{value}\n'
          }
        },
        grid: {
          top: 40,
          left: 8,
          right: 15,
          height: 270
        },
        series: [
          {
            name: '预测销量',
            type: 'line',
            smooth: true,
            symbol: 'circle',
            showSymbol: false,
            symbolSize: 15,
            sampling: 'average',
            itemStyle: {
              normal: {
                color: '#64CFAB', //折点颜色
                borderColor: '#fff',
                borderWidth: 4,
                lineStyle: {
                  color: '#64CFAB', //折线颜色
                  width: '2',
                  type: 'dashed'
                }
              }
            },
            areaStyle: {
              color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                offset: 0,
                color: '#64CFAB'
              }, {
                offset: 1,
                color: '#ffe'
              }])
            },
            data: this.futureBrokenLineNumber
          }
        ]
      }
      this.historyBrokenLineExample.setOption(option1)
      this.futureBrokenLineExample.setOption(option2)
      this.historyBrokenLineExample.hideLoading()
      this.futureBrokenLineExample.hideLoading()
      // this.$emit('change-status', false)
    }
  }
}
</script>

<style lang="scss" scoped>
.e-chart {
  height: 100%;
  .p1 {
    font-size: 12px;
    color: #333333;
    margin: 20px 0px 15px 15px;
    i{
      margin-left: 5px;
      cursor: pointer;
    }
  }
  .p2 {
    cursor: pointer;
    text-align: right;
    font-size: 12px;
    color: #333333;
    margin: 20px 15px 15px 15px;
  }
  .line {
    width: 1px;
    border: 0.5px dashed #e6e6e6;
    height: 100%;
    margin: 0 5px;
  }
  .text-wrap {
    padding-top: 60px;
    .item {
      margin-bottom: 12px;
    }
    .title {
      font-size: 12px;
      color: #666666;
      i {
        margin-left: 5px;
        cursor: pointer;
      }
    }
  @media screen and (max-width: 1366px) {
      .title {
        font-size: 10px;
        color: #666666;
        i {
          margin-left: 3px;
          cursor: pointer;
        }
      }
    }
    .number {
      font-size: 20px;
      color: #333333;
      span {
        font-size: 12px;
        margin-left: 5px;
        color: #666666;
      }
    }
    .active-red {
      color: #e1251b;
    }
    .active-green {
      color: #26a872;
    }
    .scale {
      font-size: 14px;
      .iconfont {
        font-size: 14px;
      }
      .arrow-up {
        width: 9.2px;
        height: 9.8px;
        margin-left: 5px;
        display: inline-block;
        background: url(../../../assets/img/green.png)no-repeat;
        background-size:100% 100%;
      }
      .arrow-down {
        width: 9.2px;
        height: 9.8px;
        margin-left: 5px;
        display: inline-block;
        background: url(../../../assets/img/red.png) no-repeat;
        background-size:100% 100%;
      }
      .arrow-liedown {
        width: 10.8px;
        height: 9.2px;
        margin-left: 5px;
        display: inline-block;
        background: url(../../../assets/img/black.png) no-repeat;
        background-size:100% 140%;
      }
    }
  }
}
</style>
