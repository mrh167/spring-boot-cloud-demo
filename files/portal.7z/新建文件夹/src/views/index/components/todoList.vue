<template>
  <div class="home-right">
    <!-- TOP -->
    <div v-if="getVscSellerType === 1 || getVscSellerType === 2" class="event">
      <div>
        <div class="event-name">
          <div class="line"></div> 待跟进事项
        </div>
        <div class="event-box">
          <lui-tooltip
            effect="dark"
            :visible-arrow="false"
            :content="salesForecast"
            placement="bottom">
            <div class="content-wrap" @click="openUrl('/simple/forecastResults')">
              <p class="title">预测任务</p>
              <div class="content">
                <div class="wrap">
                  <p class="p1">{{ taskItem.predictionTaskProcessing ? taskItem.predictionTaskProcessing : '- - - -' }}</p>
                  <div class="p-txt">进行中</div>
                </div>
                <div class="wrap">
                  <p class="p2">{{ taskItem.predictionTaskComplete ? taskItem.predictionTaskComplete : '- - - -' }}</p>
                  <div class="p-txt">已完成</div>
                </div>
              </div>
            </div>
          </lui-tooltip>
          <div class="line"></div>
          <lui-tooltip
            effect="dark"
            :visible-arrow="false"
            :content="commodityLayout"
            placement="bottom">
            <div class="content-wrap" @click="openUrl('/analysisPlatform')">
              <p class="title">布局任务</p>
              <div class="content">
                <div class="wrap">
                  <p class="p1">{{ taskItem.layoutTaskProcessing ? taskItem.layoutTaskProcessing : '- - - -' }}</p>
                  <div class="p-txt">进行中</div>
                </div>
                <div class="wrap">
                  <p class="p2">{{ taskItem.layoutTaskComplete ? taskItem.layoutTaskComplete : '- - - -' }}</p>
                  <div class="p-txt">已完成</div>
                </div>
              </div>
            </div>
          </lui-tooltip>
          <div class="line"></div>
          <lui-tooltip
            class="item"
            effect="dark"
            :visible-arrow="false"
            content="库存仿真系统开发中"
            placement="bottom">
            <div class="content-wrap">
              <p class="title">仿真任务</p>
              <div class="content">
                <div class="wrap">
                  <p class="p1"><span>- - - -</span></p>
                  <div class="p-txt">进行中</div>
                </div>
                <div class="wrap">
                  <p class="p2"><span style="color:#C2C2C2;font-size: 14px">- - - -</span></p>
                  <div class="p-txt">已完成</div>
                </div>
              </div>
            </div>
          </lui-tooltip>
        </div>
      </div>

      <div class="agency">
        <p class="title top">补调待办</p>
        <p class="p1">待补货</p>
        <lui-tooltip
          effect="dark"
          :visible-arrow="false"
          :content="replenishment"
          placement="bottom">
          <div class="content bottom" @click="openUrl('/allot')">
            <div class="wrap">
              <p class="p2">
                <span v-if="pendingProcessingItem.replenishUnitSingle">{{ pendingProcessingItem.replenishUnitSingle }}</span>
                <span v-else style="color:#C2C2C2;font-size: 14px">- - - -</span>
              </p>
              <p class="p3">个</p>
            </div>
            <div class="wrap">
              <p class="p2">
                <span v-if="pendingProcessingItem.replenishUnitPiece">{{ pendingProcessingItem.replenishUnitPiece }}</span>
                <span v-else style="color:#C2C2C2;font-size: 14px">- - - -</span>
              </p>
              <p class="p3">件</p>
            </div>
            <div class="wrap">
              <p class="p2">
                <span v-if="pendingProcessingItem.replenishUnitWan">{{ pendingProcessingItem.replenishUnitWan }}</span>
                <span v-else style="color:#C2C2C2;font-size: 14px">- - - -</span>
              </p>
              <p class="p3">万元</p>
            </div>
          </div>
        </lui-tooltip>
        <p class="p1">待采购</p>
        <lui-tooltip
          effect="dark"
          :visible-arrow="false"
          :content="allot"
          placement="bottom">
          <div class="content bottom" @click="openUrl('/replenishment')">
            <div class="wrap">
              <p class="p2">
                <span v-if="pendingProcessingItem.allotUnitSingle">{{ pendingProcessingItem.allotUnitSingle }}</span>
                <span v-else style="color:#C2C2C2;font-size: 14px">- - - -</span>
              </p>
              <p class="p3">个</p>
            </div>
            <div class="wrap">
              <p class="p2">
                <span v-if="pendingProcessingItem.allotUnitPiece">{{ pendingProcessingItem.allotUnitPiece }}</span>
                <span v-else style="color:#C2C2C2;font-size: 14px">- - - -</span>
              </p>
              <p class="p3">件</p>
            </div>
            <div class="wrap">
              <p class="p2">
                <span v-if="pendingProcessingItem.allotUnitWan">{{ pendingProcessingItem.allotUnitWan }}</span>
                <span v-else style="color:#C2C2C2;font-size: 14px">- - - -</span>
              </p>
              <p class="p3">万元</p>
            </div>
          </div>
        </lui-tooltip>
        <p class="title top">补调待审批</p>
        <lui-tooltip
          effect="dark"
          :visible-arrow="false"
          content="审批工作台开发中"
          placement="bottom">
          <div class="content">
            <div class="wrap">
              <p class="p2"><span style="color:#C2C2C2;font-size: 14px">- - - -</span></p>
              <p class="p3">个</p>
            </div>
            <div class="wrap">
              <p class="p2"><span style="color:#C2C2C2;font-size: 14px">- - - -</span></p>
              <p class="p3">件</p>
            </div>
            <div class="wrap">
              <p class="p2"><span style="color:#C2C2C2;font-size: 14px">- - - -</span></p>
              <p class="p3">万元</p>
            </div>
          </div>
        </lui-tooltip>
      </div>
      <div>
      </div>
    </div>

    <div v-else class="event">
      <div class="event_conter">
        <div class="conter_top">待补货</div>
        <div class="conter_catinner" @click="openUrl('/pbs/wbprediction')">
          <div class="catinner_text">
            <span v-if="pendingProcessingItem.replenishUnitSingle!==null">{{ pendingProcessingItem.replenishUnitSingle }}</span>
            <span v-else style="color:#002065;font-size: 14px">- - - -</span>
            <span>补货商品SKU数</span>
          </div>
          <div class="catinner_text">
            <span v-if="pendingProcessingItem.replenishUnitPiece!==null">{{ pendingProcessingItem.replenishUnitPiece }}</span>
            <span v-else style="color:#002065;font-size: 14px">- - - -</span>
            <span>补货商品件数</span>
          </div>
        </div>
      </div>



      <!--  <div>
        <div class="event-name">
          <div class="line"></div> 待跟进事项
        </div>
      </div>

      <div class="agency">
        <p class="title top">补调待办</p>
        <p class="p1">待补货</p>
        <lui-tooltip
          effect="dark"
          :visible-arrow="false"
          :content="replenishment"
          placement="bottom">
          <div class="content bottom" @click="openUrl('/allot')">
            <div class="wrap">
              <p class="p2">
                <span v-if="pendingProcessingItem.replenishUnitSingle">{{ pendingProcessingItem.replenishUnitSingle }}</span>
                <span v-else style="color:#C2C2C2;font-size: 14px">- - - -</span>
              </p>
              <p class="p3">个</p>
            </div>
            <div class="wrap">
              <p class="p2">
                <span v-if="pendingProcessingItem.replenishUnitPiece">{{ pendingProcessingItem.replenishUnitPiece }}</span>
                <span v-else style="color:#C2C2C2;font-size: 14px">- - - -</span>
              </p>
              <p class="p3">件</p>
            </div>
            <div class="wrap">
              <p class="p2">
                <span v-if="pendingProcessingItem.replenishUnitWan">{{ pendingProcessingItem.replenishUnitWan }}</span>
                <span v-else style="color:#C2C2C2;font-size: 14px">- - - -</span>
              </p>
              <p class="p3">万元</p>
            </div>
          </div>
        </lui-tooltip>
        <p class="p1">待采购</p>
        <lui-tooltip
          effect="dark"
          :visible-arrow="false"
          :content="allot"
          placement="bottom">
          <div class="content bottom" @click="openUrl('/replenishment')">
            <div class="wrap">
              <p class="p2">
                <span v-if="pendingProcessingItem.allotUnitSingle">{{ pendingProcessingItem.allotUnitSingle }}</span>
                <span v-else style="color:#C2C2C2;font-size: 14px">- - - -</span>
              </p>
              <p class="p3">个</p>
            </div>
            <div class="wrap">
              <p class="p2">
                <span v-if="pendingProcessingItem.allotUnitPiece">{{ pendingProcessingItem.allotUnitPiece }}</span>
                <span v-else style="color:#C2C2C2;font-size: 14px">- - - -</span>
              </p>
              <p class="p3">件</p>
            </div>
            <div class="wrap">
              <p class="p2">
                <span v-if="pendingProcessingItem.allotUnitWan">{{ pendingProcessingItem.allotUnitWan }}</span>
                <span v-else style="color:#C2C2C2;font-size: 14px">- - - -</span>
              </p>
              <p class="p3">万元</p>
            </div>
          </div>
        </lui-tooltip>
      </div>
      -->
      <div>
      </div>
    </div>

    <!-- 通知 -->

    <div class="news">
      <div class="title">
        <div class="notice">
          <div class="line"></div> 通知
        </div>
        <div
          class="more"
          @click="$router.push('/notice')">更多</div>
      </div>
      <div v-loading="loadingPage" class="content-wrap" style="min-height: 250px;">
        <div
          v-for="(item,index) in news"
          :key="index"
          class="content">
          <div @click="getClik(item)">
            <lui-tooltip
              popper-class="todolist-tooltip"
              effect="dark"
              :visible-arrow="false"
              :content="item.title"
              placement="bottom">
              <span class="s1">
                <i v-if="item.topFlag == 1" class="top"></i>
                <i v-else></i>
                {{ item.title }}
              </span>
            </lui-tooltip>
          </div>
          <div><span class="s2">{{ item.releaseTimeStr }}</span></div>
        </div>
      </div>
    </div>



    <!-- <div class="news">
      <div class="title">
        <div class="notice">
          <div class="line"></div> 通知
          <div class="more" @click="$router.push('/notice')">更多</div>
        </div>
        <div v-loading="loadingPage" class="content-wrap" style="min-height: 250px;">
          <div
            v-for="(item,index) in news"
            :key="index"
            class="content">
            <div @click="getClik(item)">
              <lui-tooltip
                popper-class="todolist-tooltip"
                effect="dark"
                :visible-arrow="false"
                :content="item.title"
                placement="bottom">
                <span class="s1">
                  <i v-if="item.topFlag == 1" class="top"></i>
                  <i v-else></i>
                  {{ item.title }}
                </span>
              </lui-tooltip>
            </div>
            <div><span class="s2">{{ item.releaseTimeStr }}</span></div>
          </div>
        </div>
      </div>
    </div> -->
    <!--    详情-->
    <!--
    <el-dialog :title="baseTitle" :visible.sync="visible" :before-close="cancelHandle" :close-on-click-modal="false" width="760px" :lock-scroll="false" :append-to-body="true">
    </el-dialog> -->



    <lui-dialog
      :visible.sync="centerDialogVisible"
      width="50%"
      top="10vh"
      :close-on-click-modal="false"
      :lock-scroll="false"
      :append-to-body="true"
      custom-class="dialog_mask"
      title="公告详情">
      <lui-form
        ref="ruleForm"
        label-width="150px"
        class="demo-ruleForm">
        <lui-row
          :gutter="20"
          class="scrollBar"
          style="width: 95%;height: 500px;overflow-y: auto;margin-left: 5%;padding-right: 5%;">
          <div
            class="dialog-title"
            style="font-size: 20px;color: #333;"><lui-link type="primary" style="font-size: 20px;" @click="openLink(ruleForm.noticeUrl)">{{ ruleForm.title }}</lui-link></div>
          <div
            class="dialog-time"
            style="font-size: 13px;color: #999;margin-top: 10px;">{{ ruleForm.time }}</div>
          <div
            v-dompurify-html="ruleForm.content"
            class="dialog-content"
            style="margin-top: 10px;">
          </div>
        </lui-row>
      </lui-form>
    </lui-dialog>
  </div>
</template>

<script>
import Api from '@/api'
import utils from '@/utils/utils'
import { mapGetters } from 'vuex'
export default {
  name: 'todoList',
  props: [],
  data() {
    return {
      loadingPage: false,
      news: [],
      ruleForm: {},
      centerDialogVisible: false,
      taskItem: {},
      pendingProcessingItem: {},
      pendingApprovalItem: {},
      salesForecast: '', //预测任务
      commodityLayout: '', //商品布局
      replenishment: '', //补货
      allot: '', //调拨
      jurisdiction: JSON.parse(sessionStorage.getItem('jurisdiction'))
    }
  },

  computed: {
    ...mapGetters(['getVscSellerType'])
  },
  mounted() {
    this.init()
    this.getList()
    this.getTaskItem()
    this.getPendingProcessingItem()
    this.getPendingApprovalItem()
  },
  methods: {

    // //获取账号信息
    // getType() {
    //   Api.Home.getVscSellerType().then(res => {
    //     if (res.success) {
    //       // res.data = 3
    //       this.getVscSellerType = res.data
    //       this.$store.dispatch('VscSellerType', res.data)
    //       sessionStorage.setItem('VscSellerType', JSON.stringify(res.data))
    //     }
    //   }).catch((e) => {})
    // },




    open() {
      this.$alert('<div class="lui-message-box__status lui-icon-warning"></div><strong>您尚未开通【布局任务】产品服务，为了更好的提升供应链管理，建议您开通【布局任务】</strong><div></div><div><a href="https://www.jd.com" target="_blank"> 前往开通</a></div>', '', {
        dangerouslyUseHTMLString: true, showConfirmButton: false, customClass: 'custom-alert' })
    },
    openLink(link) {
      if (link) {
        window.open(link, '_blank')
      }
    },
    init() {
      // if(this.jurisdiction.salesForecast === false){
      //   this.salesForecast = '点击开通销量预测'
      // }else{
      this.salesForecast = '点击进入销量预测系统'
      // }
      //  if(this.jurisdiction.replenishmentAdjust === false){
      //   this.replenishment = '点击开通智能补调'
      // }else{
      this.replenishment = '点击进入智能补货工作台'
      // }
      // if(this.jurisdiction.replenishmentAdjust === false){
      //   this.allot = '点击开通智能补调'
      // }else{
      this.allot = '点击进入智能采购工作台'
      // }
      if (this.jurisdiction.commodityLayout === false) {
        this.commodityLayout = '点击开通商品布局'
      } else {
        this.commodityLayout = '点击进入商品布局系统'
      }
    },
    openUrl(url) {
      if (url === '/predict') { //预测任务
        this.$router.push(url)
        return
      }
      if (url === '/replenishment') { //补货
        this.$router.push(url)
        return
      }
      if (url === '/allot') { //调拨
        this.$router.push(url)
        return
      }
      if (url === '/pbs/wbprediction') { //诸葛预测
        this.$router.push(url)
        return
      }
      if (url === '/analysisPlatform' && this.jurisdiction.commodityLayout === false) { //布局任务
        return
      }

      this.$router.push(url)
    },
    //数据查看
    getClik(row) {
      this.loadingPage = true
      this.ruleForm = {
        title: '',
        time: '',
        content: '',
        noticeUrl: ''
      }
      Api.Home.getFindById({ id: row.id }).then(rows => {
        const cont = utils.htmlDecode(rows.data.content)
        this.ruleForm.title = utils.htmlDecode(rows.data.title)
        this.ruleForm.time = rows.data.updateTime
        this.ruleForm.content = cont
        this.ruleForm.noticeUrl = rows.data.noticeUrl
        this.centerDialogVisible = true
        this.loadingPage = false
      }).catch((e) => {
        console.error(e)
        this.loadingPage = false
      })
    },
    //公告列表
    getList() {
      Api.Home.postPageList({
        pageNum: 1,
        pageSize: 5,
        position: 2

      }).then(res => {
        if (res.success) {
          this.news = res.data
          this.news.forEach(item => {
            item.title = utils.htmlDecode(item.title)
          })
        }
      }).catch(e => {
        console.error(e)
      })
    },
    //待跟进事项-预测任务进行
    getTaskItem() {
      Api.Home.getTaskItem('').then(res => {
        this.taskItem = res.data
      }).catch(e => {
        console.error(e)
      })
    },
    //待跟进事项-补调待办
    getPendingProcessingItem() {
      Api.Home.getPendingProcessingItem('').then(res => {
        this.pendingProcessingItem = res.data
      }).catch(e => {
        console.error(e)
      })
    },
    //待跟进事项-补调待审批
    getPendingApprovalItem() {
      Api.Home.getPendingApprovalItem('').then(res => {
        this.pendingApprovalItem = res.data
      }).catch(e => {
        console.error(e)
      })
    }
  }
}
</script>
<style lang="scss">
.todolist-tooltip {
  font-size: 12px;
  max-width: 300px !important;
}
.custom-alert {
  .lui-message-box__header {
    border-bottom: none;
  }
  .lui-message-box__content {
    display: flex;
    justify-content: left;
    align-items: left;
  }
  .lui-message-box__btns {
    border-top: none;
  }
}
</style>
<style lang="scss" scoped>
@import "@/assets/stylus/main.scss";
.home-right {
  width: 29%;
  min-width: 353px;
  margin-left: 12px;
  display: flex;
  flex-direction: column;
  .event {
    border-radius: 4px;
    padding-bottom: 12px;
    background: #fff;
    box-shadow: 0 5px 14px 0 rgba(0, 0, 0, 0.12);
    .event_conter{
      .conter_top{
        margin: 0 12px;
        height: 36px;
        border-bottom: 1px solid #C8D4E0;
        font-size: 16px;
        color: #333;
        font-weight: 600;
        line-height: 36px;
        text-align: center;
      }
      .conter_catinner{
        padding: 0 20px;
        .catinner_text{
          height: 60px;
          // border-bottom: 1px solid #E1EBF5;
          display: flex;
          // justify-content: center;
          align-items: center;

          span:nth-child(1){
             flex: 1;
            font-size: 32px;
            color: $--gl-blue;
            margin-right: 12px;
            cursor: pointer;
            text-align: right;
          }
          span:nth-child(2){
            flex: 1;
            font-size: 14px;
            color: $--gl-blue;
            cursor: pointer;
            text-align: left;
          }
        }
        .catinner_text:nth-child(2){
          border-bottom: none;
        }
      }
    }
  }
  .event-name {
    padding: 12px 0;
    margin: 0 12px;
    color: #333;
    font-size: 18px;
    font-weight: 600;
    border-bottom: 1px solid #e6e6e6;
    .line {
      width: 3px;
      height: 10px;
      display: inline-block;
      background-image: linear-gradient(270deg, $--gl-hoverBlue 0%, $--gl-blue 100%);
      box-shadow: 0 5px 14px 0 rgba(0, 0, 0, 0.12);
      border-radius: 1.5px;
    }
  }
  .event-box {
    display: flex;
    justify-content: space-between;
    .title {
      font-size: 14px;
      color: #333;
      padding: 15px 0 20px 0;
    }
    .line {
      width: 1px;
      height: 64px;
      margin: 25px 0;
      background: #e0e0e0;
    }
    .content-wrap {

      cursor: pointer;
      width: 33.3%;
      display: flex;
      flex-direction: column;
      padding-left: 12px;
      padding-bottom: 12px;
      &:hover {
        background: rgba(14, 101, 150, 0.1);
        box-shadow: 0 2px 6px 0 rgba(0, 0, 0, 0.29);
      }
    }
    .content {
      display: flex;
      .wrap {
        width: 50%;
      }
      .p1 {
        font-size: 18px;
        color: #333333;
        font-weight: 600;
      }
      p {
        font-size: 14px;
        color: #333333;
        line-height: 27px;
      }
      .p-txt {
        font-size: 12px;
        color: #666666;
      }
    }
  }
  .agency {
    .content {
      // padding: 0 12px;
      display: flex;
      justify-content: space-between;
      cursor: pointer;
      &:hover {
        background: rgba(14, 101, 150, 0.1);
        box-shadow: 0 2px 6px 0 rgba(0, 0, 0, 0.29);
      }
    }
    .title {
      padding: 15px 0;
      margin: 0 12px;
      font-size: 14px;
      color: #333;
    }
    .top {
      border-top: 1px solid #e0e0e0;
    }
    .bottom {
      margin-bottom: 12px;
    }
    .p1 {
      padding: 0 12px;
      color: #666666;
      font-size: 12px;
    }
    .wrap:nth-of-type(3){
      border-right: 0
    }
    .wrap {
      width: 33.3%;
      padding: 0 12px;
      display: flex;
      justify-content: space-between;
      border-right: 1px solid #e0e0e0;
      .p2 {
        display: inline-block;
        font-size: 18px;
        color: #333333;
      }
      .p3 {
        display: inline-block;
        font-size: 12px;
        color: #666666;
        line-height: 26px;
      }
      .p4{
        color: #666666;
        font-size: 12px;
      }
    }
  }

  .news {
    flex: 1;
    margin-top: 12px;
    padding: 0 12px;
    background: #fff;
    border-radius: 4px;
    box-shadow: 0 5px 14px 0 rgba(0, 0, 0, 0.12);
    .title {
      padding: 12px 0px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      border-bottom: 1px solid #C8D4E0;
      .notice {
        color: #333;
        font-size: 18px;
        font-weight: 600;
        .line {
          width: 3px;
          height: 10px;
          display: inline-block;
          background-image:  linear-gradient(270deg, $--gl-hoverBlue 0%, $--gl-blue 100%);
          box-shadow: 0 5px 14px 0 rgba(0, 0, 0, 0.12);
          border-radius: 1.5px;
        }
      }
      .more {
        color: #656A77;
        cursor: pointer;
        font-size: 12px;
      }
    }
    .content:nth-of-type(1){
      margin-top: 5px;
    }
    .content {
      display: flex;
      justify-content: space-between;
      padding: 8px 5px;
      cursor: pointer;
      &:hover .s1 {
        color: #333;
        font-weight: 600;
        i{
          width: 24px;
          height: 28px;
          margin-left: 5px;
          display: inline-block;
          vertical-align: middle;
          background: url(../../../assets/img/icon-notice-hover.png)no-repeat;
          background-size:100% 100%;
        }
      }
      &:hover .s2 {
        color: #333;
        font-weight: 600;
      }
      &:hover i {
        color: $--gl-blue;
      }
      i {
        font-size: 18px;
        color: #d0d1d6;
      }
      .s1 {
        display: inline-block;
        line-height: 28px;
        // margin: 0 5px;
        font-size: 14px;
        color: #666;
        overflow: hidden;
        text-overflow: ellipsis;
        width: 240px;
        white-space: nowrap;
        i{
          width: 24px;
          height: 28px;
          margin: 0 5px;
          display: inline-block;
          vertical-align: middle;
          background: url(../../../assets/img/xitonggonggao.png)no-repeat;
          background-size:100% 100%;
        }
        .top{
          width: 24px;
          height: 28px;
          margin: 0 5px;
          display: inline-block;
          vertical-align: middle;
          background: url(../../../assets/img/icon-top1.png)no-repeat;
          background-size:100% 100%;
        }
      }
      .s2 {
        display: inline-block;
        line-height: 28px;
        font-size: 14px;
        color: #999999;
      }
    }
  }
}
</style>
