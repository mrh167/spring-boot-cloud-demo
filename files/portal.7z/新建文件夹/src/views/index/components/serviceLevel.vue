<template>

  <div class="e-chart">
    <div v-if="userType === '2'" class="wrap">
      <div>
        <p class="p1">本地订单满足率</p>
        <p class="p2">本地订单满足率
          <lui-tooltip
            popper-class="custom-tooltip"
            effect="dark"
            :visible-arrow="false"
            content="昨日，7天内各区域产生的订单中由本区域完成履约的订单数/同时期内各区域的订单总数；全国维度的本地订单满足率为各区域指标的均值"
            placement="bottom">
            <i class="lui-icon-help"></i>
          </lui-tooltip>
        </p>
        <p class="p3" @click="goPage('/layoutDiagnosis')">{{ localEnoughRateView.localEnoughRate }}<span>%</span></p>
      </div>
      <div
        ref="localEnoughRateView"
        :style="{width: '100%', height: '320px'}"></div>
    </div>
    <div class="wrap" :class="{'active-wrap':userType === '1'}">
      <div>
        <p class="p1">妥投时长</p>
        <p class="p2">近7日平均妥投时长
          <lui-tooltip
            popper-class="custom-tooltip"
            effect="dark"
            :visible-arrow="false"
            content="近7日，出库订单中完成妥投订单，从出库到妥投的单均时长"
            placement="bottom">
            <i class="lui-icon-help"></i>
          </lui-tooltip>
        </p>
        <p class="p3" @click="goPage('/layoutDiagnosis')">{{ properlyTimeView.last7DayAverageProperlyTime }}<span>小时</span></p>
      </div>
      <div
        ref="properlyTimeView"
        :style="{width: '100%', height: '320px'}"></div>
    </div>
    <div class="wrap" :class="{'active-wrap':userType === '1'}">
      <div>
        <p class="p1">物流跟踪</p>
        <p class="p2">近7日妥投率
          <lui-tooltip
            popper-class="custom-tooltip"
            effect="dark"
            :visible-arrow="false"
            content="近7日，妥投单量/出库单量"
            placement="bottom">
            <i class="lui-icon-help"></i>
          </lui-tooltip>
        </p>
        <p class="p3" @click="goPage('/delivery')">{{ logisticsTrackView.last7DayProperlyRate }}<span>%</span></p>
      </div>
      <div
        ref="logisticsTrackView"
        :style="{width: '100%', height: '320px'}"></div>
    </div>
  </div>

</template>

<script>
import Api from '@/api'
import echarts from 'echarts'
import utils from '@/utils/utils'
export default {
  name: 'ServiceLevel',
  props: {
    userType: {
      type: String,
      default: ''
    }
  },
  data() {
    return {
      localEnoughRateView: {}, //本地满足率概况
      localEnoughRateBrokenLine: [],
      localEnoughRateBrokenLineNumber: [],
      properlyTimeView: {}, //妥投时长概况
      last7DayAverageProperlyTimeBrokenLine: [],
      last7DayAverageProperlyTimeBrokenLineNumber: [],
      logisticsTrackView: {}, //物流跟踪概况
      last7DayProperlyRateBrokenLine: [],
      last7DayProperlyRateBrokenLineNumber: [],
      localEnoughRateViewExample: null,
      properlyTimeViewExample: null,
      logisticsTrackViewExample: null

    }
  },
  watch: {
    userType(val) {
      this.userType = val
    }
  },
  mounted() {
    this.getProperlyTimeAndLogisticsTrack() //妥投时长 && 物流跟踪
    if (this.userType === '2') {
      this.getEnoughRateView() //本地订单满足率
    }
    this.$nextTick(() => {
      window.addEventListener('resize', () => { //重新resize绘制，保持页面缩放
        this.localEnoughRateViewExample && this.localEnoughRateViewExample.resize()
        this.properlyTimeViewExample && this.properlyTimeViewExample.resize()
        this.logisticsTrackViewExample && this.logisticsTrackViewExample.resize()
      })
    })
  },
  beforeDestroy() {
    echarts.dispose(this.properlyTimeViewExample)
    this.properlyTimeViewExample = null
    echarts.dispose(this.logisticsTrackViewExample)
    this.logisticsTrackViewExample = null
    if (this.userType === '2') {
      echarts.dispose(this.localEnoughRateViewExample)
      this.localEnoughRateViewExample = null
    }
  },
  methods: {
    goPage(path) {
      this.$router.push(path)
    },
    calMaxMin(arr) {
      arr.sort(function(a, b) {
        return a - b
      })
      var number = {
        max: '',
        min: ''
      }
      number.min = Math.floor(arr[0] * 0.1) 
      number.max = Math.ceil(arr[arr.length - 1] * 1.2)
      return number
    },
    //妥投时长 && 物流跟踪
    getProperlyTimeAndLogisticsTrack() {
      this.properlyTimeViewExample = echarts.init(this.$refs.properlyTimeView)
      this.logisticsTrackViewExample = echarts.init(this.$refs.logisticsTrackView)
      this.properlyTimeViewExample.showLoading({
        text: '数据加载中',
        color: '#2681B6',
        textColor: '#2681B6',
        maskColor: 'rgba(255, 255, 255, 0.9)'
      })
      this.logisticsTrackViewExample.showLoading({
        text: '数据加载中',
        color: '#2681B6',
        textColor: '#2681B6',
        maskColor: 'rgba(255, 255, 255, 0.9)'
      })
      Api.Home.getProperlyTimeAndLogisticsTrack('').then(res => {
        if (res.success) {
          const data = res.data
          this.properlyTimeView = data.properlyTimeView
          const last7DayAverageProperlyTimeBrokenLine = utils.formatEcharsArr(this.properlyTimeView.last7DayAverageProperlyTimeBrokenLine)
          this.last7DayAverageProperlyTimeBrokenLine = last7DayAverageProperlyTimeBrokenLine.segment
          this.last7DayAverageProperlyTimeBrokenLineNumber = last7DayAverageProperlyTimeBrokenLine.number
          this.logisticsTrackView = data.logisticsTrackView
          const last7DayProperlyRateBrokenLine = utils.formatEcharsArr(this.logisticsTrackView.last7DayProperlyRateBrokenLine)
          this.last7DayProperlyRateBrokenLine = last7DayProperlyRateBrokenLine.segment
          this.last7DayProperlyRateBrokenLineNumber = last7DayProperlyRateBrokenLine.number
          this.init()
        }
      }).catch(e => {
        console.error(e)
      })
    },
    //本地订单满足率
    getEnoughRateView() {
      this.localEnoughRateViewExample = echarts.init(this.$refs.localEnoughRateView)
      this.localEnoughRateViewExample.showLoading({
        text: '数据加载中',
        color: '#2681B6',
        textColor: '#2681B6',
        maskColor: 'rgba(255, 255, 255, 0.9)'
      })
      Api.Home.getEnoughRateView('').then(res => {
        if (res.success) {
          const data = res.data
          this.localEnoughRateView = data
          const localEnoughRateBrokenLine = utils.formatEcharsArr(this.localEnoughRateView.localEnoughRateBrokenLine)
          this.localEnoughRateBrokenLine = localEnoughRateBrokenLine.segment
          this.localEnoughRateBrokenLineNumber = localEnoughRateBrokenLine.number
          this.initLocalEnoughRateView()
        }
      }).catch(e => {
        console.error(e)
      })
    },
    initLocalEnoughRateView() {
      var min = utils.calMaxMin(this.localEnoughRateBrokenLineNumber).min
      var max = utils.calMaxMin(this.localEnoughRateBrokenLineNumber).max
      const option = {
        animation: false,
        tooltip: {
          trigger: 'axis',
          transitionDuration: 0,
          formatter(params) {
            return '<div style="font-size:14px;">' +
                params[0].name + '<br>' +
                "<div style='display:inline-block;line-height:20px'><div style='display:inline-block; width:10px;height:4px;background:#4C8FD3;margin-right:5px'></div></div>" +
                params[0].value + '  %' +
              '</div>'
          }
        },
        xAxis: {
          show: false,
          boundaryGap: false,
          data: this.localEnoughRateBrokenLine,
          type: 'category',
          axisPointer: {
            snap: true,
            lineStyle: {
              color: '#fff',
              opacity: 0.8,
              width: 5
            },
            label: {
              show: false,
              formatter(params) {
                return echarts.format.formatTime('yyyy/MM/dd', params.value)
              },
              backgroundColor: '#4C8FD3'
            },
            handle: {
              show: false,
              color: '#4C8FD3'
            }
          },
          axisTick: { //y轴刻度线
            show: false
          },
          splitLine: {//分割线
            show: true
          }
        },
        yAxis: {
          min: min,
          max: max,
          interval: (max - min) / 5,
          type: 'value',
          axisTick: {
            inside: true,
            show: false
          },
          handle: {
            show: false,
            color: '#4C8FD3'
          },
          axisLine: {
            show: false
          },
          splitLine: {
            show: true
          },
          axisLabel: {
            show: false,
            inside: true,
            formatter: '{value}\n'
          }
        },
        grid: {
          top: 40,
          left: 15,
          right: 15,
          height: 270
        },
        series: [
          {
            type: 'line',
            smooth: true,
            symbol: 'circle',
            symbolSize: 15,
            showSymbol: false,
            sampling: 'average',
            itemStyle: {
              normal: {
                color: '#4C8FD3', //折点颜色
                borderColor: '#fff',
                borderWidth: 4,
                lineStyle: {
                  color: '#4C8FD3', //折线颜色
                  width: '2'
                }
              }
            },
            areaStyle: {
              color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                offset: 0,
                color: '#4C8FD3'
              }, {
                offset: 1,
                color: '#ffe'
              }])
            },
            data: this.localEnoughRateBrokenLineNumber
          }
        ]
      }
      this.localEnoughRateViewExample.setOption(option) //本地满足率
      this.localEnoughRateViewExample.hideLoading()
    },
    init() {
      var min1 = utils.calMaxMin(this.last7DayAverageProperlyTimeBrokenLineNumber).min
      var max1 = utils.calMaxMin(this.last7DayAverageProperlyTimeBrokenLineNumber).max
      var min2 = utils.calMaxMin(this.last7DayProperlyRateBrokenLineNumber).min
      var max2 = utils.calMaxMin(this.last7DayProperlyRateBrokenLineNumber).max
      const option1 = {
        animation: false,
        tooltip: {
          trigger: 'axis',
          transitionDuration: 0, //防止tooltip的抖动
          formatter(params) {
            return '<div style="font-size:14px;">' +
              params[0].name + '<br>' +
              "<div style='display:inline-block;line-height:20px'><div style='display:inline-block; width:10px;height:4px;background:#568DFF;margin-right:5px'></div></div>" +
              params[0].value + '  小时' +
            '</div>'
          }
        },
        xAxis: {
          show: false,
          boundaryGap: false,
          data: this.last7DayAverageProperlyTimeBrokenLine,
          type: 'category',
          axisPointer: {
            snap: true,
            lineStyle: {
              color: '#fff',
              opacity: 0.8,
              width: 5
            },
            label: {
              show: false,
              backgroundColor: '#568DFF'
            },
            handle: {
              show: false,
              color: '#568DFF'
            }
          },
          axisTick: { //y轴刻度线
            show: false
          },
          splitLine: {//分割线
            show: true
          }
        },
        yAxis: {
          min: min1,
          max: max1,
          interval: (max1 - min1) / 5,
          type: 'value',
          axisTick: {
            inside: true,
            show: false
          },
          handle: {
            show: false,
            color: '#568DFF'
          },
          axisLine: {
            show: false
          },
          splitLine: {
            show: true
          },
          axisLabel: {
            show: false,
            inside: true,
            formatter: '{value}\n'
          }
        },
        grid: {
          top: 40,
          left: 15,
          right: 15,
          height: 270
        },
        series: [
          {
            type: 'line',
            smooth: true,
            symbol: 'circle',
            symbolSize: 15,
            showSymbol: false,
            sampling: 'average',
            itemStyle: {
              normal: {
                color: '#568DFF', //折点颜色
                borderColor: '#fff',
                borderWidth: 4,
                lineStyle: {
                  color: '#568DFF', //折线颜色
                  width: '2'
                }
              }
            },
            areaStyle: {
              color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                offset: 0,
                color: '#568DFF'
              }, {
                offset: 1,
                color: '#ffe'
              }])
            },
            data: this.last7DayAverageProperlyTimeBrokenLineNumber
          }
        ]
      }
      const option2 = {
        animation: false,
        tooltip: {
          trigger: 'axis',
          transitionDuration: 0,
          formatter(params) {
            return '<div style="font-size:14px;">' +
              params[0].name + '<br>' +
              "<div style='display:inline-block;line-height:20px'><div style='display:inline-block; width:10px;height:4px;background:#78C7E8;margin-right:5px'></div></div>" +
              params[0].value + '  %' +
            '</div>'
          }
        },
        xAxis: {
          show: false,
          boundaryGap: false,
          data: this.last7DayProperlyRateBrokenLine,
          type: 'category',
          axisPointer: {
            snap: true,
            lineStyle: {
              color: '#fff',
              opacity: 0.8,
              width: 5
            },
            label: {
              show: false,
              backgroundColor: '#78C7E8'
            },
            handle: {
              show: false,
              color: '#78C7E8'
            }
          },
          axisTick: { //y轴刻度线
            show: false
          },
          splitLine: {//分割线
            show: true
          }
        },
        yAxis: {
          min: min2,
          max: max2,
          interval: (max2 - min2) / 5,
          type: 'value',
          axisTick: {
            inside: true,
            show: false
          },
          handle: {
            show: false,
            color: '#78C7E8'
          },
          axisLine: {
            show: false
          },
          splitLine: {
            show: true
          },
          axisLabel: {
            show: false,
            inside: true,
            formatter: '{value}\n'
          }
        },
        grid: {
          top: 40,
          left: 15,
          right: 15,
          height: 270
        },
        series: [
          {
            type: 'line',
            smooth: true,
            symbol: 'circle',
            symbolSize: 15,
            showSymbol: false,
            sampling: 'average',
            itemStyle: {
              normal: {
                color: '#78C7E8', //折点颜色
                borderColor: '#fff',
                borderWidth: 4,
                lineStyle: {
                  color: '#78C7E8', //折线颜色
                  width: '2'
                }
              }
            },
            areaStyle: {
              color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                offset: 0,
                color: '#78C7E8'
              }, {
                offset: 1,
                color: '#ffe'
              }])
            },
            data: this.last7DayProperlyRateBrokenLineNumber
          }
        ]
      }
      this.properlyTimeViewExample.setOption(option1) //妥投时长
      this.logisticsTrackViewExample.setOption(option2)//物流跟踪
      this.properlyTimeViewExample.hideLoading()
      this.logisticsTrackViewExample.hideLoading()
    }
  }
}
</script>

<style lang="scss" scoped>
@import '@/assets/stylus/main';
.e-chart {
  height: 100%;
  .wrap:nth-of-type(1) {
    border-left: 0;
  }
  .wrap {
    width: 33.3%;
    height: 100%;
    float: left;
    border-left: 1px solid #e6e6e6;
    .p1 {
      font-size: 12px;
      color: #333333;
      margin: 20px 0px 10px 15px;
    }
    .p2 {
      font-size: 12px;
      color: #666666;
      margin-left: 15px;
      .lui-icon-help {
        margin-left: 5px;
        cursor: pointer;
      }
    }
    .p3 {
      margin-left: 15px;
      font-size: 20px;
      color: #333333;
        &:hover{
            color: $--gl-blue;
             cursor: pointer;
          }
      span {
        margin-left: 5px;
        font-size: 12px;
        color: #666666;
      }
    }
  }
  .active-wrap{
    width: 50%;
  }
}
</style>
