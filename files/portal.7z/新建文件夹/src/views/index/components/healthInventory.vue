<template>
  <div class="e-chart">
    <div class="wrap">
      <div>
        <p class="p1">库存周转</p>
        <p v-if="getVscSellerType === 1 || getVscSellerType === 2" class="p3">30天周转
          <lui-tooltip
            popper-class="custom-tooltip"
            effect="dark"
            :visible-arrow="false"
            content="历史30天在库件数/30天出库件数"
            placement="bottom">
            <i class="lui-icon-help"></i>
          </lui-tooltip>
        </p>

        <p v-else class="p3">件数周转
          <lui-tooltip
            popper-class="custom-tooltip"
            effect="dark"
            :visible-arrow="false"
            content="可用库存/日均销量。其中日均销量为30天预测日均销量，件数周转非计费口径，任何口径周转均不作财务结算依据，以物流计费为主"
            placement="bottom">
            <i class="lui-icon-help"></i>
          </lui-tooltip>
        </p>
        <p class="p2">{{ turnoverView.last30DaysTurnover }}<span>天</span></p>
      </div>
      <div
        ref="last30DaysTurnoverBrokenLine"
        :style="{width: '100%', height: '320px'}"></div>
    </div>
    <div class="details-box">
      <div
        class="details"
        style="margin-top: 48px;">
        <div class="title">
          <p>昨日入库件数
            <lui-tooltip
              popper-class="custom-tooltip"
              effect="dark"
              :visible-arrow="false"
              content="昨日，已入仓的商品件数求和"
              placement="bottom">
              <i class="lui-icon-help"></i>
            </lui-tooltip>
          </p>
          <p @click="goPage('/instorage')"><span>{{ inWarehouse }}</span> {{ toryStockCo.inWarehouse > 10000 ? '万件' : '件' }}</p>
        </div>
        <div
          ref="inWarehouseBrokenLine"
          :style="{flex:1, height: '88px'}"></div>
      </div>
      <div class="details">
        <div class="title">
          <p>昨日出库件数
            <lui-tooltip
              popper-class="custom-tooltip"
              effect="dark"
              :visible-arrow="false"
              content="昨日，销售出库商品总件数"
              placement="bottom">
              <i class="lui-icon-help"></i>
            </lui-tooltip>
          </p>
          <p @click="goPage('/outStock')"><span>{{ outWarehouse }}</span> {{ toryStockCo.outWarehouse > 10000 ? '万件' : '件' }}</p>
        </div>
        <div
          ref="outWarehouseBrokenLine"
          :style="{flex:1, height: '88px'}"></div>
      </div>
      <div class="details">
        <div class="title">
          <p>昨日在库件数
            <lui-tooltip
              popper-class="custom-tooltip"
              effect="dark"
              :visible-arrow="false"
              content="昨日，在库商品总件数"
              placement="bottom">
              <i class="lui-icon-help"></i>
            </lui-tooltip>
          </p>
          <p @click="goPage('/analysisInLibrary')"><span> {{ existWarehouse }}</span> {{ turnoverView.existWarehouse > 10000 ? '万件' : '件' }}</p>
        </div>
        <div
          ref="existWarehouseBrokenLine"
          :style="{flex:1, height: '88px'}"></div>
      </div>
    </div>
    <div class="details-wrap">
      <div v-if="getVscSellerType === 1 || getVscSellerType === 2" style="font-size:12px;color:#333;margin:20px 0 10px 0;">库存诊断</div>
      <div v-else style="font-size:12px;color:#333;margin:20px 0 10px 0;">库存预警</div>
      <div
        class="details"
        style="margin-top: 50px;">
        <div v-if="getVscSellerType === 1 || getVscSellerType === 2" class="title">
          <p>SKU断货率
            <lui-tooltip
              popper-class="custom-tooltip"
              effect="dark"
              :visible-arrow="false"
              content="昨日，断货SKU种类数/统计历史周期内总SKU种类数"
              placement="bottom">
              <i class="lui-icon-help"></i>
            </lui-tooltip>
          </p>
          <p @click="goPage('/stockDiagnosis')"><span>{{ diagnosisView.skuBreak }}</span>%</p>
        </div>

        <div v-else class="title">
          <p>畅销品现货率
            <lui-tooltip
              popper-class="custom-tooltip"
              effect="dark"
              :visible-arrow="false"
              content="有货畅销品商品数/总畅销品商品数。其中畅销品定义：您店铺每个一级品类的销量前60%的商品为畅销品"
              placement="bottom">
              <i class="lui-icon-help"></i>
            </lui-tooltip>
          </p>
          <p @click="goPage('/stockDiagnosis')"><span>{{ diagnosisView.skuBreak }}</span>%</p>
        </div>
        <div
          ref="skuBreakBrokenLine"
          :style="{flex:1, height: '88px'}"></div>
      </div>
      <div class="details">
        <div v-if="getVscSellerType === 1 || getVscSellerType === 2" class="title">
          <p>SKU滞慢销率
            <lui-tooltip
              popper-class="custom-tooltip"
              effect="dark"
              :visible-arrow="false"
              content="昨日，滞慢销SKU种类数/统计历史90天在库过的SKU种类数"
              placement="bottom">
              <i class="lui-icon-help"></i>
            </lui-tooltip>
          </p>
          <p @click="goPage('/stockDiagnosis')"><span>{{ diagnosisView.skuDrug }}</span>%</p>
        </div>

        <div v-else class="title">
          <p>滞销库存占比
            <lui-tooltip
              popper-class="custom-tooltip"
              effect="dark"
              :visible-arrow="false"
              content="滞销库存件数/总可用库存，注意只统计上柜。其中滞销商品=件数周转>滞销库存周转天数阈值的商品，滞销库存件数=滞销商品的可用库存-滞销库存周转天数阈值*预测销量"
              placement="bottom">
              <i class="lui-icon-help"></i>
            </lui-tooltip>
          </p>
          <p @click="goPage('/stockDiagnosis')"><span>{{ diagnosisView.skuDrug }}</span>%</p>
        </div>
        <div
          ref="skuDrugBrokenLine"
          :style="{flex:1, height: '88px'}"></div>
      </div>
      <div class="details">
        <div v-if="getVscSellerType === 1 || getVscSellerType === 2" class="title">
          <p>SKU不动销率
            <lui-tooltip
              popper-class="custom-tooltip"
              effect="dark"
              :visible-arrow="false"
              content="昨日，不动销SKU种类数/统计历史90天在库过的SKU种类数"
              placement="bottom">
              <i class="lui-icon-help"></i>
            </lui-tooltip>
          </p>
          <p @click="goPage('/stockDiagnosis')"><span>{{ diagnosisView.skuStopSelling }}</span>%</p>
        </div>
        <div v-else class="title">
          <p>不动销库存占比
            <lui-tooltip
              popper-class="custom-tooltip"
              effect="dark"
              :visible-arrow="false"
              content="不动销商品可用库存/总商品可用库存。其中不动销商品=近30日无销售的商品"
              placement="bottom">
              <i class="lui-icon-help"></i>
            </lui-tooltip>
          </p>
          <p @click="goPage('/stockDiagnosis')"><span>{{ diagnosisView.skuStopSelling }}</span>%</p>
        </div>
        <div
          ref="skuStopSellingBrokenLine"
          :style="{flex:1, height: '88px'}"></div>
      </div>
    </div>
  </div>
</template>

<script>
import Api from '@/api'
import echarts from 'echarts'
import utils from '@/utils/utils'
import { mapGetters } from 'vuex'
export default {
  name: 'HealthInventory',
  computed: {
    ...mapGetters(['getVscSellerType'])
  },
  data() {
    return {
      turnoverView: {}, //库存周转
      diagnosisView: {}, //库存诊断
      toryStockCo: {},
      inWarehouse: '',
      outWarehouse: '',
      existWarehouse: '',
      last30DaysTurnoverBrokenLine: [], //30天周转
      last30DaysTurnoverBrokenLineNumber: [],
      inWarehouseBrokenLine: [], //昨日入库件数
      inWarehouseBrokenLineNumber: [],
      outWarehouseBrokenLine: [], //昨日出库件数
      outWarehouseBrokenLineNumber: [],
      existWarehouseBrokenLine: [], //昨日在库件数
      existWarehouseBrokenLineNumber: [],
      skuBreakBrokenLine: [], //SKU断货率
      skuBreakBrokenLineNumber: [],
      skuDrugBrokenLine: [], //SKU滞慢销率
      skuDrugBrokenLineNumber: [],
      skuStopSellingBrokenLine: [], //SKU不动销率
      skuStopSellingBrokenLineNumber: [],
      last30DaysTurnoverBrokenLineExample: null,
      inWarehouseBrokenLineExample: null,
      outWarehouseBrokenLineExample: null,
      existWarehouseBrokenLineExample: null,
      skuBreakBrokenLineExample: null,
      skuDrugBrokenLineExample: null,
      skuStopSellingBrokenLineExample: null
    }
  },
  mounted() {
    console.log(this.getVscSellerType, '=========')
    this.getDiagnosis()
    this.getInventoryStockCo()
    this.getTurnover()
    this.$nextTick(() => {
      window.addEventListener('resize', () => {
      //重新resize绘制，保持页面缩放
        this.last30DaysTurnoverBrokenLineExample && this.last30DaysTurnoverBrokenLineExample.resize()
        this.inWarehouseBrokenLineExample && this.inWarehouseBrokenLineExample.resize()
        this.outWarehouseBrokenLineExample && this.outWarehouseBrokenLineExample.resize()
        this.existWarehouseBrokenLineExample && this.existWarehouseBrokenLineExample.resize()
        this.skuBreakBrokenLineExample && this.skuBreakBrokenLineExample.resize()
        this.skuDrugBrokenLineExample && this.skuDrugBrokenLineExample.resize()
        this.skuStopSellingBrokenLineExample && this.skuStopSellingBrokenLineExample.resize()
      })
    })
  },
  beforeDestroy() {
    // 组件销毁前，释放实例
    echarts.dispose(this.last30DaysTurnoverBrokenLineExample)
    this.last30DaysTurnoverBrokenLineExample = null
    echarts.dispose(this.inWarehouseBrokenLineExample)
    this.inWarehouseBrokenLineExample = null
    echarts.dispose(this.outWarehouseBrokenLineExample)
    this.outWarehouseBrokenLineExample = null
    echarts.dispose(this.existWarehouseBrokenLineExample)
    this.existWarehouseBrokenLineExample = null
    echarts.dispose(this.skuBreakBrokenLineExample)
    this.skuBreakBrokenLineExample = null
    echarts.dispose(this.skuDrugBrokenLineExample)
    this.skuDrugBrokenLineExample = null
    echarts.dispose(this.skuStopSellingBrokenLineExample)
    this.skuStopSellingBrokenLineExample = null
  },
  methods: {
    goPage(path) {
      this.$router.push(path)
    },
    //库存诊断
    getDiagnosis() {
      this.skuBreakBrokenLineExample = echarts.init(this.$refs.skuBreakBrokenLine)
      this.skuDrugBrokenLineExample = echarts.init(this.$refs.skuDrugBrokenLine)
      this.skuStopSellingBrokenLineExample = echarts.init(this.$refs.skuStopSellingBrokenLine)
      this.skuBreakBrokenLineExample.showLoading({
        text: '数据加载中',
        color: '#2681B6',
        textColor: '#2681B6',
        maskColor: 'rgba(255, 255, 255, 0.9)'
      })
      this.skuDrugBrokenLineExample.showLoading({
        text: '数据加载中',
        color: '#2681B6',
        textColor: '#2681B6',
        maskColor: 'rgba(255, 255, 255, 0.9)'
      })
      this.skuStopSellingBrokenLineExample.showLoading({
        text: '数据加载中',
        color: '#2681B6',
        textColor: '#2681B6',
        maskColor: 'rgba(255, 255, 255, 0.9)'
      })
      Api.Home.getDiagnosis('').then((res) => {
        this.diagnosisView = res.data
        const skuBreakBrokenLine = utils.formatEcharsArr(this.diagnosisView.skuBreakBrokenLine)
        this.skuBreakBrokenLine = skuBreakBrokenLine.segment //SKU断货率日期
        this.skuBreakBrokenLineNumber = skuBreakBrokenLine.number //SKU断货率数据
        const skuDrugBrokenLine = utils.formatEcharsArr(this.diagnosisView.skuDrugBrokenLine)
        this.skuDrugBrokenLine = skuDrugBrokenLine.segment //SKU滞慢销率
        this.skuDrugBrokenLineNumber = skuDrugBrokenLine.number //SKU滞慢销率数据
        const skuStopSellingBrokenLine = utils.formatEcharsArr(this.diagnosisView.skuStopSellingBrokenLine)
        this.skuStopSellingBrokenLine = skuStopSellingBrokenLine.segment //SKU不动销率
        this.skuStopSellingBrokenLineNumber = skuStopSellingBrokenLine.number //SKU不动销率数据
        this.initSkuDiagnosis()
      }).catch((e) => {
        console.error(e)
      })
    },
    calMaxMin(arr) {
      var newArr = JSON.parse(JSON.stringify(arr))
      newArr.sort(function(a, b) {
        return a - b
      })
      var number = {
        max: '',
        min: ''
      }
      number.min = Math.floor(newArr[0] * 0.8)
      number.max = Math.ceil(newArr[newArr.length - 1] * 1.2)
      return number
    },
    //库存健康-出库、入库
    getInventoryStockCo() {
      this.inWarehouseBrokenLineExample = echarts.init(this.$refs.inWarehouseBrokenLine)
      this.outWarehouseBrokenLineExample = echarts.init(this.$refs.outWarehouseBrokenLine)
      this.inWarehouseBrokenLineExample.showLoading({
        text: '数据加载中',
        color: '#2681B6',
        textColor: '#2681B6',
        maskColor: 'rgba(255, 255, 255, 0.9)'
      })
      this.outWarehouseBrokenLineExample.showLoading({
        text: '数据加载中',
        color: '#2681B6',
        textColor: '#2681B6',
        maskColor: 'rgba(255, 255, 255, 0.9)'
      })
      Api.Home.getInventoryStockCo('').then((res) => {
        this.toryStockCo = res.data
        if (this.toryStockCo.inWarehouse > 10000) {
          this.inWarehouse = utils.tenThousand1(this.toryStockCo.inWarehouse)
        } else {
          this.inWarehouse = this.toryStockCo.inWarehouse
        }
        if (this.toryStockCo.outWarehouse > 10000) {
          this.outWarehouse = utils.tenThousand1(this.toryStockCo.outWarehouse)
        } else {
          this.outWarehouse = this.toryStockCo.outWarehouse
        }
        const inWarehouseBrokenLine = utils.formatEcharsArr(this.toryStockCo.inWarehouseBrokenLine)
        this.inWarehouseBrokenLine = inWarehouseBrokenLine.segment //今日入库
        this.inWarehouseBrokenLineNumber = inWarehouseBrokenLine.number
        const outWarehouseBrokenLine = utils.formatEcharsArr(this.toryStockCo.outWarehouseBrokenLine)
        this.outWarehouseBrokenLine = outWarehouseBrokenLine.segment //今日出库
        this.outWarehouseBrokenLineNumber = outWarehouseBrokenLine.number
        this.initInOutStock()
      }).catch((e) => {
        console.error(e)
      })
    },
    //库存健康-库存周转
    getTurnover() {
      this.last30DaysTurnoverBrokenLineExample = echarts.init(this.$refs.last30DaysTurnoverBrokenLine)
      this.existWarehouseBrokenLineExample = echarts.init(this.$refs.existWarehouseBrokenLine)
      this.last30DaysTurnoverBrokenLineExample.showLoading({
        text: '数据加载中',
        color: '#2681B6',
        textColor: '#2681B6',
        maskColor: 'rgba(255, 255, 255, 0.9)'
      })
      this.existWarehouseBrokenLineExample.showLoading({
        text: '数据加载中',
        color: '#2681B6',
        textColor: '#2681B6',
        maskColor: 'rgba(255, 255, 255, 0.9)'
      })
      Api.Home.getTurnover('').then((res) => {
        this.turnoverView = res.data
        if (this.turnoverView.existWarehouse > 10000) {
          this.existWarehouse = utils.tenThousand1(this.turnoverView.existWarehouse)
        } else {
          this.existWarehouse = this.turnoverView.existWarehouse
        }
        const last30DaysTurnoverBrokenLine = utils.formatEcharsArr(this.turnoverView.last30DaysTurnoverBrokenLine)
        this.last30DaysTurnoverBrokenLine = last30DaysTurnoverBrokenLine.segment //30天周转
        this.last30DaysTurnoverBrokenLineNumber = last30DaysTurnoverBrokenLine.number
        const existWarehouseBrokenLine = utils.formatEcharsArr(this.turnoverView.existWarehouseBrokenLine)
        this.existWarehouseBrokenLine = existWarehouseBrokenLine.segment //昨日在库
        this.existWarehouseBrokenLineNumber = existWarehouseBrokenLine.number
        this.initInventoryTurnover()
      }).catch((e) => {
        console.error(e)
      })
    },
    //初始化出入库实例
    initInOutStock() {
      const option1 = {
        animation: false,
        tooltip: {
          trigger: 'axis',
          transitionDuration: 0,
          formatter(params) {
            return '<div style="font-size:14px;">' +
              params[0].name + '<br>' +
              "<div style='display:inline-block;line-height:20px'><div style='display:inline-block; width:10px;height:4px;background:#568DFF;margin-right:5px'></div></div>" +
              utils.tenThousand(params[0].value) +
            '</div>'
          },
          axisPointer: {
            type: 'none'
          }
        },
        xAxis: {
          show: false,
          data: this.inWarehouseBrokenLine,
          type: 'category',
          boundaryGap: false,
          axisPointer: {
            snap: true,
            lineStyle: {
              color: '#568DFF',
              opacity: 0.5,
              width: 2
            },
            label: {
              show: false,
              backgroundColor: '#568DFF'
            },
            handle: {
              show: false,
              color: '#568DFF'
            }
          },
          axisTick: { //y轴刻度线
            show: false
          },
          splitLine: {//分割线
            show: false
          }
        },
        yAxis: {
          min: this.calMaxMin(this.inWarehouseBrokenLineNumber).min,
          max: this.calMaxMin(this.inWarehouseBrokenLineNumber).max,
          type: 'value',
          axisTick: {
            inside: false,
            show: false
          },
          handle: {
            show: false,
            color: '#568DFF'
          },
          axisLine: {
            show: false
          },
          splitLine: {
            show: false
          },
          axisLabel: {
            show: false,
            inside: false,
            formatter: '{value}\n'
          }
        },
        grid: {
          top: 0,
          left: 0,
          right: 10,
          height: 83
        },
        series: [
          {
            name: '',
            type: 'line',
            smooth: true,
            symbol: 'none',
            showSymbol: false,
            symbolSize: 5,
            sampling: 'average',
            itemStyle: {
              color: '#568DFF'
            },
            data: this.inWarehouseBrokenLineNumber
          }

        ]
      }
      const option2 = {
        animation: false,
        tooltip: {
          trigger: 'axis',
          transitionDuration: 0,
          formatter(params) {
            return '<div style="font-size:14px;">' +
              params[0].name + '<br>' +
              "<div style='display:inline-block;line-height:20px'><div style='display:inline-block; width:10px;height:4px;background:#568DFF;margin-right:5px'></div></div>" +
              utils.tenThousand(params[0].value) +
            '</div>'
          },
          axisPointer: {
            type: 'none'
          }
        },
        xAxis: {
          show: false,
          data: this.outWarehouseBrokenLine,
          type: 'category',
          boundaryGap: false,
          axisPointer: {
            snap: true,
            lineStyle: {
              color: '#568DFF',
              opacity: 0.5,
              width: 2
            },
            label: {
              show: false,
              backgroundColor: '#568DFF'
            },
            handle: {
              show: false,
              color: '#568DFF'
            }
          },
          axisTick: { //y轴刻度线
            show: false
          },
          splitLine: {//分割线
            show: false
          }
        },
        yAxis: {
          min: this.calMaxMin(this.outWarehouseBrokenLineNumber).min,
          max: this.calMaxMin(this.outWarehouseBrokenLineNumber).max,
          type: 'value',
          axisTick: {
            inside: false,
            show: false
          },
          handle: {
            show: false,
            color: '#568DFF'
          },
          axisLine: {
            show: false
          },
          splitLine: {
            show: false
          },
          axisLabel: {
            show: false,
            inside: false,
            formatter: '{value}\n'
          }
        },
        grid: {
          top: 0,
          left: 0,
          right: 10,
          height: 83
        },
        series: [
          {
            name: '',
            type: 'line',
            smooth: true,
            symbol: 'none',
            showSymbol: false,
            symbolSize: 5,
            sampling: 'average',
            itemStyle: {
              color: '#568DFF'
            },
            data: this.outWarehouseBrokenLineNumber
          }
        ]
      }
      this.inWarehouseBrokenLineExample.setOption(option1)
      this.outWarehouseBrokenLineExample.setOption(option2)
      this.inWarehouseBrokenLineExample.hideLoading()
      this.outWarehouseBrokenLineExample.hideLoading()
    },
    initInventoryTurnover() {
      var min = utils.calMaxMin(this.last30DaysTurnoverBrokenLineNumber).min
      var max = utils.calMaxMin(this.last30DaysTurnoverBrokenLineNumber).max
      const option = {
        animation: false,
        tooltip: {
          trigger: 'axis',
          transitionDuration: 0,
          formatter(params) {
            return '<div style="font-size:14px;">' +
              params[0].name + '<br>' +
              "<div style='display:inline-block;line-height:20px'><div style='display:inline-block; width:10px;height:4px;background:#4C8FD3;margin-right:5px'></div></div>" +
              params[0].value + '  天' +
            '</div>'
          }
        },
        xAxis: {
          data: this.last30DaysTurnoverBrokenLine,
          show: false,
          boundaryGap: false,
          type: 'category',
          axisPointer: {
            snap: true,
            lineStyle: {
              color: '#fff',
              opacity: 0.8,
              width: 5
            },
            label: {
              show: false,
              backgroundColor: '#4C8FD3'
            },
            handle: {
              show: false,
              color: '#4C8FD3'
            }
          },

          axisTick: { //y轴刻度线
            show: false
          },
          splitLine: {//分割线
            show: true
          }
        },
        yAxis: {
          min: min,
          max: max,
          interval: (max - min) / 5,
          type: 'value',
          axisTick: {
            inside: true,
            show: false
          },
          handle: {
            show: false,
            color: '#4C8FD3'
          },
          axisLine: {
            show: false
          },
          splitLine: {
            show: true
          },
          axisLabel: {
            show: false,
            inside: true,
            formatter: '{value}\n'
          }
        },
        grid: {
          top: 40,
          left: 15,
          right: 15,
          height: 270
        },
        series: [
          {
            type: 'line',
            smooth: true,
            symbol: 'circle',
            symbolSize: 15,
            showSymbol: false,
            sampling: 'average',
            itemStyle: {
              normal: {
                color: '#4C8FD3', //折点颜色
                borderColor: '#fff',
                borderWidth: 4,
                lineStyle: {
                  color: '#4C8FD3', //折线颜色
                  width: '2'
                }
              }
            },
            areaStyle: {
              color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                offset: 0,
                color: '#4C8FD3'
              }, {
                offset: 1,
                color: '#ffe'
              }])
            },
            data: this.last30DaysTurnoverBrokenLineNumber
          }
        ]
      }
      const option3 = {
        animation: false,
        tooltip: {
          trigger: 'axis',
          transitionDuration: 0,
          formatter(params) {
            return '<div style="font-size:14px;">' +
                params[0].name + '<br>' +
                "<div style='display:inline-block;line-height:20px'><div style='display:inline-block; width:10px;height:4px;background:#568DFF;margin-right:5px'></div></div>" +
                utils.tenThousand(params[0].value) +
              '</div>'
          },
          axisPointer: {
            type: 'none'
          }
        },
        xAxis: {
          show: false,
          data: this.existWarehouseBrokenLine,
          type: 'category',
          boundaryGap: false,
          axisPointer: {
            snap: true,
            lineStyle: {
              color: '#568DFF',
              opacity: 0.5,
              width: 2
            },
            label: {
              show: false,
              backgroundColor: '#568DFF'
            },
            handle: {
              show: false,
              color: '#568DFF'
            }
          },
          axisTick: { //y轴刻度线
            show: false
          },
          splitLine: {//分割线
            show: false
          }
        },
        yAxis: {
          min: this.calMaxMin(this.existWarehouseBrokenLineNumber).min,
          max: this.calMaxMin(this.existWarehouseBrokenLineNumber).max,
          type: 'value',
          axisTick: {
            inside: false,
            show: false
          },
          handle: {
            show: false,
            color: '#568DFF'
          },
          axisLine: {
            show: false
          },
          splitLine: {
            show: false
          },
          axisLabel: {
            show: false,
            inside: false,
            formatter: '{value}\n'
          }
        },
        grid: {
          top: 0,
          left: 0,
          right: 10,
          height: 83
        },
        series: [
          {
            name: '',
            type: 'line',
            smooth: true,
            symbol: 'none',
            showSymbol: false,
            symbolSize: 5,
            sampling: 'average',
            itemStyle: {
              color: '#568DFF'
            },
            data: this.existWarehouseBrokenLineNumber
          }
        ]
      }
      this.last30DaysTurnoverBrokenLineExample.setOption(option)
      this.existWarehouseBrokenLineExample.setOption(option3)
      this.last30DaysTurnoverBrokenLineExample.hideLoading()
      this.existWarehouseBrokenLineExample.hideLoading()
    },
    //初始化库存诊断实例
    initSkuDiagnosis() {
      const option4 = {
        animation: false,
        tooltip: {
          trigger: 'axis',
          transitionDuration: 0,
          formatter(params) {
            return '<div style="font-size:14px;">' +
              params[0].name + '<br>' +
              "<div style='display:inline-block;line-height:20px'><div style='display:inline-block; width:10px;height:4px;background:#78C7E8;margin-right:5px'></div></div>" +
              params[0].value + '  %' +
            '</div>'
          },
          axisPointer: {
            type: 'none'
          }
        },
        xAxis: {
          show: false,
          data: this.skuBreakBrokenLine,
          type: 'category',
          boundaryGap: false,
          axisPointer: {
            snap: true,
            lineStyle: {
              color: '#78C7E8',
              opacity: 0.5,
              width: 2
            },
            label: {
              show: false,
              backgroundColor: '#78C7E8'
            },
            handle: {
              show: false,
              color: '#78C7E8'
            }
          },
          axisTick: { //y轴刻度线
            show: false
          },
          splitLine: {//分割线
            show: false
          }
        },
        yAxis: {
          min: this.calMaxMin(this.skuBreakBrokenLineNumber).min,
          max: this.calMaxMin(this.skuBreakBrokenLineNumber).max,
          type: 'value',
          axisTick: {
            inside: false,
            show: false
          },
          handle: {
            show: false,
            color: '#78C7E8'
          },
          axisLine: {
            show: false
          },
          splitLine: {
            show: false
          },
          axisLabel: {
            show: false,
            inside: false,
            formatter: '{value}\n'
          }
          // z: 10
        },
        grid: {
          top: 0,
          left: 0,
          right: 10,
          height: 83
        },
        series: [
          {
            type: 'line',
            smooth: true,
            symbol: 'none',
            showSymbol: false,
            symbolSize: 5,
            sampling: 'average',
            itemStyle: {
              color: '#78C7E8'
            },
            data: this.skuBreakBrokenLineNumber
          }

        ]
      }
      const option5 = {
        animation: false,
        tooltip: {
          trigger: 'axis',
          transitionDuration: 0, //防止tooltip的抖动
          formatter(params) {
            return '<div style="font-size:14px;">' +
              params[0].name + '<br>' +
              "<div style='display:inline-block;line-height:20px'><div style='display:inline-block; width:10px;height:4px;background:#78C7E8;margin-right:5px'></div></div>" +
              params[0].value + '  %' +
            '</div>'
          },
          axisPointer: {
            type: 'none'
          }
        },
        xAxis: {
          show: false,
          data: this.skuDrugBrokenLine,
          type: 'category',
          boundaryGap: false,
          axisPointer: {
            snap: true,
            lineStyle: {
              color: '#78C7E8',
              opacity: 0.5,
              width: 2
            },
            label: {
              show: false,
              backgroundColor: '#78C7E8'
            },
            handle: {
              show: false,
              color: '#78C7E8'
            }
          },
          axisTick: { //y轴刻度线
            show: false
          },
          splitLine: {//分割线
            show: false
          }
        },
        yAxis: {
          min: this.calMaxMin(this.skuDrugBrokenLineNumber).min,
          max: this.calMaxMin(this.skuDrugBrokenLineNumber).max,
          type: 'value',
          axisTick: {
            inside: false,
            show: false
          },
          handle: {
            show: false,
            color: '#78C7E8'
          },
          axisLine: {
            show: false
          },
          splitLine: {
            show: false
          },
          axisLabel: {
            show: false,
            inside: false,
            formatter: '{value}\n'
          }
        },
        grid: {
          top: 0,
          left: 0,
          right: 10,
          height: 83
        },
        series: [
          {
            type: 'line',
            smooth: true,
            symbol: 'none',
            showSymbol: false,
            symbolSize: 5,
            sampling: 'average',
            itemStyle: {
              color: '#78C7E8'
            },
            data: this.skuDrugBrokenLineNumber
          }

        ]
      }
      const option6 = {
        animation: false,
        tooltip: {
          trigger: 'axis',
          transitionDuration: 0, //防止tooltip的抖动
          formatter(params) {
            return '<div style="font-size:14px;">' +
              params[0].name + '<br>' +
              "<div style='display:inline-block;line-height:20px'><div style='display:inline-block; width:10px;height:4px;background:#78C7E8;margin-right:5px'></div></div>" +
              params[0].value + '  %' +
            '</div>'
          },
          axisPointer: {
            type: 'none'
          }
        },
        xAxis: {
          show: false,
          data: this.skuStopSellingBrokenLine,
          type: 'category',
          boundaryGap: false,
          axisPointer: {
            snap: true,
            lineStyle: {
              color: '#78C7E8',
              opacity: 0.5,
              width: 2
            },
            label: {
              show: false,
              backgroundColor: '#78C7E8'
            },
            handle: {
              show: false,
              color: '#78C7E8'
            }
          },
          axisTick: { //y轴刻度线
            show: false
          },
          splitLine: {//分割线
            show: false
          }
        },
        yAxis: {
          min: this.calMaxMin(this.skuStopSellingBrokenLineNumber).min,
          max: this.calMaxMin(this.skuStopSellingBrokenLineNumber).max,
          type: 'value',
          axisTick: {
            inside: false,
            show: false
          },
          handle: {
            show: false,
            color: '#78C7E8'
          },
          axisLine: {
            show: false
          },
          splitLine: {
            show: false
          },
          axisLabel: {
            show: false,
            inside: false,
            formatter: '{value}\n'
          }
        },
        grid: {
          top: 0,
          left: 0,
          right: 10,
          height: 83
        },
        series: [
          {
            type: 'line',
            smooth: true,
            symbol: 'none',
            showSymbol: false,
            symbolSize: 5,
            sampling: 'average',
            itemStyle: {
              color: '#78C7E8'
            },
            data: this.skuStopSellingBrokenLineNumber
          }
        ]
      }
      this.skuBreakBrokenLineExample.setOption(option4)
      this.skuDrugBrokenLineExample.setOption(option5)
      this.skuStopSellingBrokenLineExample.setOption(option6)
      this.skuBreakBrokenLineExample.hideLoading()
      this.skuDrugBrokenLineExample.hideLoading()
      this.skuStopSellingBrokenLineExample.hideLoading()
    }
  }
}
</script>

<style lang="scss" scoped>
@import '@/assets/stylus/main';
.e-chart {
  height: 100%;
  .wrap {
    width: 40%;
    height: 100%;
    float: left;
    .p1 {
      font-size: 12px;
      color: #333333;
      margin: 20px 0px 10px 15px;
    }
    .p2 {
      font-size: 20px;
      color: #333;
      margin-left: 15px;
      span {
        margin-left: 5px;
        font-size: 12px;
        color: #666666;
      }
    }
    .p3 {
      margin-left: 15px;
      font-size: 12px;
      color: #666666;
      .lui-icon-help {
        margin-left: 5px;
        cursor: pointer;
      }
    }
  }
  .details-wrap {
    float: left;
    padding: 0 10px;
    width: 35%;
    height: 100%;
    border-left: 1px solid #e6e6e6;
  }
  .details-box {
    float: left;
    padding-top: 40px;
    padding-right: 10px;
    width: 25%;
    height: 100%;
  }
  .details {
    width: 100%;
    height: 98px;
    display: flex;
    box-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.1);
    border-radius: 4px;
    margin-bottom: 12px;
    .title {
      width: 130px;
      padding: 12px;
      p {
        font-size: 12px;
        color: #666666;
        i {
          cursor: pointer;
          margin-left: 5px;
        }
        span {

          &:hover{
            color: $--gl-blue;
             cursor: pointer;
          }
          margin-right: 5px;
          font-size: 20px;
          color: #333333;
        }
      }
    }
  }


}
</style>
