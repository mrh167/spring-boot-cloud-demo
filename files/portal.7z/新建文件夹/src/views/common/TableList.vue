/**
* Table表格
*/
<template>
  <div>
    <div class="table-container">
      <lui-table
        ref="multipleTable"
        v-loading="loading"
        :row-key="options.rowKey ||'rowKey'"
        size="small"
        style="width: 200%;overflow: hidden"
        v-bind="options"
        :span-method="objectSpanMethod"
        :border="border"
        :max-height="options.height"
        :data="dataSource"
        :row-class-name="tableRowClassName"
        @selection-change="handleSelectionChange"
        @sort-change="handleSortChange"
      >
        <template slot="empty">
          <!--<img src="../../assets/empty.png" height="130" width="150" style="margin-top: 15px" />-->
          <p style="line-height: 6px;font-size: 14px;margin-top: -7px; font-weight: 600;">暂无数据</p>
        </template>
        <!-- 复选框 -->
        <lui-table-column
          v-if="options && options.selection"
          type="selection"
          width="60"
          align="center"
          :label="options && options.label"
          :fixed="options && options.selectionFixed"
        />
        <lui-table-column
          v-if="options && options.index"
          width="60"
          align="center"
          type="index"
          :label="options && options.labelIndex"
        />
        
        <!-- 表格数据 -->
        <template v-for="(column, index) in columns">
          <lui-table-column
            v-if="!column.hide"
            :key="index"
            v-bind="column.props"
            :prop="column.prop"
            :label="column.label"
            :align="column.align"
            :width="column.width"
            :sortable="column.sort"
            :show-overflow-tooltip="column.overflow"
          >
            <template slot-scope="scope">
              <template v-if="!column.render">
                <template v-if="column.formatter">
                  <span v-dompurify-html="column.formatter(scope.row, column, scope.$index,obj)"></span>
                </template>
                <template v-else-if="column.newjump">
                  <router-link
                    target="_blank"
                    class="newjump"
                    :to="column.newjump(scope.row, column, scope.$index)"
                  >{{ scope.row[column.prop] }}
                  </router-link>
                </template>
                <template v-else-if="column.lineEdit">
                  <template v-if="scope.row.lineEdit">
                    <lui-input
                      v-model="scope.row.editLineData"
                      class="edit-input"
                      :maxlength="column.maxlength"
                      size="small"
                      @input="e => scope.row.editLineData = specialForbid (e)" />
                    <lui-button
                      class="cancel-btn"
                      size="small"
                      type="warning"
                      @click="cancelEdit(scope.row)">cancel
                    </lui-button>
                  </template>
                  <span v-else>{{ scope.row[column.prop] }}</span>
                </template>
                <template v-else>
                  <span>{{ scope.row[column.prop] }}</span>
                </template>
              </template>
              <template v-else>
                <render :column="column" :row="scope.row" :render="column.render" :index="index" :obj="obj"></render>
              </template>
            </template>
          </lui-table-column>
        </template>
        
        <!-- slot插槽按钮 -->
        <lui-table-column v-if="options && options.slotcontent" label="操作" align="center">
          <template slot-scope="scope">
            <slot :data="scope.row"></slot>
          </template>
        </lui-table-column>
        <!-- slot插槽行内编辑按钮 -->
        <lui-table-column v-if="options && options.lineEdit" label="操作" align="center">
          <template slot-scope="scope">
            <lui-button
              v-if="scope.row.lineEdit"
              type="success"
              size="small"
              icon="el-icon-circle-check-outline"
              @click="confirmEdit(scope.row)">ok
            </lui-button>
            <lui-button
              v-else
              type="primary"
              size="small"
              icon="el-icon-edit"
              @click="scope.row.lineEdit = !scope.row.lineEdit">
              {{ options.editText }}
            </lui-button>
          </template>
        </lui-table-column>
        
        <!-- 操作按钮 -->
        <lui-table-column
          v-if="operates && operates.length > 0 && havCode(operates)"
          label="操作"
          align="center"
          :width="options && options.width"
          :fixed="options && options.operatesFixed"
        >
          <template slot-scope="scope">
            <div class="operate-group">
              <template v-for="(btn, key) in operates">
                <span
                  v-if="(!btn.isShow || (btn.isShow && btn.isShow(scope.row, scope.$index))) && !hideBtn[btn.label]"
                  :key="key"
                >
                  <lui-button
                    :size="btn.size"
                    :type="btn.type || `text`"
                    :icon="btn.icon"
                    :plain="btn.plain"
                    :disabled="btn.disabled && btn.disabled(scope.row, scope.$index)"
                    @click.native.prevent="btn.method(scope.row, scope.$index,obj)"
                  >{{ btn.label }}{{ operates.length >= 2 ? '&nbsp;&nbsp;' : '' }}</lui-button>
                </span>
              </template>
            </div>
          </template>
        </lui-table-column>
      </lui-table>
    </div>
    <div class="pagination-container">
      <!-- 分页部分 -->
      <lui-pagination
        v-if="pagination"
        background
        class="pagination"
        :total="pagination.total"
        :current-page="pagination.pageNum"
        :page-size="pagination.pageSize"
        :page-sizes="pagination.pageSizes"
        layout="total, sizes,prev, pager, next,jumper"
        @size-change="handleSizeChange"
        @current-change="handleChangePage"
      />
    </div>
  <!--  <lui-tooltip placement="top" content="回到顶部">
      <back-to-top :visibility-height="300" :back-position="50"
                   transition-name="fade"/>
    </lui-tooltip>-->
  </div>
</template>

<script>
// import { isAuth, isSys } from '@/utils/util'
// import BackToTop from '@/components/BackToTop'
// import Sortable from 'sortablejs'
  
const methods = {
  //按钮权限
  havCode(operates) {
    let auth = false, moreCode = false
    if (operates && operates.length > 0) {
      for (const operate of operates) {
        if (operate.code) {
          if (!isAuth(operate.code)) {
            //有其他不隐藏操作按钮
            this.hideBtn[operate.label] = true
          } else {
            auth = true
          }
        } else {
          moreCode = true
        }
      }
    }
    return (auth || moreCode)
  },
  // 复选框选中项
  handleSelectionChange(val) {
    this.multipleSelection = val
    this.$emit('handleSelectionChange', Array.from(val), this.multipleSelection)
  },
  handleSortChange(column) {
    this.$emit('handleSortChange', column)
  },
  // 改变分页页码触发事件
  handleChangePage(val) {
    this.$emit('handleChangePage', val)
  },
  // 改变分页单页数量触发事件
  handleSizeChange(val) {
    this.$emit('handleSizeChange', val)
  },
  //行样式
  tableRowClassName({ row, rowIndex }) {
    this.$emit('tableRowClassName', { row, rowIndex })
  },
  //取消行内编辑
  cancelEdit(row) {
    row.editLineData = ''
    row.lineEdit = false
    this.$message.warning('取消编辑成功')
  },
  //取消行内编辑
  confirmEdit(row) {
    this.$emit('confirmEdit', row)
  },
  //取消行内编辑
  convertEdit(edit) {
    this.$emit('convertEdit', edit)
  },
  labelHead(h, { column, index }) {
    const l = column.label.length
    const f = 16
    column.minWidth = f * l
    return h('div', { class: 'table-head', style: { width: '100%' }}, [column.label])
  },
  drag() {
    // 表格中需要实现行拖动，所以选中tr的父级元素
    const table = document.querySelector('.el-table__body-wrapper tbody')
    const self = this
    Sortable.create(table, {
      onEnd({ newIndex, oldIndex }) {
        self.$emit('draggableEnd', { newIndex, oldIndex })
      }
    })
  },
  //先固定分列 只有仓网
  objectSpanMethod({ row, column, rowIndex, columnIndex }) {
    // 库节点网络结构  通过 spanArr 判断
    if (this.spanArr && this.spanArr.length > 0) {
      let num = 10
      if (!isSys()) {
        num = 8
      }
      if (columnIndex < num || columnIndex >= num + 5) {
        const _row = this.spanArr[rowIndex]
        const _col = _row > 0 ? 1 : 0
        return {
          rowspan: _row,
          colspan: _col
        }
      }
    }
    // 补货仓支援关系 通过 rowSpanArr 判断
    if (this.rowSpanArr && this.rowSpanArr.length > 0) {
      let num = 7
      if (!isSys()) {
        num = 5
      }
      if (columnIndex < num || columnIndex >= num + 4) {
        const _row = this.rowSpanArr[rowIndex]
        const _col = _row > 0 ? 1 : 0
        return {
          rowspan: _row,
          colspan: _col
        }
      }
    }
  }
}
  
  
export default {
  name: 'TableList',
  components: {
    // BackToTop,
    // Sortable,
    //很神的组件
    render: {
      functional: true,
      props: {
        obj: Object,
        row: Object,
        render: Function,
        index: Number,
        column: {
          type: Object,
          default: null
        }
      },
      render: (h, opt) => {
        const params = {
          //this 对象 当参数传递=》会改变this 的范围
          obj: opt.props.obj,
          row: opt.props.row,
          index: opt.props.index
        }
        if (opt.props.column) params.column = opt.props.column
        return opt.props.render(h, params)
      }
    }
  },
  props: {
    dataSource: {
      type: Array,
      default: []
    },
    columns: {
      type: Array,
      default: []
    },
    border: {
      type: Boolean,
      default: false
    },
    loading: {
      type: Boolean,
      default: false
    },
    slotcontent: {
      type: Boolean,
      default: false
    },
    operates: {
      type: Array
    },
    pagination: {
      type: Object,
      default: null
    },
    dataTotal: {
      type: Number,
      default: 0
    },
    exportBut: {
      type: Array
    },
    spanArr: {
      type: Array
    },
    rowSpanArr: {
      type: Array
    },
    options: Object
  },
    
  data() {
    return {
      obj: this,
      multipleSelection: [],
      hideBtn: {}
    }
  },
    
  mounted() {
    this.$nextTick(() => {
      this.$emit('toggleRowSelection', this.$refs.multipleTable)
    })
    if (this.options && this.options.draggable) {
      this.drag()
    }
  },
    
  methods
}
</script>
<style scoped >
  .edit-input {
    padding-right: 80px;
  }
  
  .cancel-btn {
    position: absolute;
    right: 15px;
    top: 10px;
  }
</style>
