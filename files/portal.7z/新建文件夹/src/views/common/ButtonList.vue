<template>
  <div style="display: inline-block; margin:0 10px">
    <div>
      <lui-button
        v-if="buttons.upload"
        v-waves
        class="btn-upload"
        type="primary"
        @click="uploadClick">
        {{ buttons.upload.label || '批量上传' }}
      </lui-button>
      <lui-dialog v-if="buttons.upload" title="上传" :visible.sync="isUploadModalShow">
        <div v-if="uploading" v-loading="true" style="width:100%;height:200px"></div>
        <lui-upload
          v-else
          ref="upload"
          class="upload"
          drag
          :name="buttons.fileName"
          :action="UploadUrl()"
          :data="uploadData"
          :headers="header"
          close-on-click-modal="false"
          width="45%"
          :auto-upload="false"
          :file-list="fileList"
          :accept="defaultUploadConfig.accept"
          :limit="defaultUploadConfig.limit"
          :before-upload="beforeAvatarUpload"
          :on-change="changeUpload"
          :before-remove="beforeRemove"
          :on-remove="defaultUploadConfig['on-remove']"
          :on-success="defaultUploadConfig['on-success']"
          :on-error="defaultUploadConfig['on-error']"
          :on-exceed="defaultUploadConfig['on-exceed']"
        >
          <i class="lui-icon-upload"></i>
          <div class="lui-upload__text">
            将文件拖到此处，或
            <em>点击上传</em>
          </div>
          <div slot="tip" class="lui-upload__tip">{{ defaultUploadConfig.Uploadtips }}</div>
          <div slot="tip" class="lui-upload__tip red">{{ defaultUploadConfig.uploadtipsadd }}</div>
        </lui-upload>
        <template slot="footer">
          <span v-if="buttons.upload.templateUrl" style="float: left">
            <lui-link
              type="info"
              :underline="false"
              icon="lui-icon-download"
              @click="downLoadTemplate">下载模板</lui-link>
          </span>
          <lui-button size="small" class="cancel" @click="isUploadModalShow = false">取消</lui-button>
          <lui-button v-if="buttons.upload.checkUrl" type="primary" size="small " @click="uploadCheckFile">校验</lui-button>
          <lui-button v-waves type="primary" size="small " :loading="loading" @click="uploadFile">{{ loading ? '上传中...' : '上传' }}  </lui-button>
        </template>
      </lui-dialog>
      <lui-dialog
        class="error-dialog"
        title="上传结果反馈:"
        :visible.sync="dialogTableVisible"
        :close-on-click-modal="false">
        <div class="dialog-table-list">
          <div v-show="moreErr" style="color: red;font-size: 12px">异常太多，最多显示300条</div>
          <lui-table
            stripe
            border
            size="mini"
            max-height="310px"
            :data="gridData">
            <lui-table-column align="center" property="msg" label="反馈明细" width="">
              <template slot-scope="{row}">
                {{ row.msg }}
              </template>
            </lui-table-column>
            <lui-table-column align="center" property="rowNo" label="行号列表"></lui-table-column>
            <lui-table-column v-if="isDyson" align="center" label="操作">
              <template slot-scope="{row}">
                <lui-button v-if="row.middleId && !row.success" style="color:#0D6CA2;" @click="$parent.postOverlay(row.middleId)">覆盖原有记录</lui-button>
                <lui-button v-if="row.success" disabled @click="$parent.postOverlay(row.middleId)">已覆盖</lui-button>
              </template>
            </lui-table-column>
          </lui-table>
        </div>
      </lui-dialog>
    </div>
  </div>
</template>
<script>
import Http from '@/lib/http'
// import utils from '@/utils/utils'
// import Api from '@/api'
// import store from '@/store/index'
import { exportExcel } from '@/utils/downloadRequest'
export default {
  props: {
    //上传的数据
    buttons: {
      type: Object,
      default() {
        return {}
      }
    },
    //事业部编码
    configdeptNo: {
      type: String,
      default() {
        return ''
      }
    },
    //事业部名称
    configdeptName: {
      type: String,
      default() {
        return ''
      }
    },
    //是否存在事业部编码标识
    checkDeptNo: {
      type: Boolean,
      default() {
        return false
      }
    },
    //是否是戴森标识
    isDyson: {
      type: Boolean,
      default() {
        return false
      }
    },
    //戴森middleId
    dysonMiddleId: {
      type: String,
      default() {
        return ''
      }
    }
  },
  data() {
    return {
      loading: false,
      baseURL: Http.baseContextUrl,
      isUploadModalShow: false, //上传模态窗
      dialogTableVisible: false,
      gridData: [],
      uploading: false, //上传文件loading
      fileList: [], //上传列表
      onlyCheck: false,
      moreErr: false,
      header: { 'X-Requested-With': 'XMLHttpRequest' },
      uploadData: {
        async: true,
        deptNo: '',
        deptName: ''
      },
      fileSizeM: 0,
      uploadLoading: {}
    }
  },
  computed: {
    // eslint-disable-next-line vue/return-in-computed-property
    defaultUploadConfig() {
      if (this.buttons.upload && this.buttons.upload.uploadConfig) {
        return {
          uploadActionUrl: '请设置uploadURL',
          Uploadtips: this.buttons.upload.uploadtips || '只能上传xlsx文件，文件大小不超过50M，大文件可选后台上传',
          uploadtipsadd: this.buttons.upload.uploadtipsadd,
          limit: 2, //最大允许上传个数
          'on-remove': () => {
            // this.$refs.upload.clearFiles()
          },
          'before-remove': (response) => {
            this.$refs.upload.clearFiles()
          },
          //文件列表移除文件时的钩子,一般不用
          'on-success': (response) => {
            //  debugger
            this.fileList = []
            this.loading = false
            // this.uploadLoading.close()
            this.isUploadModalShow = false
            this.$refs.upload.clearFiles()
            //这里开始修改逻辑
            if (!response.success) {
              this.$message({
                message: response.errMessage,
                type: 'error',
                duration: 3 * 1000
              })
              return
            } else {
              if (response.data.errorCount === 0) {
                this.$message({
                  message: '数据全部上传成功！',
                  type: 'success',
                  duration: 3 * 1000
                })
              }
              if (response.data.errorCount > 0) {
                this.dialogTableVisible = true
                this.gridData = response.data.detaileds
                this.moreErr = response.data.detaileds.length >= 300 ? true : false
              }
              this.$emit('uploadSuccess')
              this.isUploadModalShow = false
            }
          }, //文件上传失败时的钩子
          'on-error': (response) => {
            this.loading = false
            // this.uploadLoading.close()
            this.$message({
              message: '上传异常',
              type: 'error',
              duration: 3000
            })
          }, //文件上传失败时的钩子
          'on-exceed': () => {
            this.loading = false
            // this.uploadLoading.close()
            this.$message({
              message: '上传文件数量超过限制，不能超过1个',
              type: 'error',
              duration: 3000
            })
          },
          ...this.buttons.upload.uploadConfig
        }
      }
    }
  },
  watch: {
    //事业部编码
    configdeptNo(newval, oldval) {
      this.configdeptNo = newval
      this.uploadData.deptNo = newval
    },
    //事业部名称
    configdeptName(newval, oldval) {
      this.configdeptName = newval
      this.uploadData.deptName = newval
    },
    //戴森middleId
    dysonMiddleId(newval, oldval) {
      this.updateGridData(newval)
    }
  },
  mounted() {

  },
  methods: {
    //更新戴森已覆盖数据
    updateGridData(middleId) {
      this.gridData.forEach(item => {
        if (item.middleId === middleId) {
          item.success = true
        } 
      })
    },
    //点击批量上传
    uploadClick() {
      if (this.checkDeptNo) {
        if (this.uploadData.deptNo === '' || this.uploadData.deptNo === null) {
          this.$message.error('请选择事业部！')
          return
        } else {
          this.isUploadModalShow = true
        }
      } else {
        delete this.uploadData.deptNo
        delete this.uploadData.deptName
        this.isUploadModalShow = true
      }
    },
    //下载空模板
    downLoadTemplate() {
      const actionUrl = this.buttons.upload.templateUrl
      exportExcel(actionUrl, {})
    },
    //删除前操作
    beforeRemove(file) {
      file = ''
      this.fileList = []
    },
    //上传前操作
    beforeAvatarUpload(file) {
      const Xls = file.name.split('.')
      if (Xls.pop() === 'xlsx') {
        return file
      } else {
        this.$message.error('上传文件只能是xlsx 格式')
        return false
      }
    },
    //上传时操作
    changeUpload(file, fileList) {
      const fileSizeM = file.size / 1024 / 1024
      let maxM = 50
      if (this.buttons.upload.maxM) {
        maxM = this.buttons.upload.maxM
      }
      if (fileSizeM > maxM) {
        this.$message({
          message: '上传的文件大小超出限制',
          type: 'error',
          duration: 3000
        })
        this.fileList = []
        return
      }
      const Xls = file.name.split('.')
      if (!(Xls.pop() === 'xlsx')) {
        this.$message({
          message: '上传文件只能是xlsx 格式',
          type: 'error',
          duration: 3000
        })
        this.fileList = []
        return
      }
      this.fileSizeM = fileSizeM
      if (fileList.length > 0) {
        this.fileList = [fileList[fileList.length - 1]]
      }
    },
    //上传的URL
    UploadUrl() {
      return this.buttons.upload.uploadConfig.uploadActionUrl
    },
    //校验是否选择上传文件
    uploadCheckFile() {
      if (this.fileList.length < 1) {
        this.$message({
          message: '请选择上传的文件',
          type: 'error',
          duration: 2000
        })
        return
      }
      this.onlyCheck = true
      this.defaultUploadConfig.uploadActionUrl = this.buttons.upload.checkUrl
      this.$refs.upload.submit()
    },
    //点击上传按钮
    uploadFile(params) {
      if (this.fileList.length < 1) {
        this.$message({
          message: '请选择上传的文件',
          type: 'error',
          duration: 2000
        })
        return
      }
      this.onlyCheck = false
      this.uploadData.async = true
      if (this.fileSizeM > 10) {
        this.$message({
          message: '文件请控制到10M以内！',
          type: 'error',
          duration: 2000
        })
        return false
      }
      this.loading = true
      // this.uploadLoading = this.$loading({
      //   lock: true,
      //   text: '上传中...',
      //   spinner: 'lui-icon-loading',
      //   background: 'rgba(0, 0, 0, 0.7)'
      // })
      this.defaultUploadConfig.uploadActionUrl = this.buttons.upload.uploadConfig.uploadActionUrl
      this.$refs.upload.submit()
    }
  }
}
</script>
<style>
  .error-dialog .lui-dialog__body {
    padding-top: 10px !important;
  }
.red{
  color: #ff0000;
}
</style>
<style lang="scss" scoped>
@import "@/assets/stylus/main";
  /deep/ .lui-dialog{
    width: 60%;
  }
  .upload {
    text-align: center;
  }
  .lui-link.lui-link--info{
    color: $--gl-blue!important;
  }
  .lui-upload-dragger .lui-upload__text em{
    color:$--gl-blue!important;
  }
  .upload /deep/ .lui-dialog__body {
    border-top: 1px solid #e8eaec !important;
  }

  /deep/ .lui-button + .lui-button {
    margin-left: unset !important;
  }
  .cancel{
    margin-right: 8px;
  }
</style>
