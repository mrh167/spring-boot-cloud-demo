<template>
  <div>
    <!-- 添加编辑删除通用弹出框 -->
    <lui-dialog
      class="error-dialog"
      :title="title"
      :visible.sync="dialogTableVisible"
      :close-on-click-modal="false"
      @close="closeDialog">
      <div class="dialog-table-list">
        <lui-table
          stripe
          border
          size="mini"
          max-height="310px"
          :data="gridData">
          <lui-table-column align="center" property="tip" label="反馈列表"></lui-table-column>

          <lui-table-column align="center" property="msg" label="反馈明细" width="350">
            <template slot-scope="{row}">
              {{ row.msg }}
            </template>
          </lui-table-column>
        </lui-table>
      </div>
    </lui-dialog>
  </div>
</template>

<script>
export default {
  // props: {
  //   operationList: {
  //     type: Array,
  //     default: []
  //   }
  // },
  props: ['operationList'],

  data() {
    return {
      dialogTableVisible: true,
      moreErr: false,
      title: '',
      gridData: []
    }
  },
  mounted() {
    this.gridData = this.operationList.data
    this.title = this.operationList.title
  },
  methods: {
    closeDialog() {
      this.$emit('event1', false)
    }
  }
}
</script>

<style>
</style>
