<template>
  <div class="News">
    <div class="News-button">
      <lui-radio-group v-model="radioBut" @change="allRead">
        <lui-radio-button label="全部"></lui-radio-button>
        <lui-radio-button label="未读"></lui-radio-button>
        <lui-radio-button label="已读"></lui-radio-button>
      </lui-radio-group>

      <lui-button-group style="margin-left: 12px;">
        <lui-button :disabled="multipleSelection.length==0" @click="MsgpartReadClick">标记所选已读</lui-button>
      </lui-button-group>
      <lui-button-group style="margin-left: 12px;">
        <lui-button :disabled="multipleSelection.length==0" @click="deleteClick">删除</lui-button>
      </lui-button-group>
    </div>
    <lui-table
      v-loading="listLoading"
      :data="tableData"
      style="width: 80%;margin: 0 auto "
      @cell-mouse-enter="handhoverDelete"
      @cell-mouse-leave="handhoverLeave"
      @selection-change="handleSelectionChange"
    >
      <template slot="empty">
        <showEmptyImage></showEmptyImage>
      </template>
      <lui-table-column fixed="left" type="selection" align="center" width="50"></lui-table-column>
      <lui-table-column label="消息主题" prop="msgTitle">
        <template slot-scope="{row}">
          <div v-if="row.readFlag==0" class="table-conter">
            <span class="table-p-span"></span>
            <p>{{ row.msgTitle }}</p>
          </div>
          <div v-else class="table-conter-no">
            <p>{{ row.msgTitle }}</p>
          </div>
        </template>
      </lui-table-column>
      <lui-table-column label="内容" prop="msgText">
        <template slot-scope="{row}">
          <p class="table-p">{{ row.msgText }}</p>
        </template>
      </lui-table-column>
      <lui-table-column label="时间" prop="createTime" width="190">
        <template slot-scope="{row}">
          <p class="table-date" @click="deleteSingle(row)">
            {{ row.createTime }}
            <img src="../../../assets/img/icon-delet.png" class="deleteIcon" alt />
          </p>
        </template>
      </lui-table-column>
    </lui-table>
    <div v-show="tableData.length>0" class="News-pagination">
      <lui-pagination
        background
        :current-page.sync="pageNum"
        :page-sizes="[10, 20, 50, 70, 100]"
        layout="prev, pager, next, sizes, jumper"
        :total="totals"
        @size-change="sizeChange"
        @current-change="handleSizeChange"
      >
      </lui-pagination>
    </div>
  </div>
</template>

<script>
import Api from '@/api'
import showEmptyImage from '@/components/common/showEmptyImage/index.vue'
export default {
  name: 'index',
  components: {
    showEmptyImage
  },
  data() {
    return {
      radioBut: '全部',
      tableData: [],
      multipleSelection: [],
      listLoading: true,
      totals: 0,
      pageNum: 1, //页
      pageSize: 10, //条数
      readFlag: null
    }
  },
  mounted() {
    this.msgPageList() //获取消息列表
  },
  methods: {
    //未读消息数
    unMsgCountClick() {
      this.readFlag = 0
      this.msgPageList()
    },
    // 已读消息
    partReadClick() {
      this.readFlag = 1
      this.msgPageList()
      // Api.MessageInfo.partRead({
      //   idList: ''
      // }).then(row => {}).catch(e => {})
    },
    //消息列表页
    msgPageList() {
      this.listLoading = true
      Api.MessageInfo.msgPageList({
        pageSize: this.pageSize,
        pageNum: this.pageNum,
        readFlag: this.readFlag
      }).then(row => {
        if (row.success) {
          this.tableData = row.data
          this.totals = row.total
          this.listLoading = false
        }
      }).catch(e => { this.$showErrorMsg(e) })
    },
    //分页条数改变
    sizeChange(val) {
      this.pageSize = val
      this.msgPageList()
    },
    //翻页-----根据页码变换
    handleSizeChange(val) {
      this.pageNum = val
      this.msgPageList()
    },
    //全选反选
    handleSelectionChange(val) {
      this.multipleSelection = val
    },
    //鼠标离开事件
    handhoverDelete(val) {
      val.del = true
    },
    //鼠标划入事件
    handhoverLeave(val) {
      val.del = false
    },
    //全部已读
    allRead() {
      if (this.radioBut === '全部') {
        this.readFlag = null
        this.msgPageList()
      } else if (this.radioBut === '未读') {
        this.readFlag = 0
        this.msgPageList()
      } else if (this.radioBut === '已读') {
        this.readFlag = 1
        this.msgPageList()
      }
    },
    //标记所选已读
    MsgpartReadClick() {
      const crrId = []
      const obj = {}
      for (let i = 0; i < this.multipleSelection.length; i++) {
        crrId.push(this.multipleSelection[i].id)
      }
      obj.idList = crrId
      Api.MessageInfo.partRead(obj).then(row => {
        if (row.success) {
          this.msgPageList()
        }
      }).catch((e) => { this.$showErrorMsg(e) })
    },
    //批量删除
    deleteClick() {
      const crrId = []
      const obj = {}
      for (let i = 0; i < this.multipleSelection.length; i++) {
        crrId.push(this.multipleSelection[i].id)
      }
      obj.idList = crrId
      this.delete(obj)
    },
    //单个删除
    deleteSingle(row) {
      const crrId = []
      const obj = {}
      crrId.push(row.id)
      obj.idList = crrId
      this.delete(obj)
    },
    //  删除方法
    delete(row) {
      this.$alert('<p style="font-size: 18px;color:#333">确认删除此条消息吗?</p><p style="font-size: 13px;color: #666">删除后，此条消息的相关内容信息将无法恢复</p>', '', {
        dangerouslyUseHTMLString: true,
        type: 'warning',
        center: true
      }).then(() => {
        Api.MessageInfo.deleteByIds(row).then(row => {
          if (row.success) {
            this.$message({
              message: '删除成功',
              type: 'success'
            })
            this.msgPageList()
          } else {
            this.$message.error('删除失败，请稍后再试')
          }
        }).catch((e) => { this.$showErrorMsg(e) })
      })
    }
  }
}
</script>

<style scoped lang="scss" rel="stylesheet/scss">
  @import "./news.scss";
</style>
