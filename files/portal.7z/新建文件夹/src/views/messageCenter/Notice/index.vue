<template>
  <div class="Notic">
    <lui-table
      v-loading="listLoading"
      :data="tableData"
      style="width: 85%;margin: 0 auto"
      @cell-mouse-enter="handhoverDelete"
      @cell-mouse-leave="handhoverLeave"
      @cell-click="handclick"
    >
      <template slot="empty">
        <showEmptyImage></showEmptyImage>
      </template>
      <lui-table-column prop="title" label="公告主题" show-overflow-tooltip>
        <template v-slot="{row}">
          <p v-if="row.topFlag" class="table-p">
            <img
              v-if="row.is===1"
              src="../../../assets/img/icon-top1.png"
              style="margin-right: 20px;width: 25px;"
            />
            <img
              v-if="row.is===2"
              src="../../../assets/img/icon-notice-hover.png"
              style="margin-right: 20px;width: 25px;"
            />
            {{ row.title }}
          </p>
          <p v-else class="table-p">
            <img
              v-if="row.is===1"
              src="../../../assets/img/xitonggonggao.png"
              style="margin-right: 20px;width: 25px;"
            />
            <img
              v-if="row.is===2"
              src="../../../assets/img/icon-notice-hover.png"
              style="margin-right: 20px;width: 25px;"
            />
            {{ row.title }}
          </p>
        </template>
      </lui-table-column>
      <lui-table-column
        prop="text"
        label="内容">
        <template v-slot="{row}">
          <p class="table-p">{{ row.text }}</p>
        </template>
      </lui-table-column>

      <lui-table-column
        prop="position"
        label="位置">
        <template v-slot="{row}">
          <p v-if="row.position === 1" class="table-p">官网</p>
          <p v-else class="table-p">产品首页</p>
        </template>
      </lui-table-column>

      <lui-table-column prop="releaseTime" label="时间" width="180">
        <template v-slot="{row}">
          <p class="table-p">{{ row.releaseTime }}</p>
        </template>
      </lui-table-column>
    </lui-table>

    <div v-show="totals>10" class="Notic-pagination">
      <lui-pagination
        background
        :current-page.sync="pageNum"
        layout="prev, pager, next, sizes, jumper"
        :total="totals"
        @size-change="sizeChange"
        @current-change="handleSizeChange"
      ></lui-pagination>
    </div>

    <!--    详情-->
    <lui-dialog
      :visible.sync="centerDialogVisible"
      width="60%"
      top="10vh"
      :close-on-click-modal="false"
      :lock-scroll="false"
      :append-to-body="true"
      custom-class="dialog_mask"
      title="公告详情">
      <lui-form ref="ruleForm" label-width="150px" class="demo-ruleForm">
        <lui-row :gutter="20" class="scrollBar" style="width: 95%;height: 500px;overflow-y: auto;margin-left: 5%;padding-right: 5%;">
          <div class="dialog-title" style="font-size: 20px;color: #333;cursor: pointer">{{ ruleForm.title }}</div>
          <div class="dialog-time" style="font-size: 13px;color: #999;margin-top: 10px;">{{ ruleForm.time }}</div>
          <div v-dompurify-html="ruleForm.content" class="dialog-content" style="margin-top: 10px;"></div>
        </lui-row>
      </lui-form>
    </lui-dialog>
  </div>
</template>

<script>
import Api from '@/api'
import utils from '@/utils/utils'
import showEmptyImage from '@/components/common/showEmptyImage/index.vue'
export default {
  name: 'index',
  components: {
    showEmptyImage
  },
  data() {
    return {
      pageNum: 1,
      pageSize: 10,
      totals: 0,
      listLoading: true,
      centerDialogVisible: false,
      ruleForm: {
        title: '',
        time: '',
        content: ''
      },
      tableData: []
    }
  },
  mounted() {
    this.GetList()
  },
  methods: {
    //列表简叙文章调整
    getContent(HTML) {
      var content = HTML
      return content
        .replace(/<(style|script|iframe)[^>]*?>[\s\S]+?<\/\1\s*>/gi, '')
        .replace(/<[^>]+?>/g, '')
        .replace(/\s+/g, ' ')
        .replace(/ /g, ' ')
        .replace(/>/g, ' ')
    },
    handclick(row) {
      this.listLoading = true
      this.ruleForm = {
        title: '',
        time: '',
        content: ''
      }
      Api.MessageInfo.findById({ id: row.id }).then(res => {
        if (res.success) {
          this.ruleForm.title = res.data.title ? utils.htmlDecode(res.data.title) : ''
          this.ruleForm.time = res.data.releaseTime ? res.data.releaseTime : ''
          this.ruleForm.content = res.data.content ? utils.htmlDecode(res.data.content) : ''
          this.centerDialogVisible = true
          this.listLoading = false
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
        this.listLoading = false
      })
    },
    handhoverDelete(row) {
      row.is = 2
    },
    handhoverLeave(row) {
      row.is = 1
    },
    //翻页-----根据页码变换
    handleSizeChange(val) {
      this.pageNum = val
      this.GetList()
    },
    sizeChange(val) {
      this.pageSize = val
      this.GetList()
    },
    // 列表内容
    GetList() {
      Api.MessageInfo.noticePageList({
        pageSize: this.pageSize,
        pageNum: this.pageNum
      }).then(row => {
        if (row.success) {
          for (let i = 0; i < row.data.length; i++) {
            row.data[i].title = utils.htmlDecode(row.data[i].title)
            row.data[i].is = 1
            row.data[i].text = utils.htmlDecode(row.data[i].text)
          }
          this.tableData = row.data
          this.totals = row.total
          this.listLoading = false
        }
      }).catch(e => { this.$showErrorMsg(e) })
    }

  }
}
</script>
<style scoped lang="scss">
  @import "../../backstage/information/common/css/common.scss";
</style>
<style scoped lang="scss">
.Notic {
  background: #fff;
  width: 100%;
  min-height: 600px;
  padding-bottom: 26px;
  padding-top: 35px;
}
.Notic-pagination {
  width: 100%;
  margin-top: 73px;
  text-align: center;
}
.table-p {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  cursor: pointer;
  padding-right: 15px;
}
 /deep/ .dialog-title:hover{
    color: red;
  }
</style>
