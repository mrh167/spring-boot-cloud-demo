<template>
  <div class="about">
    关于我们
  </div>
</template>

<script>
export default {
  name: 'index'
}
</script>

<style scoped lang="scss">
.about{
  width: 100%;
  min-height: 600px;
  background: white;
  p{
    line-height: 30px;
  }
}
</style>
