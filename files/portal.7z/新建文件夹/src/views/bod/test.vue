<template>
  <div id="app">
    <!-- <button @click="toUpdate">切换数据</button> -->
    <lui-button @click="addClack">点击</lui-button>

    <div v-if="show" id="container"></div>
  </div>
</template>

<script>
// import {init,update} from './utils/g6Utils.min.js';
import G6 from '@antv/g6'
export default {
  name: 'gpolyline',
  data() {
    return {
      arr: [],
      show: false,
      data: {
        children: [
          {
            children: [
              {
                children: [

                ],
                replaceBeforeGoodsNo: '111',
                replaceBeforeGoodsName: '11100',
                direction: 2
              },
              {
                children: [

                ],
                replaceBeforeGoodsNo: '111',
                replaceBeforeGoodsName: '11100',
                direction: 2
              },
              {
                children: [
                  {
                    children: [

                    ],
                    replaceBeforeGoodsNo: '111',
                    replaceBeforeGoodsName: '11100',
                    direction: 2
                  },
                  {
                    children: [

                    ],
                    replaceBeforeGoodsNo: '111',
                    replaceBeforeGoodsName: '11100',
                    direction: 2
                  }
                ],
                replaceBeforeGoodsNo: '111',
                replaceBeforeGoodsName: '11100',
                direction: 2
              }
            ],
            replaceBeforeGoodsNo: 'G001',
            replaceBeforeGoodsName: '商品名称_001',
            direction: 2
          }
        ],
        replaceBeforeGoodsNo: 'G002',
        replaceBeforeGoodsName: '商品名称_001',
        direction: null
      }
    }
  },
  mounted() {

    // const data = {
    //   children: [
    //     {
    //       children: [
    //         {
    //           children: [

    //           ],
    //           replaceBeforeGoodsNo: '111',
    //           replaceBeforeGoodsName: '11100',
    //           direction: 2
    //         },
    //         {
    //           children: [

    //           ],
    //           replaceBeforeGoodsNo: '111',
    //           replaceBeforeGoodsName: '11100',
    //           direction: 2
    //         },
    //         {
    //           children: [
    //             {
    //               children: [

    //               ],
    //               replaceBeforeGoodsNo: '111',
    //               replaceBeforeGoodsName: '11100',
    //               direction: 2
    //             },
    //             {
    //               children: [

    //               ],
    //               replaceBeforeGoodsNo: '111',
    //               replaceBeforeGoodsName: '11100',
    //               direction: 2
    //             }
    //           ],
    //           replaceBeforeGoodsNo: '111',
    //           replaceBeforeGoodsName: '11100',
    //           direction: 2
    //         }
    //       ],
    //       replaceBeforeGoodsNo: 'G001',
    //       replaceBeforeGoodsName: '商品名称_001',
    //       direction: 2
    //     }
    //   ],
    //   replaceBeforeGoodsNo: 'G002',
    //   replaceBeforeGoodsName: '商品名称_001',
    //   direction: null
    // }

    // G6.registerNode('icon-node', {
    //   draw(cfg, group) {
    //     const styles = this.getShapeStyle(cfg)
    //     const { labelCfg = {}} = cfg

    //     const keyShape = group.addShape('rect', {
    //       attrs: {
    //         ...styles,
    //         x: 0,
    //         y: 0
    //       }
    //     })

    //     if (cfg.replaceBeforeGoodsName) {
    //       group.addShape('text', {
    //         attrs: {
    //           ...labelCfg.style,
    //           text: cfg.replaceBeforeGoodsName,
    //           x: 20,
    //           y: 27
    //         }
    //       })
    //     }
    //     return keyShape
    //   }
    // },
    // 'rect',
    // )

    // G6.registerEdge('line', {
    //   draw(cfg, group) {
    //     const startPoint = cfg.startPoint
    //     const endPoint = cfg.endPoint

    //     const { style } = cfg
    //     const shape = group.addShape('path', {
    //       attrs: {
    //         stroke: style.stroke,
    //         endArrow: style.endArrow,
    //         path: [
    //           ['M', startPoint.x, startPoint.y],
    //           // ['L', startPoint.x, (startPoint.y + endPoint.y) / 2],
    //           // ['L', endPoint.x, (startPoint.y + endPoint.y) / 2],
    //           ['L', endPoint.x, endPoint.y]
    //         ]
    //       }
    //     })
    //     return shape
    //   }
    // })

    // const defaultStateStyles = {
    //   hover: {
    //     stroke: '#91d5ff',
    //     lineWidth: 2
    //   }
    // }

    // const defaultNodeStyle = {
    //   fill: '#91d5ff',
    //   stroke: '#40a9ff',
    //   radius: 5
    // }


    // var _this = this
    // const defaultLayout = {
    //   type: 'compactBox',
    //   direction: 'RL',
    //   getId: function getId(d) {
    //     if (d.direction === 2) {
    //       d.direction = '双向'
    //     } else if (d.direction === 1) {
    //       d.direction = '单向'
    //     } else {
    //       d.direction = ''
    //     }
    //     _this.arr.push(d.direction)
    //     return d
    //   },
    //   getHeight: function getHeight() {
    //     return 16
    //   },
    //   getWidth: function getWidth() {
    //     return 16
    //   },
    //   getVGap: function getVGap() {
    //     return 40
    //   },
    //   getHGap: function getHGap() {
    //     return 80
    //   }
    // }

    // const defaultLabelCfg = {
    //   style: {
    //     fill: '#000',
    //     fontSize: 10
    //   }
    // }

    // const width = document.getElementById('container').scrollWidth
    // const height = document.getElementById('container').scrollHeight || 500

    // const minimap = new G6.Minimap({
    //   size: [150, 100]
    // })
    // const graph = new G6.TreeGraph({
    //   container: 'container',
    //   width,
    //   height,
    //   linkCenter: true,
    //   plugins: [minimap],
    //   modes: {
    //     default: ['drag-canvas', 'zoom-canvas']
    //   },
    //   defaultNode: {
    //     type: 'icon-node',
    //     size: [120, 40],
    //     style: defaultNodeStyle,
    //     labelCfg: defaultLabelCfg
    //   },
    //   defaultEdge: {
    //     type: 'line',
    //     style: {
    //       stroke: '#91d5ff'
    //     }

    //   },
    //   nodeStateStyles: defaultStateStyles,
    //   edgeStateStyles: defaultStateStyles,
    //   layout: defaultLayout
    // })

    // let i = 0
    // graph.edge(function(val) {
    //   i++
    //   return {
    //     type: 'cubic-horizontal',
    //     color: '#A3B1BF',
    //     label: _this.arr[i]
    //   }
    // })

    // graph.data(data)
    // graph.render()
    // graph.fitView()

  },
  methods: {
    addClack() {
      this.show = true
      this.$nextTick(() => {
        this.treeImg()
      })
    },

    treeImg() {
      G6.registerNode('icon-node', {
        draw(cfg, group) {
          const styles = this.getShapeStyle(cfg)
          const { labelCfg = {}} = cfg
          const keyShape = group.addShape('rect', {
            attrs: {
              ...styles,
              x: 0,
              y: 0
            }
          })
          if (cfg.replaceBeforeGoodsName) {
            group.addShape('text', {
              attrs: {
                ...labelCfg.style,
                text: cfg.replaceBeforeGoodsName,
                x: 20,
                y: 27
              }
            })
          }
          return keyShape
        }
      },
      'rect',
      )
      G6.registerEdge('line', {
        draw(cfg, group) {
          const startPoint = cfg.startPoint
          const endPoint = cfg.endPoint

          const { style } = cfg
          const shape = group.addShape('path', {
            attrs: {
              stroke: style.stroke,
              endArrow: style.endArrow,
              path: [
                ['M', startPoint.x, startPoint.y],
                // ['L', startPoint.x, (startPoint.y + endPoint.y) / 2],
                // ['L', endPoint.x, (startPoint.y + endPoint.y) / 2],
                ['L', endPoint.x, endPoint.y]
              ]
            }
          })
          return shape
        }
      })
      const defaultStateStyles = {
        hover: {
          stroke: '#91d5ff',
          lineWidth: 2
        }
      }
      const defaultNodeStyle = {
        fill: '#91d5ff',
        stroke: '#40a9ff',
        radius: 5
      }
      var _this = this
      const defaultLayout = {
        type: 'compactBox',
        direction: 'RL',
        getId: function getId(d) {
          if (d.direction === 2) {
            d.direction = '双向'
          } else if (d.direction === 1) {
            d.direction = '单向'
          } else {
            d.direction = ''
          }
          _this.arr.push(d.direction)
          return d
        },
        getHeight: function getHeight() {
          return 16
        },
        getWidth: function getWidth() {
          return 16
        },
        getVGap: function getVGap() {
          return 40
        },
        getHGap: function getHGap() {
          return 80
        }
      }

      const defaultLabelCfg = {
        style: {
          fill: '#000',
          fontSize: 10
        }
      }

      const width = document.getElementById('container').scrollWidth
      const height = document.getElementById('container').scrollHeight || 500

      const minimap = new G6.Minimap({
        size: [150, 100]
      })
      const graph = new G6.TreeGraph({
        container: 'container',
        width,
        height,
        linkCenter: true,
        plugins: [minimap],
        modes: {
          default: ['drag-canvas', 'zoom-canvas']
        },
        defaultNode: {
          type: 'icon-node',
          size: [120, 40],
          style: defaultNodeStyle,
          labelCfg: defaultLabelCfg
        },
        defaultEdge: {
          type: 'line',
          style: {
            stroke: '#91d5ff'
          }

        },
        nodeStateStyles: defaultStateStyles,
        edgeStateStyles: defaultStateStyles,
        layout: defaultLayout
      })

      let i = 0
      graph.edge(function(val) {
        i++
        return {
          type: 'cubic-horizontal',
          color: '#A3B1BF',
          label: _this.arr[i]
        }
      })
      graph.data(this.data)
      graph.render()
      graph.fitView()
    }
    
    
  }
}
</script>

<style>
#container {
  width: 100%;
  height: 100%;
  border: 1px saddlebrown solid;
}
</style>
