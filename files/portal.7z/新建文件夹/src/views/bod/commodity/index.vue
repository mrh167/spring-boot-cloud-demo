<template>
  <div class="configure">
    <div class="configure-title">
      <div class="title-text">筛选搜索</div>

      <div class="title-serch">
        <div class="serch-left">
          <div class="select-content">
            <span class="content-title">事业部</span>
            <lui-select
              v-model="deptNo"
              style="width: 180px;"
              placeholder="请选择事业部"
              clearable
            >
              <lui-option
                v-for="(item,index) in deptNoList"
                :key="index"
                :label="item.deptName"
                :value="item.deptNo">
              </lui-option>
            </lui-select>
          </div>
          <div class="select-content">
            <span class="content-title">商品状态</span>
            <lui-select
              v-model="bodState"
              clearable
              style="width: 180px;"
              placeholder="请选择商品状态">
              <lui-option
                v-for="(item,index) in bodStateList"
                :key="index"
                :label="item.name"
                :value="item.code">
              </lui-option>
            </lui-select>
          </div>
          <div class="select-content">
            <span class="content-title">BOD</span>
            <lui-input
              v-model="bodNoOrName"
              clearable
              placeholder="搜索BOD编码 / 名称"
              style="width: 180px;">
            </lui-input>
          </div>
          <div class="select-content">
            <span class="content-title">商品编码</span>
            <lui-input
              v-model.trim="goodsNoStr"
              style="width: 180px;"
              clearable
              placeholder="请输入商品编码">
            </lui-input>
          </div>
          <div class="select-content">
            <span class="content-title">商品分类</span>
            <lui-cascader
              ref="cascaderAddr"
              v-model="cate3Idst"
              style="width: 180px;"
              clearable
              placeholder="请选择商品分类"
              :props="propList"
              @change="handleSelectCate"
            ></lui-cascader>
          </div>
          <div class="select-content">
            <span class="content-title">生效时间</span>
            <lui-date-picker
              v-model="startDate"
              clearable
              style="width: 180px;"
              value-format="yyyy-MM-dd"
              type="date"
              :picker-options="pickerBeginDateBefore"
              placeholder="请选择生效日期"
              @change="handleStartTime">
            </lui-date-picker>


          </div>
          <div class="select-content">
            <span class="content-title">失效时间</span>
            <lui-date-picker
              v-model="endDate"
              clearable
              style="width: 180px;"
              value-format="yyyy-MM-dd"
              type="date"
              :picker-options="pickerBeginDateAfter"
              placeholder="请选择失效时间"
              @change="handleEndTime">
            </lui-date-picker>
          </div>
        </div>
      </div>

      <div class="serch-right">
        <lui-button type="primary" style="width: 80px;" @click="handleQuery">查询</lui-button>
        <lui-button style="width: 80px;" @click="handleRest">重置</lui-button>
      </div>
    </div>

    <div class="master-container">
      <div class="container-top">
        <div class="container-top-left">
          <span class="header-border"></span>
          <span class="header-title">数据列表</span>
        </div>
        <div class="container-top-right">
          <lui-button type="primary" @click="handleSet">默认BOD设置</lui-button>
          <button-list :buttons="buttons" @uploadSuccess="getList"></button-list>
          <!--<lui-button type="primary" class="button-upload"><input ref="inputUnbundling" type="file" multiple="multiple" name="file" @change="uploadfile(1)" />批量解绑</lui-button>-->
          <lui-button type="primary" @click="download">批量下载</lui-button>
          <button-list :buttons="buttons2" @uploadSuccess="getList"></button-list>
          <!--<lui-button type="primary" class="button-upload"><input ref="uploadfile" type="file" multiple="multiple" name="file" @change="uploadfile(2)" />批量上传</lui-button>-->
          <lui-button type="primary" @click="handleDel">手工删除</lui-button>
          <lui-button type="primary" @click="handleAdd">手工添加</lui-button>
        </div>
      </div>

      <div class="container-table">
        <div class="container-table-cont">
          <lui-table
            v-loading="LoadingTable"
            :data="tableData"
            style="width: 100%"
            @selection-change="handleSelectionChange">
            <template slot="empty">
              <showEmptyImage></showEmptyImage>
            </template>
            <lui-table-column
              align="center"
              fixed="left"
              type="selection"
              width="50">
            </lui-table-column>

            <lui-table-column
              prop="deptNo"
              min-width="170"
              label="事业部编码"
              show-overflow-tooltip>
            </lui-table-column>

            <lui-table-column
              prop="deptName"
              label="事业部名称"
              min-width="170"
              show-overflow-tooltip>
            </lui-table-column>

            <lui-table-column
              prop="bodNo"
              label="BOD编码"
              min-width="210"
              show-overflow-tooltip>
            </lui-table-column>

            <lui-table-column
              prop="bodName"
              label="BOD名称"
              min-width="170"
              show-overflow-tooltip>
            </lui-table-column>

            <!--<lui-table-column
              label="分配有效期"
              width="210"
              show-overflow-tooltip>
              <template v-slot="{row}">
                <p v-if="row.alwaysEffective">始终有效</p>
                <p v-else>{{ row.startTime }}&nbsp;&nbsp;至&nbsp;&nbsp;{{ row.endTime }}</p>
              </template>
            </lui-table-column>-->

            <lui-table-column
              prop="updateUser"
              width="130"
              label="修改人"
              show-overflow-tooltip>
            </lui-table-column>

            <lui-table-column
              prop="updateTime"
              width="160"
              label="修改时间"
              show-overflow-tooltip>
            </lui-table-column>
            <lui-table-column
              fixed="right"
              width="120"
              align="center"
              label="操作">
              <template v-slot="{row}">
                <div class="table-button">
                  <lui-button type="text" @click="handleEdit(row)">编辑</lui-button>
                  <lui-button type="text" @click="handleDetails(row)">分配详情</lui-button>
                </div>
              </template>
            </lui-table-column>
          </lui-table>
        </div>
        <div v-show="tableData.length>0" class="knowledge-pagination">
          <lui-pagination
            background
            :current-page.sync="pageNum"
            :page-sizes="[10, 20, 50, 70, 100]"
            layout="prev, pager, next, sizes, jumper"
            :total="totals"
            @current-change="handleSizeChange"
            @size-change="sizeChange">
          </lui-pagination>
        </div>
      </div>
    </div>
    <!--    新增  -->
    <lui-dialog
      :visible.sync="centerDialogVisible"
      width="90%"
      top="10vh"
      :close-on-click-modal="false"
      custom-class="dialog_mask"
      :title="stateTitle"
      @close="closeDialog('ruleForm')">
      <lui-form
        ref="ruleForm"
        :model="ruleForm"
        :rules="rules"
        label-width="90px"
        class="demo-ruleForm">
        <div class="ruleForm-title">

          <lui-form-item
            label="事业部"
            prop="deptNo">
            <lui-select
              v-model="ruleForm.deptNo"
              :disabled="disabledEdit"
              style="width: 200px;"
              placeholder="请选择事业部"
              @change="deptoChange">
              <lui-option
                v-for="(item,index) in deptNoList"
                :key="index"
                :label="item.deptName"
                :value="item.deptNo">
              </lui-option>
            </lui-select>
          </lui-form-item>

          <lui-form-item
            label="BOD"
            prop="bodName">
            <lui-autocomplete
              v-model="ruleForm.bodName"
              :disabled="disabledEdit"
              style="width: 180px;"
              class="inline-input"
              :fetch-suggestions="QueryAddOrderShop"
              placeholder="输入搜索BOD编码 / 名称"
              @select="handleAddSalesOrderShop"
            ></lui-autocomplete>
          </lui-form-item>


          <lui-form-item
            v-if="checkedShow"
            label="有效期"
            prop="datalist">
            <lui-date-picker
              v-model="ruleForm.datalist"
              style="width: 280px"
              type="daterange"
              range-separator="-"
              start-placeholder="开始日期"
              end-placeholder="结束日期"
              value-format="yyyy-MM-dd"
              format="yyyy-MM-dd"
              :picker-options="pickerOptions1">
            </lui-date-picker>
          </lui-form-item>

          <lui-form-item
            label-width="30px"
            prop="alwaysEffective">
            <lui-checkbox v-model="ruleForm.alwaysEffective" @change="handleChecked">始终有效</lui-checkbox>
          </lui-form-item>
        </div>
        <div class="ruleForm-content">
          <div class="content-title">商品选择:</div>
          <div class="content-left">
            <div class="left-title">
              <!--<span style="cursor: pointer">收起</span>-->
              <span v-if="popupShow1" @click="handleRetract(1)"><i class="lui-icon-arrow-cycle-down" style="transform: rotate(180deg);cursor: pointer;"></i></span>
              <span v-else @click="handleRetract(1)"><i class="lui-icon-arrow-cycle-down"></i></span>
              <span>商品列表</span>
            </div>
            <div class="left-main">
              <div v-show="popupShow1">
                <lui-form-item
                  label="供应商"
                  label-width="110px">
                  <lui-select
                    v-model="leftCondition.supplierName"
                    clearable
                    style="width: 100%;"
                    placeholder="请选择供应商"
                    @change="handleLeftSupplier">
                    <lui-option
                      v-for="(item,index) in BaseGoodsInfoList"
                      :key="index"
                      :label="item.supplierName"
                      :value="item.supplierNo">
                    </lui-option>
                  </lui-select>
                </lui-form-item>

                <lui-form-item
                  label-width="110px"
                  label="商品分类">
                  <lui-cascader
                    ref="cascaderAddr"
                    v-model="leftCondition.cate3Idst"
                    clearable
                    style="width: 100%;"
                    placeholder="请选择商品分类"
                    :props="propList"
                    @change="handleCommodity(1)"
                  ></lui-cascader>
                </lui-form-item>

                <lui-form-item
                  label-width="110px"
                  label="商品名称">
                  <lui-input
                    v-model.trim="leftCondition.goodsName"
                    clearable
                    style="width: 100%;"
                    placeholder="请输入搜索商品编码 / 名称">
                  </lui-input>
                </lui-form-item>

                <lui-row :gutter="20">
                  <lui-col :span="24" style="text-align: right;margin-bottom: 20px;">
                    <lui-button :disabled="buttonQuery" @click="handleAddRest(1)">重置</lui-button>
                    <lui-button :disabled="buttonQuery" type="primary" @click="handleQueryLeft(1)">查询</lui-button>
                  </lui-col>
                </lui-row>
              </div>

              <lui-table
                ref="multipleTable"
                :data="leftTableDate"
                style="width: 100%"
                @selection-change="handleLeftSelect">
                <lui-table-column
                  align="center"
                  type="selection"
                  :selectable="checkSelectable"
                  width="50">
                </lui-table-column>

                <lui-table-column
                  prop="goodsNo"
                  label="商品编码"
                  show-overflow-tooltip>
                </lui-table-column>

                <lui-table-column
                  prop="goodsName"
                  label="商品名称"
                  show-overflow-tooltip>
                </lui-table-column>
              </lui-table>

              <div v-show="leftTableDate.length>0" style="margin: 15px 0" class="knowledge-pagination">
                <lui-pagination
                  background
                  :current-page.sync="leftCondition.pageNum"
                  layout="prev, pager, next"
                  :total="leftCondition.totals"
                  @current-change="handleLeftSizeChange">
                </lui-pagination>
              </div>
            </div>
          </div>
          <div class="content-cont">
            <span class="lui-icon-arrow-right" @click="handleCopyRight(1)"></span>
            <span class="lui-icon-arrow-left" @click="handleCopyRight(2)"></span>
          </div>
          <div class="content-right">
            <div class="left-title">
              <span v-if="popupShow2" @click="handleRetract(2)"><i class="lui-icon-arrow-cycle-down" style="transform: rotate(180deg);cursor: pointer;"></i></span>
              <span v-else @click="handleRetract(2)"><i class="lui-icon-arrow-cycle-down"></i></span>
              <span>已选商品列表</span>
            </div>
            <div class="left-main">
              <div v-show="popupShow2">
                <lui-form-item
                  label="供应商"
                  label-width="110px">
                  <lui-select
                    v-model="rightCondition.supplierName"
                    clearable
                    style="width: 100%;"
                    placeholder="请选择供应商">
                    <lui-option
                      v-for="(item,index) in BaseGoodsInfoList"
                      :key="index"
                      :label="item.supplierName"
                      :value="item.supplierNo">
                    </lui-option>
                  </lui-select>
                </lui-form-item>

                <lui-form-item
                  label-width="110px"
                  label="商品分类">
                  <lui-cascader
                    ref="cascaderAddr"
                    v-model="rightCondition.cate3Idst"
                    clearable
                    style="width: 100%;"
                    placeholder="请选择商品分类"
                    :props="propList"
                    @change="handleCommodity(2)"
                  ></lui-cascader>
                </lui-form-item>

                <lui-form-item
                  label-width="110px"
                  label="商品名称">
                  <lui-input
                    v-model.trim="rightCondition.goodsName"
                    clearable
                    style="width: 100%;"
                    placeholder="请输入搜索商品编码 / 名称">
                  </lui-input>
                </lui-form-item>

                <lui-row :gutter="20">
                  <lui-col :span="24" style="text-align: right;margin-bottom: 20px;">
                    <lui-button @click="handleAddRest(2)">重置</lui-button>
                    <lui-button type="primary" @click="handleQueryLeft(2)">查询</lui-button>
                  </lui-col>
                </lui-row>
              </div>

              <lui-table
                :data="rightTableDate"
                style="width: 100%"
                @selection-change="handleAddSelect">
                <lui-table-column
                  fixed="left"
                  align="center"
                  type="selection"
                  width="50">
                </lui-table-column>

                <lui-table-column
                  width="150"
                  prop="goodsNo"
                  label="商品编码"
                  show-overflow-tooltip>
                </lui-table-column>

                <lui-table-column
                  prop="goodsName"
                  min-width="150"
                  label="商品名称"
                  show-overflow-tooltip>
                </lui-table-column>

                <lui-table-column
                  width="300"
                  label="启用时间">
                  <template v-slot="scope">
                    <lui-date-picker
                      v-if="scopeTime"
                      v-model="scope.row.mainTime"
                      style="width: 280px"
                      type="daterange"
                      value-format="yyyy-MM-dd"
                      range-separator="-"
                      start-placeholder="启用日期"
                      end-placeholder="结束日期"
                      @input="handleTime(scope)"
                    >
                    </lui-date-picker>
                  </template>
                </lui-table-column>
              </lui-table>
              <div v-show="rightTableDateLsit.length>0" style="margin: 15px 0" class="knowledge-pagination">
                <lui-pagination
                  background
                  :current-page.sync="rightCondition.pageNum"
                  layout="prev, pager, next"
                  :total="rightCondition.totals"
                  @current-change="handleRightSizeChange">
                </lui-pagination>
              </div>
            </div>
          </div>
        </div>
      </lui-form>
      <span slot="footer" class="dialog-footer">
        <lui-button @click="resetForm('ruleForm')">取 消</lui-button>
        <lui-button type="primary" @click="submitForm('ruleForm')">提 交</lui-button>
      </span>
    </lui-dialog>
    <!--    默认BOD设置  -->
    <lui-dialog
      :visible.sync="setDialogVisible"
      width="60%"
      top="10vh"
      :close-on-click-modal="false"
      custom-class="dialog_mask"
      :title="setBodTitle"
      @close="closeSetDialog('setruleForm')">
      <lui-form
        ref="setruleForm"
        :model="setForm"
        :rules="setRules"
        label-width="80px"
        class="setdemo-ruleForm">
        <lui-row :gutter="20">

          <lui-col :span="12">
            <lui-form-item
              label="事业部"
              prop="deptNo">
              <lui-select
                v-model="setForm.deptNo"
                style="width: 200px;"
                placeholder="请选择事业部"
                @change="deptoChangemr">
                <lui-option
                  v-for="(item,index) in deptNoList"
                  :key="index"
                  :label="item.deptName"
                  :value="item.deptNo">
                </lui-option>
              </lui-select>
            </lui-form-item>
          </lui-col>


          <lui-col :span="12">
            <lui-form-item
              label="BOD："
              prop="bodNo">
              <lui-autocomplete
                v-model="setForm.bodName"
                clearable
                style="width: 200px;"
                class="inline-input"
                :fetch-suggestions="handleSetBod"
                placeholder="输入搜索BOD编码 / 名称"
                @select="handleSetBodSelect"
              ></lui-autocomplete>
            </lui-form-item>
          </lui-col>
          <lui-col v-if="setForm.bodNo!==''" :span="12">
            <!--<lui-form-item
              label="事业部：">
              <p>{{ setForm.deptName }}</p>
            </lui-form-item>-->
          </lui-col>
        </lui-row>
        <lui-row :gutter="20">

          <lui-col v-if="setForm.bodNo!==''" :span="12">
            <lui-form-item
              label="有效期：">
              <p>{{ setForm.time }}</p>
            </lui-form-item>
          </lui-col>
        </lui-row>
        <div class="setAddBut">
          <lui-button type="primary" @click="handleSetAdd('setruleForm')">添 加</lui-button>
        </div>

        <div class="container-table-cont container-page">
          <lui-table
            v-loading="LoadingSetTable"
            :data="tableBodData"
            style="width: 100%">
            <lui-table-column
              prop="sellerName"
              label="商家"
              show-overflow-tooltip>
            </lui-table-column>

            <lui-table-column
              prop="deptName"
              label="商家事业部"
              show-overflow-tooltip>

            </lui-table-column>

            <lui-table-column
              prop="bodName"
              label="BOD名称"
              show-overflow-tooltip>
            </lui-table-column>

            <lui-table-column
              prop="goodsNo"
              label="BOD有效期"
              width="210">
              <template v-slot="{row}">
                <p>
                  <span>{{ row.startDate }}</span>
                  <span>至</span>
                  <span>{{ row.endDate }}</span></p>
              </template>
            </lui-table-column>

            <lui-table-column
              align="center"
              width="80"
              label="操作">
              <template v-slot="{row}">
                <div class="table-button" style="cursor: pointer;">
                  <lui-button type="text" @click="handleSetDel(row)">删除</lui-button>
                </div>
              </template>
            </lui-table-column>
          </lui-table>
          <div v-show="tableBodData.length>0" class="knowledge-pagination">
            <lui-pagination
              background
              :current-page.sync="setPageNum"
              layout="prev, pager, next"
              :total="setTotals"
              @current-change="handleSetSizeChange">
            </lui-pagination>
          </div>
        </div>

      </lui-form>

      <span slot="footer" class="dialog-footer">
        <lui-button @click="resetSetForm('setRules')">关 闭</lui-button>
      </span>
    </lui-dialog>
    <!--    分配详情-->
    <lui-dialog
      :visible.sync="detailsDialogVisible"
      width="90%"
      top="10vh"
      :close-on-click-modal="false"
      custom-class="dialog_mask"
      title="BOD商品分配详情">
      <div class="details">
        <div class="details-cont">
          <div class="cont-title">商家：</div>
          <div class="cont-content">{{ editForm.sellerName }}</div>
        </div>

        <div class="details-cont">
          <div class="cont-title">事业部：</div>
          <div class="cont-content">{{ editForm.deptName }}</div>
        </div>

        <div class="details-cont">
          <div class="cont-title">BOD名称：</div>
          <div class="cont-content">{{ editForm.bodName }}</div>
        </div>

        <div class="details-cont">
          <div class="cont-title">BOD编码：</div>
          <div class="cont-content">{{ editForm.bodNo }}</div>
        </div>

        <div class="details-cont">
          <div class="cont-title">有效期：</div>
          <div class="cont-content">{{ editForm.time }}</div>
        </div>


      </div>

      <div class="details-main">
        <div class="main-left">
          <lui-table
            :data="tableBodEdit"
            style="width: 100%">
            <lui-table-column
              prop="goodsNo"
              show-overflow-tooltip
              label="商品编码">
            </lui-table-column>

            <lui-table-column
              prop="goodsName"
              show-overflow-tooltip
              label="商品名称">
              <!-- <template v-slot="{row}">
                <lui-tooltip
                  class="item"
                  effect="dark"
                  :content="row.goodsName"
                  placement="bottom-start">
                  <p class="table-p">{{ row.goodsName }}</p>
                </lui-tooltip>
              </template> -->
            </lui-table-column>

            <lui-table-column
              label="启用时间"
              width="210">
              <template v-slot="{row}">
                <p>{{ row.startTime }} 至 {{ row.endTime }}</p>
              </template>
            </lui-table-column>

            <lui-table-column
              prop="effectiveDesc"
              label="状态"
              width="80">
            </lui-table-column>


          </lui-table>
          <div style="margin: 15px 0" class="knowledge-pagination">
            <lui-pagination
              background
              :current-page.sync="editPageNum"
              layout="prev, pager, next"
              :total="editTotals"
              @current-change="handleDetailsSizeChange">
            </lui-pagination>
          </div>
        </div>
        <div class="main-right">
          <div class="right-title">BOD预览:</div>
          <div class="right-main">
            <div class="main-mask"></div>
            <bod-tree
              :data="bodNode"
              :horizontal="true"
              :render-content="renderContent"
              :judge="judge"
              :node-class="NodeClass"
            />
          </div>
        </div>
      </div>
      <span slot="footer" class="dialog-footer">
        <lui-button @click="resetFormSet('setRules')">关 闭</lui-button>
      </span>
    </lui-dialog>
    <!--批量上传失败提示-->
    <lui-dialog
      class="error-dialog"
      :title="updatedTitle"
      :visible.sync="dialogTableVisible"
      :close-on-click-modal="false">
      <div class="dialog-table-list">
        <div v-show="moreErr" style="color: red;font-size: 12px">异常太多，最多显示300条</div>
        <lui-table
          stripe
          size="mini"
          :data="gridData">
          <lui-table-column
            align="center"
            label="行号"
            width="150">
            <template slot-scope="{row}">
              <p>第{{ row.rowNo }}行异常</p>
            </template>
          </lui-table-column>

          <lui-table-column
            prop="errorMsg"
            align="center"
            label="异常原因"
            show-overflow-tooltip>
          </lui-table-column>
        </lui-table>
      </div>
    </lui-dialog>
    <!-- 新增编辑提示-->
    <lui-dialog
      class="error-dialog"
      title="新增失败"
      :visible.sync="dialogNewTableVisible"
      :close-on-click-modal="false">
      <div class="dialog-table-list">
        <div v-show="moreErrList" style="color: red;font-size: 12px">异常太多，最多显示300条</div>
        <lui-table
          stripe
          size="mini"
          :data="gridDataList">
          <lui-table-column align="center" property="tip" label="编号">
            <template slot-scope="{row}">
              {{ row.tip }}
            </template>
          </lui-table-column>

          <lui-table-column align="center" property="msg" label="异常原因">
            <template slot-scope="{row}">
              {{ row.msg }}
            </template>
          </lui-table-column>


        </lui-table>
      </div>
    </lui-dialog>
  </div>
</template>

<script>
import http from '@/lib/http'
import { exportExcel } from '@/utils/downloadRequest'
import ButtonList from '@/views/common/ButtonList'
import showEmptyImage from '@/components/common/showEmptyImage/index.vue'
import BodTree from '../common/org-tree/org-tree.vue'
import Api from '@/api'
import $ from 'jquery'
const buttons = {
  upload: {
    noAsync: true,
    maxM: 10,
    uploadtips: '只能上传xlsx文件，文件大小不超过10M',
    label: '批量解绑',
    uploadConfig: {
      uploadActionUrl: http.baseContextUrl + 'bodGoods/unbindUpload'
    },
    templateUrl: http.baseContextUrl + 'bodGoods/unbindTemplateDownload'
  }
}
const buttons2 = {
  upload: {
    noAsync: true,
    maxM: 10,
    uploadtips: '只能上传xlsx文件，文件大小不超过10M',
    label: '批量上传',
    uploadConfig: {
      uploadActionUrl: http.baseContextUrl + 'bodGoods/upload'
    },
    templateUrl: http.baseContextUrl + 'bodGoods/templateDownload'
  }
}
export default {
  name: 'configure.veu',
  components: {
    showEmptyImage,
    ButtonList,
    BodTree
  },
  data() {
    return {
      gridDataList: [],
      moreErrList: false,
      dialogNewTableVisible: false,
      scopeTime: true,
      //=============================> 上传
      checkDeptNo: false, //默认false表示不上传事业部
      baseURL: http.baseContextUrl,
      buttons,
      buttons2,
      //=============================> 详情
      editPageSize: 10,
      editPageNum: 1,
      editTotals: 1,
      detailsDialogVisible: false,
      tableBodEdit: [], //数据列表
      editForm: {
        bodName: '',
        bodNo: '',
        time: '',
        deptNo: ''
      },
      //=============================>列表、查询条件
      updatedTitle: '批量上传',
      dialogTableVisible: false, //上传失败返回数据
      gridData: [],
      moreErr: false,
      bodState: '', //bod状态
      goodsNoStr: '', //商品编码
      bodNoOrName: '', //Bod编码
      cate3Id: '', //商品分类ID
      cate3Idst: '',
      bodName: '', //BOD输入
      deptNo: '', //事业部编码
      endDate: '', //结束时间
      startDate: '', //开始时间
      pickerBeginDateBefore: {}, //生效时间
      pickerBeginDateAfter: {}, //失效时间
      totals: 0, //总条数
      pageNum: 1, //页
      pageSize: 10, //条数
      LoadingTable: false,
      deptNoList: [], //事业部列表
      multipleSelection: [], //全选反选
      tableData: [], //列表数据
      bodStateList: [
        {
          code: 2,
          name: '启用'
        }, {
          code: 4,
          name: '预警'
        }, {
          code: 3,
          name: '禁用'
        }
      ],
      //================================================> BOD设置
      tableBodData: [], //bod 设置数据
      setTotals: 0, //总条数
      setPageNum: 1, //页
      setPageSize: 10, //条数
      LoadingSetTable: false,
      setBodTitle: '默认BOD设置', //默认BOD设置 title
      setDialogVisible: false, //默认BOD设置弹窗===>新增
      setForm: {
        deptNo: '', //事业部
        bodNo: '', //bod
        bodName: '', //bod
        time: ''
      },
      setRules: {
        deptNo: [{ required: true, message: '请选择事业部', trigger: ['blur', 'change'] }], //测试字段
        bodNo: [{ required: true, message: '请选择BOD', trigger: ['blur', 'change'] }] //测试字段
      },
      //================================================> 新增、编辑条件
      popupShow1: true,
      popupShow2: true,
      nowTimeNew: '',
      pickerOptions1: {},
      disabledEdit: false,
      buttonQuery: true,
      multipleLeftSelection: [], //全选反选
      leftTableDate: [], //左数据列表
      leftCondition: {
        supplierName: '', //供应商名称
        supplierNo: '', //供应商编号
        cate3Idst: '', //商品分类
        cate3Id: '', //商品分类ID
        goodsName: '', //商品名称
        totals: 0, //总条数
        pageNum: 1, //页
        pageSize: 10 //条数
      },
      multipleRightSelection: [], //全选反选
      rightTableDate: [], //右数据列表
      rightTableDateLsit: [], //右数据列表
      rightCondition: {
        supplierName: '', //供应商名称
        supplierNo: '', //供应商编码
        cate3Idst: '', //商品分类
        cate3Id: '', //商品分类ID
        goodsName: '', //商品名称
        totals: 0, //总条数
        pageNum: 1, //页
        pageSize: 10 //条数
      },
      centerDialogVisible: false, //弹窗===>新增
      checkedShow: true, //有效期显示隐藏
      stateTitle: '新增BOD商品分配',
      BaseGoodsInfoList: [], //供应商列表获取
      ruleForm: { //新增条件
        alwaysEffective: false, //始终有效
        bodNo: '', //bod编码
        bodName: '', //bod名称
        deptNo: '', //事业部编码
        deptName: '', //事业部名称
        datalist: [], //时间容器
        defaultEndTime: '', //结束时间
        defaultStartTime: '', //开始时间
        bodGoodsList: [ //BOD商品集合
          {
            cate1Id: '', //一级分类ID
            cate1Name: '', //一级分类名称
            cate2Id: '', //一级分类ID
            cate2Name: '', //一级分类名称
            cate3Id: '', //一级分类ID
            cate3Idst: '', //一级分类ID
            cate3Name: '', //一级分类名称
            goodsName: '', //商品名称
            goodsNo: '', //商品编码
            supplierName: '', //供应商名称
            supplierNo: '', //供应商编码
            endTime: '', //商品生效结束时间
            startTime: '' //商品生效开始时间
          }
        ]
      },
      rules: {
        deptNo: [{ required: true, message: '请选择事业部', trigger: ['blur', 'change'] }], //事业部选择
        bodName: [{ required: true, message: '请选择BOD', trigger: ['blur', 'change'] }], //BOD 数据选择
        datalist: [{ required: false, message: '请选择有效期', trigger: ['blur', 'change'] }] //BOD 数据选择
      },
      //打开分配详情树形结构展示
      bodNode: {},
      //============================>详情树形结构显示
      judge: {
        switch: true
      },
      NodeClass: ['factory', 'rdc', 'fdc', 'cdc', 'store', 'tc'],
      transportList: [] //运输方式
    }
  },
  computed: {
    propList() {
      return {
        lazy: true,
        lazyLoad(node, resolve) {
          if (node) {
            if (node.level === 0) {
              Api.BodCommodity.category().then(res => {
                const cities = res.data.map((value) => ({
                  value: value.cate1Id,
                  label: value.cate1Name,
                  leaf: node.level >= 2 //控制几级数据
                }))
                // 通过调用resolve将子节点数据返回，通知组件数据加载完成
                resolve(cities)
              }).catch((e) => {
                this.$showErrorMsg(e)
              })
            }
            if (node.level === 1) {
              Api.BodCommodity.category({
                cate1Id: node.value
              }).then(res => {
                const cities = res.data.map((value) => ({
                  value: value.cate2Id,
                  label: value.cate2Name,
                  leaf: node.level >= 2 //控制几级数据
                }))
                // 通过调用resolve将子节点数据返回，通知组件数据加载完成
                resolve(cities)
              }).catch((e) => {
                this.$showErrorMsg(e)
              })
            }
            if (node.level === 2) {
              Api.BodCommodity.category({
                cate1Id: node.path[0],
                cate2Id: node.path[1]
              }).then(res => {
                const cities = res.data.map((value) => ({
                  value: value.cate3Id,
                  label: value.cate3Name,
                  leaf: node.level >= 2 //控制几级数据
                }))
                // 通过调用resolve将子节点数据返回，通知组件数据加载完成
                resolve(cities)
              }).catch((e) => {
                this.$showErrorMsg(e)
              })
            }
          }
        }
      }
    }
  },
  mounted() {
    this.getList() //数据列表
    this.queryDept() //事业部
    //运输方式
    this.transport()
    //开始日期小于结束日期
    this.pickerOptions1 = {
      disabledDate: (time) => {
        if (this.nowTimeNew) {
          // const day1 = 366 * 24 * 3600 * 1000
          // const maxTime = this.nowTimeNew + day1
          // const minTime = this.nowTimeNew - day1
          // return time.getTime() < maxTime || time.getTime() < minTime || time.getTime() > Date.now() - 1 * 24 * 3600 * 1000
          return time.getTime() < Date.now(this.nowTimeNew) - 1 * 24 * 3600 * 1000
        } else {
          return time.getTime() < Date.now() - 1 * 24 * 3600 * 1000
        }
      }
    }
  },
  methods: {
    dataAjax() { //获取当前时间
      const now = new Date($.ajax({ async: false }).getResponseHeader('Date'))
      this.nowTimeNew = now.getTime()
    },
    //========================================================================================> 默认BOD设置
    // 获取BOD下拉模糊搜索
    handleSetBod(queryString, cb) {
      Api.BodConfig.getBaseByBodNo({
        bodNo: this.setForm.bodName,
        deptNo: this.setForm.deptNo

      }).then(res => {
        if (res.success) {
          var results = []
          if (res.data.length > 0) {
            for (let i = 0, len = res.data.length; i < len; i++) {
              res.data[i].value = res.data[i].bodName
            }
            results = res.data
          } else {
            this.$showErrorMsg('没有找到对应BOD')
          }
          cb(results)
        }
      }).catch((e) => {})
    },
    // 选择BOD下拉模糊搜索
    handleSetBodSelect(item) {
      this.setForm.time = item.startDate + ' 至 ' + item.endDate
      this.setForm.deptName = item.deptName
      this.setForm.deptNo = item.deptNo
      this.setForm.bodNo = item.bodNo
    },
    //关闭弹窗×
    closeSetDialog(type) {
      if (type) {
        this.setForm = {
          deptNo: '', //事业部
          bodNo: '', //bod
          bodName: '', //bod
          time: ''
        }
        this.$refs[type].resetFields()
        this.setDialogVisible = false
      }
    },
    //重新赋值
    deptoChangemr(val) {
      this.setForm.bodName = ''
      this.setForm.bodNo = ''
    },



    //默认BOD设置打开
    handleSet() {
      this.setDialogVisible = true
      this.defaultBod()
    },
    //取消
    resetSetForm(setRules) {
      this.setDialogVisible = false
    },
    //删除
    handleSetDel(res) {
      const array = []
      this.$alert('<p style="font-size: 18px;color:#333">确认删除此条BOD消息吗?</p><p style="font-size: 13px;color: #666">删除后，此条BOD消息的相关内容信息将无法恢复</p>', '', {
        dangerouslyUseHTMLString: true,
        type: 'warning',
        center: true
      }).then(() => {
        array.push(res.id)
        //===============================================接口待修改
        Api.BodCommodity.cancelDefaultBod({ bodNo: res.bodNo }).then(row => {
          if (row.success) {
            this.$showSuccessMsg('删除成功')
            this.defaultBod()
          } else {
            this.$showErrorMsg(row.errMessage)
          }
        }).catch((e) => { this.$showErrorMsg(e) })
      }).catch(() => {})
    },
    //bod新增
    handleSetAdd(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          this.LoadingSetTable = true
          Api.BodCommodity.settingDefaultBod({
            bodNo: this.setForm.bodNo,
            cover: false
          }).then(res => {
            if (res.success) {
              if (res.data === '0001') {
                this.$confirm('此事业部已添加默认BOD，是否进行覆盖?', '提示', {
                  confirmButtonText: '是',
                  cancelButtonText: '否',
                  type: 'warning'
                }).then(() => {
                  Api.BodCommodity.settingDefaultBod({
                    bodNo: this.setForm.bodNo,
                    cover: true
                  }).then(row => {
                    if (row.success) {
                      this.$showSuccessMsg('添加成功')
                      this.defaultBod()
                      this.LoadingSetTable = false
                    } else {
                      this.$showSuccessMsg('添加失败')
                      this.LoadingSetTable = false
                    }
                  }).catch((e) => {
                    this.$showSuccessMsg(e)
                    this.LoadingSetTable = false
                  })
                }).catch(() => {
                  this.$message({
                    type: 'info',
                    message: '已取消添加'
                  })
                  this.LoadingSetTable = false
                })
              } else {
                this.$showSuccessMsg('添加成功')
                this.defaultBod()
                this.LoadingSetTable = false
              }
            }

          }).catch((e) => {
            this.$showErrorMsg(e)
            this.LoadingSetTable = false
          })
        }
      })
    },
    //默认BOD列表
    defaultBod() {
      Api.BodCommodity.defaultBod({
        pageNum: this.setPageNum,
        pageSize: this.setPageSize
      }).then(res => {
        if (res.success) {
          this.tableBodData = res.data
          this.setTotals = res.total
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
      })
    },
    //翻页-----根据页码变换
    handleSetSizeChange(val) {
      this.setPageNum = val
      this.defaultBod()
    },
    //========================================================================================> 编辑条件
    handleEdit(item) {
      this.disabledEdit = true
      this.popupShow1 = true
      this.popupShow2 = true
      // this.checkedShow = true
      this.checkedShow = !item.alwaysEffective
      this.ruleForm.alwaysEffective = item.alwaysEffective
      //判断有效期是否显示隐藏
      //始终有效时间不回显
      if (item.alwaysEffective) {
        this.ruleForm.dataList = []
      } else {
        this.ruleForm.datalist = [item.startDate, item.endDate]
      }
      this.buttonQuery = true
      this.BaseGoodsInfoList = [] //供应商列表清空
      this.leftTableDate = [] //左数据列表
      this.leftCondition = {
        supplierName: '', //供应商名称
        supplierNo: '', //供应商编号
        cate3Idst: '', //商品分类
        cate3Id: '', //商品分类ID
        goodsName: '', //商品名称
        totals: 0, //总条数
        pageNum: 1, //页
        pageSize: 10 //条数
      }
      this.rightTableDate = [] //右数据列表
      this.rightTableDateLsit = []//右数据列表
      this.rightCondition = {
        supplierName: '', //供应商名称
        cate3Idst: '', //商品分类
        cate3Id: '', //商品分类ID
        goodsName: '', //商品名称
        totals: 0, //总条数
        pageNum: 1, //页
        pageSize: 10 //条数
      }
      Api.BodCommodity.getBodGoodsByBodNo({ bodNo: item.bodNo }).then(res => {
        if (res.success) {
          this.centerDialogVisible = true
          this.ruleForm.bodNo = item.bodNo
          this.ruleForm.bodName = item.bodName
          this.ruleForm.deptNo = item.deptNo
          this.ruleForm.deptName = item.deptName
          this.ruleForm.id = item.id
          // this.ruleForm.datalist = [item.startTime, item.endTime]
          this.rightTableDateLsit = res.data
          this.getLeftList()//回显
          this.baseSupplierInfo(item.deptNo)
          this.buttonQuery = false
          for (let i = 0; i < this.rightTableDateLsit.length; i++) {
            this.rightTableDateLsit[i].mainTime = [this.rightTableDateLsit[i].startTime, this.rightTableDateLsit[i].endTime]
          }
          this.rightCondition.totals = this.rightTableDateLsit.length
          if (this.rightCondition.pageNum === 1) {
            this.rightTableDate = this.rightTableDateLsit.slice(0, this.rightCondition.pageSize)
          } else {
            this.rightTableDate = this.rightTableDateLsit.slice(this.rightCondition.pageSize * (this.rightCondition.pageNum - 1), this.rightCondition.pageSize * this.rightCondition.pageNum)
          }
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
      })
    },
    //========================================================================================> 分配详情
    //弹窗分配详情
    handleDetails(item) {
      this.editForm = {
        bodName: item.bodName,
        bodNo: item.bodNo,
        time: item.startDate + ' 至 ' + item.endDate,
        deptName: item.deptName,
        sellerName: item.sellerName
      }
      this.detailsDialogVisible = true
      this.detailsList()
      this.getCanvas(item)
    },
    //运输方式
    transport() {
      Api.BodConfig.transportMode()
        .then((res) => {
          if (res.success) {
            this.transportList = res.data
          }
        }).catch((e) => {
          this.$showErrorMsg(e)
        })
    },
    resetFormSet(setRules) {
      this.detailsDialogVisible = false
    },
    //========================================================================================> 分配详情树形结构展示
    getCanvas(item) {
      this.bodNode = {}
      Api.BodConfig.getNodesByBodNo({
        bodNo: item.bodNo
      }).then(res => {
        if (res.success) {
          const data = {
            dayNum: '1', //最低可配天数
            distributionPatio: '1', //最大可配占比
            distributionRules: '1', //分配规则
            parentNodeNo: '1', //上游节点编码
            priority: '1', //级别
            nodeNo: '1', //节点编码
            transportMode: '1', //运输方式
            label: '入口仓',
            level: 1,
            type: '',
            tips: '',
            children: []
          }
          this.bodNode = data
          this.bodNode.children = res.data.bodNode.children
          const data2 = []
          data2.push(this.bodNode)
          this.editBod(res.data.bodNode.children)
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
      })
    },
    renderContent(h, data) {
      //如果是入口仓返回-----------------------------------------------------需要修改
      if (data.label === '入口仓') {
        return h('div', { class: ['testparents'] }, [
          h('span', { class: ['taspam'] }, data.label),
          h('p', { class: ['testp'] }, data.nodeName) //标题
        ])
      } else {
        //判断是否为第一层库节点是机会隐藏运输方式
        if (data.parentNodeNo === 1 || data.parentNodeNo == null) {
          return h('div', { class: ['testparent'] }, [
            h('span', { class: ['taspam'] }, data.label),
            h('p', { class: ['testp'] }, data.nodeName), //标题
            h('i', { class: ['iconts lui-icon-caret-right'] }) //icon 图标
          ])
        } else {
          return h('div', { class: ['testparent'] }, [
            h('span', { class: ['testchild'] }, data.transportModeName),
            h('span', { class: ['taspam'] }, data.label),
            h('p', { class: ['testp'] }, data.nodeName), //标题
            h('i', { class: ['iconts lui-icon-caret-right'] }) //icon 图标
          ])
        }
      }
    },
    //========================================================================================> 树形方法结束
    changeChecked(source) {
      for (var i in source) {
        const item = source[i]
        if (item.type === 'factory') {
          item.switch = 'factory'
        } else if (item.type === 'fdc') {
          item.switch = 'fdc'
        } else if (item.type === 'rdc') {
          item.switch = 'rdc'
        } else if (item.type === 'cdc') {
          item.switch = 'cdc'
        } else if (item.type === 'store') {
          item.switch = 'store'
        } else if (item.type === 'tc') {
          item.switch = 'tc'
        } else {
          item.switch = '1'
        }
        if (item.children && item.children.length > 0) {
          this.changeChecked(item.children)
        }
      }
    },
    //图标赋值
    editBod(arr) {
      for (let i = 0; i < arr.length; i++) {
        switch (arr[i].nodeType) { //根据库节点判断图形形态
          case 1:
          case 8:
            arr[i].type = 'factory'//工厂
            arr[i].switch = 'factory'
            break
          case 2:
            arr[i].type = 'fdc'//区域仓
            arr[i].switch = 'fdc'
            break
          case 3:
            arr[i].type = 'rdc'//前置仓
            arr[i].switch = 'rdc'
            break
          case 5:
          case 9:
            arr[i].type = 'cdc'//中央仓
            arr[i].switch = 'cdc'
            break
          case 4:
          case 6:
          case 7:
            arr[i].type = 'store' //门店
            arr[i].switch = 'store'
            break
          case 10:
            arr[i].type = 'tc' //TC仓库
            arr[i].switch = 'tc'
            break
        }
        //子节点编辑字段
        arr[i].isSet = false
        for (let j = 0; j < this.transportList.length; j++) {
          if (arr[i].transportMode === this.transportList[j].code) {
            arr[i].transportModeName = this.transportList[j].name
          }
        }
        if (arr[i].children) {
          this.editBod(arr[i].children)
        }
      }
    },
    //分配详情翻页
    handleDetailsSizeChange(val) {
      this.editPageNum = val
      this.detailsList()
    },
    //列表页
    detailsList() {
      Api.BodCommodity.bodGoodDetailPage({
        pageSize: this.editPageSize,
        pageNum: this.editPageNum,
        bodNo: this.editForm.bodNo
      }).then(res => {
        if (res.success) {
          this.tableBodEdit = res.data
          this.editTotals = res.total
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
      })
    },
    //========================================================================================> 新增条件
    //显示隐藏搜索条件
    handleRetract(item) {
      switch (item) {
        case 1:
          this.popupShow1 = !this.popupShow1
          break
        case 2:
          this.popupShow2 = !this.popupShow2
          break
      }
    },
    //事业部选取
    deptoChange(val) {
      var obj = {} //多条件查找
      obj = this.deptNoList.find(function(item) {
        return item.deptNo === val
      })
      this.ruleForm.deptName = obj.deptName
      this.ruleForm.bodNo = ''
      this.ruleForm.bodName = ''
      this.baseSupplierInfo(val)
      this.rightCondition.supplierName = ''
      this.buttonQuery = false
      this.leftCondition = {
        supplierName: '', //供应商名称
        supplierNo: '', //供应商编号
        cate3Idst: '', //商品分类
        cate3Id: '', //商品分类ID
        goodsName: '', //商品名称
        totals: 0, //总条数
        pageNum: 1, //页
        pageSize: 10 //条数
      }
      this.rightCondition = {
        supplierName: '', //供应商名称
        cate3Idst: '', //商品分类
        cate3Id: '', //商品分类ID
        goodsName: '', //商品名称
        totals: 0, //总条数
        pageNum: 1, //页
        pageSize: 10 //条数
      }
    },
    //打开新增弹窗
    handleAdd() {
      this.checkedShow = true
      this.popupShow1 = true
      this.popupShow2 = true
      this.centerDialogVisible = true
      this.disabledEdit = false
      this.buttonQuery = true
      this.BaseGoodsInfoList = [] //供应商列表清空
      this.leftTableDate = [] //左数据列表
      this.leftCondition = {
        supplierName: '', //供应商名称
        supplierNo: '', //供应商编号
        cate3Idst: '', //商品分类
        cate3Id: '', //商品分类ID
        goodsName: '', //商品名称
        totals: 0, //总条数
        pageNum: 1, //页
        pageSize: 10 //条数
      }
      this.rightTableDate = [] //右数据列表
      this.rightTableDateLsit = []//右数据列表
      this.rightCondition = {
        supplierName: '', //供应商名称
        cate3Idst: '', //商品分类
        cate3Id: '', //商品分类ID
        goodsName: '', //商品名称
        totals: 0, //总条数
        pageNum: 1, //页
        pageSize: 10 //条数
      }
      this.ruleForm = { //新增条件
        alwaysEffective: false, //始终有效
        bodNo: '', //bod编码
        bodName: '', //bod名称
        deptNo: '', //事业部编码
        deptName: '', //事业部名称
        datalist: [], //时间容器
        defaultEndTime: '', //结束时间
        defaultStartTime: '' //开始时间
      }
      this.$nextTick(() => {
        this.$refs.ruleForm.clearValidate()
      })
    },
    //新增提交
    submitForm(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          if (this.ruleForm.datalist !== '' && this.ruleForm.datalist != null) {
            this.ruleForm.defaultStartTime = this.ruleForm.datalist[0]
            this.ruleForm.defaultEndTime = this.ruleForm.datalist[1]
          }
          for (let i = 0; i < this.rightTableDateLsit.length; i++) {
            this.rightTableDateLsit[i].startTime = this.rightTableDateLsit[i].mainTime ? this.rightTableDateLsit[i].mainTime[0] : ''
            this.rightTableDateLsit[i].endTime = this.rightTableDateLsit[i].mainTime ? this.rightTableDateLsit[i].mainTime[1] : ''
          }
          this.ruleForm.bodGoodsList = this.rightTableDateLsit

          if (this.ruleForm.bodGoodsList === '') {
            this.$showErrorMsg('请选择商品')
            return
          }


          if (this.disabledEdit) { //编辑
            Api.BodCommodity.batchEditBodGoods(this.ruleForm).then(res => {
              if (res.success) {
                if (res.data.successCount > 0) {
                  this.getList()
                }
                if (res.data.errorCount > 0) {
                  this.dialogNewTableVisible = true
                  this.gridDataList = res.data.detaileds
                  this.moreErrList = res.data.detaileds.length > 300 ? true : false
                } else {
                  this.dialogNewTableVisible = false
                  this.centerDialogVisible = false
                  this.$showSuccessMsg('编辑成功')
                  this.getList()
                }
              } else {
                this.$showSuccessMsg(res.errMessage)
                this.centerDialogVisible = false
              }
            }).catch((e) => {
              this.$showErrorMsg(e)
            })
          } else { //新增
            Api.BodCommodity.batchSaveBodGoods(this.ruleForm).then(res => {
              if (res.success) {
                if (res.data.successCount > 0) {
                  this.getList()
                }
                if (res.data.errorCount > 0) {
                  this.dialogNewTableVisible = true
                  this.gridDataList = res.data.detaileds
                  this.moreErrList = res.data.detaileds.length > 300 ? true : false
                } else {
                  this.dialogNewTableVisible = false
                  this.centerDialogVisible = false
                  this.$showSuccessMsg('新增成功')
                  this.getList()
                }
              } else {
                this.$showSuccessMsg(res.errMessage)
                this.centerDialogVisible = false
              }
            }).catch((e) => {
              this.$showErrorMsg(e)
            })
          }
        }
      })
    },
    //取消新增弹窗
    resetForm(formName) {
      this.$refs[formName].resetFields()
      this.centerDialogVisible = false
    },
    //关闭弹窗×
    closeDialog(type) {
      if (type) {
        this.$refs[type].resetFields()
        this.centerDialogVisible = false
      }
    },
    //始终有效控制有效期显示隐藏
    handleChecked(val) {
      this.checkedShow = !val
    },
    // 获取BOD下拉模糊搜索
    QueryAddOrderShop(queryString, cb) {
      Api.BodConfig.getBaseByBodNo({
        bodNo: this.ruleForm.bodName,
        deptNo: this.ruleForm.deptNo
      }).then(res => {
        if (res.success) {
          var results = []
          if (res.data.length > 0) {
            for (let i = 0, len = res.data.length; i < len; i++) {
              res.data[i].value = res.data[i].bodName
            }
            results = res.data
          }
          cb(results)
        }
      }).catch((e) => {})
    },
    // 选择BOD下拉模糊搜索
    handleAddSalesOrderShop(item) {
      if (this.BaseGoodsInfoList === '') {
        this.baseSupplierInfo(item.deptNo)
      }
      this.ruleForm.bodNo = item.bodNo
      this.ruleForm.deptNo = item.deptNo
      this.ruleForm.deptName = item.deptName
      this.buttonQuery = false
    },
    //供应商获取
    baseSupplierInfo(val) {
      Api.BodCommodity.baseSupplierInfo({
        deptNo: val
      }).then(row => {
        if (row.success) {
          this.BaseGoodsInfoList = row.data
        } else {
          this.$showErrorMsg(row.errMessage)
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
      })
    },
    //商品分类
    handleCommodity(type) {
      if (type === 1) { //left
        this.leftCondition.cate3Id = this.leftCondition.cate3Idst[2]
      } else { //right
        this.rightCondition.cate3Id = this.rightCondition.cate3Idst[2]
      }
    },
    //重置
    handleAddRest(type) {
      if (type === 1) {
        this.leftCondition = {
          supplierName: '', //供应商名称
          supplierNo: '', //供应商编号
          cate3Idst: '', //商品分类
          cate3Id: '', //商品分类ID
          goodsName: '', //商品名称
          totals: 0, //总条数
          pageNum: 1, //页
          pageSize: 10 //条数
        }
        this.getLeftList()
      } else {
        this.rightCondition = {
          supplierName: '', //供应商名称
          supplierNo: '', //供应商编号
          cate3Idst: '', //商品分类
          cate3Id: '', //商品分类ID
          goodsName: '', //商品名称
          totals: 0, //总条数
          pageNum: 1, //页
          pageSize: 10 //条数
        }
        this.rightTableDate = this.rightTableDateLsit
        this.rightCondition.totals = this.rightTableDateLsit.length
        if (this.rightCondition.pageNum === 1) {
          this.rightTableDate = this.rightTableDateLsit.slice(0, this.rightCondition.pageSize)
        } else {
          this.rightTableDate = this.rightTableDateLsit.slice(this.rightCondition.pageSize * (this.rightCondition.pageNum - 1), this.rightCondition.pageSize * this.rightCondition.pageNum)
        }
      }
    },
    //新增查询列表
    handleQueryLeft(type) {
      if (type === 1) { //left
        this.getLeftList()
      } else { //right
        if (this.rightCondition.cate3Id === undefined) this.rightCondition.cate3Id = ''

        let temp = []
        if (this.rightCondition.supplierName !== '') {
          for (let i = 0, size = this.rightTableDateLsit.length; i < size; i++) {
            if (this.rightTableDateLsit[i].supplierNo === this.rightCondition.supplierName) {
              temp.push(this.rightTableDateLsit[i])
            }
          }
        } else {
          temp = this.rightTableDateLsit
        }
        if (this.rightCondition.goodsName !== '') {
          this.rightTableDate = []
          for (let i = 0, size = temp.length; i < size; i++) {
            // if (temp[i].goodsName === this.rightCondition.goodsName) {
            if (temp[i].goodsName.toLowerCase().indexOf(this.rightCondition.goodsName.toLowerCase()) !== -1 ||
              temp[i].goodsNo.toLowerCase().indexOf(this.rightCondition.goodsName.toLowerCase()) !== -1
            ) {
              console.log(temp[i].goodsName, this.rightCondition.goodsName, 1212455)
              this.rightTableDate.push(temp[i])
            }
          }
          temp = this.rightTableDate
        } else {
          this.rightTableDate = temp
        }
        if (this.rightCondition.cate3Id !== '') {
          this.rightTableDate = []
          for (let i = 0, size = temp.length; i < size; i++) {
            if (temp[i].cate3Id === this.rightCondition.cate3Id) {
              this.rightTableDate.push(temp[i])
            }
          }
          temp = []
        } else {
          this.rightTableDate = temp
        }

        if (type !== 3) { //当不是点击分页查询时
          this.rightCondition.pageNum = 1
        }
        if (this.rightCondition.pageNum === 1) {
          this.rightTableDate = this.rightTableDate.slice(0, this.rightCondition.pageSize)
        } else {
          this.rightTableDate = this.rightTableDate.slice(this.rightCondition.pageSize * (this.rightCondition.pageNum - 1), this.rightCondition.pageSize * this.rightCondition.pageNum)
        }
      }
    },
    //数据穿梭
    handleCopyRight(type) {
      if (type === 1) {
        for (let i = 0; i < this.multipleLeftSelection.length; i++) {
          this.rightTableDateLsit.push(this.multipleLeftSelection[i])
        }
        for (let i = 0; i < this.rightTableDateLsit.length; i++) {
          for (let j = i + 1; j < this.rightTableDateLsit.length; j++) {
            if (this.rightTableDateLsit[i].goodsNo === this.rightTableDateLsit[j].goodsNo) {
              this.rightTableDateLsit.splice(j, 1)
              j--
            }
          }
        }
        this.rightCondition.totals = this.rightTableDateLsit.length
        if (this.rightCondition.pageNum === 1) {
          this.rightTableDate = this.rightTableDateLsit.slice(0, this.rightCondition.pageSize)
        } else {
          this.rightTableDate = this.rightTableDateLsit.slice(this.rightCondition.pageSize * (this.rightCondition.pageNum - 1), this.rightCondition.pageSize * this.rightCondition.pageNum)
        }
      } else {
        let array = []
        array = this.rightTableDateLsit
        for (let j = 0; j < this.multipleRightSelection.length; j++) {
          for (let i = 0; i < array.length; i++) {
            if (this.multipleRightSelection[j].goodsNo === array[i].goodsNo) {
              array.splice(i, 1)
            }
          }
        }
        this.rightTableDateLsit = array
        this.rightCondition.totals = this.rightTableDateLsit.length
        this.rightTableDate = this.pagination(this.rightCondition.pageNum, this.rightCondition.pageSize, this.rightTableDateLsit)
        if (this.rightTableDate.length === 0 && this.rightCondition.pageNum > 1) {
          this.rightCondition.pageNum = this.rightCondition.pageNum - 1
          this.rightTableDate = this.pagination(this.rightCondition.pageNum, this.rightCondition.pageSize, this.rightTableDateLsit)
        }
      }
      this.toggleSelection(this.rightTableDateLsit)//选中置灰已选
    },
    //分页
    pagination(pageNo, pageSize, array) {
      let offset = (pageNo - 1) * pageSize
      return (offset + pageSize >= array.length) ? array.slice(offset, array.length) : array.slice(offset, offset + pageSize)
    },
    //左边供应商分类赋值
    handleLeftSupplier(val) {
      this.leftCondition.supplierNo = val
    },
    //已选中置灰
    checkSelectable(row) {
      let mark = 0
      this.rightTableDateLsit.forEach((item) => {
        if (item.goodsNo === row.goodsNo) {
          mark = mark + 1
          return false
        }
      })
      return mark <= 0
    },
    //已选中勾选
    toggleSelection(rightTableData) {
      if (rightTableData) {
        this.leftTableDate.forEach((leftRow, index) => {
          const isHave = rightTableData.some(rightRow => rightRow.goodsNo === leftRow.goodsNo)
          this.$refs.multipleTable.toggleRowSelection(this.$refs.multipleTable.data[index], isHave)
        })
      } else {
        this.$refs.multipleTable.clearSelection()
      }
    },
    //新增左边表格数据
    getLeftList() {
      Api.BodCommodity.letList({
        pageSize: this.leftCondition.pageSize,
        pageNum: this.leftCondition.pageNum,
        cate3Id: this.leftCondition.cate3Id,
        deptNo: this.ruleForm.deptNo,
        supplierNo: this.leftCondition.supplierNo,
        goodsNo: this.leftCondition.goodsName,
        goodsName: this.leftCondition.goodsName
      }).then(res => {
        if (res.success) {
          this.leftTableDate = res.data
          this.leftCondition.totals = res.total
          this.$nextTick(() => {
            this.toggleSelection(this.rightTableDateLsit)//选中置灰已选
          })
        } else {
          this.$showErrorMsg(res.errMessage)
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
      })
    },
    //全选反选
    handleLeftSelect(val) {
      for (const item in val) {
        val[item].startTime = ''
        val[item].endTime = ''
      }
      this.multipleLeftSelection = val
    },
    //左边翻页-----根据页码变换
    handleLeftSizeChange(val) {
      this.leftCondition.pageNum = val
      this.getLeftList()
    },
    //右边全选反选
    handleAddSelect(val) {
      this.multipleRightSelection = val
      console.log(val, 777)
    },
    //右边翻页-----根据页码变换
    handleRightSizeChange(val) {
      this.rightCondition.pageNum = val
      this.handleQueryLeft(3)
    },
    //解决时间赋值
    handleTime(obj) {
      this.scopeTime = false
      this.scopeTime = true
    },
    //========================================================================================>数据列表操作
    handleStartTime() {
      if (this.startDate !== '') {
        //结束日期小于开始日期
        this.pickerBeginDateAfter = {
          disabledDate: (time) => {
            var start = new Date(this.startDate).getTime()
            if (start) {
              return time.getTime() < start
            }
          }
        }
      }
    },
    handleEndTime() { //结束时间
      if (this.endDate !== '') {
        //开始日期小于结束日期
        this.pickerBeginDateBefore = {
          disabledDate: (time) => {
            var end = new Date(this.endDate).getTime()
            if (end) {
              return (time.getTime() > new Date(this.endDate).getTime())
            }
          }
        }
      }
    },
    //手工删除
    handleDel() {
      if (this.multipleSelection.length === 0) {
        this.$showErrorMsg('请选择数据')
        return
      }
      const crrId = []
      for (let i = 0; i < this.multipleSelection.length; i++) {
        crrId.push(this.multipleSelection[i].id)
      }
      this.delete(crrId)
    },
    //  删除方法
    delete(row) {
      this.$alert('<p style="font-size: 18px;color:#333">确认删除此条消息吗?</p><p style="font-size: 13px;color: #666">删除后，此条消息的相关内容信息将无法恢复</p>', '', {
        dangerouslyUseHTMLString: true,
        type: 'warning',
        center: true
      }).then(() => {
        Api.BodCommodity.deleteBodGoods({ ids: row }).then(row => {
          if (row.success) {
            this.$showSuccessMsg('删除成功')
            this.getList()
          } else {
            this.$showErrorMsg(row.errMessage)
          }
        }).catch((e) => { this.$showErrorMsg(e) })
      }).catch(() => {})
    },
    //商品分类
    handleSelectCate() {
      this.cate3Id = this.cate3Idst[2]
    },
    //数据列表
    getList() {
      this.LoadingTable = true
      const params = {
        bodGoodsStatus: this.bodState, //bod状态
        goodsNoStr: this.goodsNoStr, //商品编码
        bodNoOrName: this.bodNoOrName, //Bod编码
        cate3Id: this.cate3Id, //商品分类ID
        deptNo: this.deptNo, //事业部编码
        endTime: this.endDate, //结束时间
        startTime: this.startDate, //开始时间
        pageNum: this.pageNum, //页
        pageSize: this.pageSize //条数
      }
      Api.BodCommodity.listPage(params).then(res => {
        if (res.success) {
          this.tableData = res.data
          this.totals = res.total
          this.LoadingTable = false
        } else {
          this.LoadingTable = false
          this.$showErrorMsg(res.errMessage)
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
      })
    },
    //批量下载
    download() {
      const params = {
        bodState: this.bodState, //bod状态
        goodsNoStr: this.goodsNoStr, //商品编码
        bodNoOrName: this.bodNoOrName, //Bod编码
        cate3Id: this.cate3Id, //商品分类ID
        deptNo: this.deptNo, //事业部编码
        endDate: this.endDate, //结束时间
        startDate: this.startDate, //开始时间
        pageNum: this.pageNum, //页
        pageSize: this.pageSize //条数
      }
      const actionUrl = this.baseURL + Api.BodCommodity.download
      exportExcel(actionUrl, params)
    },
    //全选反选
    handleSelectionChange(val) {
      this.multipleSelection = val
    },
    //分页条数改变
    sizeChange(val) {
      this.pageSize = val
      this.getList()
    },
    //翻页-----根据页码变换
    handleSizeChange(val) {
      this.pageNum = val
      this.getList()
    },
    //查询
    handleQuery() {
      this.getList()
    },
    //重置条件清空
    handleRest() {
      this.bodState = '' //bod状态
      this.goodsNoStr = '' //商品编码
      this.bodNoOrName = '' //Bod编码
      this.bodName = '' //Bod编码
      this.cate3Id = '' //商品分类ID
      this.cate3Idst = ''
      this.deptNo = '' //事业部编码
      this.endDate = '' //结束时间
      this.startDate = '' //开始时间
      this.getList()
    },
    //获取事业部编码
    queryDept() {
      Api.BodCommodity.queryDept().then(row => {
        if (row.success) {
          this.deptNoList = row.data
        } else {
          this.$showErrorMsg(row.errMessage)
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
      })
    }
  }
}
</script>
<style scoped lang="scss">
@import "@/assets/stylus/main.scss";
  @import "../common/common";
  /*  弹窗信息*/
  .demo-ruleForm{
    .ruleForm-title{
      display: flex;
      flex-wrap: wrap;
    }
    .ruleForm-content{
      border-radius: 4px;
      /*height: 300px;*/
      display: flex;
      .content-title{
        width: 75px;
        text-align: center;
      }
      .content-left{
        width: calc(50% - 80px);
        border: 1px solid #D9D9D9;
        border-radius: 4px;
        /deep/.lui-table td{
          height: 57px;
        }
        .left-title{
          width: 100%;
          height: 40px;
          border-bottom: 1px solid #d9d9d9;
          display: flex;
          justify-content:space-between;
          align-items: center;
          span{
            padding: 0 15px
          }
        }
        .left-main{
          margin-top: 10px;
          padding: 0 12px;
          .table-p {
            //display: inline-block;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            cursor: pointer;
            padding-right: 15px;
            //border: 1px solid red;/**/
          }
          .knowledge-pagination {
            width: 100%;
            margin-top: 10px;
            text-align: right;
          }
        }
      }
      .content-cont{
        width: 80px;
        position: relative;
        span{
          display: block;
          width: 32px;
          height: 32px;
          border-radius: 4px;
          font-size: 16px;
          background: rgba(0,0,0,0.04);
          color: rgba(0,0,0,0.15);
          border: 1px solid rgba(0,0,0,0.15);
          text-align: center;
          line-height: 32px;
          cursor: pointer;
          &:hover{
            background: $--gl-blue;
            color: #fff;
          }
        }
        span:nth-child(1){
          position: absolute;
          top: 50%;
          left: 50%;
          margin-top: -32px;
          margin-left: -16px;
        }
        span:nth-child(2){
          position: absolute;
          top: 50%;
          left: 50%;
          margin-top: 16px;
          margin-left: -16px;
        }
      }
      .content-right{
        border-radius: 4px;
        width: calc(50% - 80px);
        border: 1px solid #D9D9D9;
        .left-title{
          width: 100%;
          height: 40px;
          border-bottom: 1px solid #d9d9d9;
          display: flex;
          justify-content:space-between;
          align-items: center;
          span{
            padding: 0 15px
          }
        }
        .left-main{
          margin-top: 10px;
          padding: 0 12px;
          .table-p {
            //display: inline-block;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            cursor: pointer;
            padding-right: 15px;
            //border: 1px solid red;/**/
          }
          .knowledge-pagination {
            width: 100%;
            margin-top: 10px;
            text-align: right;
          }
        }
      }
    }
  }
/*  默认设置*/
  .setdemo-ruleForm{
    width: 100%;
    .setAddBut{
      width: 100%;
      text-align: center;
      margin-bottom: 30px;
    }
    .container-page{
      .knowledge-pagination {
        width: 100%;
        margin-top: 15px;
        text-align: right;
      }
    }
  }
/*  详情*/
  .details{
    width: 100%;
    display: flex;
    flex-wrap: wrap;
    .details-cont{
      height: 30px;
      display: flex;
      align-items: center;
      padding-right: 40px;
      .cont-title{
        display: inline-block;
        text-align: right;
        color: #222222;
      }
    }
    .details-cont:nth-child(1){
      height: 30px;
      display: flex;
      align-items: center;
      .cont-title{
        padding-left: 0;
      }
    }
  }
  .details-main{
    width: 100%;
    min-height: 450px;
    border: 1px solid #d9d9d9;
    border-radius: 4px;
    margin-top: 15px;
    display: flex;
    .main-left{
      width: 540px;
      height: 100%;
      .knowledge-pagination {
        width: 100%;
        margin-top: 10px;
        padding-right: 15px;
        text-align: right;
      }
    }
    .main-right{
      width: calc(100% - 540px);
      min-height: 450px;
      border-left: 1px solid #d9d9d9;
      .right-title{
        height: 50px;
        line-height: 50px;
        padding-left: 15px;
      }
      .right-main{
        width: 100%;
        height: calc(100% - 50px);
        position: relative;
        .main-mask{
          position: absolute;
            top: 0;
            bottom: 0;
            width: 167px;
            left: 0;
            z-index: 12;
            /* height: 100px; */
            background: #fff;
        }
        .org-tree-container{
          width: 100%;
          overflow: auto;
        }
      }
    }
  }
</style>
