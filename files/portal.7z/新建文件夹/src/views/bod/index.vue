<template>
  <div class="container">
    <div class="information-nav">
      <lui-menu
        :default-active="activeIndex"
        class="lui-menu-demo nav-menu"
        mode="horizontal"
        @select="handleSelect">
        <lui-menu-item index="1">BOD配置</lui-menu-item>
        <lui-menu-item index="2">BOD商品配置</lui-menu-item>
        <!-- <lui-menu-item index="3">按商品查询BOD</lui-menu-item> -->
      </lui-menu>
      <div class="line"></div>
    </div>
    <div class="container-content">
      <component :is="currentRole" />
    </div>
  </div>
</template>

<script>
import configure from './configure'
import commodity from './commodity'
import query from './queryBod'
export default {
  name: 'index',
  components: {
    configure,
    commodity,
    query
  },
  data() {
    return {
      activeIndex: '1',
      currentRole: 'configure'
    }
  },
  methods: {
    // 页面跳转
    handleSelect(key) {
      switch (key) {
        case '1':
          //BOD配置
          this.currentRole = 'configure'
          break
        case '2':
          //BOD商品配置
          this.currentRole = 'commodity'
          break
        case '3':
          //按商品查询BOD
          this.currentRole = 'query'
          break
      }
    }
  }
}
</script>

<style scoped lang="scss">
  .container{
    width: 100%;
    .information-nav{
      box-shadow: 2px 2px 7px 2px #ccc;
      border-radius: 0 0 4px 4px;
      width: 100%;
      background: #ffffff;
      /*margin-bottom: 20px;*/
      .nav-menu{
        li{
          font-size: 14px;
        }
        li:first-child{
          margin-left: 30px;
        }
      }
    }

    .container-content{
      width: 100%;
      padding-bottom: 30px;
      /*border: 1px solid red;*/
    }
  }
</style>
