<template>
  <div class="org-tree-container">
    <div class="org-tree" :class="{horizontal, collapsable}">
      <org-tree-node
        :data="data"
        :props="props"
        :judge="judge"
        :node-class="nodeClass"
        :horizontal="horizontal"
        :label-width="labelWidth"
        :collapsable="collapsable"
        :render-content="renderContent"
        :label-class-name="labelClassName"
        @on-expand="(e, data) => $emit('on-expand', e, data)"
        @on-node-focus="(e, data) => $emit('on-node-focus', e, data)"
        @on-node-click="(e, data) => $emit('on-node-click', e, data)"
        @on-node-mouseover="(e, data) => $emit('on-node-mouseover', e, data)"
        @on-node-mouseout="(e, data) => $emit('on-node-mouseout', e, data)"
      />
    </div>
  </div>
</template>

<script>
import render from './node'

export default {
  name: 'Vue2OrgTree',
  components: {
    OrgTreeNode: {
      render,
      functional: true
    }
  },
  props: {
    data: {
      type: Object,
      required: true
    },
    props: {
      type: Object,
      default: () => ({
        label: 'label',
        expand: 'expand',
        children: 'children'
      })
    },
    judge: {
      type: Object,
      required: false
    },
    nodeClass: {
      type: Array,
      required: false
    },
    horizontal: Boolean,
    selectedKey: String,
    collapsable: Boolean,
    renderContent: Function,
    labelWidth: [String, Number],
    labelClassName: [Function, String],
    selectedClassName: [Function, String]
  }
}
</script>

<style lang="scss" scoped>
  @import '@/assets/stylus/main';
  .org-tree-container {
    display: inline-block;
    padding: 15px;
    padding-left: 0;
    background-color: #fff;
  }

  .org-tree {
    // display: inline-block;
    display: table;
    text-align: center;

    &:before, &:after {
      content: '';
      display: table;
    }

    &:after {
      clear: both;
    }
  }

  .org-tree-node,
  .org-tree-node-children {
    position: relative;
    margin: 0;
    padding: 0;
    list-style-type: none;

    &:before, &:after {
      transition: all .35s;
    }
  }
  .org-tree-node-label {
    position: relative;
    display: inline-block;

    .org-tree-node-label-inner {
      padding: 10px 0;
      text-align: center;
      border-radius: 3px;
      width: 75px;
      height: 41px;
      box-shadow: none;
      cursor: pointer;
    }
  }
  .org-tree-node-btn {
    position: absolute;
    top: 100%;
    left: 50%;
    width: 20px;
    height: 20px;
    z-index: 10;
    margin-left: -11px;
    margin-top: 9px;
    background-color: #fff;
    border: 1px solid #ccc;
    border-radius: 50%;
    box-shadow: 0 0 2px rgba(0, 0, 0, .15);
    cursor: pointer;
    transition: all .35s ease;

    &:hover {
      background-color: #e7e8e9;
      transform: scale(1.15);
    }

    &:before, &:after {
      content: '';
      position: absolute;
    }

    &:before {
      top: 50%;
      left: 4px;
      right: 4px;
      height: 0;
      border-top: 1px solid #ccc;
    }

    &:after {
      top: 4px;
      left: 50%;
      bottom: 4px;
      width: 0;
      border-left: 1px solid #ccc;
    }

    &.expanded:after {
      border: none;
    }
  }
  .org-tree-node {
    padding-top: 20px;
    display: table-cell;
    vertical-align: top;

    &.is-leaf, &.collapsed {
      padding-left: 10px;
      padding-right: 10px;
    }

    &:before, &:after {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      width: 50%;
      height: 19px;
    }

    &:after {
      left: 50%;
      border-left: 1px dashed $--gl-blue;
    }

    &:not(:first-child):before,
    &:not(:last-child):after {
      border-top: 1px dashed $--gl-blue;
    }

  }
  .collapsable .org-tree-node.collapsed {
    padding-bottom: 30px;

    .org-tree-node-label:after {
      content: '';
      position: absolute;
      top: 100%;
      left: 0;
      width: 50%;
      height: 20px;
      border-right: 1px dashed $--gl-blue;
    }
  }
  .org-tree > .org-tree-node {
    padding-top: 0;

    &:after {
      border-left: 0;
    }
  }
  .org-tree-node-children {
    padding-top: 20px;
    display: table;

    &:before {
      content: '';
      position: absolute;
      top: 0;
      left: 50%;
      width: 0;
      height: 20px;
      border-left: 1px dashed $--gl-blue;
    }

    &:after {
      content: '';
      display: table;
      clear: both;
    }
  }

  .horizontal {
    .org-tree-node {
      display: table-cell;
      float: none;
      padding-top: 0;
      padding-left: 30px;

      &.is-leaf, &.collapsed {
        padding-top: 19px;
        padding-bottom: 20px;
      }

      &:before, &:after {
        width: 35px;
        height: 50%;
      }

      &:after {
        top: 50%;
        left: 0;
        border-left: 0;
      }
      &:only-child:before {
        // top: 1px;
        top:50%;
        position:absolute;
        height: 1px;
        border-bottom: 1px dashed $--gl-blue;
      }

      &:not(:first-child):before,
      &:not(:last-child):after {
        border-top: 0;
        border-left: 1px dashed $--gl-blue;
      }

      &:not(:only-child):after {
        border-top: 1px dashed $--gl-blue;
      }

      .org-tree-node-inner {
        display: table;
      }

    }

    .org-tree-node-label {
      display: table-cell;
      vertical-align: middle;
    }

    &.collapsable .org-tree-node.collapsed {
      padding-right: 30px;

      .org-tree-node-label:after {
        top: 0;
        left: 100%;
        width: 20px;
        height: 50%;
        border-right: 0;
        border-bottom: 1px dashed $--gl-blue;
      }
    }

    .org-tree-node-btn {
      top: 50%;
      left: 100%;
      margin-top: -11px;
      margin-left: 9px;
    }

    & > .org-tree-node:only-child:before {
      border-bottom: 0;
    }

    .org-tree-node-children {
      // display: flex;
      // flex-direction: column;
      // justify-content: center;
      // align-items: flex-start;
      display: table-cell;
      padding-top: 0;
      padding-left: 20px;

      &:before {
        top: 50%;
        left: 0;
        width: 19px;
        height: 0;
        border-left: 0;
        border-bottom: 1px dashed $--gl-blue;
      }

      &:after {
        display: none;
      }

      & > .org-tree-node {
        display: block;
      }
    }
  }
.factory {
  background: url("../../../../assets/img/factory.png") no-repeat center;
}

.rdc {
  background: url("../../../../assets/img/rdc.png") no-repeat center;
}

.store {
  background: url("../../../../assets/img/store.png") no-repeat center;
}

.fdc {
  background: url("../../../../assets/img/fdc.png") no-repeat center;
}

.cdc {
  background: url("../../../../assets/img/cdc.png") no-repeat center;
}

.tc {
  background: url("../../../../assets/img/tc.png") no-repeat center;
}

.org-tree-node-label-inner {
  position: relative;
}

.testparents {
  position: absolute;
  top: 0px;
  left: 0px;
  box-shadow: 0 1px 5px rgba(0, 0, 0, 0.15);
  width: 70px;
  height: 39px;
  line-height: 41px;
  border-radius: 4px;
}

.testchild {
  position: absolute;
  width: 100%;
  top: 13px;
  left: -63px;
  font-size: 10px;
  z-index: 10;
  color: $--gl-blue;
}

.iconts {
  position: absolute;
  width: 100%;
  top: 50%;
  margin-top: -6px;
  left: -31px;
  transform: scaleY(0.55);
  color: $--gl-blue;
}

.testp {
  position: absolute;
  top: 45px;
  left: -14px;
  font-size: 10px;
  width: 104px;
  color: $--gl-blue;
  z-index: 15;
  text-align: center;
  color: $--gl-blue;
  overflow:hidden;
  text-overflow:ellipsis;
  white-space: nowrap;

}
</style>
