<template>
  <div class="configure">
    <div class="configure-title">
      <div class="title-text">筛选搜索</div>
      <div class="title-serch">
        <div class="serch-left">
          <div class="select-content">
            <span class="content-title">事业部</span>
            <lui-select
              v-model="deptNo"
              style="width: 180px;"
              clearable
              placeholder="请选择事业部">
              <lui-option
                v-for="(item,index) in deptNoList"
                :key="index"
                :label="item.deptName"
                :value="item.deptNo">
              </lui-option>
            </lui-select>
          </div>
          <div class="select-content">
            <span class="content-title">BOD状态</span>
            <lui-select
              v-model="bodState"
              clearable
              style="width: 180px;"
              placeholder="请选择BOD状态">
              <lui-option
                v-for="(item,index) in bodStateList"
                :key="index"
                :label="item.name"
                :value="item.code">
              </lui-option>
            </lui-select>
          </div>
          <div class="select-content">
            <span class="content-title">BOD</span>
            <lui-input
              v-model="bodNo"
              clearable
              placeholder="搜索BOD编码 / 名称"
              style="width: 180px;">
            </lui-input>
          </div>
          <div class="select-content">
            <span class="content-title">生效时间</span>
            <lui-date-picker
              v-model="startDate"
              style="width: 180px;"
              value-format="yyyy-MM-dd"
              type="date"
              :picker-options="pickerBeginDateBefore"
              placeholder="请选择生效日期"
              @change="handleStartTime">
            </lui-date-picker>
          </div>
          <div class="select-content">
            <span class="content-title">失效时间</span>
            <lui-date-picker
              v-model="endDate"
              style="width: 180px;"
              value-format="yyyy-MM-dd"
              type="date"
              :picker-options="pickerBeginDateAfter"
              placeholder="请选择失效时间"
              @change="handleEndTime">
            </lui-date-picker>
          </div>
        </div>
      </div>
      <div class="serch-right">
        <lui-button type="primary" style="width: 80px;" @click="handleQuery">查询</lui-button>
        <lui-button style="width: 80px;" @click="handleRest">重置</lui-button>
      </div>
    </div>
    <div class="master-container">
      <div class="container-top">
        <div class="container-top-left">
          <span class="header-border"></span>
          <span class="header-title">数据列表</span>
        </div>
        <div class="container-top-right">
          <lui-button type="primary" @click="download">批量下载</lui-button>
          <button-list
            :buttons="buttons"
            :configdept-no="deptNo.split('&')[0]"
            :configdept-name="deptNo.split('&')[1]"
            :check-dept-no="checkDeptNo"
            @uploadSuccess="getList">
          </button-list>
          <lui-button type="primary" @click="handleDel">手工删除</lui-button>
          <lui-button type="primary" @click="handleAdd">手工添加</lui-button>
        </div>
      </div>

      <div class="container-table">
        <div class="container-table-cont">
          <lui-table
            v-loading="LoadingTable"
            :data="tableData"
            style="width: 100%"
            @selection-change="handleSelectionChange">
            <template slot="empty">
              <showEmptyImage></showEmptyImage>
            </template>
            <lui-table-column
              align="center"
              fixed="left"
              type="selection"
              width="50">
            </lui-table-column>

            <lui-table-column
              prop="deptNo"
              min-width="170"
              label="事业部编码"
              show-overflow-tooltip>
            </lui-table-column>

            <lui-table-column
              prop="deptName"
              label="事业部名称"
              min-width="170"
              show-overflow-tooltip>
            </lui-table-column>

            <lui-table-column
              prop="bodNo"
              label="BOD编码"
              min-width="220"
              show-overflow-tooltip>
            </lui-table-column>

            <lui-table-column
              prop="bodName"
              label="BOD名称"
              min-width="170"
              show-overflow-tooltip>
            </lui-table-column>

            <lui-table-column
              prop="goodsNo"
              label="有效期"
              width="210"
              show-overflow-tooltip>
              <template v-slot="{row}">
                <p v-if="row.alwaysEffective">始终有效</p>
                <p v-else>{{ row.startDate }}&nbsp;&nbsp;至&nbsp;&nbsp;{{ row.endDate }}</p>
              </template>
            </lui-table-column>

            <lui-table-column
              prop="updateUser"
              width="130"
              label="修改人"
              show-overflow-tooltip>
            </lui-table-column>

            <lui-table-column
              prop="updateTime"
              width="160"
              label="修改时间">
            </lui-table-column>

            <lui-table-column
              fixed="right"
              width="80"
              align="center"
              label="操作">
              <template v-slot="{row}">
                <div class="table-button">
                  <lui-button type="text" @click="handlerEdit(row)">编辑</lui-button>
                </div>
              </template>
            </lui-table-column>
          </lui-table>
        </div>
        <div v-show="tableData.length>0" class="knowledge-pagination">
          <lui-pagination
            background
            :current-page.sync="pageNum"
            :page-sizes="[10, 20, 50, 70, 100]"
            layout="prev, pager, next, sizes, jumper"
            :total="totals"
            @current-change="handleSizeChange"
            @size-change="sizeChange">
          </lui-pagination>
        </div>
      </div>
    </div>
    <!--    新增  -->
    <lui-dialog
      :visible.sync="centerDialogVisible"
      width="94%"
      top="10vh"
      :close-on-click-modal="false"
      custom-class="dialog_mask"
      :title="stateTitle"
      @close="closeDialog('ruleForm')">
      <lui-form
        ref="ruleForm"
        :model="ruleForm"
        :rules="rules"
        label-width="90px"
        class="demo-ruleForm">
        <div class="ruleForm-title">
          <lui-form-item
            label="BOD名称"
            prop="bodName">
            <lui-input
              v-model.trim="ruleForm.bodName"
              :disabled="editShow"
              maxlength="50"
              placeholder="请输入BOD名称"
              style="width: 180px;">
            </lui-input>
          </lui-form-item>

          <lui-form-item
            label="事业部"
            prop="deptNo">
            <lui-select
              v-model="ruleForm.deptNo"
              :disabled="editShow"
              style="width: 180px;"
              placeholder="请选择事业部"
              @change="handleSelectDept">
              <lui-option
                v-for="(item,index) in deptNoList"
                :key="index"
                :label="item.deptName"
                :value="item.deptNo">
              </lui-option>
            </lui-select>
          </lui-form-item>

          <lui-form-item
            v-if="checkedShow"
            label="有效期"
            prop="dataList">
            <lui-date-picker
              v-if="editShow"
              v-model="ruleForm.dataList"
              style="width: 360px"
              type="daterange"
              range-separator="-"
              start-placeholder="开始日期"
              end-placeholder="结束日期"
              value-format="yyyy-MM-dd"
              format="yyyy-MM-dd">
            </lui-date-picker>
            <lui-date-picker
              v-else
              v-model="ruleForm.dataList"
              style="width: 360px"
              type="daterange"
              range-separator="-"
              start-placeholder="开始日期"
              end-placeholder="结束日期"
              value-format="yyyy-MM-dd"
              format="yyyy-MM-dd"
              :picker-options="pickerOptions1">
            </lui-date-picker>
          </lui-form-item>

          <lui-form-item
            label-width="30px"
            prop="alwaysEffective">
            <lui-checkbox
              v-model="ruleForm.alwaysEffective"
              @change="handleChecked">始终有效</lui-checkbox>
          </lui-form-item>
        </div>

        <div class="ruleForm-buttons">
          <div class="buttons-left"></div>
          <div class="buttons-left">
            <lui-button icon="lui-icon-delete" @click="handleDelBod">删除</lui-button>
            <lui-button icon="lui-icon-document-empty" @click="handleCopy">从现有复制</lui-button>
            <lui-button :loading="buttonLoading" type="primary" icon="lui-icon-upload-empty" @click="submitForm('ruleForm')">提交</lui-button>
          </div>
        </div>
        <div class="ruleForm-content">
          <!-- 树形图展示 -->
          <div class="content-left">
            <div class="left-mask"></div>
            <bod-tree
              :data="ruleForm.bodNode"
              :horizontal="true"
              :render-content="renderContent"
              :judge="judge"
              :node-class="NodeClass"
              @on-node-click="NodeClickadd" />
          </div>
          <!-- 右侧面板 -->
          <div
            v-if="leftShowCanvas"
            class="content-right">
            <lui-form
              ref="addForm"
              :model="addForm"
              :rules="addRules"
              label-width="145px"
              label-position="left"
              class="demo-ruleForm">

              <div class="right-main">
                <div v-if="disabledNode">
                  <lui-form-item
                    label="库节点"
                    prop="nodeNo">
                    <lui-select
                      v-model="addForm.nodeNo"
                      style="width: 100%;"
                      placeholder="请选择库节点"
                      filterable
                      @change="handleSelectNodePart">
                      <lui-option
                        v-for="(item,index) in libraryList"
                        :key="index"
                        :label="item.nodeName"
                        :value="item.nodeNo"
                        :disabled="item.disabled">
                      </lui-option>
                    </lui-select>
                  </lui-form-item>

                  <lui-form-item
                    label="最大可配出比"
                    prop="distributionPatio">
                    <lui-input-number
                      v-model="addForm.distributionPatio"
                      controls-position="right"
                      :precision="2"
                      :step="0.1"
                      :min="0.01"
                      :max="100">
                    </lui-input-number>

                  </lui-form-item>

                  <lui-form-item
                    label="最低周转天数"
                    prop="dayNum">
                    <lui-input
                      v-model="addForm.dayNum"
                      oninput="if(value > 99999 || value < 1 || isNaN(value)){value = ''}"
                      placeholder="请输入最低周转天数">
                    </lui-input>
                  </lui-form-item>

                  <lui-form-item
                    label="分配规则"
                    prop="distributionRules">
                    <lui-select
                      v-model="addForm.distributionRules"
                      style="width: 100%;"
                      placeholder="请选择分配规则"
                      @change="handleDistribution">
                      <lui-option
                        v-for="(item,index) in distributionRules"
                        :key="index"
                        :label="item.name"
                        :value="item.code">
                      </lui-option>
                    </lui-select>
                  </lui-form-item>

                  <lui-form-item
                    label="最大库存预留比例"
                    prop="maxReserveRatio">
                    <lui-input-number
                      v-model.trim="addForm.maxReserveRatio"
                      :precision="2"
                      :step="1"
                      :max="100"
                      :min="0">
                    </lui-input-number>
                  </lui-form-item>

                  <lui-form-item
                    label="是否全国周转"
                    prop="isNationwideTurnover">
                    <lui-radio-group
                      v-model="addForm.isNationwideTurnover">
                      <lui-radio :label="1" class="button_radio">是</lui-radio>
                      <lui-radio :label="0" class="button_radio">否</lui-radio>
                    </lui-radio-group>
                  </lui-form-item>

                  <lui-form-item
                    label="是否启用最大可配出比分配规则"
                    label-width="200"
                    prop="openRuleType">
                    <lui-radio
                      v-model="addForm.openRuleType"
                      label="1"
                      @change="handleOpenRuleType">是</lui-radio>
                    <lui-radio
                      v-model="addForm.openRuleType"
                      label="0"
                      @change="handleOpenRuleType">否</lui-radio>
                  </lui-form-item>

                  <div v-if="addForm.openRuleType === '1'">
                    <lui-form-item label="对门店最大可分配占比" label-width="160px">
                      <lui-input-number
                        v-model.trim="addForm.shopRatio"
                        :precision="2"
                        :step="1"
                        :max="100"
                        :min="0"
                        controls-position="right"
                      >
                      </lui-input-number>
                    </lui-form-item>

                    <lui-form-item label="对FDC最大可分配占比" label-width="160px">
                      <lui-input-number
                        v-model.trim="addForm.fdcRatio"
                        :precision="2"
                        :step="1"
                        :max="100"
                        :min="0"
                        controls-position="right"
                      >
                      </lui-input-number>
                    </lui-form-item>

                    <lui-form-item label="对RDC最大可分配占比" label-width="160px">
                      <lui-input-number
                        v-model.trim="addForm.rdcRatio"
                        :precision="2"
                        :step="1"
                        :max="100"
                        :min="0"
                        controls-position="right"
                      >
                      </lui-input-number>
                    </lui-form-item>
                  </div>

                </div>

                <div v-if="rightTableShow">
                  <div v-if="isEntrance">
                    <lui-form-item
                      label-width="">
                      <span slot="label"><i style="color: #E1251B;margin-right: 4px;">*</i>是否读取上游库存</span>
                      <lui-radio
                        v-model="addForm.entranceReadUpperStock"
                        label="1"
                        @change="handleEntranceReadUpperStock">是</lui-radio>
                      <lui-radio
                        v-model="addForm.entranceReadUpperStock"
                        label="0"
                        @change="handleEntranceReadUpperStock">否</lui-radio>
                    </lui-form-item>
                    
                    <lui-form-item
                      v-if="addForm.entranceReadUpperStock === '1'"
                      label-width=""
                      label="分配规则设置"
                      prop="entranceAllocationType"
                      :rules="addForm.entranceReadUpperStock === '1'?addRules.entranceAllocationType:[{ required: false, message: '请选择分配规则', trigger: ['blur'] }]">
                      <lui-select
                        v-model="addForm.entranceAllocationType"
                        style="width: 100%;"
                        placeholder="请选择分配规则"
                        @change="handleDistribution">
                        <lui-option
                          v-for="(item,index) in distributionRules"
                          :key="index"
                          :label="item.name"
                          :value="item.code">
                        </lui-option>
                      </lui-select>
                    </lui-form-item>
                  </div>


                  <lui-form-item
                    label-width="0">
                    <template>
                      <lui-table
                        :key="Math.random()"
                        :data="addForm.children"
                        style="width: 100%">
                        <!-- v-if="priorityShow" -->
                        <!-- <lui-table-column
                         
                          width="30">
                          <template v-slot="scope">
                            <span class="lui-icon-top" style="color: #999;list-style: none" @click="handerTop(scope)"></span>
                          </template>
                        </lui-table-column> -->

                        <lui-table-column
                          :label="nodeTitle">
                          <template v-slot="scope">
                            <lui-select
                              v-model="scope.row.nodeNo"
                              style="width: 100%;"
                              :placeholder="nodePlace"
                              filterable
                              @change="handleSelectNode(scope.row.nodeNo,scope.$index)">
                              <lui-option
                                v-for="(item,index) in libraryList"
                                :key="index"
                                :label="item.nodeName"
                                :value="item.nodeNo"
                                :disabled="item.disabled">
                              </lui-option>
                            </lui-select>
                          </template>
                        </lui-table-column>

                        <lui-table-column
                          v-if="disabledNode"
                          width="100"
                          label="运输方式">
                          <template v-slot="scope">
                            <lui-select
                              v-model="scope.row.transportMode"
                              style="width: 100%;"
                              placeholder="请选择"
                              @change="handleSelectTar(scope.row.transportMode,scope.$index)">
                              <lui-option
                                v-for="(item,index) in transportList"
                                :key="index"
                                :label="item.name"
                                :value="item.code">
                              </lui-option>
                            </lui-select>
                          </template>
                        </lui-table-column>

                        <lui-table-column
                          v-if="priorityShow"
                          label="优先级"
                          width="80">
                          <template v-slot="scope">
                            <span>{{ scope.$index + 1 }}</span>
                          </template>
                        </lui-table-column>

                        <lui-table-column
                          label="操作"
                          width="70"
                          align="center">
                          <template v-slot="scope">
                            <lui-tooltip
                              popper-class="custom-tooltip"
                              effect="dark"
                              :visible-arrow="false"
                              content="上移"
                              placement="top">
                              <img v-if="priorityShow" class="handle-btn" src="@/assets/svg/moveup.svg" alt="" @click="handerTop(scope)">
                            </lui-tooltip>
                            <lui-tooltip
                              popper-class="custom-tooltip"
                              effect="dark"
                              :visible-arrow="false"
                              content="删除"
                              placement="top">
                              <img style="margin-left: 12px;" class="handle-btn" src="@/assets/svg/remove.svg" alt="" @click="deleteRowEdit(scope.row,scope.$index,false)">
                            </lui-tooltip>
                          </template>
                        </lui-table-column>
                      </lui-table>
                    </template>

                    <lui-button
                      icon="lui-icon-plus"
                      class="table-puls"
                      @click="handleNodeAdd(addForm.children)">
                    </lui-button>
                    <lui-form-item
                      v-if="isEntrance && addForm.entranceReadUpperStock === '1'"
                      style="margin-top:22px"
                      label-width=""
                      label="冗余库存预留"
                      prop="entranceStockStay"
                      :rules="addForm.entranceReadUpperStock === '1'?addRules.entranceStockStay:[{ required: false, message: '请选择冗余库存预留', trigger: ['blur'] }]">
                      <lui-select
                        v-model="addForm.entranceStockStay"
                        style="width: 100%;"
                        placeholder="请选择冗余库存预留">
                        <lui-option
                          v-for="(item,index) in addForm.children"
                          :key="index"
                          :label="item.nodeName"
                          :value="item.nodeNo">
                        </lui-option>
                      </lui-select>
                    </lui-form-item>
                  </lui-form-item>
                </div>
              </div>
              <div class="right-button">
                <lui-button :loading="buttonLoading" @click="resetForm('addForm')">取消</lui-button>
                <lui-button type="primary" @click="handleSubmit('addForm')">确定</lui-button>
              </div>
            </lui-form>
          </div>
        </div>
      </lui-form>
    </lui-dialog>
    <!--    复制 BOD-->
    <lui-dialog
      :visible.sync="copyDialogVisible"
      width="70%"
      top="10vh"
      :close-on-click-modal="false"
      custom-class="dialog_mask"
      title="选择复制的BOD">
      <div class="dialog-mask-title">
        <div class="mask-left">
          <div class="select-content">
            <span class="content-title">BOD</span>
            <lui-autocomplete
              v-model="bodCope"
              clearable
              class="inline-input"
              :fetch-suggestions="QuerySalesOrderCopy"
              placeholder="输入搜索BOD编码 / 名称"
              @select="handleQuerySalesOrderCopy">
            </lui-autocomplete>
          </div>

          <div class="select-content">
            <span class="content-title">入口仓</span>
            <lui-autocomplete
              v-model="copyNodeNo"
              clearable
              class="inline-input"
              :fetch-suggestions="QuerySalesWarehouse"
              placeholder="输入搜索入口仓编码 / 名称"
              @select="handleQuerySalesWarehouse">
            </lui-autocomplete>
          </div>

        </div>

        <div class="mask-right">
          <lui-button type="primary" style="width: 80px;" @click="handleQueryCopy">查询</lui-button>
          <lui-button style="width: 80px;" @click="handleRestCopy">重置</lui-button>
        </div>
      </div>
      <div class="dialog-mask-content">
        <lui-table
          v-loading="copyLoading"
          :data="tableDataCopy"
          style="width: 100%">
          <template slot="empty">
            <showEmptyImage></showEmptyImage>
          </template>
          <lui-table-column
            prop="bodNo"
            show-overflow-tooltip
            min-width="200"
            label="BOD编码">
          </lui-table-column>

          <lui-table-column
            min-width="200"
            show-overflow-tooltip
            prop="bodName"
            label="BOD名称">
          </lui-table-column>

          <lui-table-column
            width="330"
            label="有效期">
            <template v-slot="{row}">
              <p>{{ row.startDate }} 至 {{ row.endDate }}</p>
            </template>
          </lui-table-column>

          <lui-table-column
            fixed="right"
            label="操作"
            width="110"
            align="center">
            <template v-slot="{row}">
              <div class="table-button">
                <span class="table-look" @click="handlePreview(row,true)">预览</span>
                <span class="table-look" @click="handlePreview(row,false)">复制</span>
              </div>
            </template>
          </lui-table-column>
        </lui-table>
        <div
          v-if="tableDataCopy.length>0"
          class="knowledge-pagination">
          <lui-pagination
            background
            :current-page.sync="copyPageNum"
            :page-sizes="[10, 20, 50, 70, 100]"
            layout="prev, pager, next, sizes, jumper"
            :total="copyTotal"
            @current-change="handleSizeChangeCopy"
            @size-change="sizeChangeCopy">
          </lui-pagination>
        </div>
      </div>
    </lui-dialog>
    <!--    预览BOD-->
    <lui-dialog
      :visible.sync="copyDialogPreview"
      width="80%"
      top="10vh"
      :close-on-click-modal="false"
      custom-class="dialog_mask"
      :title="copyBodTitle">
      <div
        v-loading="loadingPreviewShow"
        class="preview-mask">
        <div class="mask-cont"></div>
        <bod-tree
          :data="bodNode"
          :horizontal="true"
          :render-content="renderContent"
          :judge="judge"
          :node-class="NodeClass" />
      </div>
    </lui-dialog>
    <!--批量上传失败提示-->
    <lui-dialog
      class="error-dialog"
      :title="updatedTitle"
      :visible.sync="dialogTableVisible"
      :close-on-click-modal="false">
      <div class="dialog-table-list">
        <div
          v-show="moreErr"
          style="color: red;font-size: 12px">异常太多，最多显示300条</div>
        <lui-table
          stripe
          size="mini"
          :data="gridData">
          <lui-table-column
            align="center"
            label="行号"
            width="150">
            <template slot-scope="{row}">
              <p>第{{ row.rowNo }}行异常</p>
            </template>
          </lui-table-column>

          <lui-table-column
            prop="errorMsg"
            align="center"
            label="异常原因"
            show-overflow-tooltip>
          </lui-table-column>
        </lui-table>
      </div>
    </lui-dialog>
  </div>
</template>

<script>
import http from '@/lib/http'
import ButtonList from '@/views/common/ButtonList'
import showEmptyImage from '@/components/common/showEmptyImage/index.vue'
import BodTree from '../common/org-tree/org-tree.vue'
import {
  exportExcel
} from '@/utils/downloadRequest'
import Api from '@/api'
import $ from 'jquery'
const buttons = {
  upload: {
    noAsync: true,
    maxM: 10,
    uploadtips: '只能上传xlsx文件，文件大小不超过10M',
    label: '批量上传',
    uploadConfig: {
      uploadActionUrl: http.baseContextUrl + 'bodNodes/upload'
    },
    templateUrl: http.baseContextUrl + 'bodNodes/downloadTemplate'
  }
}
export default {
  name: 'configure.veu',
  components: {
    showEmptyImage,
    ButtonList,
    BodTree
  },
  data() {
    return {
      isEntrance: false,
      updatedTitle: '批量上传',
      gridData: [],
      moreErr: false,
      dialogTableVisible: false, //删除错误提示
      buttons,
      checkDeptNo: false, //默认false表示不上传事业部
      loadingPreviewShow: true,
      //打开分配详情树形结构展示
      bodNode: {},
      //============================>详情树形结构显示
      judge: {
        switch: true
      },
      treedata: [],
      NodeClass: ['factory', 'rdc', 'fdc', 'cdc', 'store', 'tc'],
      //=================================>列表、查询条件
      pickerBeginDateBefore: {}, //生效时间
      pickerBeginDateAfter: {}, //失效时间
      bodName: '', //Bod编码
      bodNo: '', //Bod编码
      bodState: '', //BOD状态
      deptNo: '', //事业部编码
      endDate: '', //结束时间
      startDate: '', //开始时间
      totals: 0, //总条数
      pageNum: 1, //页
      pageSize: 10, //条数
      LoadingTable: false,
      tableData: [], //列表数据
      deptNoList: [], //事业部列表
      multipleSelection: [], //全选反选
      timeout: null,
      bodStateList: [{
        code: 1,
        name: '未生效'
      },
      {
        code: 2,
        name: '有效'
      },
      {
        code: 3,
        name: '失效'
      },
      {
        code: 4,
        name: '预警'
      }
      ],
      list: [],
      //=================================> 新增编辑条件
      nodeTitle: '下游库节点',
      nodePlace: '请选择下游库节点 ',
      priorityShow: false, //优先级控制
      pickerOptions1: {},
      nowTimeNew: '', //时间控制
      editShow: false, //编辑判断 true--编辑   false--新增
      buttonLoading: false,
      disabledNode: false, //控制库节点是否显示
      addFormBodList: [], //前端存放整体图形JSON
      addNodeJSON: [], //点击存放图形JSON---去重使用
      addNodeList: '', //存放图形点击时数据信息----新增使用
      leftShowCanvas: false,
      distributionRules: [], //分配规则
      centerDialogVisible: false, //弹窗===>新增
      libraryList: [],
      stateTitle: '新增BOD配置',
      checkedShow: true, //新增有效期显示与隐藏
      ruleForm: {
        alwaysEffective: false, //始终有效
        bodName: '', //bod名称
        bodNo: '', //bod编码
        bodState: '0', //bod状态
        deptName: '', //事业部名称
        deptNo: '', //事业部编码
        endDate: '', //失效日期
        startDate: '', //生效日期
        sellerName: '', //商户名称
        sellerNo: '', //商户编码
        dataList: [], //时间数组存放
        bodNode: {}
      },
      rules: {
        deptNo: [{
          required: true,
          message: '请选择事业部',
          trigger: ['blur', 'change']
        }], //事业部选择

        bodName: [{
          required: true,
          message: '请输入BOD名称',
          trigger: ['blur', 'change']
        }], //BOD名称
        // bodNo: [{ required: true, message: '请输入BOD编码', trigger: ['blur', 'change'] }], //BOD编码
        dataList: [{
          required: true,
          message: '请选择有效期',
          trigger: ['blur', 'change']
        }] //BOD 数据选择
      },
      addForm: {
        nodeNo: '',
        nodeName: '',
        distributionPatio: '',
        dayNum: '',
        distributionRules: '',
        children: [],
        maxReserveRatio: '',
        isNationwideTurnover: '',
        openRuleType: '',
        shopRatio: 0,
        fdcRatio: 0,
        rdcRatio: 0,
        entranceStockStay: '', //入口仓-冗余库存预留
        entranceReadUpperStock: '0',
        entranceAllocationType: 1 //入口仓-分配规则设置
      },
      addRules: {
        nodeNo: [{
          required: true,
          message: '请选择库节点',
          trigger: ['blur', 'change']
        }],
        maxReserveRatio: [{
          required: false,
          message: '请输入最大库存预留比例',
          trigger: ['blur', 'change']
        }],
        isNationwideTurnover: [{
          required: false,
          message: '请选择是否全国周转',
          trigger: ['blur', 'change']
        }],
        distributionPatio: [{
          required: true,
          message: '请输入最大可配出比',
          trigger: ['blur']
        }],
        dayNum: [{
          required: true,
          message: '请输入最低周转天数(1~99999)',
          trigger: ['blur'],
          pattern: /(^[1-9]{1}[0-9]{0,4}$)/
        }],
        distributionRules: [{
          required: true,
          message: '请选择分配规则',
          trigger: ['blur', 'change']
        }],
        entranceStockStay: [{
          required: true,
          message: '请选择冗余库存预留',
          trigger: ['blur', 'change']
        }],
        entranceAllocationType: [{
          required: true,
          message: '请选择分配规则',
          trigger: ['blur', 'change']
        }],
        openRuleType: [{
          required: true,
          message: '请选择是否启用最大可配出比分配规则',
          trigger: ['blur', 'change']
        }]
      },
      transportList: [], //运输方式
      nodePageNum: 1,
      nodePageSize: 10,
      nodeTotal: 0,
      //==================================>
      baseURL: http.baseContextUrl,
      value: '',
      //=====================>BOD复制
      copyBodTitle: 'BOD预览',
      copyLoading: false,
      tableDataCopy: [],
      copyDialogVisible: false,
      copyDialogPreview: false,
      bodCope: '',
      copyBodNo: '', //bod 编码
      copyNodeNo: '', //入口仓
      copyTotal: '', //入口仓
      // warehouseList: '', //入口仓
      copyPageNum: 1,
      copyPageSize: 10,
      nodeListStr: [], //删除库节点禁用状态
      nodeListStrEdit: [],
      nodeNoCopy: '',
      rightTableShow: true
     
    }
  },
  mounted() {
    //数据列表
    this.getList()
    this.queryDept()
    //图形展示
    this.getCanvas()
    //运输方式
    this.transport()
    //分配规则
    this.rulesList()
    this.dataAjax()
    //开始日期小于结束日期
    this.pickerOptions1 = {
      disabledDate: (time) => {
        if (this.nowTimeNew) {
          return time.getTime() < Date.now(this.nowTimeNew) - 1 * 24 * 3600 * 1000
        } else {
          return time.getTime() < Date.now() - 1 * 24 * 3600 * 1000
        }
      }
    }
  },
  methods: {
    //是否启用最大可分配配比规则
    handleOpenRuleType(val) {
      console.log(val, '========')
      if (val === '1') {
        this.addForm.shopRatio = 0
        this.addForm.fdcRatio = 0
        this.addForm.rdcRatio = 0
      }
    },
    //是否读取上游库存
    handleEntranceReadUpperStock(val) {
      console.log(typeof (val))
      if (val === '1' && this.addForm.entranceAllocationType === 1) {
        this.priorityShow = true
      } else {
        this.priorityShow = false
      }
    },
    dataAjax() { //获取当前时间
      const now = new Date($.ajax({
        async: false
      }).getResponseHeader('Date'))
      this.nowTimeNew = now.getTime()
    },
    //=====================================================================> 复制BOD 列表
    // 获取BOD下拉模糊搜索
    QuerySalesOrderCopy(queryString, cb) {
      if (queryString === '') {
        this.copyBodNo = ''
      }

      Api.BodConfig.getBaseByBodNo({
        bodNo: this.bodCope
      }).then((res) => {
        if (res.success) {
          var results = []
          if (res.data.length > 0) {
            for (let i = 0, len = res.data.length; i < len; i++) {
              res.data[i].value = res.data[i].bodName
            }
            results = res.data
          }
          cb(results)
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
      })
    },
    // // 选择BOD下拉模糊搜索
    handleQuerySalesOrderCopy(item) {
      this.copyBodNo = item.bodNo
    },
    // 选择入口仓下拉模糊搜索
    QuerySalesWarehouse(queryString, cb) {
      let str = ''

      if (queryString === '') {
        this.nodeNoCopy = ''
      } else {
        str = this.copyNodeNo.split(' ')[0]
      }

      Api.BodConfig.getNodeNameByBodNo({
        nodeNo: str
      }).then((res) => {
        if (res.success) {
          var results = []
          if (res.data.length > 0) {
            for (let i = 0, len = res.data.length; i < len; i++) {
              res.data[i].value = res.data[i].nodeNo + ' —— ' + res.data[i].nodeName
            }
            results = res.data
          }
          cb(results)
        }
      }).catch((e) => {})
    },
    // // 选择入口仓下拉模糊搜索
    handleQuerySalesWarehouse(item) {
      this.nodeNoCopy = item.nodeNo
    },

    //查询
    handleQueryCopy() {
      this.getListCopy()
    },
    //重置
    handleRestCopy() {
      this.bodCope = ''
      this.copyBodNo = ''
      this.copyNodeNo = ''
      this.nodeNoCopy = ''
      this.copyPageNum = 1
      this.getListCopy()
    },
    //列表页
    getListCopy() {
      this.copyLoading = true
      const params = {}
      params.pageNum = this.copyPageNum
      params.pageSize = this.copyPageSize
      params.bodNo = this.copyBodNo
      params.nodeNo = this.nodeNoCopy
      Api.BodConfig.listPage(params).then((res) => {
        if (res.success) {
          this.tableDataCopy = res.data
          this.copyTotal = res.total
          this.copyLoading = false
        } else {
          this.copyLoading = true
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
      })
    },
    //分页条数改变
    sizeChangeCopy(val) {
      this.copyPageSize = val
      this.getListCopy()
    },
    //翻页-----根据页码变换
    handleSizeChangeCopy(val) {
      this.copyPageNum = val
      this.getListCopy()
    },
    //预览 type=false 复制  type=true 预览
    handlePreview(item, type) {
      this.bodNode = {}
      if (type) {
        this.copyDialogPreview = true
        this.loadingPreviewShow = true
      }
      Api.BodConfig.getNodesByBodNo({
        bodNo: item.bodNo
      }).then(res => {
        if (res.success) {
          //图标赋值、运输方式、分配规则
          this.editBod(res.data.bodNode.children)
          if (type) {
            const datas = {
              dayNum: '1', //最低可配天数
              distributionPatio: '1', //最大可配占比
              distributionRules: '1', //分配规则
              parentNodeNo: '1', //上游节点编码
              priority: 1, //级别
              nodeNo: '1', //节点编码
              transportMode: '1', //运输方式
              label: '入口仓',
              level: 1,
              type: '',
              maxReserveRatio: '',
              isNationwideTurnover: '',
              tips: '',
              children: []
            }
            this.bodNode = datas
            this.bodNode.children = res.data.bodNode.children
            this.loadingPreviewShow = false
          } else {
            this.nodeListStrEdit = []
            for (let j = 0; j < this.libraryList.length; j++) {
              this.libraryList[j].disabled = false
            }

            const data = {
              dayNum: '1', //最低可配天数
              distributionPatio: '1', //最大可配占比
              distributionRules: '1', //分配规则
              parentNodeNo: '1', //上游节点编码
              priority: 1, //级别
              nodeNo: '1', //节点编码
              transportMode: '1', //运输方式
              label: '+ 入口仓',
              level: 1,
              type: '',
              maxReserveRatio: '',
              isNationwideTurnover: '',
              tips: '',
              entranceAllocationType: res.data.bodNode.entranceAllocationType,
              entranceReadUpperStock: res.data.bodNode.entranceReadUpperStock,
              entranceStockStay: res.data.bodNode.entranceStockStay,
              children: []
            }
            this.addForm.entranceAllocationType = res.data.bodNode.entranceAllocationType
            this.addForm.entranceReadUpperStock = res.data.bodNode.entranceReadUpperStock + ''
            this.addForm.entranceStockStay = res.data.bodNode.entranceStockStay
  
            this.$nextTick(() => {
              this.copyDialogPreview = false
              this.copyDialogVisible = false
              //复制之后隐藏右边并清空
              this.leftShowCanvas = false
              this.addForm.children = []
              this.$showSuccessMsg('复制成功')
              this.ruleForm.bodNode = data
              this.ruleForm.bodNode.children = res.data.bodNode.children
              this.deptEdit(this.ruleForm.bodNode)
              for (let i = 0; i < this.nodeListStrEdit.length; i++) {
                for (let j = 0; j < this.libraryList.length; j++) {
                  if (this.nodeListStrEdit[i].nodeNo === this.libraryList[j].nodeNo) {
                    this.libraryList[j].disabled = true
                  }
                }
              }
            })

          }
        } else {
          this.copyDialogPreview = false
          this.copyDialogVisible = false
          this.loadingPreviewShow = false
          this.$showErrorMsg(res.errMessage)
        }
      }).catch((e) => {
        this.copyDialogPreview = false
        this.loadingPreviewShow = false
        this.$showErrorMsg(e)
      })
    },
    //=====================================================================> 新增

    handerTop(scope) {
      if (scope.$index !== 0) {
        const obj = JSON.stringify(this.addForm.children[(scope.$index) - 1])
        this.addForm.children[(scope.$index) - 1] = scope.row
        this.addForm.children[(scope.$index)] = JSON.parse(obj)
        this.rightTableShow = false
        this.rightTableShow = true
      }
    },

    //图标判断显示
    changeChecked(source) {
      for (var i in source) {
        const item = source[i]
        if (item.type === 'factory') {
          item.switch = 'factory'
        } else if (item.type === 'fdc') {
          item.switch = 'fdc'
        } else if (item.type === 'rdc') {
          item.switch = 'rdc'
        } else if (item.type === 'cdc') {
          item.switch = 'cdc'
        } else if (item.type === 'store') {
          item.switch = 'store'
        } else if (item.type === 'tc') {
          item.switch = 'tc'
        } else {
          item.switch = '1'
        }
        if (item.children && item.children.length > 0) {
          this.changeChecked(item.children)
        }
      }
    },
    //实例化树形结构
    getCanvas() {
      const data = {
        dayNum: '1', //最低可配天数
        distributionPatio: '1', //最大可配占比
        distributionRules: '1', //分配规则
        parentNodeNo: '1', //上游节点编码
        priority: 1, //级别
        nodeNo: '1', //节点编码
        transportMode: '1', //运输方式
        label: '+ 入口仓',
        level: 1,
        type: '',
        tips: '',
        maxReserveRatio: '',
        isNationwideTurnover: '',
        children: []
      }
      //根据预览BOD状态判断图形展示

      if (this.copyDialogVisible) {
        this.bodNode = data
      } else {
        this.ruleForm.bodNode = data
        const data2 = []
        data2.push(this.addForm.children)
        this.changeChecked(data2)
      }
    },
    //点击当前图形事件
    NodeClickadd(e, data) {
      console.log(data, 555555555555555)
      if (this.ruleForm.deptNo === '') {
        return this.$showErrorMsg('请先选择事业部')
      }
      if (this.addForm.children.length > 0) {
        if (this.disabledNode) {
          for (let i = 0; i < this.addForm.children.length; i++) {
            if (this.addForm.children[i].nodeNo === '') {
              this.$showErrorMsg('请选择或删除第 ' + (i + 1) + ' 条下游库节点')
              return
            }
            if (this.addForm.children[i].transportMode === '') {
              this.$showErrorMsg('请选择或删除第 ' + (i + 1) + ' 条运输方式')
              return
            }
            if (this.addForm.distributionRules === 1) {
              if (this.addForm.children[i].priority === '') {
                this.$showErrorMsg('请输入或删除第 ' + (i + 1) + ' 条优先级')
                return
              }
            }
          }
        } else {
          for (let i = 0; i < this.addForm.children.length; i++) {
            if (this.addForm.children[i].nodeNo === '') {
              this.$showErrorMsg('请选择或删除第 ' + (i + 1) + ' 条入口仓')
              return
            }
          }
        }
      }
      this.nodeListStr = []
      if (data.label === '+ 入口仓') {
        this.disabledNode = false
        this.priorityShow = false
        this.nodeTitle = '入口仓'
        this.nodePlace = '请选择入口仓'
      } else {
        this.nodeTitle = '下游库节点'
        this.nodePlace = '请选择下游库节点'
        this.disabledNode = true
        if (data.distributionRules === 1) {
          this.priorityShow = true
        } else {
          this.priorityShow = false
        }
      }
      this.leftShowCanvas = true
      this.$nextTick(() => {
        this.$refs['addForm'].clearValidate()
      })
      // 当前项的所有详情 如：id label children

      this.addForm.openRuleType = data.openRuleType ? data.openRuleType + '' : '0'
      this.addForm.shopRatio = data.shopRatio
      this.addForm.fdcRatio = data.fdcRatio
      this.addForm.rdcRatio = data.rdcRatio
      this.addForm.nodeNo = data.nodeNo
      this.addForm.nodeName = data.nodeName
      this.addForm.distributionPatio = data.distributionPatio
      this.addForm.dayNum = data.dayNum
      this.addForm.distributionRules = data.distributionRules
      this.addForm.maxReserveRatio = data.maxReserveRatio
      this.addForm.isNationwideTurnover = data.isNationwideTurnover
      
      if (!data.type) {
        this.isEntrance = true
        if (this.addForm.entranceReadUpperStock === '1' && this.addForm.entranceAllocationType === 1) {
          this.priorityShow = true
        } else {
          this.priorityShow = false
        }
      } else {
        this.isEntrance = false
      }
     
      if (data.children) {
        this.addForm.children = data.children
      } else {
        this.addForm.children = []
      }
      
      this.addNodeList = data
      // if (this.addNodeList.children) {
      this.addNodeJSON = JSON.stringify(this.addNodeList)
      // }
      console.log(data, this.addForm.children, 'data')
    },
    //删除当前节点
    handleDelBod() {
      const data = this.addNodeList
      if (this.addNodeList.label === '+ 入口仓') {
        return
      } else {
        //判断当前是否有未保存选项
        if (this.disabledNode) {
          for (let i = 0; i < this.addForm.children.length; i++) {
            if (this.addForm.children[i].nodeNo === '') {
              this.$showErrorMsg('请选择或删除第 ' + (i + 1) + ' 条下游库节点')
              return
            }
            if (this.addForm.children[i].transportMode === '') {
              this.$showErrorMsg('请选择或删除第 ' + (i + 1) + ' 条运输方式')
              return
            }
            if (this.addForm.distributionRules === 1) {
              if (this.addForm.children[i].priority === '') {
                this.$showErrorMsg('请输入或删除第 ' + (i + 1) + ' 条优先级')
                return
              }
            }
          }
        } else {
          for (let i = 0; i < this.addForm.children.length; i++) {
            if (this.addForm.children[i].nodeNo === '') {
              this.$showErrorMsg('请选择或删除第 ' + (i + 1) + '  条入口仓')
              return
            }
          }
        }
        this.leftShowCanvas = false
        const ary01 = []
        ary01.push(this.ruleForm.bodNode)
        this.loopDel(ary01, data)
        for (let i = 0; i < this.libraryList.length; i++) {
          if (data.nodeNo === this.libraryList[i].nodeNo) {
            this.libraryList[i].disabled = false
          }
        }
        const strObj = JSON.parse(this.addNodeJSON)
        this.deptDel(strObj)
        for (const i of this.nodeListStr) {
          for (const n of this.libraryList) {
            if (n.nodeNo === i.nodeNo) {
              n.disabled = false
            }
          }
        }
      }
    },
    // 递归删除子节点
    loopDel(arr, item) {
      for (let i = 0; i < arr.length; i++) {
        if (item === arr[i]) {
          this.$alert('<p style="font-size: 18px;color:#333">确定删除此节点以及下游节点的信息吗？</p><p style="font-size: 13px;color: #666"></p>', '', {
            dangerouslyUseHTMLString: true,
            type: 'warning',
            center: true
          }).then(() => {
            arr.splice(i, 1)
            return
          }).catch(() => {})
        }
        if (arr[i].children && arr[i].children.length > 0) {
          this.loopDel(arr[i].children, item)
        }
      }
    },
    // 分配规则判断是否优先级
    handleDistribution(val) {
      if (val === 1) {
        this.priorityShow = true
      } else {
        this.priorityShow = false
      }
    },
    //新增节点
    handleSubmit(addForm) {
      this.$refs[addForm].validate((valid) => {
        if (valid) {
          if (this.addForm.openRuleType === '1') {
            let sum = this.addForm.shopRatio + this.addForm.fdcRatio + this.addForm.rdcRatio
            if (sum > 100) {
              this.$showErrorMsg('门店+FDC+RDC最大可分配占比总和不能大于100')
              return
            }
          } else {
            this.addForm.shopRatio = 0
            this.addForm.fdcRatio = 0
            this.addForm.rdcRatio = 0
          }

          if (this.disabledNode) {
            for (let i = 0; i < this.addForm.children.length; i++) {
              if (this.addForm.children[i].nodeNo === '') {
                this.$showErrorMsg('请选择或删除第 ' + (i + 1) + ' 条下游库节点')
                return
              }
              if (this.addForm.children[i].transportMode === '') {
                this.$showErrorMsg('请选择或删除第 ' + (i + 1) + ' 条运输方式')
                return
              }
              if (this.addForm.distributionRules === 1) {
                if (this.addForm.children[i].priority === '') {
                  this.$showErrorMsg('请输入或删除第 ' + (i + 1) + ' 条优先级')
                  return
                }
              }
            }
          } else {
            for (let i = 0; i < this.addForm.children.length; i++) {
              if (this.addForm.children[i].nodeNo === '') {
                this.$showErrorMsg('请选择或删除第 ' + (i + 1) + ' 条入口仓')
                return
              }
            }
          }
          this.nodeListStrEdit = [] //先清空在赋值
          let arrList = []
          if (this.addNodeList.children) {
            for (let i = 0; i < this.addNodeList.children.length; i++) {
              for (let j = 0; j < this.addForm.children.length; j++) {
                this.addForm.children[j].priority = Number(this.addForm.children[j].priority) //强制转数字
                if (this.addNodeList.children[i] !== this.addForm.children[j]) {
                  arrList.push(this.addForm.children[j])
                }
              }
            }
          }
          // if (this.priorityShow) {
          for (let i = 0; i < this.addForm.children.length; i++) {
            this.addForm.children[i].priority = i + 1
            this.addForm.children[i].entrancePriorityLevel = i + 1
          }
          // }
          //确定时先将所有的库节点disabled设为false
          for (let j = 0; j < this.libraryList.length; j++) {
            this.libraryList[j].disabled = false
          }
          arrList = this.addForm.children
        
          this.addNodeList.nodeNo = this.addForm.nodeNo
          this.addNodeList.nodeName = this.addForm.nodeName
          this.addNodeList.dayNum = this.addForm.dayNum
          this.addNodeList.rdcRatio = this.addForm.rdcRatio
          this.addNodeList.fdcRatio = this.addForm.fdcRatio
          this.addNodeList.shopRatio = this.addForm.shopRatio
          this.addNodeList.distributionPatio = this.addForm.distributionPatio
          this.addNodeList.distributionRules = this.addForm.distributionRules
          this.addNodeList.maxReserveRatio = this.addForm.maxReserveRatio
          this.addNodeList.isNationwideTurnover = this.addForm.isNationwideTurnover
          //判断是否第一次新增
          if (this.addForm.type !== undefined) {
            this.addNodeList.type = this.addForm.type
          }
          //判断是不是入口仓
          if (!this.addNodeList.type) {
            this.addNodeList.entranceReadUpperStock = Number(this.addForm.entranceReadUpperStock)
            this.addNodeList.entranceAllocationType = this.addForm.entranceAllocationType
            this.addNodeList.entranceStockStay = this.addForm.entranceStockStay
          } else {
            this.addNodeList.openRuleType = Number(this.addForm.openRuleType)
            this.addNodeList.shopRatio = this.addForm.shopRatio
            this.addNodeList.fdcRatio = this.addForm.fdcRatio
            this.addNodeList.rdcRatio = this.addForm.rdcRatio
          }
          this.addNodeList.children = arrList
          const ary01 = this.ruleForm.bodNode
          this.ruleForm.bodNode = JSON.parse(JSON.stringify(ary01))
          this.addFormBodList = JSON.stringify(this.ruleForm.bodNode.children)
          const data2 = []
          data2.push(this.ruleForm.bodNode)
          this.changeChecked(data2)
          this.leftShowCanvas = false
          //最后将已选字段disabled设为true
          this.deptEdit(this.ruleForm.bodNode)
          for (let i = 0; i < this.nodeListStrEdit.length; i++) {
            for (let j = 0; j < this.libraryList.length; j++) {
              if (this.nodeListStrEdit[i].nodeNo === this.libraryList[j].nodeNo) {
                this.libraryList[j].disabled = true
              }
            }
          }
        }
      })
    },
    //运输方式
    handleSelectTar(val, index) {
      var obj = {} //多条件查找
      obj = this.transportList.find(function(item) {
        return item.code === val
      })
      this.addForm.children[index].transportModeName = obj.name
    },
    //库节点选择---父节点
    handleSelectNodePart(val) {
      var obj = {} //多条件查找
      obj = this.libraryList.find(function(item) {
        return item.nodeNo === val
      })
      switch (obj.nodeType) { //根据库节点判断图形形态
        case 1:
        case 8:
          this.addForm.type = 'factory'//工厂
          break
        case 2:
          this.addForm.type = 'fdc'//区域仓
          break
        case 3:
          this.addForm.type = 'rdc'//前置仓
          break
        case 4:
        case 6:
        case 7:
          this.addForm.type = 'store' //门店
          break
        case 5:
        case 9:
          this.addForm.type = 'cdc' //中央仓
          break
        case 10:
          this.addForm.type = 'tc' //TC仓库
          break
      }
      this.addForm.nodeName = obj.nodeName

      for (let i = 0; i < this.addForm.children.length; i++) {
        if (this.addForm.children[i].nodeNo === val) {
          this.$showErrorMsg('上下游库节点不能重复')
          this.addForm.nodeNo = this.addNodeList.nodeNo
          this.addForm.nodeName = this.addNodeList.nodeName
        }
      }

      //判断选择的与已选的比较
      const listObj = JSON.parse(this.addNodeJSON)
      const nodeNo = listObj.nodeNo
      for (const n of this.libraryList) {
        if (n.nodeNo === nodeNo) {
          n.disabled = false
          break
        }
      }

    },
    //库节点-----子节点
    handleSelectNode(val, index) {

      var obj = {} //多条件查找
      obj = this.libraryList.find(function(item) {
        return item.nodeNo === val
      })
      switch (obj.nodeType) { //根据库节点判断图形形态
        case 1:
        case 8:
          this.addForm.children[index].type = 'factory'
          break
        case 2:
          this.addForm.children[index].type = 'fdc'
          break
        case 3:
          this.addForm.children[index].type = 'rdc'
          break
        case 4:
        case 6:
        case 7:
          this.addForm.children[index].type = 'store'
          break
        case 5:
        case 9:
          this.addForm.children[index].type = 'cdc'
          break
        case 10:
          this.addForm.children[index].type = 'tc'
          break
      }
      console.log(this.addForm,'this.addForm')
      this.addForm.children[index].nodeName = obj.nodeName
     
      for (let i = 0; i < this.addForm.children.length; i++) {
        //本地循环判断如果有则空
        if (this.addForm.children[i].nodeNo === this.addForm.nodeNo) {
          this.$showErrorMsg('上下游库节点不能重复')
          this.addForm.children[i].nodeNo = ''
          this.addForm.children[i].nodeName = ''
          return
        }
        for (let j = i + 1; j < this.addForm.children.length; j++) {
          if (this.addForm.children[i].nodeNo === this.addForm.children[j].nodeNo) {
            if (this.disabledNode) {
              this.$showErrorMsg('下游库节点不能重复')
            } else {
              this.$showErrorMsg('入口仓已存在')
            }
            this.addForm.children[index].nodeNo = ''
            this.addForm.children[index].nodeName = ''
            j--
            return
          }
        }
      }
      //判断选择的与已选的比较
      const listObj = JSON.parse(this.addNodeJSON)
      console.log(listObj.children, '88889')
      if (listObj.children && listObj.children.length > 0) {
        if (this.addForm.children.length <= listObj.children.length) {
          const nodeNo = listObj.children[index].nodeNo
          for (const n of this.libraryList) {
            if (n.nodeNo === nodeNo) {
              n.disabled = false
              break
            }
          }
        }
      }
    },
    //运输方式
    transport() {
      Api.BodConfig.transportMode()
        .then((res) => {
          if (res.success) {
            this.transportList = res.data
          }
        }).catch((e) => {
          this.$showErrorMsg(e)
        })
    },
    //删除该行库节点
    deleteRowEdit(row, index, cg) {
      this.$alert('<p style="font-size: 18px;color:#333">确定删除此节点的信息吗？</p><p style="font-size: 13px;color: #666"></p>', '', {
        dangerouslyUseHTMLString: true,
        type: 'warning',
        center: true
      }).then(() => {
        this.addForm.children.splice(index, 1)
        return
      }).catch(() => {})
      const strObj = JSON.parse(this.addNodeJSON)
      this.deptDel(strObj)
      for (const i of this.nodeListStr) {
        for (const n of this.libraryList) {
          if (n.nodeNo === i.nodeNo) {
            n.disabled = false
          }
        }
      }
    },
    //解决禁用
    deptDel(arr) {
      if (arr.children) {
        for (let i = 0; i < arr.children.length; i++) {
          this.nodeListStr.push(arr.children[i])
          if (arr.children[i].children) {
            this.deptDel(arr.children[i])
          }
        }
      } else {
        this.nodeListStr.push(arr)
      }

    },
    // 添加仓库节点
    handleNodeAdd(tableData) {
      if (this.disabledNode) {
        for (let i = 0; i < this.addForm.children.length; i++) {
          if (this.addForm.children[i].nodeNo === '') {
            this.$showErrorMsg('请选择第' + (i + 1) + '条下游库节点')
            return
          }
          if (this.addForm.children[i].transportMode === '') {
            this.$showErrorMsg('请选择第' + (i + 1) + '条运输方式')
            return
          }
          if (this.addForm.distributionRules === 1) {
            if (this.addForm.children[i].priority === '') {
              this.$showErrorMsg('请选择第' + (i + 1) + '条优先级')
              return
            }
          }
          // this.addForm.children[i].parentNodeNo = this.addNodeList.nodeNo //复制上游库节点
        }
      } else {
        for (let i = 0; i < this.addForm.children.length; i++) {
          if (this.addForm.children[i].nodeNo === '') {
            this.$showErrorMsg('请选择第 ' + (i + 1) + ' 条入口仓')
            return
          }
        }
      }

      const obj = {
        parentNodeNo: this.addNodeList.nodeNo, //父节点编码
        transportMode: '', //运输方式
        priority: tableData.length, //优先级
        transportModeName: '',
        nodeNo: '', //库节点
        nodeName: '', //库节点名称
        distributionPatio: '',
        dayNum: '',
        distributionRulesName: '',
        distributionRules: '',
        type: '',
        tips: '',
        label: '',
        maxReserveRatio: '',
        isNationwideTurnover: '',
        level: '',
        children: []
      }
      tableData.push(obj)
      console.log(tableData, 111)
    },
    //库节点列表
    baseNodeInfo(val) {
      Api.BodConfig.baseNodeInfo({
        deptNo: val
      }).then((res) => {
        if (res.success) {
          this.libraryList = res.data
          if (this.editShow) { //如果编辑标识为true 打开新增弹窗
            this.centerDialogVisible = true
          }
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
      })
    },
    //递归编辑查看是否禁用
    deptEdit(arr) {
      for (let i = 0; i < arr.children.length; i++) {
        this.nodeListStrEdit.push(arr.children[i])
        if (arr.children[i].children) {
          this.deptEdit(arr.children[i])
        }
      }
    },
    //编辑
    handlerEdit(item) {
      //编辑标识
      this.editShow = true
      this.stateTitle = '编辑BOD配置'
      //清空库节点列表
      this.nodeListStrEdit = []
      this.libraryList = []
      this.addForm.children = []
      //调用库节点方法赋值libraryList
      this.baseNodeInfo(item.deptNo)
      // 新增右边条件显示隐藏
      this.leftShowCanvas = false
      //库节点是否禁用
      Api.BodConfig.getNodesByBodNo({
        bodNo: item.bodNo
      }).then(res => {
        if (res.success) {
          //判断有效期是否显示隐藏
          this.checkedShow = !res.data.alwaysEffective
          //始终有效时间不回显
          if (res.data.alwaysEffective) {
            this.ruleForm.dataList = []
          } else {
            this.ruleForm.dataList = [res.data.startDate, res.data.endDate]
          }
          //图标赋值、运输方式、分配规则
          this.editBod(res.data.bodNode.children)
          this.ruleForm.bodName = res.data.bodName
          this.ruleForm.bodNo = res.data.bodNo
          this.ruleForm.deptNo = res.data.deptNo
          this.ruleForm.deptName = res.data.deptName
          this.ruleForm.alwaysEffective = res.data.alwaysEffective
          this.ruleForm.bodState = res.data.bodState
          this.ruleForm.sellerName = res.data.sellerName
          this.ruleForm.sellerNo = res.data.sellerNo
          this.addForm.entranceReadUpperStock = res.data.bodNode.entranceReadUpperStock + ''
          this.addForm.entranceStockStay = res.data.bodNode.entranceStockStay
          this.addForm.entranceAllocationType = res.data.bodNode.entranceAllocationType
          const data = {
            dayNum: '1', //最低可配天数
            distributionPatio: '1', //最大可配占比
            distributionRules: '1', //分配规则
            parentNodeNo: '1', //上游节点编码
            priority: 1, //级别
            nodeNo: '1', //节点编码
            transportMode: '1', //运输方式
            label: '+ 入口仓',
            level: 1,
            type: '',
            maxReserveRatio: '',
            isNationwideTurnover: '',
            tips: '',
            children: [],
            entranceReadUpperStock: '0'
          }
          for (let i = 0; i < res.data.bodNode.children.length; i++) {
            res.data.bodNode.children[i].parentNodeNo = 1
          }

          this.ruleForm.bodNode = data
          this.ruleForm.bodNode.children = res.data.bodNode.children
         
          //递归平铺数据
          this.deptEdit(this.ruleForm.bodNode)
          // 宏任务解决是否禁用
          setTimeout(() => {
            for (let i = 0; i < this.nodeListStrEdit.length; i++) {
              for (let j = 0; j < this.libraryList.length; j++) {
                if (this.nodeListStrEdit[i].nodeNo === this.libraryList[j].nodeNo) {
                  this.libraryList[j].disabled = true
                }
              }
            }

            for (let i = 0; i < this.nodeListStrEdit.length; i++) {
              for (let j = 0; j < this.libraryList.length; j++) {
                if (this.nodeListStrEdit[i].nodeNo === this.libraryList[j].nodeNo) {
                  this.libraryList[j].disabled = true
                }
              }
            }
          }, 1000)
        }
      }).catch((e) => {
        this.centerDialogVisible = false
        this.$showErrorMsg(e)
      })
    },
    //图标赋值、运输方式、分配规则
    editBod(arr) {
      for (let i = 0; i < arr.length; i++) {
        switch (arr[i].nodeType) { //根据库节点判断图形形态
          case 1:
          case 8:
            arr[i].type = 'factory'
            arr[i].switch = 'factory'
            break
          case 2: 
            arr[i].type = 'fdc'
            arr[i].switch = 'fdc'
            break
          case 3:
            arr[i].type = 'rdc'
            arr[i].switch = 'rdc'
            break
          case 4:
          case 6:
          case 7:
            arr[i].type = 'store'
            arr[i].switch = 'store'
            break
          case 5:
          case 9:
            arr[i].type = 'cdc'
            arr[i].switch = 'cdc'
            break
          case 10:
            arr[i].type = 'tc'
            arr[i].switch = 'tc'
            break
        }
        //运输方式回显
        for (let j = 0; j < this.transportList.length; j++) {
          if (arr[i].transportMode === this.transportList[j].code) {
            arr[i].transportModeName = this.transportList[j].name
          }
        }
        //优先级回显
        for (let j = 0; j < this.distributionRules.length; j++) {
          if (arr[i].distributionRules === this.distributionRules[j].code) {
            arr[i].distributionRulesName = this.distributionRules[j].name
          }
        }
        if (arr[i].children) {
          this.editBod(arr[i].children)
        }
      }
    },
    //打开新增弹窗
    handleAdd() {
      this.editShow = false
      this.stateTitle = '新增BOD配置'
      this.addForm.children = []
      this.centerDialogVisible = true
      this.leftShowCanvas = false
      this.libraryList = []
      this.addFormBodList = []
      this.ruleForm.bodName = ''
      this.ruleForm.bodNo = ''
      this.ruleForm.deptName = ''
      this.ruleForm.deptNo = ''
      this.ruleForm.alwaysEffective = false
      this.ruleForm.dataList = []
      this.ruleForm.bodNode.children = []
      this.checkedShow = true
      this.$nextTick(() => {
        this.$refs.ruleForm.clearValidate()
      })
    },
    //提交
    submitForm(formName) {
      this.$refs[formName].validate((valid) => {
        this.ruleForm.startDate = this.ruleForm.dataList[0]
        this.ruleForm.endDate = this.ruleForm.dataList[1]

        if (valid) {
          if (this.leftShowCanvas) {
            this.$showErrorMsg('请确定或取消库节点编辑')
            return
          }
          this.buttonLoading = true
          if (this.editShow) { //编辑
            //数据第一层children transportMode 强制设为1
            for (let i = 0; i < this.ruleForm.bodNode.children.length; i++) {
              if (this.ruleForm.bodNode.children[i].transportMode == null) {
                this.ruleForm.bodNode.children[i].transportMode = 1
              }
            }
            console.log(this.ruleForm, 'edit')
            Api.BodConfig.editBodNodes(this.ruleForm).then((res) => {
              if (res.success) {
                this.$showSuccessMsg('编辑成功')
                this.buttonLoading = false
                this.centerDialogVisible = false
                this.leftShowCanvas = false
                this.getList()
              } else {
                this.buttonLoading = false
                this.$showErrorMsg(res.errMessage)
              }
            }).catch((e) => {
              this.$showErrorMsg(e)
              this.buttonLoading = false
            })
          } else { //新增
            console.log(this.ruleForm, 'add')
            Api.BodConfig.saveBodBaseInfo(this.ruleForm).then((res) => {
              if (res.success) {
                this.$showSuccessMsg('新增成功')
                this.buttonLoading = false
                this.centerDialogVisible = false
                this.leftShowCanvas = false
                this.getList()
              } else {
                this.buttonLoading = false
                this.$showErrorMsg(res.errMessage)
              }
            }).catch((e) => {
              this.$showErrorMsg(e)
              this.buttonLoading = false
            })
          }
        }
      })
    },
    //取消右边
    resetForm(addForm) {
      for (let i = this.addForm.children.length - 1; i >= 0; i--) {
        if (this.addForm.children[i].switch === undefined || this.addForm.children[i].switch === null) {
          this.addForm.children.splice(i, 1)
        }
      }
      this.leftShowCanvas = false
    },
    //关闭弹窗
    closeDialog(type) {
      if (type) {
        this.$refs[type].resetFields()
        this.centerDialogVisible = false
      }
    },
    //复制
    handleCopy() {
      if (this.ruleForm.deptNo === '') {
        return this.$showErrorMsg('请先选择事业部')
      }
      this.copyDialogVisible = true
      this.bodCope = ''
      this.copyBodNo = ''
      this.copyNodeNo = ''
      this.nodeNoCopy = ''
      this.getListCopy()
    },
    //始终有效控制有效期显示隐藏
    handleChecked(val) {
      this.checkedShow = !val
    },
    //事业部选取
    handleSelectDept(val) {
      var obj = {} //多条件查找
      obj = this.deptNoList.find(function(item) {
        return item.deptNo === val
      })
      this.ruleForm.deptName = obj.deptName
      this.baseNodeInfo(val)
      this.addForm.children = []
      this.addForm.entranceStockStay = ''
      this.ruleForm.bodNode.children = []
    },
    //分配规则
    rulesList() {
      Api.BodConfig.distributionRules().then((res) => {
        if (res.success) {
          this.distributionRules = res.data
          console.log(this.distributionRules, 888)
        }
      }).catch(() => {})
    },
    //=====================================================================>表格数据操作
    //生效日趋
    handleStartTime() {
      if (this.startDate !== '') {
        //结束日期小于开始日期
        this.pickerBeginDateAfter = {
          disabledDate: (time) => {
            var start = new Date(this.startDate).getTime()
            if (start) {
              return time.getTime() < start
            }
          }
        }
      }
    },
    handleEndTime() { //结束时间
      if (this.endDate !== '') {
        //开始日期小于结束日期
        this.pickerBeginDateBefore = {
          disabledDate: (time) => {
            var end = new Date(this.endDate).getTime()
            if (end) {
              return (time.getTime() > new Date(this.endDate).getTime())
            }
          }
        }
      }
    },
    //数据列表
    getList() {
      this.LoadingTable = true
      const params = {
        bodState: this.bodState, //bod状态
        bodNo: this.bodNo, //Bod编码
        deptNo: this.deptNo.split('&')[0], //事业部编码
        endDate: this.endDate, //结束时间
        startDate: this.startDate, //开始时间
        pageNum: this.pageNum, //页
        pageSize: this.pageSize //条数
      }
      Api.BodConfig.listPage(params).then((res) => {
        if (res.success) {
          this.LoadingTable = false
          this.totals = res.total
          this.tableData = res.data
        } else {
          this.LoadingTable = false
          this.$showErrorMsg(res.errMessage)
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
      })
    },
    //下载模版
    download() {
      const params = {
        bodState: this.bodState, //bod状态
        bodNo: this.bodNo, //Bod编码
        deptNo: this.deptNo.split('&')[0], //事业部编码
        endDate: this.endDate, //结束时间
        startDate: this.startDate, //开始时间
        pageNum: this.pageNum, //页
        pageSize: this.pageSize //条数
      }
      const actionUrl = this.baseURL + Api.BodConfig.download
      exportExcel(actionUrl, params)
    },
    //删除
    handleDel() {
      if (this.multipleSelection.length === 0) {
        this.$showErrorMsg('请选择数据')
        return
      }
      const crrId = []
      for (let i = 0; i < this.multipleSelection.length; i++) {
        crrId.push(this.multipleSelection[i].id)
      }
      this.delete(crrId)
    },
    //  删除方法
    delete(row) {
      this.$alert('<p style="font-size: 18px;color:#333">确认删除此条消息吗?</p><p style="font-size: 13px;color: #666">删除后，此条消息的相关内容信息将无法恢复</p>', '', {
        dangerouslyUseHTMLString: true,
        type: 'warning',
        center: true
      }).then(() => {
        Api.BodConfig.deleteBodNodes({
          ids: row
        }).then((row) => {
          if (row.success) {
            this.$showSuccessMsg('删除成功')
            this.getList()
          } else {
            this.$showErrorMsg(row.errMessage)
          }
        }).catch((e) => {
          this.$showErrorMsg(e)
        })
      }).catch(() => {})
    },
    handleSelectionChange(val) {
      //全选反选
      this.multipleSelection = val
    },
    //分页条数改变
    sizeChange(val) {
      this.pageSize = val
      this.getList()
    },
    //翻页-----根据页码变换
    handleSizeChange(val) {
      this.pageNum = val
      this.getList()
    },
    //查询
    handleQuery() {
      this.getList()
    },
    //重置
    handleRest() {

      this.bodState = '' //bod状态
      this.goodsNo = '' //商品编码
      this.bodNo = '' //Bod编码
      this.bodName = '' //Bod编码
      this.deptNo = '' //事业部编码
      this.endDate = '' //结束时间
      this.startDate = '' //开始时间
      this.getList()
    },
    //获取事业部编码
    queryDept() {
      Api.BodCommodity.queryDept().then((row) => {
        if (row.success) {
          this.deptNoList = row.data
        } else {
          this.$showErrorMsg(row.errMessage)
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
      })
    },
    renderContent(h, data) {
      //如果是入口仓返回-----------------------------------------------------需要修改
      if (data.label === '+ 入口仓') {
        return h('div', { class: ['testparents'] }, [
          h('span', { class: ['taspam'] }, data.label),
          h('p', { class: ['testp'] }, data.nodeName) //标题
        ])
      } else {
        //判断是否为第一层库节点是机会隐藏运输方式
        if (data.parentNodeNo === 1 || data.parentNodeNo == null) {
          return h('div', { class: ['testparent'] }, [
            h('span', { class: ['taspam'] }, data.label),
            // h('lui-tooltip', { class: ['testparent'], content: [data.nodeName] }, [h('p', { class: ['testp'] }, data.nodeName)]), //标题
            h('lui-tooltip', {
              props: {
                effect: 'dark',
                content: data.nodeName,
                placement: 'bottom'
              }
            }, [h('p', { class: ['testp'] }, data.nodeName)]),
            h('i', { class: ['iconts lui-icon-caret-right'] }) //icon 图标
          ])
        } else {
          return h('div', { class: ['testparent'] }, [
            h('span', { class: ['testchild'] }, data.transportModeName),
            h('span', { class: ['taspam'] }, data.label),
            // h('p', { class: ['testp'] }, data.nodeName), //标题
            h('lui-tooltip', {
              props: {
                effect: 'dark',
                content: data.nodeName,
                placement: 'bottom'
              }
            }, [h('p', { class: ['testp'] }, data.nodeName)]),
            // [h('p', { class: ['testp'] }, data.nodeName)]), //标题
            // h('lui-tooltip', { class: ['testparent'], content: [data.nodeName] },
            h('i', { class: ['iconts lui-icon-caret-right'] }) //icon 图标
          ])
        }
      }
    },
    // renderContent(h, data) {
    //   //如果是入口仓返回
    //   if (data.label === '+ 入口仓') {
    //     return (<div class='testparents'><span class='testchild'>{data.transportModeName}</span><span class='taspam'>{data.label}</span><p class='testp'>{data.nodeName}</p></div>
    //     )
    //   } else {
    //     //判断是否为第一层库节点是机会隐藏运输方式
    //     if (data.parentNodeNo === 1 || data.parentNodeNo == null) {
    //       return (<div class='testparent'><span class= 'taspam'>{data.label}</span> <p class='testp'>{data.nodeName} </p><i class='iconts lui-icon-caret-right' ></i> </div>
    //       )
    //     } else {
    //       return (<div class='testparent'><span class='testchild'>{data.transportModeName}</span><span class='taspam'>{data.label}</span> <lui-tooltip placement='top' content='data.nodeName'><p class='testp' > {data.nodeName} </p></lui-tooltip> <i class='iconts lui-icon-caret-right'> </i> </div >)
    //     }
    //   }
    // },
    renderContentEdit(h, data) {
      //如果是入口仓返回
      if (data.label === '入口仓') {
        return (<div class='testparents'><span class='testchild'> {data.transportModeName}</span><span class='taspam'>{data.label}</span><p class='testp'>{data.nodeName}</p></div >)
      } else { //判断是否为第一层库节点是机会隐藏运输方式
        if (data.parentNodeNo == null) {
          return (<div class='testparent'><span class='taspam'>{data.label}</span><p class='testp'>{data.nodeName}</p><i class='iconts lui-icon-caret-right'></i></div>)
        } else {
          return (<div class='testparent'><span class='testchild'>{data.transportModeName}</span><span class='taspam'> {data.label}</span><p class='testp'>{data.nodeName}</p><i class='iconts lui-icon-caret-right'></i></div>)
        }
      }
    }
  }
}
</script>

<style lang="scss" scoped>
@import '@/assets/stylus/main';
@import "../../backstage/information/common/css/common.scss";
@import "../common/common";
.handle-btn{
  cursor: pointer;
  width: 17px;
  height: 17px;
}
.table-p {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  cursor: pointer;
  padding-right: 15px;
}

/*  弹窗信息*/
.demo-ruleForm {
  .ruleForm-title {
    display: flex;
    flex-wrap: wrap;
  }

  .ruleForm-buttons {
    margin-bottom: 10px;
    margin-top: 10px;
    display: flex;
    justify-content: space-between;
  }

  .ruleForm-content {
    border: 1px solid #d9d9d9;
    border-radius: 4px;
    display: flex;
    min-height: 500px;
    overflow: auto;

    .content-left {
      /*width: calc(100% - 550px);*/
      width: 100%;
      overflow: auto;
      position: relative;

      .left-mask {
        // display: none;
        position: absolute;
        top: 0;
        bottom: 0;
        width: 66px;
        left: 103px;
        z-index: 12;
        /* height: 100px; */
        background: #fff;
      }
    }

    .content-right {
      border-left: 1px solid #d9d9d9;
      width: 450px;

      .right-main {
        width: 410px;
        margin: 20px;

        .table-puls {
          margin-top: 15px;
          width: 100%;
          height: 36px;
          border: 1px $--gl-blue dashed;
          border-radius: 6px;
          text-align: center;
          color: $--gl-blue;
          /*line-height: 36px;*/
          cursor: pointer;
        }

        .knowledge-pagination {
          width: 100%;
          margin-top: 15px;
          text-align: right;
        }

        .table-button {
          display: flex;
          justify-content: space-around;
        }
      }

      .right-button {
        margin: 20px 0;
        text-align: center;
      }
    }
  }
}

//BOD复制
.dialog-mask-title {
  width: 100%;
  display: flex;

  .mask-left {
    display: flex;

    width: calc(100% - 180px);

    .select-content {
      .content-title {
        padding-right: 10px;
      }

      margin-right: 30px;
    }
  }

  .mask-right {
    display: flex;
    width: 180px;
  }

  .header-buttons {
    display: flex;
    justify-content: flex-end;
  }
}

.dialog-mask-content {
  margin-top: 30px;

  .table-look {
    cursor: pointer;
    color: $--gl-blue;
    font-size: 14px;
    font-weight: 500;
  }

  .table-button {
    display: flex;
    justify-content: space-around;
  }

  .knowledge-pagination {
    width: 100%;
    /*margin-top: 73px;*/
    margin-top: 20px;
    text-align: right;
  }
}

/*  预览*/
.preview-mask {
  min-height: 400px;
  overflow-y: auto;
  position: relative;

  .mask-cont {
    position: absolute;
    top: 0;
    bottom: 0;
    width: 167px;
    left: 0;
    z-index: 12;
    /* height: 100px; */
    background: #fff;
  }
}
</style>
