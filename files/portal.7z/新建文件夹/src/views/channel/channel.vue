<template>
  <div class="channel">
    <lui-table
      v-loading="LoadingTable"
      border
      :data="tableData"
      style="width: 100%"
    >
      <template slot="empty">
        <showEmptyImage></showEmptyImage>
      </template>
      <lui-table-column
        prop="appNameZh"
        label="应用名称"
        width="">
      </lui-table-column>
      <lui-table-column
        prop="passport"
        label="商家登录"
        width="">
        <template slot-scope="{row}">
          <lui-checkbox v-model="row.passport" disabled :true-label="1"></lui-checkbox>
        </template>
      </lui-table-column>
      <lui-table-column
        prop="erp"
        label="运营登录">
        <template slot-scope="{row}">
          <lui-checkbox v-model="row.erp" disabled :true-label="1"></lui-checkbox>
        </template>
      </lui-table-column>
    </lui-table>
  </div>
</template>

<script>
import Api from '@/api/index'
import Http from '@/lib/http'
// import { exportExcel } from '@/utils/downloadRequest'
// import ButtonList from '@/views/common/ButtonList'
import showEmptyImage from '@/components/common/showEmptyImage/index.vue'
// import { mapGetters } from 'vuex'

// const buttons = {
//   upload: {
//     noAsync: true,
//     maxM: 10,
//     uploadtips: '只能上传xlsx文件，文件大小不超过10M',
//     uploadConfig: {
//       uploadActionUrl: Http.baseContextUrl + 'baseGoodsCate/upload'
//     },
//     templateUrl: Http.baseContextUrl + 'baseGoodsCate/downloadTemplate'
//   }
//   // fileName: 'userInfoFile'
// }

export default {
  name: 'Channel',
  components: {
    // ButtonList,
    showEmptyImage
  },
  data() {
    return {
      LoadingTable: false,
      baseURL: Http.baseContextUrl,
      tableData: []
    }
  },
  mounted() {
    this.postListPage()
  },
  methods: {
    postListPage() {
      this.LoadingTable = true
      Api.BackStageChannel.postChannelList().then((res) => {
        if (res.success) {
          this.tableData = res.data
          this.total = res.total
          this.LoadingTable = false
        } else {
          this.LoadingTable = false
        }
      }).catch((e) => {
        console.error(e)
        this.LoadingTable = false
      })
    }
  }
}
</script>

<style lang="scss" scoped>
 
.channel {
  padding: 20px;
  background: #fff;
  min-height: 600px;
  .custom-table {
    margin-top: 20px;
    background: #fff;
    padding: 0 24px;
    box-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.1);
    border-radius: 4px;
    .table-header{
      display: flex;
      justify-content: space-between;
      padding: 20px 0;
      .header-title{
        height: 32px;
        line-height: 32px;
        .line{
          margin: 10px 6px 0 0;
        }
      }
    }
  }
  .footer {
    padding: 20px 0 30px 0;
    text-align: right;
  }
}
</style>
