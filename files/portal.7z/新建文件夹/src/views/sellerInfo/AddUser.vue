<template>
  <div style="position: relative">
    <lui-card v-loading="loading" class="form-container" shadow="never">
      <lui-button size="mini" style="margin-bottom:20px" @click="onBack">返回</lui-button>
      <lui-form ref="userFrom" :model="user" :rules="rules" label-width="150px">
        <!--<lui-form-item label="账号类型：" prop="createType">
          <lui-radio-group v-model="user.createType" :disabled="!source || isEdit" @change="initUser">
            <lui-radio :label="1">系统账号</lui-radio>
            <lui-radio :label="2">商家账号</lui-radio>
          </lui-radio-group>
        </lui-form-item>-->
        <lui-row>
          <lui-col :span="16">
            <lui-form-item label="商家编码：" prop="sellerNo">
              <lui-input
                v-model="user.sellerNo"
                placeholder="请输入商家编码"
                :disabled="!isEdit || source"
                maxlength="30"
                @input="e => user.sellerNo = numberStringForbid (e)">
              </lui-input>
            </lui-form-item>
          </lui-col>
        </lui-row>
        <lui-row>
          <lui-col :span="16">
            <lui-form-item label="商家名称：" prop="sellerName">
              <lui-input
                v-model="user.sellerName"
                placeholder="系统自动"
                :disabled="true"
                maxlength="50"
                @input="e => user.sellerName = specialForbid (e)">
              </lui-input>
            </lui-form-item>
          </lui-col>
        </lui-row>
        <!--<lui-form-item
          key="userType"
          label="登录账号类型："
          prop="userType">
          <lui-radio-group v-model="user.userType">
            <lui-radio :label="1" name="userType" disabled>ECLP商家账号</lui-radio>
          </lui-radio-group>
        </lui-form-item>-->
        <lui-row>
          <lui-col :span="16">
            <lui-form-item
              v-if="!isEdit"
              key="accountList"
              label="账号绑定："
              prop="accountList">
              <lui-select
                v-model="user.accountList"
                multiple
                filterable
                allow-create
                default-first-option
                style="width: 100%"
                placeholder="请输入绑定账号名称，最多10条"
                :multiple-limit="10"
                :popper-append-to-body="false"
                @input="e => user.account = formatLength (e)">
                <lui-option
                  v-for="item in accountOptions"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value">
                </lui-option>
              </lui-select>
            </lui-form-item>
          </lui-col>
        </lui-row>
        <lui-row>
          <lui-col :span="16">
            <lui-form-item
              key="userServerList"
              label="产品及角色："
              prop="account">
              <lui-cascader
                v-model="serveList"
                :options="options"
                :props="props"
                clearable
                style="width: 100%"
                @change="treeChange"></lui-cascader>
            </lui-form-item>
          </lui-col>
        </lui-row>

        <lui-form-item align="right" class="sellerBtnright">
          <lui-button v-if="!isEdit" v-waves @click="onBack">取消</lui-button>
          <lui-button v-if="!isEdit" v-waves type="primary" @click="onSubmit('userFrom')">提交</lui-button>
        </lui-form-item>
      </lui-form>
    </lui-card>
  </div>
</template>
<script>
import Api from '@/api'
import { mapGetters } from 'vuex'
// import { getSellerInfoBySeller } from '@/api/sellerInfo'
// import { getRole, addUserInfo, getUserById } from '@/api/userInfo'

const defaultuser = {
  account: '',
  sellerNo: '',
  sellerName: '',
  accountList: [],
  createType: '',
  userServerList: []
}
export default {
  name: 'UserInfoDetail',
  props: {
    // isEdit 为true是可编辑页，为false是增加页
    isEdit: {
      type: Boolean,
      default: false
    },
    //通过source来判断 是商家的添加用户页还是账号配置的手工添加 true是商家的添加用户页
    source: {
      type: Boolean,
      default: true
    }
  },
  data() {
    var trimvalidator = (rule, value, callback) => {
      var myreg = /\s+/g
      if (value === '') {
        callback(new Error('请输入账号'))
      } else if (myreg.test(value)) {
        callback(new Error('输入的账号有空格'))
      } else {
        callback() //重点在这 如果在验证通过后不添加callback()函数在验证时是条件会为false
      }
      callback()
    }
    return {
      sellerNo: '',
      sellerdisabled: true,
      user: Object.assign({}, defaultuser),
      loading: false,
      resetSeller: false,
      newAdd: false,
      props: { multiple: true },
      tree: [],
      serveList: [
        {
          menuRoleCodeList: [],
          serverCode: '',
          serverName: ''
        }
      ],
      options: [],
      rules: {
        /*createType: [
            { required: true, message: '创建类型不能为空', trigger: 'blur' }
          ]*/
        accountList: [
          { validator: trimvalidator, trigger: 'change' },
          { required: true, message: '账号不能为空', trigger: 'change' }
        ]
      },
      roleOptions: [],
      serverCodeMap: {},
      accountOptions: [] //账号的下拉选项
    }
  },
  computed: {
    ...mapGetters(['getPortalSellerNo'])
  },
  mounted() {
    this.getSellerInfo()
  },
  methods: {
    formatLength(value) {
      if (value.length) {
        value.forEach((item, index) => {
          if (item.length > 15) {
            this.user.accountList[index] = item.substring(0, 15)
          }
        })
      }
    },
    //change完以后给后台传这个值
    treeChange(val) {
      var map = {}
      var userServerList = []
      this.serveList.forEach((item) => {
        if (!map[item[0]]) {
          userServerList.push({
            serverCode: item[0],
            serverName: this.serverCodeMap[item[0]],
            menuRoleCodeList: [item[1]]
          })
          map[item[0]] = item
        } else {
          userServerList.forEach(userServer => {
            if (userServer.serverCode === item[0]) {
              userServer.menuRoleCodeList.push(item[1])
            }
          })
        }
      })
      this.user.userServerList = userServerList
    },
    //获取所有option就是指能选的产品菜单所有值，这个是后台给我返的格式，我放到options上绑定
    getRole() {
      Api.UserInfo.getRole().then(res => {
        this.roleOptions = res.data
        //this.roleOptions把这个结构遍历成前端想要的格式,目前前后端数据格式一样
        this.options = res.data
        res.data.forEach(item => {
          this.serverCodeMap[item.serverCode] = item.serverName
        })
      }).catch(err => {
        this.$showErrorMsg(err)
      })
    },
    initUser(value) {
      this.$refs['userFrom'].resetFields()
      this.user = Object.assign({}, defaultuser)
      this.user.accountList = []
    },
    // 一进来获取商家信息
    getSellerInfo() {
      this.user.sellerNo = this.getPortalSellerNo
      Api.UserInfo.getSellerBySellerNo({ sellerNo: this.user.sellerNo }).then(response => {
        this.user.sellerNo = response.data.sellerNo
        this.user.sellerName = response.data.sellerName
        this.options = response.data.sellerServerList
        response.data.sellerServerList.forEach(item => {
          this.serverCodeMap[item.serverCode] = item.serverName
        })
        this.resetSeller = true
      }).catch(err => {
        this.$showErrorMsg(err)
      })
    },
    // 取消
    onBack() {
      this.$store.dispatch('sellerBtnType', 3)
    },
    //添加提交
    onSubmit(formName) {
      if (this.user.accountList.length <= 0) {
        this.$message({
          message: '请输入账号',
          type: 'error',
          duration: 1000
        })
        return false
      }
      if (this.user.userServerList.length <= 0) {
        this.$message({
          message: '请输入产品及角色',
          type: 'error',
          duration: 1000
        })
        return false
      }
      this.$refs[formName].validate((valid) => {
        if (valid) {
          //如果是添加页
          if (!this.isEdit) {
            this.loading = true
            const params = {
              accountType: 2, //商家类型写死
              sellerInfos: [{ 'sellerName': this.user.sellerName, 'sellerNo': this.user.sellerNo }],
              accountList: this.user.accountList,
              createType: this.user.createType,
              sellerName: this.user.sellerName,
              sellerNo: this.user.sellerNo,
              userServerList: this.user.userServerList
            }
            //先把格式处理好
            // params = this.user
            const _this = this
            Api.UserInfo.getUserAdd(params).then(res => {
              if (res.success) {
                this.$message({
                  message: '提交成功',
                  type: 'success',
                  duration: '1000'
                })
                setTimeout(function() {
                  _this.$store.dispatch('sellerBtnType', 3)
                  _this.$emit('func')
                  _this.loading = false
                }, 1500)
              } else {
                _this.$showErrorMsg(res.errMessage)
              }

            }).catch((err) => {
              _this.$showErrorMsg(err)
              _this.loading = false
            })
          }
        } else {
          this.$message({
            message: '验证失败',
            type: 'error',
            duration: 1000
          })
          return false
        }
      })
    },
    resetSellerInfo() {
      this.user.sellerNo = ''
      this.user.sellerName = ''
      this.resetSeller = false
    }
  }
}
</script>
<style lang="scss">
  .form-container {
      .lui-select-dropdown{
        border: 0;
        .lui-select-dropdown__empty{
          display: none!important;
        }
    }
  }
</style>
<style scoped>
  .form-container {
    position: unset !important;
  }
  .lui-button--primary.is-disabled{
    background-color: #9eb7f8 !important;
    border-color: #9eb7f8 !important;
  }
</style>

