<template>
  <div class="updataSeller" style="position: relative">
    <lui-card v-loading="loading" class="form-container" shadow="never">
      <lui-button size="mini" style="margin-bottom:20px" @click="onBack">返回</lui-button>
      <lui-form ref="sellerFrom" :model="seller" :rules="rules" label-width="150px">
        <lui-form-item label="商家类型：" prop="sellerType">
          <lui-radio-group v-model="seller.sellerType" :disabled="isEdit" @change="handlechangesellertype">
            <lui-radio label="ECLP" disabled>ECLP</lui-radio>
            <lui-radio label="CLPS" disabled>CLPS</lui-radio>
            <lui-radio label="OTHER" disabled>其他</lui-radio>
          </lui-radio-group>
        </lui-form-item>
        <lui-row>
          <lui-col :span="20">
            <lui-form-item label="商家编码：" prop="sellerNo">
              <lui-input
                v-model="seller.sellerNo"
                placeholder="请输入商家编码"
                maxlength="30"
                disabled
                @input="e => seller.sellerNo = numberStringForbid (e)">
              </lui-input>
            </lui-form-item>
          </lui-col>
          <lui-col :span="4">
            <div align="right">
              <lui-button
                v-waves
                type="primary"
                :disabled="seller.sellerType !=='ECLP'"
                @click="getSellerInfoEclp">查询商家
              </lui-button>
              <lui-button v-waves disabled @click="resetSellerInfo">重置</lui-button>
            </div>
          </lui-col>
        </lui-row>

        <lui-form-item
          label="商家名称："
          prop="sellerName">
          <lui-input
            v-model="seller.sellerName"
            :disabled="seller.sellerType ==='ECLP'||seller.sellerType ==='OTHER'"
            placeholder="请输入商家名称，ECLP点击查询获取"
            maxlength="50"
            @input="e => seller.sellerName = specialForbid (e)"></lui-input>
        </lui-form-item>
        <lui-form-item label="是否多级管理：" prop="level">
          <lui-radio-group v-model="seller.level" :disabled="seller.sellerType ==='ECLP'||seller.sellerType ==='OTHER'" @change="initDept">
            <lui-radio :label="1">是</lui-radio>
            <lui-radio :label="0">否</lui-radio>
          </lui-radio-group>
        </lui-form-item>

        <lui-row v-for="(dept, index) in seller.sellerDeptList" :key="dept.key">
          <div>
            <lui-col :span="7">
              <lui-form-item
                :label="'事业部名称'+'：'"
                :prop="'sellerDeptList.' + index + '.deptName'"
                :rules="[
                  { required: true, message: '事业部名称不能为空', trigger: 'blur' },
                ]"
              >
                <lui-input
                  v-model="dept.deptName"
                  :disabled="seller.sellerType =='ECLP'"
                  :placeholder="seller.sellerType ==='ECLP'?'请输入商家名称，ECLP点击查询获取':'请输入事业部名称'"
                  maxlength="50"
                  @input="e => dept.deptName = specialForbid (e)"></lui-input>
              </lui-form-item>
            </lui-col>
            <lui-col :span="7">
              <lui-form-item
                :label="'事业部编码'+'：'"
                :prop="'sellerDeptList.' + index + '.deptNo'"
                :rules="[
                  { required: true, message: '事业部编码不能为空', trigger: 'blur' },
                ]"
              >
                <lui-input
                  v-model="dept.deptNo"
                  placeholder="请输入事业部编码"
                  disabled
                  maxlength="50"
                  @input="e => dept.deptNo = numberStringForbid (e)"> </lui-input>
              </lui-form-item>
            </lui-col>

            <lui-col :span="7">
              <lui-form-item
                :label="'签约区域'+'：'"
                :prop="'sellerDeptList.' + index + '.registerRegion'"
                :rules="[
                  { required: true, message: '请选择签约区域', trigger: ['change','blur'] },
                ]">
                <lui-select 
                  v-model="dept.registerRegion"
                  :disabled="seller.sellerType =='ECLP'"
                  style="width: 100%"
                  placeholder="请选择签约区域">
                  <lui-option
                    v-for="item in regionList"
                    :key="item.code"
                    :label="item.desc"
                    :value="item.code">
                  </lui-option>
                </lui-select>
              </lui-form-item>
            </lui-col>

            <lui-col :span="2">
              <lui-button style="float:right" icon="lui-icon-delete" disabled></lui-button>
            </lui-col>
          </div>
        </lui-row>
        <lui-row>
          <lui-col :span="24">
            <lui-form-item align="center">
              <lui-button style="width:100%;height: 40px;border: 1px dashed #ccc" :disabled="seller.sellerType =='ECLP'||seller.sellerType ==='OTHER'||seller.level === 0" @click="addDomain">新增事业部</lui-button>
            </lui-form-item>
          </lui-col>
        </lui-row>
        <lui-form-item label="部署方式：" prop="build" style="margin-top: 30px;">
          <lui-select v-model="seller.build" placeholder="请选部署方式" style="width: 100%">
            <lui-option label="京东内部署" value="JS"></lui-option>
            <lui-option label="云部署" value="JY"></lui-option>
            <lui-option label="私有化部署" value="OTHER"></lui-option>
          </lui-select>
        </lui-form-item>
        <lui-form-item label="商品是否可添：" prop="goodsSource">
          <lui-radio-group v-model="seller.goodsSource">
            <lui-radio :label="0">不可添</lui-radio>
            <lui-radio :label="1">可添</lui-radio>
          </lui-radio-group>
        </lui-form-item>
        <lui-form-item label="节点数据是否可添：" server-config-list="nodeSource">
          <lui-radio-group v-model="seller.nodeSource">
            <lui-radio :label="0">不可添</lui-radio>
            <lui-radio :label="1">可添</lui-radio>
          </lui-radio-group>
        </lui-form-item>
        <p class="servertitle">开通产品</p>
        <lui-row v-for="(serveItem,index) in serveoptions" :key="serveItem.key" class="serve buttonserve">
          <lui-col :span="1" class="indexBtn">
            <input v-model="serveItem.serverCode" style="display: none">
            <input
              ref="checkClass"
              type="checkbox"
              :checked="serveItem.id"
              :disabled="serveItem.id"
              @click="checkedBox(serveItem,index)">
          </lui-col>
          <lui-col :span="6">
            <lui-form-item
              :label="'开通产品'"
              label-width="70px"
            >
              <lui-input v-model="serveItem.serverName" disabled style="width:100%"></lui-input>
              <input v-model="serveItem.serverCode" type="hidden">
            </lui-form-item>
          </lui-col>
          <lui-col :span="1"><span style="color: #fff">d</span></lui-col>
          <lui-col :span="6">
            <lui-form-item
              :label="'生效时间'"
              label-width="80px"
            >
              <lui-date-picker
                v-model="serveItem.startTime"
                style="width: 100%"
                type="date"
                format="yyyy-MM-dd"
                value-format="yyyy-MM-dd HH:mm:ss"
                width="80px"
                :picker-options="serveItem.pickerBeginDateBefore"
                placeholder="请选择生效时间"
                @change="handleStartTime(index)">
              </lui-date-picker>
            </lui-form-item>
          </lui-col>
          <lui-col :span="1"><span style="color: #fff">d</span></lui-col>
          <lui-col :span="6">
            <lui-form-item
              label-width="80px"
              :label="'到期时间'"
            >
              <lui-date-picker
                v-model="serveItem.endTime"
                style="width: 100%"
                type="date"
                format="yyyy-MM-dd"
                value-format="yyyy-MM-dd HH:mm:ss"
                placeholder="请选择到期时间"
                :picker-options="serveItem.pickerBeginDateAfter"
                @change="handleEndTime(index)">
              </lui-date-picker>
            </lui-form-item>
          </lui-col>
          <lui-col :span="1"><span style="color: #fff">d</span></lui-col>
          <lui-col :span="1">
            <div v-if="serveItem.sellerServerConfigList&&serveItem.sellerServerConfigList.length>0">
              <lui-button class="configBtn" @click="configBtn(serveItem)">产品配置</lui-button>
            </div>
          </lui-col>
        </lui-row>
        <lui-dialog
          title="服务配置"
          :visible.sync="configurable"
          width="30%"
        >
          <lui-form-item
            v-for="(item,index) in dialogServer.serverConfigList"
            :key="item.dictCode"
            :label="item.dictName"
          >
            <lui-select
              v-model="dialogServer.sellerServerConfigList[index]"
              value-key="dictValue"
            >
              <lui-option
                v-for="(subItem,subindex) in item.options"
                :key="subindex"
                :label="subItem.dictLabel"
                :value="subItem"
              >
              </lui-option>
            </lui-select>

          </lui-form-item>
          <span slot="footer" class="dialog-footer">
            <lui-button @click="cancelDialog(dialogServer)">取 消</lui-button>
            <lui-button type="primary" @click="bindDialog(dialogServer,serverConfigList)">确 定</lui-button>
          </span>
        </lui-dialog>
        <!--这里结束-->
        <lui-form-item align="right" style="margin-top: 30px;">
          <lui-button v-waves @click="onBack('sellerFrom')">取消</lui-button>
          <lui-button v-if="!isEdit" v-waves type="primary" @click="onSubmit('sellerFrom')">提交</lui-button>
        </lui-form-item>
      </lui-form>
    </lui-card>
  </div>
</template>
<script>
/* eslint-disable consistent-return */
import Api from '@/api'
import $ from 'jquery'
import { mapGetters } from 'vuex'
const defaultSeller = {
  build: 'JS',
  goodsSource: 0,
  level: 0,
  sellerType: 'ECLP',
  nodeSource: 0,
  sellerDeptList: [
    {
      deptName: '',
      deptNo: '',
      registerRegion: ''
    }
  ],
  sellerName: '',
  sellerNo: '',

  sellerServerList: [
    {
      endTime: '',
      sellerServerConfigList: [
        {
          dictCode: '',
          dictValue: 0
        }
      ],
      serverCode: '',
      startTime: ''
    }
  ]
}
export default {
  name: 'sellerInfoDetail',
  props: {
    isEdit: {
      type: Boolean,
      default: false //false代表添加
    }
  },
  data() {
    return {
      //存储产品配置的SellerServerList
      editSellerServerList: [],
      regionList: [],
      editSellerServerConfigList: [],
      //回显的选中的数组
      nowTimeNew: '',
      // 是否有个性化配置
      configurable: false,
      //勾选的数组
      checkedArr: [],
      uuu: [],
      serveoptions: [], //显示所有服务
      //弹框
      dialogVisible: false,
      dialogServer: {},
      //个性化参数 serverConfigList
      serverConfigList: [],
      //给后台提交的serverConfigList
      //这个指每一个sellerServerConfigList
      configoptions2: [],
      //编辑回显的新的数组
      arr: [],
      c: [],
      loading: false,
      resetSeller: false,
      seller: Object.assign({}, defaultSeller),
      rules: {
        sellerNo: [
          { required: true, message: '商家编码不能为空', trigger: 'blur' }
        ],
        sellerName: [
          { required: true, message: '商家名称不能为空', trigger: 'blur' },
          {
            min: 2, max: 50, message: '长度在 2 到 50 个字符', trigger: 'blur'
          }
        ]
      },
      serverOptions: [], // 开通产品下拉
      configServerOptions: [], //开通个性化服务下拉
      addProductabled: false //新增开通产品
    }
  },
  computed: {
    ...mapGetters(['getPortalRowId'])
  },
  created() {
    this.dataAjax()
  },
  mounted() {
    this.regionEnum()
    this.getServerOptions()
  },
  methods: {
    // -----------------------------------新增区域------开始
    //区域列表
    regionEnum() {
      Api.Merchants.regionEnum().then(res => {
        if (res.success) {
          if (Array.isArray(res.data) && res.data.length) {
            this.regionList = res.data
          }
        } else {
          this.$showErrorMsg(res.errMessage)
        }
      }).catch((e) => {
        console.error(e)
      })
    },
    // -----------------------------------新增区域-----结束
    dataAjax() { //获取当前时间
      const now = new Date($.ajax({ async: false }).getResponseHeader('Date'))
      this.nowTimeNew = now.getTime()
    },
    handleStartTime(val) { //开始时间
      if (this.serveoptions[val].startTime) {
        //开始日期小于结束日期
        this.serveoptions[val].pickerBeginDateBefore = {
          disabledDate: (time) => {
            var end = new Date(this.serveoptions[val].endTime).getTime()
            if (end) {
              return (time.getTime() > new Date(this.serveoptions[val].endTime).getTime()) || (time.getTime() < (this.nowTimeNew - 8.64e7))
            } else {
              return (time.getTime() < (this.nowTimeNew - 8.64e7))
            }
          }
        }
        //结束日期小于开始日期
        this.serveoptions[val].pickerBeginDateAfter = {
          disabledDate: (time) => {
            var start = new Date(this.serveoptions[val].startTime).getTime()
            if (start) {
              return time.getTime() < start
            }
          }
        }
      } else {
        //结束日期不能选今天之前包含今天
        this.serveoptions[val].pickerBeginDateAfter = {
          disabledDate: (time) => {
            return (time.getTime() < (this.nowTimeNew))
          }
        }
      }
    },
    handleEndTime(val) { //结束时间
      if (this.serveoptions[val].endTime) {

        //结束日期小于开始日期
        this.serveoptions[val].pickerBeginDateAfter = {
          disabledDate: (time) => {
            var start = new Date(this.serveoptions[val].startTime).getTime()
            if (start) {
              return time.getTime() < start
            }
          }
        }
        //开始日期小于结束日期
        this.serveoptions[val].pickerBeginDateBefore = {
          disabledDate: (time) => {
            var end = new Date(this.serveoptions[val].endTime).getTime()
            if (end) {
              return (time.getTime() > new Date(this.serveoptions[val].endTime).getTime()) || (time.getTime() < (this.nowTimeNew - 8.64e7))
            }
          }
        }
      } else {
        this.serveoptions[val].pickerBeginDateBefore = {
          disabledDate: (time) => {
            return (time.getTime() < (this.nowTimeNew - 8.64e7))
          }
        }
      }
    },
    //获取所有开通产品下拉
    getServerOptions() {
      Api.SellerInfo.getAllSysServer().then((res) => {
        const data = res.data
        //获取属性的时候将所有serverConfigList的 换成sellerServerConfigList
        /*const data2 = JSON.parse(JSON.stringify(data).replace(/serverConfigList/g, 'sellerServerConfigList'))

      */
        if (res.success) {
          data.forEach(serveItem => {
            this.serveoptions.push({
              serverCode: serveItem.serverCode,
              serverName: serveItem.serverName,
              sellerServerConfigList: serveItem.serverConfigList,
              startTime: '',
              endTime: '',
              pickerBeginDateBefore: {},
              pickerBeginDateAfter: {}
            })
          })
          for (let i = 0; i < this.serveoptions.length; i++) {
            //开始日期不能小于今天
            this.serveoptions[i].pickerBeginDateBefore = {
              disabledDate: (time) => {
                return (time.getTime() < (this.nowTimeNew - 8.64e7))
              }
            }
            //结束日期不能选今天之前
            this.serveoptions[i].pickerBeginDateAfter = {
              disabledDate: (time) => {
                return (time.getTime() < (this.nowTimeNew - 8.64e7))
              }
            }
          }
          // this.seller.sellerServerList = this.serveoptions
        }
        this.loadServeData()
        this.loading = false
      }).catch((err) => {
        this.$showErrorMsg(err)
        this.loading = false
      })
    },
    //编辑页主键id查询
    loadServeData() {
      const rowId = this.getPortalRowId
      Api.SellerInfo.getSellerInfoById({ id: rowId }).then((res) => {
        this.seller = res.data
        this.seller.goodsSource = res.data.goodsSource
        this.seller.nodeSource = res.data.nodeSource
        this.arr = this.seller.sellerServerList
        this.checkedArr = this.seller.sellerServerList
        //ary01代表产品全量,ary02代表后端返的已勾选编辑的
        const ary01 = this.serveoptions
        const ary02 = this.seller.sellerServerList
        this.editSellerServerList = JSON.parse(JSON.stringify(ary02))
        this.editSellerServerList.forEach(item => {
          if (item.sellerServerConfigList !== undefined && item.sellerServerConfigList != null) {
            this.editSellerServerConfigList = [...item.sellerServerConfigList]
          }
        })
        for (let i = 0; i < ary02.length; i++) {
          //开始时间不能小于今天不能大于结束时间
          ary02[i].pickerBeginDateBefore = {
            disabledDate: (time) => {
              var end = new Date(ary02[i].endTime).getTime()
              if (end) {
                return (time.getTime() > new Date(ary02[i].endTime).getTime()) || (time.getTime() < (this.nowTimeNew - 8.64e7))
              } else {
                return (time.getTime() < (this.nowTimeNew - 8.64e7))
              }
            }
          }
          //结束日期不能选今天之前不能小于开始时间
          ary02[i].pickerBeginDateAfter = {
            disabledDate: (time) => {
              var start = new Date(ary02[i].startTime).getTime()
              if (start) {
                return (time.getTime() < new Date(ary02[i].startTime).getTime()) || (time.getTime() < (this.nowTimeNew - 8.64e7))
              } else {
                return (time.getTime() < (this.nowTimeNew - 8.64e7))
              }
            }
          }
        }
        //数组去重，将已编辑的回显，将未勾选的还显示到这里
        for (var i = 0; i < ary01.length; i++) {
          for (var j = 0; j < ary02.length; j++) {
            if (ary01[i].serverCode === ary02[j].serverCode) {
              var serverNameTemp = ary01[i].serverName
              ary01[i] = ary02[j]
              ary01[i].serverName = serverNameTemp
              break
            }
          }
        }
      }).catch((err) => {
        this.$showErrorMsg(err)
      })
    },
    checkedBox(serveItem, index) {
      if (this.$refs.checkClass[index].checked) {
        this.checkedArr.push(serveItem)
      } else {
        const i = this.checkedArr.findIndex(item => item.serverCode === serveItem.serverCode)
        this.checkedArr.splice(i, 1)
      }
    },
    cancelDialog(item) {
      this.configurable = false
      const sellerServerConfigList = this.dialogServer.sellerServerConfigList //变量
      setTimeout(() => {
        if (!this.editSellerServerConfigList.length) {
          for (let i = 0, len = sellerServerConfigList.length; i < len; i++) {
            sellerServerConfigList[i].dictLabel = ''
            sellerServerConfigList[i].dictValue = ''
          }
          return
        }
        for (let i = 0, len = sellerServerConfigList.length; i < len; i++) {
          for (let j = 0, len2 = this.editSellerServerConfigList.length; j < len2; j++) {
            if (sellerServerConfigList[i].dictCode === this.editSellerServerConfigList[j].dictCode) {
              sellerServerConfigList[i].dictLabel = this.editSellerServerConfigList[j].dictValue
              sellerServerConfigList[i].dictValue = this.editSellerServerConfigList[j].dictValue
              break
            }
          }
        }
      }, 100)
    },
    //获取个性化配置参数，item指的是sellerServerList每一项里的服务
    configBtn(serveItem) {
      // serveItem指的就是sellerServerList里的每一个对象
      this.dialogServer = serveItem
      Api.SellerInfo.getServerConfigByServerCode({ serverCode: serveItem.serverCode }).then(res => {
        //获取配置，给后端传全量,{"dictCode":"SIMULATION_TIMES","dictValue":10,"dictLabel":"10"},
        this.configurable = true
        this.dialogServer.serverConfigList = res.data
      })
    },
    // 这里的方法绑定很重要
    bindDialog(item, serverConfigList) {
      //指的是当前选中的一条serverConfigList对象
      //重新给选中的服务配置赋值
      this.editSellerServerConfigList = JSON.parse(JSON.stringify(item.sellerServerConfigList))
      // item.sellerServerConfigList = []
      // item.sellerServerConfigList = serverConfigList
      // delete item.serverConfigList
      this.configurable = false
    },
    // 编辑提交
    onSubmit(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          this.loading = true
          const arr = this.seller.sellerDeptList
          for (var i = 0; i < arr.length - 1; i++) {
            for (var j = i + 1; j < arr.length; j++) {
              if (arr[i].deptNo === arr[j].deptNo) {
                this.$showWarningMsg('事业部编码不能重复，请重新输入')
                this.loading = false
                return false
              }
            }
          }
          if (this.checkedArr.length > 0) {
            this.seller.sellerServerList = this.checkedArr
          } else {
            this.$showWarningMsg('请至少勾选一项产品服务')
          }
          const _this = this
          Api.SellerInfo.updateSellerInfo(this.seller).then((res) => {
            //debugger
            if (res.success) {
              this.$message({
                message: '修改成功',
                type: 'success',
                duration: '1000'
              })
              //sellerBtnType需要设置为3的时候显示index
              this.$store.dispatch('sellerBtnType', 3)
              this.$store.dispatch('portalSellerNo', _this.seller.sellerNo)
              //_this.$router.push({ path: '/sellerInfo' })
              this.$emit('func')
              _this.loading = false
              // setTimeout(function() {
              //   _this.$router.push({ path: '/sellerInfo' })
              //   _this.loading = false
              // }, 1500)
            } else {
              _this.$showErrorMsg(res.errMessage)
            }

          }).catch((err) => {
            //debugger
            _this.$showErrorMsg(err)
            _this.loading = false
          })
        } else {
          this.$message({
            message: '验证失败',
            type: 'error',
            duration: 1000
          })
          return false
        }
      })
    },
    // 取消
    onBack() {
      this.$store.dispatch('sellerBtnType', 3)
      //this.$router.push({ path: '/sellerInfo' })
    },
    // 商家类型切换
    handlechangesellertype(value) {
      this.seller.sellerNo = ''
      this.seller.sellerName = ''
      this.seller.sellerType = value
      this.seller.sellerDeptList = [{
        deptNo: '',
        deptName: '',
        registerRegion: ''
      }]
      this.seller.level = 0
      this.resetSeller = false
      if (this.seller.sellerType === 'OTHER') {
        this.getDeptNo('change')
      }
    },
    getDeptNo(type) {
      Api.SellerInfo.getDeptNot().then((res) => {
        if (type === 'change') {
          this.seller.sellerDeptList[0].deptNo = res.data
        }
        if (type === 'add') {
          this.seller.sellerDeptList.push({
            deptNo: res.data,
            deptName: '',
            registerRegion: '',
            key: Date.now()
          })
        }
      }).catch((err) => {
        this.$showErrorMsg(err)
      })
    },
    initDept(value) {
      if (value === 0) {
        if (this.seller.sellerDeptList.length > 1) {
          this.seller.sellerDeptList = [{
            deptNo: '',
            deptName: '',
            registerRegion: ''
          }]
        }

      }
    },
    removeDomain(item) {
      if (this.isEdit) {
        if (this.seller.sellerNo && item.deptNo) {
          const param = {}
          param.sellerNo = this.seller.sellerNo
          param.deptNo = item.deptNo
          Api.getUserCountByDept(param).then((response) => {
            if (response.data > 0) {
              this.$message({
                message: '删除失败！当前事业部存在绑定的账号信息',
                type: 'error',
                duration: 3000
              })
            } else {
              const index = this.seller.sellerDeptList.indexOf(item)
              if (index !== -1) {
                this.seller.sellerDeptList.splice(index, 1)
              }
            }
          })
        } else {
          const index = this.seller.sellerDeptList.indexOf(item)
          if (index !== -1) {
            this.seller.sellerDeptList.splice(index, 1)
          }
        }
      } else {
        const index = this.seller.sellerDeptList.indexOf(item)
        if (index !== -1) {
          this.seller.sellerDeptList.splice(index, 1)
        }
      }

    },
    removeProjectDomain(item) {
      const index = this.seller.sellerServerList.indexOf(item)
      if (index !== -1) {
        this.seller.sellerServerList.splice(index, 1)
      }
    },
    //新增事业部
    addDomain(depNo) {
      if (this.seller.sellerType === 'ECLP') {
        this.seller.sellerDeptList.push({
          deptNo: depNo,
          deptName: '',
          registerRegion: '',
          key: Date.now()
        })
      }
      if (this.seller.sellerType === 'OTHER') {
        this.getDeptNo('add')
      }
    },
    // 查询商家
    getSellerInfoEclp() {
      const params = {}
      params.sellerNo = this.seller.sellerNo
      //这里暂时先模拟数据
      /* var sellerDeptList = [{
        'id': 4398046515679,
        'sellerNo': 'ECP0000000002929',
        'deptName': '中石化事业部1',
        'deptNo': 'EBU4398046515679'
      },
      {
        'id': 4398046515672,
        'sellerNo': 'ECP0000000002929',
        'deptName': '中石化事业2',
        'deptNo': 'EBU4398046515676'
      }]
      this.seller.sellerNo = 'ECP0000000002929'
      this.seller.sellerName = '中石化'
      this.seller.level = 1
      this.seller.sellerDeptList = sellerDeptList*/
      Api.SellerInfo.getSellerByEclp(params).then((response) => {
        this.seller.sellerNo = response.data.sellerNo
        this.seller.sellerName = response.data.sellerName
        this.seller.level = response.data.level
        this.seller.sellerDeptList = response.data.sellerDeptList
        this.resetSeller = true
      }).catch((err) => {
        this.$showErrorMsg(err)
      })
    },
    // 重置
    resetSellerInfo() {
      this.seller.sellerNo = ''
      this.seller.sellerName = ''
      this.seller.sellerDeptList = [{
        deptNo: '',
        deptName: '',
        registerRegion: ''
      }]
      this.seller.level = 0
      this.resetSeller = false
    }
  }
}
</script>
<style scoped lang="scss">
  .updataSeller{
    width: 100%;
    background: #fff;
    padding: 20px 0;
    .form-container{
      width: 90%;
      margin: 0 auto;
    }
    .buttonserve{
      width: 90%;
      margin-left: 10%;
      padding-left: 20px;
      margin-top: 15px;
    }
    .servertitle{
      width: 95%;
      line-height: 30px;
      padding-bottom: 10px;
      padding-top: 20px;
      margin-left: 5%;
      font-size: 16px;
      color: #333;
      border-bottom: 1px solid #eee;
      margin-bottom: 30px;
    }
  }
  .lui-card{
    border: none !important;
  }
  .indexBtn{
    position: absolute;
    top: 10px;
    left: 0px;
  }
  .serve {
    box-showdow: 1px solid #ccc;
    margin-bottom: 8px;
    padding-bottom: 5px;
    .lui-form-item {
      margin-bottom: 0
    }
  }

  .form-container {
    position: unset !important;
  }

  /deep/ .lui-date-editor.lui-input {
    width: 120px;
  }
</style>
