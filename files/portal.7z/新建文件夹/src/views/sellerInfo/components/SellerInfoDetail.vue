<template>
  <div style="position: relative">
    <lui-card v-loading="loading" class="form-container" shadow="never">
      <lui-form ref="sellerFrom" :model="seller" :rules="rules" label-width="150px">
        <lui-form-item label="商家类型：" prop="sellerType">
          <lui-radio-group v-model="seller.sellerType" :disabled="isEdit" @change="clearFrom">
            <lui-radio label="ECLP">ECLP</lui-radio>
            <lui-radio label="CLPS" disabled>CLPS</lui-radio>
            <lui-radio label="OTHER" disabled>其他</lui-radio>
          </lui-radio-group>
        </lui-form-item>
        <lui-row>
          <lui-col :span="16">
            <lui-form-item label="商家编码：" prop="sellerNo">
              <lui-input
                v-model="seller.sellerNo"
                placeholder="请输入商家编码"
                :disabled="isEdit || resetSeller"
                maxlength="30"
                @input="e => seller.sellerNo = numberStringForbid (e)">
              </lui-input>
            </lui-form-item>
          </lui-col>
          <lui-col :span="8">
            <div align="right">
              <lui-button v-waves :disabled="isEdit" @click="resetSellerInfo">重置</lui-button>
              <lui-button
                v-waves
                type="primary"
                :disabled="seller.sellerType == 2 || seller.sellerType == 3||isEdit || resetSeller "
                @click="getSellerInfoEclp">查询商家
              </lui-button>
            </div>
          </lui-col>
        </lui-row>

        <lui-form-item
          label="商家名称："
          prop="sellerName">
          <lui-input
            v-model="seller.sellerName"
            :disabled="seller.sellerType == 'ECLP'"
            placeholder="请输入商家名称，ECLP点击查询获取"
            maxlength="50"
            @input="e => seller.sellerName = specialForbid (e)"></lui-input>
        </lui-form-item>
        <lui-form-item label="是否多级管理：" prop="level">
          <lui-radio-group v-model="seller.level" :disabled="seller.sellerType == 1" @change="initDept">
            <lui-radio :label="1">是</lui-radio>
            <lui-radio :label="0">否</lui-radio>
          </lui-radio-group>
        </lui-form-item>

        <lui-row v-for="(dept, index) in seller.sellerDeptList" :key="dept.key">
          <div>
            <!--  :rules="[
                  { required: true, message: '事业部不能为空', trigger: 'blur' },
                  {min: 2, max: 50, message: '长度在 2 到 50 个字符', trigger: 'blur'}
                ]"-->
            <lui-col :span="19">
              <div>
                <lui-form-item
                  :label="'事业部'+(index+1)"
                  :prop="'sellerDeptList.' + index + '.deptName'"
                  :rules="[
                    { required: true, message: '事业部不能为空', trigger: 'blur' },
                  ]"
                >
                  <lui-input
                    v-model="dept.deptName"
                    :disabled="seller.sellerType == 1"
                    placeholder="请输入商家名称，ECLP点击查询获取"
                    maxlength="50"
                    @input="e => dept.deptName = specialForbid (e)"></lui-input>
                </lui-form-item>
              </div>
            </lui-col>
            <lui-col :span="5">
              <div align="right">
                <lui-button
                  v-waves
                  :disabled="seller.sellerType == 1 || seller.sellerDeptList.length<2"
                  @click.prevent="removeDomain(dept)">删除
                </lui-button>
              </div>
            </lui-col>
          </div>
        </lui-row>
        <lui-form-item align="right">
          <lui-button :disabled="seller.sellerType == 1 || seller.level == 0" @click="addDomain">新增事业部</lui-button>
        </lui-form-item>
        <lui-form-item label="部署方式" prop="build">
          <lui-select v-model="seller.build" placeholder="请选部署方式" style="width: 458px">
            <lui-option label="京东内部署" value="JS"></lui-option>
            <lui-option label="云部署" value="JY"></lui-option>
            <lui-option label="私有化部署" value="OTHER"></lui-option>
          </lui-select>
        </lui-form-item>
        <!--添加服务-->
        <!--<lui-button
          type="success"
          class="addicon"
          :disabled="addProductabled"
          @click="addProductMember">
          <i class="lui-icon-circle-plus-outline"></i>
        </lui-button>-->
        <!--sellerServerItem指的是每条开通模块-->
        <lui-row v-for="(serveItem,index) in seller.sellerServerList" :key="serveItem.key" class="serve">
          <lui-col :span="2">
            <input v-model="serveItem.serverCode" style="display: none">
            <!--v-if="serveItem.id?'"-->
            <input
              ref="checkClass"
              type="checkbox"
              :checked="serveItem.id?true:false"
              :disabled="serveItem.id?true:false"
              @click="checkedBox(serveItem,index)">

          </lui-col>
          <lui-col :span="5">
            <lui-form-item
              :label="'开通服务'"
            >
              <lui-input v-model="serveItem.serverName" disabled></lui-input>
              <input v-model="serveItem.serverCode" type="hidden">
            </lui-form-item>
          </lui-col>
          <lui-col :span="5">
            <lui-form-item
              :label="'生效时间'+(index+1)"
              :prop="'sellerServerList.' + index + '.startTime'"
            >
              <lui-date-picker
                v-model="serveItem.startTime"
                type="datetime"
                format="yyyy-MM-dd HH:mm:ss"
                value-format="yyyy-MM-dd HH:mm:ss"
                width="80px"
                placeholder="请选择生效时间">
              </lui-date-picker>
            </lui-form-item>
          </lui-col>
          <lui-col :span="5">
            <lui-form-item
              :label="'到期时间'+(index+1)"
              :prop="'sellerServerList.' + index + '.endTime'"

            >
              <lui-date-picker
                v-model="serveItem.endTime"
                type="datetime"
                format="yyyy-MM-dd HH:mm:ss"
                value-format="yyyy-MM-dd HH:mm:ss"
                placeholder="请选择到期时间">
              </lui-date-picker>
            </lui-form-item>
          </lui-col>
          <lui-col :span="2">
            <div v-if="serveItem.sellerServerConfigList&&serveItem.sellerServerConfigList.length>0">
              <lui-button class="configBtn" @click="configBtn(serveItem)">可配置</lui-button>
            </div>
          </lui-col>
          <!--<lui-col :span="2">
            <lui-button
              v-waves
              @click.prevent="removeProjectDomain(serveItem)">删除
            </lui-button>
          </lui-col>-->
        </lui-row>


        <lui-dialog
          title="某某服务配置"
          :visible.sync="configurable"
          width="30%"
        >
          <span v-model="dialogServer">某某服务配置</span>
          <lui-form-item
            v-for="(item,index) in configoptions2"
            :key="item.dictCode"
            :label="item.dictName"
          >
            <lui-select
              v-model="serverConfigList[index]"
              value-key="dictValue"
            >
              <lui-option
                v-for="(subItem) in item.options"
                :key="subItem.dictValue"
                :label="subItem.dictLabel"
                :value="subItem"
              >
              </lui-option>
            </lui-select>

          </lui-form-item>
          <span slot="footer" class="dialog-footer">
            <lui-button @click="dialogVisible = false">取 消</lui-button>
            <lui-button type="primary" @click="bindDialog(dialogServer,serverConfigList)">确 定</lui-button>
          </span>
        </lui-dialog>

        <!--这里结束-->
        <lui-form-item label="商品是否可添：" prop="goodsSource">
          <lui-radio-group v-model="seller.goodsSource">
            <lui-radio :label="0">不可添</lui-radio>
            <lui-radio :label="1">可添</lui-radio>
          </lui-radio-group>
        </lui-form-item>
        <lui-form-item label="节点数据是否可添：" server-config-list="nodeSource">
          <lui-radio-group v-model="seller.nodeSource">
            <lui-radio :label="0">不可添</lui-radio>
            <lui-radio :label="1">可添</lui-radio>
          </lui-radio-group>
        </lui-form-item>
        <lui-form-item align="right">
          <lui-button v-waves @click="onBack('sellerFrom')">取消</lui-button>
          <lui-button v-if="isEdit" v-waves type="primary" @click="onSubmit('sellerFrom')">提交</lui-button>
          <lui-button v-if="!isEdit" v-waves type="primary" @click="onSubmit('sellerFrom')">下一步</lui-button>
        </lui-form-item>
      </lui-form>
    </lui-card>
  </div>
</template>
<script>
/* eslint-disable consistent-return */
import Api from '@/api'

const defaultSeller = {
  build: 'JS',
  goodsSource: 0,
  level: 0,
  sellerType: 'ECLP',
  nodeSource: 0,
  sellerDeptList: [
    {
      deptName: '',
      deptNo: ''
    }
  ],
  sellerName: '',
  sellerNo: '',

  sellerServerList: [
    {
      endTime: '',
      sellerServerConfigList: [
        {
          dictCode: '',
          dictValue: 0
        }
      ],
      serverCode: '',
      startTime: ''
    }
  ]

}
export default {
  name: 'sellerInfoDetail',
  props: {
    isEdit: {
      type: Boolean,
      default: false //false代表添加
    }
  },
  data() {
    return {
      //回显的选中的数组
      aaa: [],
      // 是否有个性化配置
      configurable: false,
      //勾选的数组
      checkedArr: [],
      uuu: [],
      serveoptions: [], //显示所有服务
      //弹框
      dialogVisible: false,
      dialogServer: {},
      //个性化参数
      serverConfigList: [{ name: {}}, { name: {}}],
      configoptions2: [{ name: [{}, {}] }, { name: [{}, {}, {}] }],

      //编辑回显的新的数组
      arr: [],
      c: [],
      loading: false,
      resetSeller: false,
      seller: Object.assign({}, defaultSeller),
      rules: {
        sellerNo: [
          { required: true, message: '商家编码不能为空', trigger: 'blur' }
        ],
        sellerName: [
          { required: true, message: '商家名称不能为空', trigger: 'blur' },
          {
            min: 2, max: 50, message: '长度在 2 到 50 个字符', trigger: 'blur'
          }
        ]
      },
      serverOptions: [], // 开通产品下拉
      configServerOptions: [], //开通个性化服务下拉
      addProductabled: false //新增开通产品
    }
  },
  created() {

  },
  mounted() {
    this.getServerOptions()
    this.loadServeData()
  },
  methods: {
    //获取所有开通服务下拉
    getServerOptions() {
      // sellerServerConfigList
      // getAllSysServer
      this.seller.sellerServerList = []
      Api.SellerInfo.getAllSysServer().then((res) => {
        const data = res.data
        //获取属性的时候将所有serverConfigList的 换成sellerServerConfigList
        /*const data2 = JSON.parse(JSON.stringify(data).replace(/serverConfigList/g, 'sellerServerConfigList'))
          this.options = []

  */
        if (res.success) {
          data.forEach(serveItem => {
            this.serveoptions.push({
              serverCode: serveItem.serverCode,
              serverName: serveItem.serverName,
              sellerServerConfigList: serveItem.serverConfigList,
              startTime: '',
              endTime: ''
            })
          })
          //如果是新增页
          this.seller.sellerServerList = this.serveoptions
        }
        this.loading = false
      }).catch((error) => {
        this.loading = false
      })
    },
    //判断是否为编辑页
    loadServeData() {
      //代表编辑
      if (this.isEdit) {
        Api.SellerInfo.getSellerInfoById({ id: this.$route.query.id }).then((res) => {
          this.seller = res.data
          this.seller.goodsSource = res.data.goodsSource
          this.seller.nodeSource = res.data.nodeSource
          //处理一下sellerInfoList
          //this.seller.sellerServerList 这个是单量
          //this.serveoptions 这个是全量
          this.arr = this.seller.sellerServerList
          const ary01 = this.serveoptions
          const ary02 = this.seller.sellerServerList
          for (var i = 0; i < ary01.length; i++) {
            for (var j = 0; j < ary02.length; j++) {
              if (ary01[i].serverCode === ary02[j].serverCode) {
                // obj = ary02[j]
                // obj.chedkdkk = "sss";
                // ary01[i].id=ary02[j].id
                ary01[i] = ary02[j]
                break
              }
            }
          }
          this.c = ary01
          this.seller.sellerServerList = this.c
        }).catch((e) => {
        })
      } else {
        this.seller.sellerServerList = this.serveoptions
      }

    },

    //勾选下拉
    checkedBox(serveItem, index) {
      if (this.$refs.checkClass[index].checked) {
        this.checkedArr.push(serveItem)
      } else {
        this.checkedArr.splice(index, 1)
      }
    },
    //获取个性化配置参数，item指的是sellerServerList每一项里的服务
    configBtn(item) {
      // item指的就是sellerServerList里的每一个对象
      const params = {}
      const serverCode = item.serverCode
      /*const arr = [
          { 'dictName': '任务次数配置', 'dictCode': 'SIMULATION_TIMES', 'list': [{ 'dictValue': 10, 'dictLabel': '10次', 'dictCode': 'SIMULATION_TIMES' }, { 'dictValue': 15, 'dictLabel': '15次', 'dictCode': 'SIMULATION_TIMES' }] },
          { 'dictName': '天数', 'dictCode': 'SIMULATION_DURATION', 'list': [{ 'dictValue': 90, 'dictLabel': '90天', 'dictCode': 'SIMULATION_DURATION' }, { 'dictValue': 112, 'dictLabel': '112天', 'dictCode': 'SIMULATION_DURATION' }] }

        ]*/
      if (item.sellerServerConfigList.length > 0) {
        this.configoptions2 = item.sellerServerConfigList
      }
      params.serverCode = serverCode
      this.dialogServer = item
      this.configurable = true
    },
    // 这里的方法绑定很重要
    bindDialog(item, serverConfigList) {
      item.sellerServerConfigList = ''
      item.sellerServerConfigList = serverConfigList
      this.configurable = false
    },
    // 下一步或者提交
    onSubmit(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          this.loading = true
          this.seller.sellerServerList = this.checkedArr
          if (this.isEdit) {
            Api.SellerInfo.updateSellerInfo(this.seller).then((response) => {
              this.$message({
                message: '修改成功',
                type: 'success',
                duration: 1000
              })
              this.loading = false
              this.$router.back()
            }).catch((err) => {
              this.$showErrorMsg(err.message)
              this.loading = false
            })
          } else {
            this.seller.sellerServerList = this.checkedArr
            const paramsobjuu = this.seller
            Api.SellerInfo.addSellerInfo(paramsobjuu).then((response) => {
              this.loading = false
              this.$router.push({ path: '/sellerInfo/addUser', query: { seller: this.seller.sellerNo }})
              this.$showSuccessMsg('保存成功！')
            }).catch((err) => {
              this.$showErrorMsg(err)
              this.loading = false
            })
          }
        } else {
          this.$message({
            message: '验证失败2222',
            type: 'error',
            duration: 1000
          })
          return false
        }
      })
    },
    // 取消
    onBack() {
      this.$router.push({ path: '/sellerInfo' })
    },
    resetForm(formName) {
      this[formName] = {}
    },
    // 商家类型切换
    clearFrom(value) {
      this.seller = { ...defaultSeller }
      if (value == 2) {
        this.seller.sellerNo = `DCP${new Date().getTime()}`
      }
      this.seller.sellerType = value
      this.seller.sellerDeptList = [{
        deptNo: '',
        deptName: ''
      }]
      this.resetSeller = false
    },
    initDept(value) {
      if (value == 0) {
        if (this.seller.sellerDeptList.length > 1) {
          this.seller.sellerDeptList = [{
            deptNo: '',
            deptName: ''
          }]
        }

      }
    },
    removeDomain(item) {
      if (this.isEdit) {
        if (this.seller.sellerNo && item.deptNo) {
          const param = {}
          param.sellerNo = this.seller.sellerNo
          param.deptNo = item.deptNo
          Api.getUserCountByDept(param).then((response) => {
            if (response.data > 0) {
              this.$message({
                message: '删除失败！当前事业部存在绑定的账号信息',
                type: 'error',
                duration: 3000
              })
            } else {
              const index = this.seller.sellerDeptList.indexOf(item)
              if (index !== -1) {
                this.seller.sellerDeptList.splice(index, 1)
              }
            }
          })
        } else {
          const index = this.seller.sellerDeptList.indexOf(item)
          if (index !== -1) {
            this.seller.sellerDeptList.splice(index, 1)
          }
        }
      } else {
        const index = this.seller.sellerDeptList.indexOf(item)
        if (index !== -1) {
          this.seller.sellerDeptList.splice(index, 1)
        }
      }

    },
    removeProjectDomain(item) {
      const index = this.seller.sellerServerList.indexOf(item)
      if (index !== -1) {
        this.seller.sellerServerList.splice(index, 1)
      }
    },
    //新增事业部
    addDomain() {
      this.seller.sellerDeptList.push({
        deptNo: '',
        deptName: '',
        key: Date.now()
      })
    },
    // 查询商家
    getSellerInfoEclp() {
      const params = {}
      params.sellerNo = this.seller.sellerNo
      //这里暂时先模拟数据
      var sellerDeptList = [{
        'id': 4398046515679,
        'sellerNo': 'ECP0000000002929',
        'deptName': '中石化事业部1',
        'deptNo': 'EBU4398046515679'
      },
      {
        'id': 4398046515672,
        'sellerNo': 'ECP0000000002929',
        'deptName': '中石化事业2',
        'deptNo': 'EBU4398046515676'
      }]
      this.seller.sellerNo = 'ECP0000000002929'
      this.seller.sellerName = '中石化'
      this.seller.level = 1
      this.seller.sellerDeptList = sellerDeptList
      /* Api.SellerInfo.getSellerByEclp(params).then((response) => {
          console.log(response.data)
          this.seller.sellerNo = response.data.sellerNo
          this.seller.sellerName = response.data.sellerName
          this.seller.level = response.data.level
          this.seller.sellerDeptList = response.data.sellerDeptList

          this.seller.sellerDeptList = sellerDeptList
          this.resetSeller = true
        }).catch()*/
    },
    // 重置
    resetSellerInfo() {
      this.seller.sellerNo = ''
      this.seller.sellerName = ''
      this.seller.sellerDeptList = [{
        deptNo: '',
        deptName: ''
      }]
      this.resetSeller = false
    },
    //添加产品模块
    addProductMember() {
      this.seller.sellerServerList.push({
        endTime: '',
        serverCode: '',
        startTime: ''
      })
    }
  }
}
</script>

<style scoped lang="scss">
  .serve {
    box-showdow: 1px solid #ccc;
    margin-bottom: 8px;
    padding-bottom: 5px;
    .lui-form-item {
      margin-bottom: 0
    }
  }

  .form-container {
    position: unset !important;
  }

  /deep/ .lui-date-editor.lui-input {
    width: 120px;
  }
</style>
