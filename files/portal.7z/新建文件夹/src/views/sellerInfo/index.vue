<template>
  <div v-loading="loading">
    <div v-if="getSellerBtnType===3" class="list-class">
      <div class="search-box is-always-shadow">
        <div class="header-title">
          <div><i class="lui-icon-search"></i>筛选搜索</div>
          <div></div>
        </div>
        <lui-form
          ref="searchform"
          :model="searchform"
          label-width="80px"
          style="padding: 0;margin: 0;margin-bottom: 20px">
          <lui-row style="width: 96%;margin: 15px auto">
            <lui-col :span="8" style="text-align: left">
              <div class="grid-content filterrow1">
                <div class="grid-content filterrow1">
                  <lui-form-item label="商家编码" style="width:90%">
                    <lui-input
                      v-model="searchform.sellerNo"
                      clearable
                      style="width:100%"
                      placeholder="请输入商家编码"></lui-input>
                  </lui-form-item>
                </div>
              </div>
            </lui-col>
            <lui-col :span="8">
              <div class="grid-content filterrow1">
                <div class="grid-content filterrow1">
                  <lui-form-item label="商家名称" style="width:90%">
                    <lui-input
                      v-model="searchform.sellerName"
                      clearable
                      style="width:100%"
                      placeholder="请输入商家名称"></lui-input>
                  </lui-form-item>
                </div>
              </div>
            </lui-col>
            <lui-col :span="8" style="text-align: right">
              <div class="grid-content filterrow1">
                <lui-form-item label="商家类型" style="width:90%">
                  <lui-select
                    v-model="searchform.sellerType"
                    filterable
                    clearable
                    placeholder="请选择"
                    style="width:100%">
                    <lui-option
                      v-for="item in sellerTypeOptions"
                      :key="item.value"
                      :label="item.name"
                      :value="item.value">
                    </lui-option>
                  </lui-select>
                </lui-form-item>
              </div>
            </lui-col>
          </lui-row>
          <lui-row style="width: 96%;margin: 15px auto">
            <lui-col :span="8" style="text-align: left">
              <div class="grid-content filterrow1">
                <lui-form-item label="开通产品" style="width:90%">
                  <lui-select
                    v-model="searchform.serverCode"
                    filterable
                    clearable
                    placeholder="请选择"
                    style="width:100%">
                    <lui-option
                      v-for="item in serversOptions"
                      :key="item.serverCode"
                      :label="item.serverName"
                      :value="item.serverCode">
                    </lui-option>
                  </lui-select>
                </lui-form-item>
              </div>
            </lui-col>
            <lui-col :span="8" style="text-align: center">
              <div class="grid-content filterrow1">
                <lui-form-item label="部署方式" style="width:90%">
                  <lui-select
                    v-model="searchform.build"
                    filterable
                    clearable
                    placeholder="请选择"
                    style="width:100%">
                    <lui-option
                      v-for="item in buildOptions"
                      :key="item.value"
                      :label="item.name"
                      :value="item.value">
                    </lui-option>
                  </lui-select>
                </lui-form-item>
              </div>
            </lui-col>
            <lui-col :span="8" style="text-align: right">
              <div class="grid-content filterrow1">
                <lui-form-item label="状态" style="width: 90%;">
                  <lui-select
                    v-model="searchform.status"
                    filterable
                    clearable
                    placeholder="请选择"
                    style="width:100%">
                    <lui-option
                      v-for="item in statusOptions"
                      :key="item.value"
                      :label="item.name"
                      :value="item.value">
                    </lui-option>
                  </lui-select>
                </lui-form-item>
              </div>
            </lui-col>
          </lui-row>
          <lui-row style="width: 96%;margin: 15px auto">
            <lui-col :span="8" style="text-align: left">
              <div class="grid-content filterrow1">
                <lui-form-item label="签约区域" style="width: 90%;">
                  <lui-select
                    v-model="searchform.registerRegion"
                    filterable
                    clearable
                    placeholder="请选择签约区域"
                    style="width:100%">
                    <lui-option
                      v-for="item in regionList"
                      :key="item.code"
                      :label="item.desc"
                      :value="item.code">
                    </lui-option>
                  </lui-select>
                </lui-form-item>
              </div>
            </lui-col>
          </lui-row>

          <div class="btn-wrap">
            <lui-form-item>
              <lui-button
                class="filters-btn-group"
                type="primary"
                style="width:88px"
                @click="searchClick"><i class="fa fa-search"></i>查询</lui-button>
            </lui-form-item>
            <lui-form-item>
              <lui-button
                class="filters-btn-group"
                style="width:88px"
                @click="handleReset('searchform')"><i class="fa fa-refresh"></i>重置</lui-button>
            </lui-form-item>
          </div>
        </lui-form>
      </div>
      <!-- <lui-card class="operate-container" shadow="never">
        <button-list
          ref="buttons"
          :buttons="buttons"
          @handleAddClick="handleAddClick"
          @deleteClick="handDeleteClick"
          @downloadClick="downloadClick">
        </button-list>
      </lui-card>-->
      <div class="addManually">
        <div class="manually-title">
          <div class="title-left"><i class="lui-icon-document-empty"></i><span>数据列表</span></div>
          <div class="title-right">
            <lui-button type="primary" @click="uploadClickWarn">批量上传</lui-button>
            <lui-button type="primary" @click="downloadClick">批量下载</lui-button>
            <lui-button type="primary" class="disabled-is" @click="deleteClick">手工删除</lui-button>
            <lui-button type="primary" @click="handleAddClick">手工添加</lui-button>
          </div>
        </div>
        <!--table列表-->
        <lui-table
          v-loading="listLoading"
          border
          :data="dataSource"
          class="slisttable table-list"
          style="width:96%; margin: 0 auto;"
          @selection-change="handleSelectionChange">
          <template slot="empty">
            <showEmptyImage></showEmptyImage>
          </template>
          <lui-table-column
            type="selection"
            width="60"
            fixed="left"
            align="center">
          </lui-table-column>
          <input
            type="hidden"
            prop="id" />
          <lui-table-column
            prop="sellerNo"
            label="商家编码"
            show-overflow-tooltip>
          </lui-table-column>
          <lui-table-column
            prop="sellerName"
            label="商家名称"
            show-overflow-tooltip>
          </lui-table-column>
          <lui-table-column
            prop="sellerType"
            label="商家类型"
            show-overflow-tooltip>
          </lui-table-column>
          <!-- 新增区域 -->
          <lui-table-column
            prop="registerRegion"
            label="签约区域"
            show-overflow-tooltip>
          </lui-table-column>

          <lui-table-column
            prop="build"
            label="部署方式"
            show-overflow-tooltip>
          </lui-table-column>
          <lui-table-column
            prop="sellerServerNames"
            label="开通产品"
            show-overflow-tooltip>
          </lui-table-column>
          <lui-table-column
            prop="status"
            width="90"
            label="状态">
            <template slot-scope="scope">
              <lui-tag :type="scope.row.status===true?'success':(scope.row.status===false?'info':'')">{{ scope.row.status===true?'正常':'禁用' }}</lui-tag>
            </template>
          </lui-table-column>
          <lui-table-column
            prop="status"
            width="90"
            label="状态修改">
            <template slot-scope="scope">
              <lui-switch
                v-model="scope.row.status"
                active-circle-class="1"
                active-color="rgba(60,110,240,.2)"
                inactive-color="rgba(142,145,152,.2)"
                @change="changeStatusTab(scope.row)">
              </lui-switch>
            </template>
          </lui-table-column>
          <lui-table-column
            label="操作"
            width="210"
            fixed="right">
            <template slot-scope="scope">
              <lui-button size="small" plain icon="lui-icon-edit" @click="handleEdit(scope.$index, scope.row)">编辑</lui-button>
              <lui-button size="small" plain icon="lui-icon-plus" @click="addHandle(scope.$index, scope.row)">添加用户</lui-button>
            </template>
          </lui-table-column>
        </lui-table>
        <!--分页-->
        <div
          v-show="dataSource != undefined && dataSource.length>0"
          class="block rotation-pagination">
          <lui-pagination
            background
            :current-page.sync="pageNum"
            :page-sizes="[10, 20, 50, 100]"
            layout="prev, pager, next, sizes, jumper, total"
            :total="total"
            @current-change="handleSizeChange"
            @size-change="sizeChange">
          </lui-pagination>
        </div>
      </div>
    </div>
    <addSeller v-if="getSellerBtnType===1" @func="childenClick"></addSeller>
    <addUser v-if="getSellerBtnType===2" @func="childenClick"></addUser>
    <updateSeller v-if="getSellerBtnType===4" @func="childenClick"></updateSeller>
  </div>
</template>
<script>
import Http from '@/lib/http'
// import { DatePickerMixin } from '@/mixins/date-picker-mixin'
import Api from '@/api'
//import ButtonList from '@/views/common/ButtonList'
import showEmptyImage from '@/components/common/showEmptyImage/index.vue'
import { exportExcel } from '@/utils/downloadRequest'
import addSeller from '@/views/sellerInfo/AddSeller.vue'
import addUser from '@/views/sellerInfo/AddUser.vue'
import updateSeller from '@/views/sellerInfo/UpdateSeller.vue'
import { mapGetters } from 'vuex'
export default {
  components: {
    showEmptyImage,
    addSeller,
    addUser,
    updateSeller
    //  ButtonList
  },
  // mixins: [DatePickerMixin],
  data() {
    return {
      regionList: [],
      //列表显示
      listShow: true,
      //手工添加页面
      addSellerShow: false,
      //添加用户
      addUserShow: false,
      baseURL: Http.baseContextUrl,
      //面包屑
      breadCrumbObj: {
        hrefList: [
          {
            title: '项目列表',
            href: 'new-project'
          }
        ],
        currRentTitle: '方案列表'
      },
      //筛选搜索
      searchform: {
        sellerNo: '', //商家编码
        sellerName: '', //商家名称
        sellerType: '', //商家类型
        build: '', //部署方式
        serverCode: '', //开通模块
        status: '', //状态
        registerRegion: '' //签约区域
      },
      //列表的多选
      multipleSelection: [],
      //商家类型下拉
      sellerTypeOptions: [
        {
          name: 'ECLP',
          value: 'ECLP'
        },
        {
          name: 'CLPS',
          value: 'CLPS'
        },
        {
          name: '其他',
          value: 'OTHER'
        }
      ],
      serversOptions: [], //开通模块下拉
      buildOptions: [
        {
          name: '京东内部署',
          value: 'JS'
        },
        {
          name: '云部署',
          value: 'JY'
        },
        {
          name: '私有化部署',
          value: 'OTHER'
        }
      ], //部署方式下拉
      //状态下拉
      statusOptions: [
        {
          name: '正常',
          value: '1'
        },
        {
          name: '禁用',
          value: '0'
        }
      ],
      //table列表
      tableData: [],
      loading: false,
      listLoading: false,
      selections: [],
      options: {
        label: '全部',
        selection: true,
        index: false
      },
      searchData: {},
      //分页
      pageNum: 1, // 起始页
      pageSize: 10, // 每页条数
      currentPage: 1, // 起始页
      total: 0,
      dataSource: []
    }
  },
  computed: {
    ...mapGetters(['getSellerBtnType', 'getPortalSellerNo'])
  },
  created() {
    this.$bus.on('handlBtn', (val) => {
      //a为1的时候保存
      if (val.type === 1) {
        this.listShow = true
        this.addSellerShow = false
        this.addUserShow = false
      } else if (val.type === 2) {
        //a为2的时候下一步
        this.listShow = false
        this.addSellerShow = false
        this.addUserShow = true
      } else if (val.type === 3) {
        //a为3的时候取消
        this.listShow = true
        this.addSellerShow = false
        this.addUserShow = false
      }
    })
  },
  mounted() {
    this.regionEnum()
    this.getServerOptions()
    this.getList()
  },
  methods: {
    // -----------------------------------新增区域------开始
    //区域列表
    regionEnum() {
      Api.Merchants.regionEnum().then(res => {
        if (res.success) {
          if (Array.isArray(res.data) && res.data.length) {
            this.regionList = res.data
          }
        } else {
          this.$showErrorMsg(res.errMessage)
        }
      }).catch((e) => {
        console.error(e)
      })
    },
    // -----------------------------------新增区域-----结束


    childenClick() {
      this.getList()
    },
    //手工删除
    handleDel() {
    },
    //获取所有开通服务下拉
    getServerOptions() {
      Api.SellerInfo.getAllSysServer().then((res) => {
        if (res.success) {
          //获取开通服务的下拉选项
          this.serversOptions = res.data
        }
        this.listLoading = false
      }).catch((error) => {
        this.listLoading = false
      })
    },
    uploadClickWarn() {
      this.$message({
        type: 'warning',
        message: '批量上传功能暂不支持！'
      })
    },
    //重置
    handleReset() {
      this.searchform = {
        sellerNo: '', //商家编码
        sellerName: '', //商家名称
        sellerType: '', //商家类型
        build: '', //部署方式
        serverCode: '', //开通模块
        status: '', //状态
        registerRegion: '' //签约区域
      }
      this.getList()
    },
    //查询表格事件
    getList() {
      this.listLoading = true
      const paramObj = {
        build: this.searchform.build,
        sellerName: this.searchform.sellerName,
        sellerNo: this.searchform.sellerNo,
        sellerType: this.searchform.sellerType,
        serverCode: this.searchform.serverCode,
        status: this.searchform.status,
        registerRegion: this.searchform.registerRegion //签约区域
      }
      paramObj.pageNum = this.pageNum
      paramObj.pageSize = this.pageSize
      Api.SellerInfo.getSellerInfoList(paramObj).then((res) => {
        this.listLoading = false
        if (res.data) {
          for (let i = 0; i < res.data.length; i++) {
            if (res.data[i].status === 1) {
              res.data[i].status = true
            } else {
              res.data[i].status = false
            }
          }
          this.dataSource = res.data
          // this.pagination.pageNum = res.pageNum
          this.total = res.total
        }

      }).catch((error) => {
        this.$showErrorMsg(error)
        this.listLoading = false
        this.dataSource = []
        this.pageNum = 1
        this.total = 0
      })
    },
    searchClick(val) {
      //  this.searchData = val
      // this.getList(this.searchData)
      this.getList()
    },

    //表格内容状态事件
    changeStatus(params, value) {
      const { obj } = params
      obj.$confirm('是否要修改商家状态?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        Api.SellerInfo.updateStatusSellerInfo({ id: params.row.id, status: value ? 1 : 0 }).then((response) => {
          obj.$parent.getList(this.searchData)
          obj.$message({
            type: 'success',
            message: '修改成功!'
          })
        })
      }).catch(() => {
        obj.$message({
          type: 'success',
          message: '已取消操作!'
        })
      })
    },
    //修改这里的状态
    changeStatusTab(row) {
      if (row.status) {
        this.$confirm('是否开启该商家的所有权限？', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          Api.SellerInfo.updateStatusSellerInfo({ id: row.id, status: 1 }).then((res) => {
            this.$message({
              type: 'success',
              message: '修改成功!'
            })
          }).catch((e) => {
            this.$showErrorMsg(e)
            row.status = false
          })
        }).catch((e) => {
          row.status = false
        })
      } else {
        this.$confirm('是否禁用该商家的所有权限？', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          Api.SellerInfo.updateStatusSellerInfo({ id: row.id, status: 0 }).then((res) => {
            this.$message({
              type: 'success',
              message: '修改成功!'
            })
          }).catch((e) => {
            this.$showErrorMsg(e)
            row.status = true
          })
        }).catch((e) => {
          row.status = true
        })
      }
    },
    //清除表格内容
    toggleRowSelection(that) {
      return that.clearSelection()
    },
    //翻页-----根据页码变换
    handleSizeChange(val) {
      this.pageNum = val
      this.getList()
    },
    //分页条数改变
    sizeChange(val) {
      this.pageSize = val
      this.getList()
    },
    handleAddClick() {
      this.$store.dispatch('sellerBtnType', 1)
    /*  this.listShow = false
      this.addSellerShow = true
      this.addUserShow = false*/
      //this.$router.push({ path: '/sellerInfo/addSeller' })
    },
    // 获取选中的id
    getSelectionId() {
      const selectIds = []
      this.multipleSelection.map((item) => {
        selectIds.push(item.id)
      })
      return selectIds
    },
    //这里开始
    handleSelectionChange(val) {
      this.multipleSelection = val
    },
    //批量上传
    uploadClick() {
      this.isUploadModalShow = true
    },
    //批量下载 downloadUserInfo
    downloadClick() {
      const options = Object.assign({}, this.searchform)
      const ids = this.getSelectionId()
      if (ids.length > 0) {
        options.ids = ids
      }
      const actionUrl = this.baseURL + Api.SellerInfo.downloadSellerInfoUrl
      exportExcel(actionUrl, options)
    },
    //批量删除的方法
    deleteClick() {
      const param = {}
      param.idList = this.getSelectionId()
      if (param.idList.length < 1) {
        this.$message({
          message: '未选择要删除的内容',
          type: 'warning',
          duration: 1000
        })
        return
      }
      this.$confirm('确定要删除选中的商家吗？', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        this.loading = true
        Api.SellerInfo.deleteSellerInfo(param).then(response => {
          this.$message({
            message: '删除成功',
            type: 'success',
            duration: 1000
          })
          this.loading = false
          this.getList()
        }).catch(err => {
          this.loading = false
          this.$showErrorMsg(err)
        })
      }).catch(err => {
        this.loading = false
        console.log(err)
      })
    },
    //编辑方法
    handleEdit(index, row) {
      //sellerBtnType设置4时，显示编辑商家
      this.$store.dispatch('sellerBtnType', 4)
      this.$store.dispatch('portalRowId', row.id)
      // this.$router.push({ path: '/sellerInfo/updateSeller', query: { id: row.id }})
    },
    //添加用户的方法
    addHandle(index, row) {
      //sellerBtnType设置2时，显示添加用户
      this.$store.dispatch('sellerBtnType', 2)
      this.$store.dispatch('portalSellerNo', row.sellerNo)
      // this.$router.push({ path: '/sellerInfo/addUser', query: { sellerNo: row.sellerNo }})
    }
  }
}
</script>

<style lang="scss" scoped >
@import "@/assets/stylus/main.scss";
.list-class{
  .header-title{
    width: 96%;
    margin: 0 auto;
    margin-top: 20px;
    height: 40px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    div{
      font-size: 18px;
      color: #666;
      i{
        margin-right: 10px;
      }
    }
  }
  /*手工添加部分*/
  .addManually{
    padding-top: 10px;
    padding-bottom: 30px;
    width: 100%;
    background: #fff;
    box-shadow:0 0 5px 5px #eee;
    .manually-title{  //头部
      width: 96%;
      margin: 0 auto;
      height: 70px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      .title-left{
        i{
          font-size: 16px;
          margin-right: 10px;
        }
        span{
          font-size: 14px;
          color: #666
        }
      }

    }

    .table-button{ //表格内部按钮
      display: flex;
      justify-content: space-around;
      span{
        color: $--gl-blue;
        cursor: pointer;
      }
    }

    .rotation-pagination{ //分页
      width: 100%;
      margin-top: 50px;
      text-align: center;
      /deep/ .lui-pagination__total{
        margin-left: 20px;
      }
    }

  }


  .is-always-shadow {
    box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
  }
  .search-box {
    border: 1px solid #eaeaea;
    background: #ffffff;
    margin-bottom: 20px;
  }
  .lui-breadcrumb {
    border-bottom: 1px solid rgb(230, 230, 230);
    padding: 5px 0 10px;
    margin-bottom: 10px;
  }
  /deep/ .lui-form-item {
    display: inline-block;
    margin-bottom: 15px;
  }
  /deep/ .btn-wrap {
    width: 96%;
    padding: 0;
    margin: 0 auto;
    text-align: right;
    .lui-form-item .lui-form-item__content {
      margin-left: 10px !important;

      /*margin: 0 8px !important;*/
    }
    i {
      padding: 0 2px;
    }
  }
  .filters-btn-group {
    display: inline-block;
  }
  .search-box {
    text-align: center;
  }
  .table-list {
    /*background: #f00;*/
    box-shadow: 0px 1px 8px #ebeef5;
  }
  /deep/ .lui-button--mini {
    padding: 5px 8px;
  }

  // /deep/ .is-disabled{
  //   color: rgba(255, 255, 255, 0.55) !important;
  //   background-color: rgba(13, 108, 162, 0.54) !important;
  //   border-color: rgba(13, 108, 162, 0.54) !important;
  // }
  // /deep/ .lui-tag.lui-tag--success{
  //   color:#0D6CA2;
  //   border-color:rgba(60, 110, 240, 0.2);
  //   background-color: rgba(60, 110, 240, 0.2);
  // }

  // /*去除多选框颜色*/
  // /deep/ .lui-table th>.cell>.is-disabled {
  //   color: rgba(255, 255, 255, 0.55) !important;
  //   background-color:  #F1F4F9 !important;
  //   border-color: #F1F4F9 !important;
  // }
  // /deep/ .lui-table th>.cell>.is-disabled>.is-disabled {
  //   color: #F1F4F9 !important;
  //   background-color: #F1F4F9 !important;
  //   border-color: #F1F4F9 !important;
  // }
  // /*去除多选框颜色*/
  // .table-link{ //表格溢出隐藏
  //   overflow: hidden;
  //   text-overflow:ellipsis;
  //   white-space: nowrap;
  //   cursor: pointer;
  // }
}

</style>
