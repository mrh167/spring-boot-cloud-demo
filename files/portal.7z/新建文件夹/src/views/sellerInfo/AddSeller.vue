<template>
  <div class="add-seller" style="position: relative">
    <lui-card v-loading="loading" class="form-container" shadow="never">
      <lui-button size="mini" style="margin-bottom:20px" @click="onBack">返回</lui-button>
      <lui-form ref="sellerFrom" :model="seller" :rules="rules" label-width="150px">
        <lui-form-item label="商家类型：" prop="sellerType">
          <lui-radio-group v-model="seller.sellerType" @change="handlechangesellertype">
            <lui-radio label="ECLP">ECLP</lui-radio>
            <lui-radio label="CLPS" disabled>CLPS</lui-radio>
            <lui-radio label="OTHER">其他</lui-radio>
          </lui-radio-group>
        </lui-form-item>
        <lui-row>
          <lui-col :span="20">
            <lui-form-item label="商家编码：" prop="sellerNo">
              <lui-input
                v-model="seller.sellerNo"
                placeholder="请输入商家编码"
                maxlength="30"
                @input="e => seller.sellerNo = numberStringForbid (e)">
              </lui-input>
            </lui-form-item>
          </lui-col>
          <lui-col :span="4">
            <div align="right">
              <lui-button
                v-waves
                type="primary"
                :disabled="seller.sellerType !=='ECLP'"
                @click="getSellerInfoEclp">查询商家
              </lui-button>
              <lui-button v-waves @click="resetSellerInfo">重置</lui-button>
            </div>
          </lui-col>
        </lui-row>
        <lui-form-item
          label="商家名称："
          prop="sellerName">
          <lui-input
            v-model="seller.sellerName"
            placeholder="请输入商家名称，ECLP点击查询获取"
            maxlength="50"
            :disabled="seller.sellerType =='ECLP'"
            @input="e => seller.sellerName = specialForbid (e)"></lui-input>
        </lui-form-item>
        <lui-form-item label="是否多级管理：" prop="level">
          <lui-radio-group v-model="seller.level" :disabled="seller.sellerType =='ECLP'" @change="initDept">
            <lui-radio :label="1">是</lui-radio>
            <lui-radio :label="0">否</lui-radio>
          </lui-radio-group>
        </lui-form-item>
        <lui-row v-for="(dept, index) in seller.sellerDeptList" :key="dept.key">
          <div>
            <lui-col :span="7">
              <lui-form-item
                :label="'事业部名称'+'：'"
                :prop="'sellerDeptList.' + index + '.deptName'"
                :rules="[{ required: true, message: '事业部名称不能为空', trigger: 'blur' },]"
              >
                <lui-input
                  v-model="dept.deptName"
                  :disabled="seller.sellerType =='ECLP'"
                  :placeholder="seller.sellerType ==='ECLP'?'请输入商家名称，ECLP点击查询获取':'请输入事业部名称'"
                  maxlength="50"
                  @input="e => dept.deptName = specialForbid (e)"></lui-input>
              </lui-form-item>
            </lui-col>
            <lui-col :span="7">
              <lui-form-item
                :label="'事业部编码'+'：'"
                :prop="'sellerDeptList.' + index + '.deptNo'"
                :rules="[{ required: true, message: '事业部编码不能为空', trigger: 'blur' },]"
              >
                <lui-input
                  v-model="dept.deptNo"
                  placeholder="请输入事业部编码"
                  :disabled="seller.sellerType =='ECLP'"
                  maxlength="50"
                  @input="e => dept.deptNo = numberStringForbid (e)"> </lui-input>
              </lui-form-item>
            </lui-col>
            <!-- 新增区域 -->
            <lui-col :span="7">
              <lui-form-item
                :label="'签约区域'+'：'"
                :prop="'sellerDeptList.' + index + '.registerRegion'"
                :rules="[
                  { required: true, message: '请选择签约区域', trigger: ['change','blur'] },
                ]">
                <lui-select 
                  v-model="dept.registerRegion"
                  :disabled="seller.sellerType =='ECLP'"
                  style="width: 100%"
                  placeholder="请选择签约区域">
                  <lui-option
                    v-for="item in regionList"
                    :key="item.code"
                    :label="item.desc"
                    :value="item.code">
                  </lui-option>
                </lui-select>
              </lui-form-item>
            </lui-col>
            <!--  -->
            <lui-col :span="2">
              <lui-button style="float:right" icon="lui-icon-delete" :disabled="seller.sellerType =='ECLP'||seller.sellerDeptList.length<2" @click.prevent="removeDomain(dept)"></lui-button>
            </lui-col>
          </div>
        </lui-row>
        <lui-row>
          <lui-col :span="24">
            <lui-form-item align="center">
              <lui-button style="width:100%;height: 40px;border: 1px dashed #ccc" :disabled="seller.sellerType =='ECLP'||seller.level === 0" @click="addDomain">新增事业部</lui-button>
            </lui-form-item>
          </lui-col>
        </lui-row>

        <lui-form-item label="部署方式：" prop="build" style="margin-top: 30px;">
          <lui-select v-model="seller.build" placeholder="请选部署方式" style="width: 100%">
            <lui-option label="京东内部署" value="JS"></lui-option>
            <lui-option label="云部署" value="JY"></lui-option>
            <lui-option label="私有化部署" value="OTHER"></lui-option>
          </lui-select>
        </lui-form-item>
        <!--这里结束-->
        <lui-form-item label="商品是否可添：" prop="goodsSource">
          <lui-radio-group v-model="seller.goodsSource">
            <lui-radio :label="0">不可添</lui-radio>
            <lui-radio :label="1">可添</lui-radio>
          </lui-radio-group>
        </lui-form-item>
        <lui-form-item label="节点数据是否可添：" server-config-list="nodeSource">
          <lui-radio-group v-model="seller.nodeSource">
            <lui-radio :label="0">不可添</lui-radio>
            <lui-radio :label="1">可添</lui-radio>
          </lui-radio-group>
        </lui-form-item>
        <p class="servertitle">开通产品</p>
        <lui-row v-for="(serveItem,index) in serveoptions" :key="serveItem.serverCode" class="serve buttonserve">
          <lui-col :span="1" class="indexBtn">
            <input v-model="serveItem.serverCode" style="display: none">
            <input
              ref="checkClass"
              type="checkbox"
              :checked="serveItem.id"
              :disabled="serveItem.id"
              @click="checkedBox(serveItem,index)">
          </lui-col>
          <lui-col :span="6">
            <lui-form-item
              label-width="70px"
              :label="'开通产品'"
            >
              <lui-input v-model="serveItem.serverName" disabled style="width:100%"></lui-input>
              <input v-model="serveItem.serverCode" type="hidden">
            </lui-form-item>
          </lui-col>
          <lui-col :span="1"><span style="color: #fff">d</span></lui-col>
          <lui-col :span="6">
            <lui-form-item
              label-width="90px"
              :label="'生效时间'">
              <lui-date-picker
                v-model="serveItem.startTime"
                style="width: 100%"
                type="date"
                :picker-options="serveItem.pickerBeginDateBefore"
                format="yyyy-MM-dd"
                value-format="yyyy-MM-dd HH:mm:ss"
                placeholder="请选择生效时间"
                @change="handleStartTime(index)">
              </lui-date-picker>
            </lui-form-item>
          </lui-col>
          <lui-col :span="1"><span style="color: #fff">d</span></lui-col>
          <lui-col :span="6">
            <lui-form-item
              label-width="90px"
              :label="'到期时间'"
            >
              <lui-date-picker
                v-model="serveItem.endTime"
                style="width: 100%"
                type="date"
                format="yyyy-MM-dd"
                value-format="yyyy-MM-dd HH:mm:ss"
                :picker-options="serveItem.pickerBeginDateAfter"
                placeholder="请选择到期时间"
                @change="handleEndTime(index)">
              </lui-date-picker>
            </lui-form-item>
          </lui-col>
          <lui-col :span="1"><span style="color: #fff">d</span></lui-col>
          <lui-col :span="1">
            <div v-if="serveItem.serverConfigList&&serveItem.serverConfigList.length>0">
              <lui-button class="configBtn" @click="configBtn(serveItem)">产品配置</lui-button>
            </div>
          </lui-col>
          <lui-dialog
            v-if="serveItem.serverConfigList&&serveItem.serverConfigList.length>0"
            title="服务配置"
            :visible.sync="serveItem.configurable"
            width="30%"
          >
            <lui-form-item
              v-for="(item,i) in serveItem.serverConfigList"
              :key="item.dictCode"
              :label="item.dictName"
              style="margin-bottom: 20px;"
            >
              <lui-select
                v-model="serveItem.sellerServerConfigList[i]"
                value-key="dictValue"
              >
                <lui-option
                  v-for="(subItem) in item.options"
                  :key="subItem.dictValue"
                  :label="subItem.dictLabel"
                  :value="subItem">
                </lui-option>
              </lui-select>
            </lui-form-item>
            <span slot="footer" class="dialog-footer">
              <lui-button @click="cancelDialog(serveItem)">取 消</lui-button>
              <lui-button type="primary" @click="bindDialog(serveItem)">确 定</lui-button>
            </span>
          </lui-dialog>
        </lui-row>
        <lui-form-item align="right" style="margin-top: 50px;">
          <lui-button v-waves @click="onBack('sellerFrom')">取消</lui-button>
          <lui-button v-waves type="primary" @click="onSubmit('sellerFrom',1)">保存</lui-button>
          <lui-button v-waves type="primary" @click="onSubmit('sellerFrom',2)">下一步</lui-button>
        </lui-form-item>
      </lui-form>
    </lui-card>
  </div>
</template>
<script>
import Api from '@/api'
import $ from 'jquery'
const defaultSeller = {
  build: 'JS',
  goodsSource: 0,
  level: 0,
  sellerType: 'ECLP',
  nodeSource: 0,
  sellerDeptList: [
    {
      deptName: '',
      deptNo: '',
      registerRegion: ''
    }
  ],
  sellerName: '',
  sellerNo: '',
  sellerServerList: [
    {
      endTime: '',
      sellerServerConfigList: [
        {
          dictCode: '',
          dictValue: 0
        }
      ],
      serverCode: '',
      startTime: ''
    }
  ]
}
export default {
  name: 'sellerInfoDetail',
  components: {
    //  ButtonList
  },
  props: {
    isEdit: {
      type: Boolean,
      default: false //false代表添加
    }
  },
  data() {
    return {
      regionList: [],
      // 限制收货时间不让选择今天以前的
      pickerOptions0: {
        disabledDate(time) {
          return time.getTime() < Date.now() - 8.64e7
        }
      },
      //定义一个空数组
      addSeller: [],
      //勾选的数组
      checkedArr: [],
      uuu: [],
      serveoptions: [], //显示所有服务
      //弹框
      dialogVisible1: false,
      dialogServer: {},
      configoptions2: [],
      //编辑回显的新的数组
      arr: [],
      loading: false,
      resetSeller: false,
      seller: Object.assign({}, defaultSeller),
      rules: {
        sellerNo: [
          { required: true, message: '商家编码不能为空', trigger: 'blur' }
        ],
        sellerName: [
          { required: true, message: '商家名称不能为空', trigger: 'blur' },
          {
            min: 2, max: 50, message: '长度在 2 到 50 个字符', trigger: 'blur'
          }
        ]
      },
      nowTimeNew: '', //ajax获取时间
      serverOptions: [], // 开通产品下拉
      configServerOptions: [], //开通个性化服务下拉
      addProductabled: false //新增开通产品
    }
  },
  created() {
    this.dataAjax()
  },
  mounted() {
    this.regionEnum()
    this.getServerOptions()
  },
  methods: {
    // -----------------------------------新增区域------开始
    //区域列表
    regionEnum() {
      Api.Merchants.regionEnum().then(res => {
        if (res.success) {
          if (Array.isArray(res.data) && res.data.length) {
            this.regionList = res.data
          }
        } else {
          this.$showErrorMsg(res.errMessage)
        }
      }).catch((e) => {
        console.error(e)
      })
    },
    // -----------------------------------新增区域-----结束
    dataAjax() { //获取当前时间
      const now = new Date($.ajax({ async: false }).getResponseHeader('Date'))
      this.nowTimeNew = now.getTime()
    },
    handleStartTime(val) { //开始时间
      if (this.serveoptions[val].startTime) {
        //开始日期小于结束日期
        this.serveoptions[val].pickerBeginDateBefore = {
          disabledDate: (time) => {
            var end = new Date(this.serveoptions[val].endTime).getTime()
            if (end) {
              return (time.getTime() > new Date(this.serveoptions[val].endTime).getTime()) || (time.getTime() < (this.nowTimeNew - 8.64e7))
            } else {
              return (time.getTime() < (this.nowTimeNew - 8.64e7))
            }
          }
        }
        //结束日期小于开始日期
        this.serveoptions[val].pickerBeginDateAfter = {
          disabledDate: (time) => {
            var start = new Date(this.serveoptions[val].startTime).getTime()
            if (start) {
              return time.getTime() < start
            }
          }
        }
      } else {
        //结束日期不能选今天之前包含今天
        this.serveoptions[val].pickerBeginDateAfter = {
          disabledDate: (time) => {
            return (time.getTime() < (this.nowTimeNew))
          }
        }
      }
    },
    handleEndTime(val) { //结束时间
      if (this.serveoptions[val].endTime) {
        //结束日期小于开始日期
        this.serveoptions[val].pickerBeginDateAfter = {
          disabledDate: (time) => {
            var start = new Date(this.serveoptions[val].startTime).getTime()
            if (start) {
              return time.getTime() < start
            }
          }
        }
        //开始日期小于结束日期
        this.serveoptions[val].pickerBeginDateBefore = {
          disabledDate: (time) => {
            var end = new Date(this.serveoptions[val].endTime).getTime()
            if (end) {
              return (time.getTime() > new Date(this.serveoptions[val].endTime).getTime()) || (time.getTime() < (this.nowTimeNew - 8.64e7))
            }
          }
        }
      } else {
        this.serveoptions[val].pickerBeginDateBefore = {
          disabledDate: (time) => {
            return (time.getTime() < (this.nowTimeNew - 8.64e7))
          }
        }
      }
    },
    cancelDialog(serveItem) {
      serveItem.configurable = false
      serveItem.sellerServerConfigList = []
    },
    //获取所有开通产品下拉
    getServerOptions() {
      Api.SellerInfo.getAllSysServer().then((res) => {
        const data = res.data
        if (res.success) {
          data.forEach(serveItem => {
            this.serveoptions.push({
              serverCode: serveItem.serverCode,
              serverName: serveItem.serverName,
              serverConfigList: serveItem.serverConfigList,
              startTime: '',
              endTime: '',
              configurable: false,
              sellerServerConfigList: [],
              pickerBeginDateBefore: {},
              pickerBeginDateAfter: {}
            })
          })
          // 当数据加载时时间控制
          for (let i = 0; i < this.serveoptions.length; i++) {
            //开始日期不能小于今天
            this.serveoptions[i].pickerBeginDateBefore = {
              disabledDate: (time) => {
                return (time.getTime() < (this.nowTimeNew - 8.64e7))
              }
            }
            //结束日期不能选今天之前
            this.serveoptions[i].pickerBeginDateAfter = {
              disabledDate: (time) => {
                return (time.getTime() < (this.nowTimeNew - 8.64e7))
              }
            }
          }
        }
        this.loading = false
      }).catch((error) => {
        this.loading = false
      })
    },
    //勾选下拉
    checkedBox(serveItem, index) {
      if (this.$refs.checkClass[index].checked) {
        this.checkedArr.push(serveItem)
      } else {
        const i = this.checkedArr.findIndex(item => item.serverCode === serveItem.serverCode)
        this.checkedArr.splice(i, 1)
      }
    },
    //获取个性化配置参数，item指的是sellerServerList每一项里的服务
    configBtn(serveItem) {
      serveItem.configurable = true
    },
    // 这里的方法绑定很重要
    bindDialog(serveItem) {
      serveItem.configurable = false
    },
    // 下一步
    onSubmit(formName, type) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          this.loading = true
          const arr = this.seller.sellerDeptList
          for (var i = 0; i < arr.length - 1; i++) {
            for (var j = i + 1; j < arr.length; j++) {
              if (arr[i].deptNo === arr[j].deptNo) {
                this.$showWarningMsg('事业部编码不能重复，请重新输入')
                this.loading = false
                return false
              }
            }
          }
          if (this.checkedArr.length > 0) {
            this.seller.sellerServerList = this.checkedArr
          } else {
            this.$showWarningMsg('请至少勾选一项产品服务')
            this.loading = false
            return false
          }
          const paramsobjuu = this.seller
          const _this = this
          Api.SellerInfo.addSellerInfo(paramsobjuu).then((res) => {
            if (res.success) {
              this.$message({
                message: '保存成功!',
                type: 'success',
                duration: '1000'
              })
              if (type === 2) {
                _this.loading = false
                //type为2下一步，sellerBtnType设置为2的时候显示adduser
                this.$store.dispatch('sellerBtnType', 2)
                this.$store.dispatch('portalSellerNo', _this.seller.sellerNo)
              }
              if (type === 1) {
                //type为1保存，sellerBtnType需要设置为3的时候显示index
                this.$store.dispatch('sellerBtnType', 3)
                this.$store.dispatch('portalSellerNo', _this.seller.sellerNo)
                this.$emit('func')
                _this.loading = false
              }
            } else {
              _this.$showErrorMsg(res.errMessage)
            }

          }).catch((err) => {
            _this.$showErrorMsg(err)
            _this.loading = false
          })
        } else {
          this.$message({
            message: '验证失败',
            type: 'error',
            duration: 1000
          })
          return false
        }
      })
    },
    // 取消
    onBack() {
      this.$store.dispatch('sellerBtnType', 3)
    },
    resetForm(formName) {
      this[formName] = {}
    },
    // 商家类型切换
    handlechangesellertype(value) {
      this.seller.sellerNo = ''
      this.seller.sellerName = ''
      this.seller.sellerDeptList = [{
        deptNo: '',
        deptName: '',
        registerRegion: ''
      }]
      this.seller.level = 0
      this.seller.sellerType = value
      this.resetSeller = false
      if (this.seller.sellerType === 'OTHER') {
        this.getDeptNo('change')
      }
    },
    getDeptNo(type) {
      Api.SellerInfo.getDeptNot().then((res) => {
        if (type === 'change') {
          this.seller.sellerDeptList[0].deptNo = res.data
        }
        if (type === 'add') {
          this.seller.sellerDeptList.push({
            deptNo: res.data,
            deptName: '',
            registerRegion: '',
            key: Date.now()
          })
        }
      }).catch((err) => {
        this.$showErrorMsg(err)
      })
    },
    initDept(value) {
      if (value === 0) {
        if (this.seller.sellerDeptList.length > 1) {
          this.seller.sellerDeptList = [{
            deptNo: '',
            deptName: '',
            registerRegion: ''
          }]
        }
      }
    },
    removeDomain(item) {
      const index = this.seller.sellerDeptList.indexOf(item)
      if (index !== -1) {
        this.seller.sellerDeptList.splice(index, 1)
      }
    },
    //新增事业部
    addDomain(depNo) {
      if (this.seller.sellerType === 'ECLP') {
        this.seller.sellerDeptList.push({
          deptNo: depNo,
          deptName: '',
          registerRegion: '',
          key: Date.now()
        })
      }
      if (this.seller.sellerType === 'OTHER') {
        this.getDeptNo('add')
      }
    },
    // 查询商家
    getSellerInfoEclp() {
      const params = {}
      params.sellerNo = this.seller.sellerNo
      //这里暂时先模拟数据
      Api.SellerInfo.getSellerByEclp(params).then((response) => {
        this.seller.sellerNo = response.data.sellerNo
        this.seller.sellerName = response.data.sellerName
        this.seller.level = response.data.level
        this.seller.sellerDeptList = response.data.sellerDeptList
        this.resetSeller = true
      }).catch((err) => {
        this.$showErrorMsg(err)
      })
    },
    // 重置
    resetSellerInfo() {
      this.seller.sellerNo = ''
      this.seller.sellerName = ''
      this.seller.sellerDeptList = [{
        deptNo: '',
        deptName: '',
        registerRegion: ''
      }]
      this.seller.level = 0
      this.resetSeller = false
    }
  }
}
</script>

<style scoped lang="scss">
  .add-seller{
    width: 100%;
    background: #fff;
    padding: 20px 0;
    .form-container{
      width: 90%;
      margin: 0 auto;
      border: 1px solid red;
    }
    .buttonserve{
      width: 90%;
      margin-left: 10%;
      padding-left: 20px;
      margin-top: 15px;
    }
    .servertitle{
      width: 95%;
      line-height: 30px;
      padding-bottom: 10px;
      padding-top: 20px;
      margin-left: 5%;
      font-size: 16px;
      color: #333;
      border-bottom: 1px solid #eee;
      margin-bottom: 30px;
    }
    .lui-card{
      border: none !important;
    }
    .serve {
      box-showdow: 1px solid #ccc;
      margin-bottom: 8px;
      padding-bottom: 5px;
      .lui-form-item {
        margin-bottom: 0
      }
    }

    .form-container {
      position: unset !important;
    }

    /deep/ .lui-date-editor.lui-input {
      width: 120px;
    }
    .indexBtn{
      position: absolute;
      top: 10px;
      left: 0px;
    }
  }


</style>
