<template>
  <div>
    <gl-line-bar-chart
      :chart-width="800"
      :chart-height="300"
      :data="data">
    </gl-line-bar-chart>
  </div>
</template>

<script>
import echarts from 'echarts'
export default {
  name: 'MyBarChartTest',
  components: {
    GlLineBarChart: () => import('@/components/shared/GlLineBarChart.vue')
  },
  data() {
    return {
      data: {
        title: 'aaa',
        legend: [],
        xAxis: [],
        yAxis: [],
        seriesArray: []
      }
    }
  },
  mounted() {
    this.loadLineData()
  },
  methods: {
    loadLineData() {
      // let barData = {
      //   textTitle: 'aaa',
      //   nameTitle: 'bbb',
      //   nameArray: [],
      //   dataArray: [],
      //   colorArray: []
      // }
      //
      // this.barData.colorArray.push(
      //   new echarts.graphic.LinearGradient(0, 1, 0, 0, [{
      //     offset: 0,
      //     color: 'rgba(29,144,255,0.5)' // 0% 处的颜色
      //   }, {
      //     offset: 1,
      //     color: '#1d92ff' // 100% 处的颜色
      //   }], false)
      // )
      // this.barData.colorArray.push(
      //   new echarts.graphic.LinearGradient(0, 1, 0, 0, [{
      //     offset: 0,
      //     color: 'rgba(255,0,0,0.5)' // 0% 处的颜色
      //   }, {
      //     offset: 1,
      //     color: '#ff0000' // 100% 处的颜色
      //   }], false)
      // )
      // this.barData.colorArray.push('#ff0000')
      // this.barData.colorArray.push('#ff0000')

      this.data.legend = {
        // x: 'center',
        y: 'top',
        data: ['111', '222', '333']
      }
      this.data.xAxis = [
        {
          type: 'category',
          data: ['测试1', '测试2', '测试3', '测试4'],
          axisPointer: {
            type: 'shadow'
          }
        }
      ]
      this.data.yAxis = [
        {
          type: 'value',
          name: '水量',
          axisLabel: {
            formatter: '{value} ml'
          }
        }
      ]
      this.data.seriesArray.push(
        { name: '111',
          type: 'bar',
          barWidth: '20px',
          data: [1, 2, 3, 4],
          markPoint: {
            data: [
              { type: 'max', name: '最大值' },
              { type: 'min', name: '最小值' }
            ]
          },
          color: new echarts.graphic.LinearGradient(0, 1, 0, 0, [{
            offset: 0,
            color: 'rgba(29,144,255,0.5)' // 0% 处的颜色
          }, {
            offset: 1,
            color: '#1d92ff' // 100% 处的颜色
          }], false) },
        { name: '222', type: 'bar', barWidth: '20px', data: [2, 5, 3, 14], color: '#ff0000', gradient: true },
        { name: '333', type: 'bar', barWidth: '20px', data: [2, 5, 3, 24, 24], color: '#555555', gradient: true }
      )
    }
  }
}
</script>

<style scoped>

</style>
