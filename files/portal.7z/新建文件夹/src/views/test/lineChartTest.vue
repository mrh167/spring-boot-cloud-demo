<template>
  <div>
    <div id="container" :style="{width: '800px', height: '800px'}"></div>
  </div>
</template>

<script>
var base = +new Date(2016, 9, 3)
var oneDay = 24 * 3600 * 1000
var valueBase = Math.random() * 300
var valueBase2 = Math.random() * 50
var data = []
var data2 = []

for (var i = 1; i < 10; i++) {
  var now = new Date(base += oneDay)
  var dayStr = [now.getFullYear(), now.getMonth() + 1, now.getDate()].join('-')

  valueBase = Math.round((Math.random() - 0.5) * 20 + valueBase)
  valueBase <= 0 && (valueBase = Math.random() * 300)
  data.push([dayStr, valueBase])

  valueBase2 = Math.round((Math.random() - 0.5) * 20 + valueBase2)
  valueBase2 <= 0 && (valueBase2 = Math.random() * 50)
  data2.push([dayStr, valueBase2])
}
import echarts from 'echarts'
export default {
  name: 'lineChartTest',
  data() {
    return {
      option: {}
    }
  },
  mounted() {
    this.drawLine()
  },
  methods: {
    drawLine() {
      // 基于准备好的dom，初始化echarts实例
      const myChart = echarts.init(document.getElementById('container'))
      // 绘制图表
      myChart.setOption({
        title: { text: '在Vue中使用echarts' },
        tooltip: {},
        xAxis: {
          data: ['衬衫', '羊毛衫', '雪纺衫', '裤子', '高跟鞋', '袜子']
        },
        yAxis: {},
        series: [{
          name: '销量',
          type: 'bar',
          data: [5, 20, 36, 10, 10, 20]
        }]
      })
    }
  }
}
</script>

<style scoped>

</style>
