<template>
  <div>
    <gl-line-chart
      :chart-width="800"
      :chart-height="300"
      :data="data">
    </gl-line-chart>
  </div>
</template>

<script>
export default {
  name: 'MyLineChartTest',
  components: {
    GlLineChart: () => import('@/components/shared/GlLineChart.vue')
  },
  data() {
    return {
      data: {
        title: 'aaa',
        legend: [],
        xAxis: [],
        yAxis: [],
        seriesArray: []
      }
    }
  },
  mounted() {
    this.loadLineData()
  },
  methods: {
    loadLineData() {
      this.data.legend = {
        x: 'center',
        y: 'bottom',
        data: ['111', '222', '333']
      }
      this.data.tooltip = {
        trigger: 'none',
        axisPointer: {
          type: 'cross'
        }
      }
      this.data.xAxis = [
        {
          type: 'category',
          data: ['测试1', '测试2', '测试3', '测试4'],
          axisTick: {
            alignWithLabel: true
          },
          axisLine: {
            onZero: false,
            lineStyle: {
              color: '#d14a61'
            }
          },
          axisPointer: {
            label: {
              formatter: function(params) {
                return '降水量  ' + params.value +
                  (params.seriesData.length ? '：' + params.seriesData[0].data : '')
              }
            }
          }
        }
      ]
      this.data.yAxis = [
        {
          type: 'value',
          name: '水量',
          axisLabel: {
            formatter: '{value} ml'
          }
        }
      ]
      this.data.seriesArray.push(
        {
          name: '111',
          data: [1, 2, 3, 4],
          smooth: true,
          symbol: 'circle',
          symbolSize: 10,
          itemStyle: {
            normal: {
              color: '#5fbdff',
              lineStyle: {
                width: 3
              }
            }
          }
        },
        { name: '222',
          data: [21, 25, 13, 14],
          color: '#999999',
          smooth: true,
          symbol: 'circle',
          symbolSize: 10,
          itemStyle: {
            normal: {
              color: '#ff975f',
              lineStyle: {
                width: 3,
                type: 'dotted'
              },
              label: {
                show: true,
                formatter: function(param) {
                  let currentValue = param.value
                  if (currentValue > 14) {
                    currentValue = currentValue + '偏高'
                  }
                  return currentValue
                }
              }
            }
          }
          // markPoint: {
          //   itemStyle: {
          //     color: '#4587E7',
          //     borderColor: '#000',
          //     borderWidth: 0,
          //     borderType: 'solid'
          //   },
          //   data: [
          //     {value: 25, xAxis: 1, yAxis: 25}
          //   ]
          // }
        },
        { name: '333',
          data: [2, 5, 3, 24, 24],
          smooth: true,
          symbol: 'circle',
          symbolSize: 10,
          itemStyle: {
            normal: {
              color: '#86ce80',
              lineStyle: {
                width: 3,
                type: 'dotted'
              }
            }
          }}
      )
    }
  }
}
</script>

<style scoped>

</style>
