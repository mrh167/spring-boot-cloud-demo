<template>
  <div class="container">
    <div ref="mask" class="login_mask">
      <div ref="masks" class="mask_wapper">
        <i class="lui-icon-circle-close" @click="handelClick"></i>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {}
  },
  methods: {
    handelClick() {
      // 
      this.$refs.masks.animate([
        { width: '640px', height: '500px', right: '50%', bottom: '50%', marginTop: '0' },
        { width: '20px', height: '20px', right: '1%', bottom: '250px', marginTop: '0', transform: 'skew(60deg)' }
      ], {
        duration: 1000,
        iteration: 2,
        delay: 0
      })


      this.$refs.mask.animate([
        { background: 'rgba(0, 0, 0, 0.6)' },
        { background: 'rgba(0, 0, 0, 0)' }
      ], {
        duration: 1000,
        iteration: 2,
        delay: 0
      })

      setTimeout(() => {
        this.$refs.mask.style.display = 'none'
      }, 1000)
      
    }
  }
}
</script>
<style scoped lang='scss'>
  .container{
    width: 100%;
    height: 650px;
    background: #fff;

    position: relative;
    .login_mask{
      position: fixed;
      z-index: 1000;
      width: 100%;
      height: 100%;
      background: rgba(0,0,0,0.6);
      .mask_wapper{
        width: 640px;
        height: 500px;
        position: absolute;
        // top: 100px;
        margin-top: 100px;
        right: 50%;
        background: #fff;
        margin-right: -320px;
        // transform: skew(60deg);
        i{
          cursor: pointer;
          font-size: 20px;
          color: #ccc;
        }
      }
    }
  }
</style>
