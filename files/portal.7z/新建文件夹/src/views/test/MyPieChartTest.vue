<template>
  <div>
    <gl-pie-chart
      :chart-width="800"
      :chart-height="300"
      :data="data">
    </gl-pie-chart>
  </div>
</template>

<script>
export default {
  name: 'MyPieChartTest',
  components: {
    GlPieChart: () => import('@/components/shared/GlPieChart.vue')
  },
  data() {
    return {
      data: {
        title: {},
        tooltip: {},
        legend: {},
        seriesArray: []
      }
    }
  },
  mounted() {
    this.loadPieData()
  },
  methods: {
    loadPieData() {
      this.data.title = '饼图测试'
      this.data.tooltip = {
        trigger: 'item',
        formatter: '{a} <br/>{b} : {c} ({d}%)'
      }
      this.data.legend = {
        x: 'center',
        y: 'bottom',
        data: ['数据1', '数据2', '数据3', '数据4', '数据5']
      }
      this.data.seriesArray.push(
        {
          name: '测试',
          // radius: '55%',
          radius: ['30%', '60%'],
          center: ['50%', '50%'],
          roseType: 'radius', // 使用玫瑰饼图
          data: [
            { value: 10, name: '数据1' },
            { value: 5, name: '数据2' },
            { value: 15, name: '数据3' },
            { value: 25, name: '数据4' },
            { value: 20, name: '数据5' }
          ]
        }
      )
    }
  }
}
</script>

<style scoped>

</style>
