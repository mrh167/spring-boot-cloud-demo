<template>
  <div>
    <div></div>
  </div>
</template>

<script>
export default {
  name: 'treetest',
  data() {
    return {
      dataSource: [
        {
          id: '1',
          parentId: '0',
          name: '智能手机1 '
        },
        {
          id: '1-1',
          parentId: '1',
          name: 'android'
        },
        {
          id: '1-2',
          parentId: '1',
          name: 'ios'
        },
        {
          id: '1-1-1',
          parentId: '1-1',
          name: '华为手机'
        },
        {
          id: '1-1-2',
          parentId: '1-1',
          name: '小米手机'
        },
        {
          id: '1-2-1',
          parentId: '1-2',
          name: '苹果手机'
        }
      ],
      treedata: []
    }
  },
  mounted() {
    this.treedata = this.listToTree(this.dataSource)
  },
  methods: {
    listToTree(dataSource) {
      // datasource是平级的数据来源
      return dataSource.filter(e => {
        const pid = e.parentId
        const resultArr = dataSource.filter(ele => {
          if (ele.id === pid) {
            if (!ele.children) {
              ele.children = []
            }
            ele.children.push(e)
            return true
          }
        })
        return resultArr.length === 0
      })
    }
  }
}
</script>

<style scoped>

</style>
