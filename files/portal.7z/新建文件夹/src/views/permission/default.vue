<template>
  <div class="container">
    <div class="container-title">您当前暂无权限访问【京慧】系统，“申请使用”并“审核通过”后即可为您提供更多的服务</div>
    <div class="container-body">
      <img src="@/assets/img/body.png" alt="">
    </div>
    <div class="container-footer">
      <div class="footer-top">
        <div v-for="(item,index) in tableData" :key="index" class="top-img">
          <span>{{ item.label1 }}</span>
          <span>{{ item.label2 }}</span>  
        </div>
      </div>
      <div class="footer-bottom">「京慧」标准版是京东物流面向企业客户着力打造的数字化价值供应链管理平台型产品。它将大数据与智能算法相结合，将需求和计划相结合，通过基础数据可视、行为数据分析和核心数据决策三个维度，打通仓储、配送、异常等全链路数据，为多行业、多类型企业提供集供应链管理和执行的全方位平台服务。重点围绕实时数据、分析诊断、销量预测、智能补调以及轻量化小工具等方向提供了专业服务模块。</div>
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {
      tableData: [
        {
          label1: '全链数据',
          label2: '直观可视'
        },
        {
          label1: '全链数据',
          label2: '直观可视'
        },
        {
          label1: '全链数据',
          label2: '直观可视'
        },
        {
          label1: '全链数据',
          label2: '直观可视'
        }
      ]
    }
  }
}
</script>

<style lang='scss' scoped>
.container{
  width: 100%;
  height: 100%;
  min-width: 1000px;
  background: url('../../assets/img/background.png') no-repeat;
  background-size: 100% 100%;
  padding-bottom: 50px;
  .container-title{
    width: 100%;
    font-size: 34px;
    color: #23252C;
    letter-spacing: 0;
    text-align: center;
    padding-top: 44px;
  }
  .container-body{
    width: 878px;
    height: 432px;
    margin: 0 auto;
    margin-top: 54px;
    img{
      width: 100%;
    }
  }
  .container-footer{
    width: 80%;
    // height: 240px;
    margin: 0 auto;
    background: #fff;
    margin-top: 20px;
    // margin-bottom: 50px;
    box-shadow: 0 2px 10px 1px rgba(184,198,209,0.40);
    border-radius: 8px;
    .footer-top{
      width: 100%;
      display: flex;
      .top-img{
        height: 120px;
        flex:1;
        margin-top: 10px;
        margin-bottom: 10px;
        // box-shadow: 0 2px 10px 1px rgba(146,185,216,0.50);
        border-radius: 8px;
        display: flex;
        justify-content: center;
        align-items: center;
        
        span{
          font-size: 24px;
          color: #FFFFFF;
          letter-spacing: 0;
          text-align: center;
          text-shadow: 0 2px 4px rgba(49,73,134,0.53);
          &:last-child{
            margin-left: 10px;
          }
          
        }
        &:last-child{
          margin-right: 10px;
        }
        &:first-child{
            margin-left: 10px;
          }
        &:nth-child(1){
          background: url('../../assets/img/bg1.png') no-repeat;
          background-size: 100% 100%;
        }
        &:nth-child(2){
          background: url('../../assets/img/bg2.png') no-repeat;
          background-size: 100% 100%;
        }
        &:nth-child(3){
          background: url('../../assets/img/bg3.png') no-repeat;
          background-size: 100% 100%;
        }
        &:nth-child(4){
          background: url('../../assets/img/bg4.png') no-repeat;
          background-size: 100% 100%;
        }

      }
    }
    .footer-bottom{
      padding: 20px;
      padding-top: 0;
      font-size: 16px;
      color: #3C3F4D;
      letter-spacing: 0;
      line-height: 24px;
    }
  }
}
</style>
