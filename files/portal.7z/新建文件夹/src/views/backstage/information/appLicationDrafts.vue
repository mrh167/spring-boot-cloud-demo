<template>
  <div class="drafts">
    <div v-if="darftsMain">
      <div class="drafts-title">
        <div>
          <span @click="backClick">返回</span>
        </div>
        <div>草稿箱</div>
        <div></div>
      </div>
      <lui-table
        ref="table"
        v-loading="listLoading"
        :data="tableData"
        class="dartfs-table"
        style="width: 85%;margin: 0 auto "
      >
        <template slot="empty">
          <showEmptyImage></showEmptyImage>
        </template>
        <lui-table-column
          prop="number"
          label="应用ID"
          width="150"
          show-overflow-tooltip>
        </lui-table-column>
        <lui-table-column
          prop="name"
          show-overflow-tooltip
          label="应用名称">
        </lui-table-column>
        <lui-table-column
          width="120"
          label="应用图标">
          <template slot-scope="{row}">
            <div
              v-if="row.icon!=''"
              v-viewer
              class="images">
              <lui-tooltip
                class="item"
                effect="dark"
                content="点击预览"
                placement="bottom">
                <img
                  :src="row.icon"
                  style="width: 40px;height: 40px;object-fit: cover;cursor: pointer" />
              </lui-tooltip>
            </div>
          </template>
        </lui-table-column>
        <lui-table-column
          width="180"
          label="操作时间"
          prop="updateTime"
          show-overflow-tooltip>
        </lui-table-column>

        <lui-table-column
          label="操作人"
          width="120"
          show-overflow-tooltip
          prop="updateUser">
        </lui-table-column>

        <lui-table-column
          width="230"
          label="操作">
          <template slot-scope="{row}">
            <lui-button type="text" @click="getDetails(row)">产品介绍</lui-button>
            <lui-button type="text" @click="toogleExpand(row)">产品详情</lui-button>
            <lui-button type="text" @click="editClick(row)">编辑</lui-button>
            <lui-button type="text" @click="deleteClick(row)">删除</lui-button>
          </template>
        </lui-table-column>
      </lui-table>
      <div v-show="totals>10" class="drafts-pagination">
        <lui-pagination
          background
          :current-page.sync="pageNum"
          :page-sizes="[10, 20, 50, 70, 100]"
          layout="prev, pager, next, sizes, jumper"
          :total="totals"
          @current-change="handleSizeChange"
          @size-change="sizeChange"
        ></lui-pagination>
      </div>

    </div>


    <DarftsEdit v-if="darftsEditShow" :header-user-name="headerUserName" @eventDraftsEdit="draftsEditChange($event)"></DarftsEdit>
    <!--    详情-->
    <lui-dialog
      :visible.sync="centerDialogVisible"
      width="50%"
      top="10vh"
      :close-on-click-modal="false"
      custom-class="dialog_mask"
      title="公告详情">
      <lui-form
        ref="ruleForm"
        label-width="150px"
        class="demo-ruleForm">
        <lui-row
          :gutter="20"
          class="scrollBar"
          style="width: 95%;height: 500px;overflow-y: auto;margin-left: 5%;padding-right: 5%;">
          <div
            class="dialog-title">{{ ruleForm.title }}</div>
          <div
            class="dialog-time"
            style="font-size: 13px;color: #999;margin-top: 10px;">{{ ruleForm.time }}</div>
          <div
            v-dompurify-html="ruleForm.content"
            class="dialog-content"
            style="margin-top: 10px;"></div>
        </lui-row>
      </lui-form>
    </lui-dialog>
  </div>
</template>

<script>
import Api from '@/api'
import showEmptyImage from '@/components/common/showEmptyImage/index.vue'
import DarftsEdit from './appLicationDraftsAdd'
import utils from '@/utils/utils'
export default {
  name: 'index',
  components: {
    showEmptyImage,
    DarftsEdit
  },
  data() {
    return {
      headerUserName: null,
      darftsEditShow: false,
      darftsMain: true,
      pageNum: 1,
      pageSize: 10,
      totals: 0,
      tableData: [],
      listLoading: true,
      centerDialogVisible: false,
      ruleForm: {
        title: '',
        time: '',
        content: ''
      }
    }
  },
  mounted() {
    this.getList()
  },
  methods: {
    //接收子组建传参
    draftsEditChange(data) {
      if (!data) {
        this.darftsMain = true
        this.darftsEditShow = data
      }
      this.getList()
    },
    //返回上一级
    backClick() {
      this.$emit('eventDrafts', false)
    },
    //编辑
    editClick(row) {
      this.headerUserName = row.id
      this.darftsEditShow = true
      this.darftsMain = false
      // this.$router.push({ 'path': '/information/appLication/draftsEdit', query: { id: row.id }})
    },
    // 产品详情查看页面
    getDetails(row) { //数据查看
      this.$router.push({ 'path': '/application' })
    },

    //产品介绍查看页
    toogleExpand(row) {
      this.$router.push({ 'path': '/appLication', query: { id: row.id }})
    },
    //删除数据
    deleteClick(row) {
      this.$alert('<p style="font-size: 18px;color:#333">确认删除此条应用吗?</p><p style="font-size: 13px;color: #666">删除后，应用的相关内容信息将无法恢复</p>', '', {
        dangerouslyUseHTMLString: true,
        type: 'warning',
        center: true
      }).then(() => {
        Api.BackStageAppContent.appCenterDelete({ id: row.id }).then(row => {
          this.$showSuccessMsg('删除成功')
          this.getList()
        }).catch((e) => { this.$showErrorMsg(e) })
      })
    },

    //是否显示
    switchClick(row) {
      Api.BackStageAppContent.appCenterSetIfShow({
        id: row.id,
        enabled: row.enabled ? 1 : 2
      }).then(row => {
        this.$showSuccessMsg('设置成功')
        this.listLoading = false
      }).catch((e) => {
        this.$showErrorMsg(e)
        this.getList()
      })
    },
    //置顶
    topClick(row) {
      Api.BackStageAppContent.appCenterEditTop({
        id: row.id,
        topFlag: 1
      }).then(row => {
        if (row.success) {
          this.$showSuccessMsg('置顶成功')
          this.getList()
        } else {
          this.$showErrorMsg(row.errMessage)
        }
      }).catch((e) => { this.$showErrorMsg(e) })
    },
    //列表
    getList() {
      this.listLoading = true //数据加载动画
      Api.BackStageAppContent.appCenterList({
        pageNum: this.pageNum, //页
        pageSize: this.pageSize, //条数
        stage: 0
      }).then(row => {
        if (row.success) {
          for (let i = 0; i < row.data.length; i++) {
            row.data[i].number = utils.htmlDecode(row.data[i].number)
            row.data[i].name = utils.htmlDecode(row.data[i].name)
            if (row.data[i].enabled === 2) {
              row.data[i].enabled = false
            } else {
              row.data[i].enabled = true
            }
          }
          this.tableData = row.data
          this.totals = row.total
          this.listLoading = false
        }
      }).catch((e) => { this.$showErrorMsg(e) })

    },
    //分页条数改变
    sizeChange(val) {
      this.pageSize = val
      this.getList()
    },
    //翻页-----根据页码变换
    handleSizeChange(val) {
      this.pageNum = val
      this.getList()
    }
  }
}
</script>

<style scoped lang="scss" rel="stylesheet/scss">
@import "@/assets/stylus/main.scss";


.drafts{
  background: #fff;
  width: 100%;
  min-height: 600px;
  padding-bottom: 26px;
  padding-top: 35px;
}

.icon-buttons{
  display: flex;
  justify-content: space-between;
  span{
    cursor: pointer;
    color: $--gl-blue;
  }
}
.table-icon{
  display: flex;
  justify-content: space-between;
  span{
    color: #1d76a8;
    cursor: pointer;
  }
}
.table-link{
  overflow: hidden;
  text-overflow:ellipsis;
  white-space: nowrap;
}
.img{
  width: 40px;
  height: 40px;
  img{
    width: 40px;
    height: 40px;
    object-fit: cover;
  }
}
.drafts-title{
  width: 85%;
  height: 40px;
  margin: 0 auto;
  display: flex;
  justify-content: space-between;
  justify-items: center;
}
.drafts-title div{
  font-size: 16px;
}
.drafts-title span:nth-child(1){
  font-size: 12px;
  cursor: pointer;
  display: inline;
  padding: 4px 17px;
  border: 1px solid #e9e9e9;
  border-radius: 3px;
  color: #999
}
.drafts-pagination{
  width: 100%;
  margin-top: 73px;
  text-align: center;
}
.table-p{
  overflow: hidden;
  text-overflow:ellipsis;
  white-space: nowrap;
  cursor: pointer;
  padding-right: 15px;
}
.knowledge-caozuo {
  display: flex;
  justify-content: space-between;
  align-items: center;
  cursor: pointer;
}
.dialog-title{
  cursor: pointer;
  font-size: 20px;
  color: #333;
  font-weight: 500;
  &:hover{
    color: $--gl-blue;
  }

}
.dartfs-table {
  /deep/ .lui-table__body-wrapper{
    margin-top: -50px;
  }
}

</style>
