<template>
  <div class="broadcast">
    <lui-table
      v-loading="listLoading"
      :data="tableData"
      style="width: 85%;margin: 0 auto;">

      <template slot="empty">
        <showEmptyImage></showEmptyImage>
      </template>
      <lui-table-column
        prop="id"
        label="ID"
        width="90"
        show-overflow-tooltip>
      </lui-table-column>
      <lui-table-column
        prop="title"
        label="广播标题"
        show-overflow-tooltip>
      </lui-table-column>
      <lui-table-column
        prop="content"
        label="广播正文"
        show-overflow-tooltip>
      </lui-table-column>
      <lui-table-column
        prop="url"
        label="广播链接"
        show-overflow-tooltip>
      </lui-table-column>
      <lui-table-column
        width="80"
        label="是否显示">
        <template slot-scope="{row}">
          <lui-switch
            v-model="row.enabled"
            active-circle-class="1"
            active-color="rgba(60,110,240,.2)"
            inactive-color="rgba(142,145,152,.2)"
            @change="placementClick(row)">
          </lui-switch>
        </template>
      </lui-table-column>
      <lui-table-column
        width="165"
        prop="updateTime"
        label="修改时间">
      </lui-table-column>
      <lui-table-column
        prop="updateUser"
        width="120"
        label="操作人"
        show-overflow-tooltip>
      </lui-table-column>
      <lui-table-column
        prop="date"
        width="95"
        label="操作">
        <template slot-scope="{row}">
          <lui-button type="text" @click="editClick(row)">编辑</lui-button>
          <lui-button type="text" @click="deleteClick(row)">删除</lui-button>
        </template>
      </lui-table-column>
    </lui-table>
    <div class="broadcast-add">
      <div
        class="add-button"
        @click="addClick">
        <span class="lui-icon-plus"></span>
        <span>新建广播</span>
      </div>
    </div>
    <div v-show="totals>10" class="broadcast-pagination">
      <lui-pagination
        background
        :current-page.sync="pageNum"
        :page-sizes="[10, 20, 50, 70, 100]"
        layout="prev, pager, next, sizes, jumper"
        :total="totals"
        @current-change="handleSizeChange"
        @size-change="sizeChange">
      </lui-pagination>
    </div>

    <lui-dialog
      :visible.sync="centerDialogVisible"
      width="60%"
      top="10vh"
      :show-close="false"
      :close-on-click-modal="false"
      custom-class="dialog_mask"
      title="小广播发布">
      <lui-form
        ref="ruleForm"
        :model="ruleForm"
        :rules="rules"
        label-width="150px"
        class="demo-ruleForm">
        <lui-row :gutter="20">
          <lui-col :span="20">
            <lui-form-item
              label="小广播名称:"
              prop="name">
              <lui-input
                v-model="ruleForm.name"
                placeholder="请输入小广播简介"></lui-input>
            </lui-form-item>
            <lui-form-item
              label="小广播正文:"
              prop="textarea">
              <lui-input
                v-model="ruleForm.textarea"
                type="textarea"
                placeholder="请输入小广播正文"
                maxlength="30"
                show-word-limit></lui-input>
            </lui-form-item>
            <lui-form-item
              label="是否生效"
              prop="enabled">
              <lui-radio-group v-model="ruleForm.enabled" @change="enabledClick">
                <lui-radio
                  :label="1"
                  class="button_radio">是</lui-radio>
                <lui-radio
                  :label="0"
                  class="button_radio">否</lui-radio>
              </lui-radio-group>
            </lui-form-item>
            <lui-form-item
              label="广播链接"
              prop="url">
              <lui-input
                v-model.trim="ruleForm.url"
                placeholder="请输入链接地址">
              </lui-input>
            </lui-form-item>
          </lui-col>
        </lui-row>
      </lui-form>
      <div
        slot="footer"
        class="dialog-footer"
        style="text-align: center">
        <lui-button @click="resetForm('ruleForm')">取 消</lui-button>
        <lui-button
          :loading="loadingBut"
          type="primary"
          @click="submitForm('ruleForm')">确 定</lui-button>
      </div>
    </lui-dialog>
  </div>
</template>

<script>
import Api from '@/api'
import utils from '@/utils/utils'
import showEmptyImage from '@/components/common/showEmptyImage/index.vue'
export default {
  name: 'index',
  components: {
    showEmptyImage
  },
  data() {
    return {
      loadingBut: false,
      listLoading: true,
      activeIndex: '4',
      value1: true,
      dialogTableVisible: false,
      dialogFormVisible: false,
      centerDialogVisible: false,
      pageSize: 10,
      pageNum: 1,
      totals: 0,
      edit: false,
      ruleForm: {
        name: '', // 名称
        textarea: '', //正文
        enabled: '', //是否启用
        url: '' //链接
      },
      rules: {
        name: [{ required: true, message: '请输入广播名称', trigger: 'blur' }],
        textarea: [{ required: true, message: '请输入广播正文', trigger: 'blur' }],
        enabled: [{ required: true, message: '是否显示', trigger: 'blur' }],
        url: [{ required: false, message: '请输入链接', trigger: 'blur' }]
      },
      tableData: []
    }
  },
  mounted() {
    this.getList()
  },
  methods: {
    //分页条数改变
    sizeChange(val) {
      this.pageSize = val
      this.getList()
    },
    getList() {
      this.listLoading = true
      Api.BackStageBroadcast.manageBroadcastList({
        pageSize: this.pageSize,
        pageNum: this.pageNum
      }).then(response => {
        if (response.success) {
          for (let i = 0; i < response.data.length; i++) {
            response.data[i].title = utils.htmlDecode(response.data[i].title)
            response.data[i].content = utils.htmlDecode(response.data[i].content)
            if (response.data[i].enabled === 0) {
              response.data[i].enabled = false
            } else {
              response.data[i].enabled = true
            }
          }
          this.tableData = response.data
          this.totals = response.total
          this.listLoading = false
        }
      }).catch((e) => { this.$showErrorMsg(e) })
    },
    enabledClick() {
      this.$refs.ruleForm.clearValidate('enabled')
    },
    //是否置顶
    placementClick(row) {
      Api.BackStageBroadcast.manageBroadcastSetIfShow({
        id: row.id,
        enabled: row.enabled ? 1 : 0
      }).then(() => {
        this.$showSuccessMsg('设置成功')
        this.getList()
      }).catch((e) => { this.$showErrorMsg(e) })

    },
    //翻页-----根据页码变换
    handleSizeChange(val) {
      this.pageNum = val
      this.getList()
    },
    //修改
    editClick(row) {
      this.centerDialogVisible = true //open弹窗
      this.edit = true
      this.ruleForm = {
        id: row.id,
        name: row.title, // 名称
        textarea: row.content, //正文
        enabled: row.enabled ? 1 : 0, //是否启用
        url: row.url //链接
      }
    },
    //新增保存
    submitForm(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          this.loadingBut = true
          if (this.edit) { //编辑
            Api.BackStageBroadcast.manageBroadcastEdit({
              id: this.ruleForm.id,
              enabled: this.ruleForm.enabled,
              title: this.ruleForm.name,
              content: this.ruleForm.textarea,
              url: this.ruleForm.url
            }).then(row => {
              if (row.success) {
                this.$message({
                  message: '修改成功',
                  type: 'success'
                })
                this.loadingBut = false
                this.edit = false
                this.centerDialogVisible = false //关闭弹窗
                this.getList()
              }
            }).catch((e) => {
              this.loadingBut = false
              this.$showErrorMsg(e)
            })
          } else {
            // 新增
            Api.BackStageBroadcast.manageBroadcastAdd({
              enabled: this.ruleForm.enabled,
              title: this.ruleForm.name,
              content: this.ruleForm.textarea,
              url: this.ruleForm.url
            }).then(row => {
              if (row.success) {
                this.$message({
                  message: '新增成功',
                  type: 'success'
                })
                this.centerDialogVisible = false //关闭弹窗
                this.getList()
                this.loadingBut = false
              }
            }).catch((e) => {
              this.loadingBut = false
              this.$showErrorMsg(e)
            })
          }
        } else {
          return
        }
      })
    },
    //新建取消按钮
    resetForm(formName) {
      this.$refs[formName].resetFields()
      this.centerDialogVisible = false //关闭弹窗
    },
    addClick() {
      this.edit = false
      this.centerDialogVisible = true
      this.ruleForm = {
        name: '', // 名称
        textarea: '', //正文
        enabled: '', //是否启用
        url: '' //链接
      }
    },
    //删除
    deleteClick(row) {
      this.$alert('<p style="font-size: 18px;color:#333">确认删除此条广播管理吗?</p><p style="font-size: 13px;color: #666">删除后，广播管理的相关内容信息将无法恢复</p>', '', {
        dangerouslyUseHTMLString: true,
        type: 'warning',
        center: true
      }).then(() => {
        Api.BackStageBroadcast.manageBroadcastDelete({ id: row.id }).then(row => {
          if (row.success) {
            this.$message({
              message: '删除成功',
              type: 'success'
            })
            this.getList()
          }
        }).catch((e) => { this.$showErrorMsg(e) })
      })
    }
  }
}
</script>

<style scoped lang="scss" rel="stylesheet/scss">
@import "@/assets/stylus/main.scss";
.broadcast{
  background: #fff;
  width: 100%;
  min-height: 600px;
  padding-bottom: 26px;
  //padding-top: 20px;
  position: relative;
  .information-nav{
    width: 85%;
    margin: 0 auto;
    margin-bottom: 20px;
    .nav-menu{
      li{
        font-size: 14px;
      }
    }
  }
  .broadcast-add{
    width: 85%;
    height: 50px;
    margin: 0 auto;
    .add-button{
      background: #fff;
      width: 100%;
      height: 50px;
      display: flex;
      cursor: pointer;
      justify-content: center;
      align-items: center;
      border: 1px dashed #c2c2c2;
      span{
        display: inline-block;
        height: 20px;
        line-height: 20px;
        font-size: 14px;
        color: #333;
      }
      span:nth-child(1){
        font-size: 12px;
        color: $--gl-blue;
        line-height: 18px;
        margin-right: 6px;
      }
    }
    .add-button:hover{
      background: #e7f0f6;
      border: 1px dashed $--gl-blue;
      span{
        display: inline-block;
        height: 20px;
        line-height: 20px;
        font-size: 14px;
        color: $--gl-blue;
      }
      span:nth-child(1){
        font-size: 12px;
        color: $--gl-blue;
        line-height: 18px;
        margin-right: 6px;
      }
    }
  }

  .broadcast-pagination{
    width: 100%;
    margin-top: 73px;
    text-align: center;
  }
  .table-link{
    overflow: hidden;
    text-overflow:ellipsis;
    white-space: nowrap;
  }
  .table-p{
    overflow: hidden;
    text-overflow:ellipsis;
    white-space: nowrap;
    cursor: pointer;
    padding-right: 15px;
  }
  .table-icon{
    display: flex;
    justify-content: space-between;
    span{
      color: #1d76a8;
      cursor: pointer;
    }
  }
  .dialog-img{
    width: 100%;
    height: 100%;
    overflow: hidden;
    img{
      width: 100%;
      height: 100%;
      object-fit: cover;
    }
  }
}


</style>
