<template>
  <div class="information">
    <div v-if="navShow" class="information-nav">
      <lui-menu
        :default-active="activeIndex"
        class="lui-menu-demo nav-menu"
        mode="horizontal"
        @select="handleSelect">
        <lui-menu-item index="1">轮播图管理</lui-menu-item>
        <lui-menu-item index="2">帮助中心管理</lui-menu-item>
        <lui-menu-item index="3">公告管理</lui-menu-item>
        <lui-menu-item index="4">广播管理</lui-menu-item>
        <lui-menu-item index="5">反馈查看</lui-menu-item>
        <lui-menu-item index="6">精准投放</lui-menu-item>
        <lui-menu-item index="7">应用中心管理</lui-menu-item>
      </lui-menu>
      <div class="line"></div>
    </div>
    <div class="information-content">
      <component :is="currentRole" @event1="changeParent($event)" />
    </div>
  </div>
</template>

<script>
import Rotation from './rotation.vue'
import Knowledge from './knowledge.vue'
import Broadcast from './broadcast.vue'
import Delivery from './delivery.vue'
import Notice from './notice.vue'
import Feedback from './feedback.vue'
import AppLication from './appLication.vue'
export default {
  name: 'index',
  components: {
    Rotation,
    Knowledge,
    Broadcast,
    Delivery,
    Notice,
    Feedback,
    AppLication
  },
  data() {
    return {
      activeIndex: '1',
      currentRole: 'Rotation',
      navShow: true
    }
  },
  created() {
    //判断没有状态值默认为1
    this.activeIndex = sessionStorage.getItem('activeIndex')
    if (this.activeIndex === null || this.activeIndex === undefined) {
      this.activeIndex = '1'
    }
  },
  mounted() {
    this.getNavList(this.activeIndex)
  },
  methods: {
    getNavList: function(key) {
      switch (key) {
        case '1':
          this.currentRole = 'Rotation'
          break
        case '2':
          this.currentRole = 'Knowledge'
          break
        case '3':
          this.currentRole = 'Notice'
          break
        case '4':
          this.currentRole = 'Broadcast'
          break
        case '5':
          this.currentRole = 'Feedback'
          break
        case '6':
          this.currentRole = 'Delivery'
          break
        case '7':
          this.currentRole = 'AppLication'
          break
      }
      sessionStorage.setItem('activeIndex', key)
    },

    //接受子组件传参改变父组件状态
    changeParent(data) {
      this.navShow = data.show //导航条显示与隐藏
      this.activeIndex = data.arrInt //定位所在模块
    },
    // 页面跳转
    handleSelect(key) {
      this.getNavList(key)
    }
  }
}
</script>

<style scoped lang="scss">
.information{
  width: 100%;
  min-height: 650px;
  background: #fff;
  .information-nav{
    padding-top: 20px;
    width: 85%;
    margin: 0 auto;
    margin-bottom: 20px;
    .nav-menu{
      li{
        font-size: 14px;
      }
    }
  }

  .information-content{
    width: 100%;
    padding-bottom: 30px;
    /*border: 1px solid red;*/
  }
}
</style>
