<template>
  <div class="feedback">
    <div class="feedback-title">
      <div>
        <span @click="downloadClick">
          <img
            src="@/assets/svg/download.svg"
            style="margin-right: 8px;"
            alt />全部下载
        </span>
        <a
          v-show="false"
          ref="transportDownloadLink"
          class="download"
          href="#"
          download=""></a>
      </div>
      <div></div>
      <div></div>
    </div>
    <lui-table
      v-loading="listLoading"
      :data="tableData"
      style="width: 85%;margin: 0 auto ">
      <template slot="empty">
        <showEmptyImage></showEmptyImage>
      </template>
      <lui-table-column
        prop="id"
        label="ID"
        width="80"
        show-overflow-tooltip>
      </lui-table-column>
      <lui-table-column
        prop="pin"
        show-overflow-tooltip
        label="用户PIN">
      </lui-table-column>
      <lui-table-column
        show-overflow-tooltip
        prop="location"
        label="反馈位置">
      </lui-table-column>
      <lui-table-column
        prop="updateUser"
        width="110"
        label="联系人"
        show-overflow-tooltip>
      </lui-table-column>
      <lui-table-column
        prop="phone"
        width="130"
        label="联系电话"
        show-overflow-tooltip>
      </lui-table-column>
      <lui-table-column
        prop="email"
        label="联系邮箱"
        show-overflow-tooltip>
      </lui-table-column>
      <lui-table-column
        prop="content"
        label="反馈内容"
        show-overflow-tooltip>
      </lui-table-column>
      <lui-table-column
        prop="updateTime"
        width="170"
        label="修改时间"
        show-overflow-tooltip>
      </lui-table-column>
    </lui-table>
    <div v-show="totals>10" class="feedback-pagination">
      <lui-pagination
        background
        :current-page.sync="pageNum"
        layout="prev, pager, next, sizes, jumper"
        :total="totals"
        @size-change="sizeChange"
        @current-change="handleSizeChange"
      ></lui-pagination>
    </div>
  </div>
</template>

<script>
import http from '@/lib/http'
import utils from '@/utils/utils'
import { exportExcel } from '@/utils/downloadRequest'
import Api from '@/api'
import showEmptyImage from '@/components/common/showEmptyImage/index.vue'
export default {
  name: 'index',
  components: {
    showEmptyImage
  },
  data() {
    return {
      baseURL: http.baseContextUrl,
      listLoading: true,
      tableData: [],
      activeIndex: '5',
      pageSize: 10,
      pageNum: 1,
      totals: 0
    }
  },
  mounted() {
    this.getList()
  },
  methods: {
    //分页条数改变
    sizeChange(val) {
      this.pageSize = val
      this.getList()
    },
    getList() {
      this.listLoading = true
      Api.BackStageFeedback.feedbackList({
        pageSize: this.pageSize,
        pageNum: this.pageNum
      }).then(row => {
        if (row.success && row.data) {
          for (let i = 0; i < row.data.length; i++) {
            row.data[i].location = row.data[i].location ? utils.htmlDecode(row.data[i].location) : ''
            row.data[i].content = row.data[i].content ? utils.htmlDecode(row.data[i].content) : ''
          }
          this.tableData = row.data
          this.totals = row.total
          this.listLoading = false
        }
      }).catch((e) => { this.$showErrorMsg(e) })
    },
    //翻页-----根据页码变换
    handleSizeChange(val) {
      this.pageNum = val
      this.getList()
    },
    downloadClick() { //excel下载

      const actionurl = this.baseURL + Api.BackStageFeedback.feedbackDownloadNew
      exportExcel(actionurl)
    }
  }
}
</script>

<style scoped lang="scss" rel="stylesheet/scss">
@import "@/assets/stylus/main.scss";
.feedback{
  background: #fff;
  min-height: 600px;
  width: 100%;
  padding-bottom: 26px;
  //padding-top: 20px;
  .information-nav{
    width: 85%;
    margin: 0 auto;
    margin-bottom: 20px;
    .nav-menu{
      li{
        font-size: 14px;
      }
    }
  }
  .feedback-title{
    width: 85%;
    height: 40px;
    margin: 0 auto;
    display: flex;
    justify-content: space-between;
    justify-items: center;
    div{
      font-size: 16px;
      span:nth-child(1){
        font-size: 12px;
        cursor: pointer;
        display: inline-block;
        width: 120px;
        height: 30px;
        border: 1px solid #e9e9e9;
        border-radius: 3px;
        color: #434343;
        line-height: 30px;
        text-align: center;
        i{
          font-size: 12px;
          padding-right: 5px;
        }
      }
    }
  }
  .feedback-pagination{
    width: 100%;
    margin-top: 73px;
    text-align: center;
  }

  .table-p{
    overflow: hidden;
    text-overflow:ellipsis;
    white-space: nowrap;
    cursor: pointer;
    padding-right: 15px;
  }
}
</style>
