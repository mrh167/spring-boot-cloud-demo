<template>
  <div class="knowledge">
    <div v-if="noticeCont">
      <div class="knowledge-title">
        <div>
          <span @click="draftsClick">
            <i class="lui-icon-document-empty"></i>草稿箱
          </span>
        </div>
        <div></div>
        <div></div>
      </div>
      <div class="rotation-add">
        <div
          class="add-button"
          @click="addClick">
          <span class="lui-icon-plus"></span>
          <span>新增应用</span>
        </div>
      </div>
      <lui-table
        ref="table"
        v-loading="LoadingOne"
        :data="tableData"
        style="width: 85%;margin: 0 auto"
      >
        <template slot="empty">
          <showEmptyImage></showEmptyImage>
        </template>
        <lui-table-column
          prop="number"
          label="应用ID"
          width="150"
          show-overflow-tooltip>
        </lui-table-column>
        <lui-table-column
          prop="name"
          label="应用名称"
          show-overflow-tooltip>
        </lui-table-column>
        <lui-table-column
          width="120"
          label="应用图标">
          <template slot-scope="{row}">
            <div
              v-if="row.icon!=null"
              v-viewer
              class="images">
              <lui-tooltip
                class="item"
                effect="dark"
                content="点击预览"
                placement="bottom">
                <img
                  :src="row.icon"
                  style="width: 40px;height: 40px;object-fit: cover;cursor: pointer" />
              </lui-tooltip>
            </div>
          </template>
        </lui-table-column>

        <lui-table-column
          width="120"
          label="是否显示">
          <template slot-scope="{row}">
            <lui-switch
              v-model="row.enabled"
              active-circle-class="1"
              active-color="rgba(60,110,240,.2)"
              inactive-color="rgba(142,145,152,.2)"
              @change="switchClick(row)">
            </lui-switch>
          </template>
        </lui-table-column>

        <lui-table-column
          width="180"
          label="操作时间"
          prop="updateTime"
          show-overflow-tooltip>
        </lui-table-column>

        <lui-table-column
          prop="updateUser"
          label="操作人"
          show-overflow-tooltip
          width="120">
        </lui-table-column>

        <lui-table-column
          width="270"
          label="操作">
          <template slot-scope="{row}">
            <lui-button type="text" @click="topClick(row)">置顶</lui-button>
            <lui-button type="text" @click="getDetails(row)">产品介绍</lui-button>
            <lui-button type="text" @click="toogleExpand(row)">产品详情</lui-button>
            <lui-button type="text" @click="editClick(row)">编辑</lui-button>
            <lui-button type="text" @click="delClick(row)">删除</lui-button>
          </template>
        </lui-table-column>
      </lui-table>
      <div v-show="totals>10" class="knowledge-pagination">
        <lui-pagination
          background
          :current-page.sync="pageNum"
          :page-sizes="[10, 20, 50, 70, 100]"
          layout="prev, pager, next, sizes, jumper"
          :total="totals"
          @current-change="handleSizeChange"
          @size-change="sizeChange"
        >
        </lui-pagination>
      </div>
    </div>

    <!--    新增编辑模块-->
    <AddApplication v-if="addShow" :header-user-name="headerUserName" @event1="change($event)"></AddApplication>

    <!--    草稿箱-->
    <Drafts v-if="draftShow" @eventDrafts="draftsChange($event)"></Drafts>
    <!--    详情-->
    <lui-dialog
      :visible.sync="centerDialogVisible"
      width="50%"
      top="10vh"
      :close-on-click-modal="false"
      custom-class="dialog_mask"
      title="目录详情">
      <lui-form
        ref="ruleForm"
        label-width="150px"
        class="demo-ruleForm">
        <lui-row
          :gutter="20"
          class="scrollBar"
          style="width: 95%;height: 500px;overflow-y: auto;margin-left: 5%;padding-right: 5%;">
          <div
            class="dialog-title">{{ ruleForm.title }}</div>
          <div
            class="dialog-time"
            style="font-size: 13px;color: #999;margin-top: 10px;">{{ ruleForm.time }}</div>
          <div
            v-dompurify-html="ruleForm.content"
            class="dialog-content"
            style="margin-top: 10px"></div>
        </lui-row>
      </lui-form>
    </lui-dialog>
  </div>
</template>

<script>
import Api from '@/api'
import utils from '@/utils/utils'
import showEmptyImage from '@/components/common/showEmptyImage/index.vue'
import AddApplication from './appLicationAdd.vue'
import Drafts from './appLicationDrafts.vue'
export default {
  name: 'index',
  components: {
    showEmptyImage,
    AddApplication,
    Drafts
  },
  data() {
    return {
      noticeCont: true,
      headerUserName: null,
      draftShow: false,
      addShow: false,
      LoadingOne: false,
      activeIndex: '7',
      centerDialogVisible: false,
      totals: 0,
      pageNum: 1, //页
      pageSize: 10, //条数
      tableData: [], //数据
      ruleForm: {
        title: '',
        time: '',
        content: ''
      }
    }
  },
  mounted() {
    // 一级列表获取
    this.getList()
  },
  methods: {
    //接收草稿箱传参
    draftsChange(data) {
      if (!data) {
        this.noticeCont = true
        this.draftShow = false
        const params = { //传参给上级父组件
          show: true,
          arrInt: '7'
        }
        this.$emit('event1', params)
        this.getList()
      }
    },
    //接受子组建参数改变状态
    change(data) {
      if (!data) {
        this.noticeCont = true
        this.addShow = false
        const params = { //传参给上级父组件
          show: true,
          arrInt: '7'
        }
        this.$emit('event1', params)
        this.getList()
      }
    },
    //草稿箱跳转
    draftsClick() {
      // this.$router.push({ 'path': '/information/addApplication/drafts' })
      this.$emit('event1', false)
      this.draftShow = true
      this.noticeCont = false
    },
    // 产品介绍查看页面
    getDetails() { //数据查看
      this.$router.push({ 'path': '/application' })
    },

    //产品详情查看页
    toogleExpand(row) {
      this.$router.push({ 'path': '/application', query: { id: row.id }})
    },

    //添加
    addClick() { //添加
      // this.$router.push({ 'path': '/information/addApplication' })
      this.headerUserName = null
      this.$emit('event1', false)
      this.addShow = true
      this.noticeCont = false
    },
    editClick(row) { //修改
      // this.$router.push({ 'path': '/information/addApplication', query: { id: row.id }})
      this.headerUserName = row.id
      this.$emit('event1', false)
      this.addShow = true
      this.noticeCont = false
    },
    //是否显示
    switchClick(row) {
      Api.BackStageAppContent.appCenterSetIfShow({
        id: row.id,
        enabled: row.enabled ? 1 : 0
      }).then(() => {
        this.$showSuccessMsg('设置成功')
        this.LoadingOne = false
      }).catch((e) => {
        this.$showErrorMsg(e)
        this.LoadingOne = true
        this.getList()
      })
    },
    //置顶
    topClick(row) {
      Api.BackStageAppContent.appCenterEditTop({
        id: row.id,
        topFlag: 1
      }).then(row => {
        if (row.success) {
          this.$showSuccessMsg('置顶成功')
          this.getList()
        } else {
          this.$showErrorMsg(row.errMessage)
        }
      }).catch((e) => { this.$showErrorMsg(e) })
    },
    // 列表获取
    getList() {
      this.LoadingOne = true //数据加载动画
      Api.BackStageAppContent.appCenterList({
        pageNum: this.pageNum, //页
        pageSize: this.pageSize, //条数
        stage: 1
      }).then(row => {
        if (row.success) {
          for (let i = 0; i < row.data.length; i++) {
            row.data[i].number = utils.htmlDecode(row.data[i].number)
            row.data[i].name = utils.htmlDecode(row.data[i].name)
            if (row.data[i].enabled === 0) {
              row.data[i].enabled = false
            } else {
              row.data[i].enabled = true
            }
          }
          this.tableData = row.data
          this.totals = row.total
          this.LoadingOne = false
        }
      }).catch((e) => { this.$showErrorMsg(e) })
    },
    //删除
    delClick(row) {
      this.$alert('<p style="font-size: 18px;color:#333">确认删除此条应用吗?</p><p style="font-size: 13px;color: #666">删除后，应用的相关内容信息将无法恢复</p>', '', {
        dangerouslyUseHTMLString: true,
        type: 'warning',
        center: true
      }).then(() => {
        Api.BackStageAppContent.appCenterDelete({ id: row.id }).then(() => {
          this.$showSuccessMsg('删除成功')
          this.getList()
        }).catch((e) => { this.$showErrorMsg(e) })
      })
    },
    //分页条数改变
    sizeChange(val) {
      this.pageSize = val
      this.getList()
    },
    //翻页-----根据页码变换
    handleSizeChange(val) {
      this.pageNum = val
      this.getList()
    }
  }
}
</script>

<style scoped lang="scss" rel="stylesheet/scss">
@import "@/assets/stylus/main.scss";
.knowledge {
    background: #fff;
    width: 100%;
    min-height: 600px;
    padding-bottom: 26px;
    //padding-top: 20px;
    position: relative;
    .rotation-add{
        width: 85%;
        height: 50px;
        position: absolute;
        top: 88px;
        left: 7.5%;
        z-index: 1;
        .add-button{
            background: #fff;
            width: 100%;
            height: 50px;
            display: flex;
            cursor: pointer;
            justify-content: center;
            align-items: center;
            border: 1px dashed #c2c2c2;
            span{
                display: inline-block;
                height: 20px;
                line-height: 20px;
                font-size: 14px;
                color: #333;
            }
            span:nth-child(1){
                font-size: 12px;
                color: $--gl-blue;
                line-height: 18px;
                margin-right: 6px;
            }
        }
        .add-button:hover{
            background: #e7f0f6;
            border: 1px dashed $--gl-blue;
            span{
                display: inline-block;
                height: 20px;
                line-height: 20px;
                font-size: 14px;
                color: $--gl-blue;
            }
            span:nth-child(1){
                font-size: 12px;
                color: $--gl-blue;
                line-height: 18px;
                margin-right: 6px;
            }
        }
    }
    .information-nav {
        width: 85%;
        margin: 0 auto;
        margin-bottom: 20px;
        .nav-menu {
            li {
                font-size: 14px;
            }
        }
    }
    .knowledge-title {
        width: 85%;
        height: 40px;
        margin: 0 auto;
        display: flex;
        justify-content: space-between;
        justify-items: center;
        div {
            font-size: 16px;
            span:nth-child(1) {
                font-size: 12px;
                cursor: pointer;
                display: inline-block;
                width: 120px;
                height: 30px;
                border: 1px solid #e9e9e9;
                border-radius: 3px;
                color: #434343;
                line-height: 30px;
                text-align: center;
                i {
                    font-size: 12px;
                    padding-right: 5px;
                }
            }
        }
    }
    .knowledge-pagination {
        width: 100%;
        margin-top: 73px;
        text-align: center;
    }
    .table-p {
        //display: inline-block;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        cursor: pointer;
        padding-right: 15px;
        //border: 1px solid red;/**/
    }
    .img{
        width: 40px;
        height: 40px;
        img{
            width: 40px;
            height: 40px;
            object-fit: cover;
        }
    }
    .knowledge-caozuo {
        display: flex;
        justify-content: space-between;
        align-items: center;
        cursor: pointer;
    }
}
.dialog-title{
    cursor: pointer;
    font-size: 20px;
    color: #333;
    font-weight: 500;
    &:hover{
        color: $--gl-blue;
    }
}

/deep/ .lui-table__body{
    margin-top: 50px;
}
.knowledge .rotation-add-two {
    width: 100%;
    height: 50px;
    position: absolute;
    top: 48px;
    /* left: 10%; */
    z-index: 1;
    .add-button{
        background: #fff;
        width: 100%;
        height: 50px;
        display: flex;
        cursor: pointer;
        justify-content: center;
        align-items: center;
        border: 1px dashed #c2c2c2;
        span{
            display: inline-block;
            height: 20px;
            line-height: 20px;
            font-size: 14px;
            color: #333;
        }
        span:nth-child(1){
            font-size: 12px;
            color: $--gl-blue;
            line-height: 18px;
            margin-right: 6px;
        }
    }
    .add-button:hover{
        background: #e7f0f6;
        border: 1px dashed $--gl-blue;
        span{
            display: inline-block;
            height: 20px;
            line-height: 20px;
            font-size: 14px;
            color: $--gl-blue;
        }
        span:nth-child(1){
            font-size: 12px;
            color: $--gl-blue;
            line-height: 18px;
            margin-right: 6px;
        }
    }
}
.knowledge .knowledge-pagination-two{
    width: 100%;
    margin-top: 30px;
    text-align: center;
}
/deep/ .lui-table__expanded-cell[class*=cell] {
     padding: 20px 0;
}

</style>
