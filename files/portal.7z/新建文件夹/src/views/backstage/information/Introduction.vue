<template>
  <div class="Intro">
    <div v-loading="LoadingOne" class="Intro-container">
      <lui-button size="mini" style="margin-bottom:20px" @click="sendMessage">返回</lui-button>
      <div class="container-title">
        <div class="title-left">
          <img :src="dataCont.icon" alt="">
        </div>
        <div class="title-right">
          <h2>{{ dataCont.name }}</h2>
          <p>{{ dataCont.introduce }}</p>
          <button @click="purchase(dataCont)">去购买</button>
        </div>
      </div>
      <div class="container-content">
        <div class="information-nav">
          <lui-menu
            :default-active="activeIndex"
            class="lui-menu-demo nav-menu"
            mode="horizontal"
            @select="handleSelect">
            <lui-menu-item index="1">产品详情</lui-menu-item>
            <lui-menu-item index="2">使用教程</lui-menu-item>
            <lui-menu-item index="3">用户评价</lui-menu-item>
          </lui-menu>
          <div class="line"></div>
        </div>
        <div v-show="details" v-dompurify-html="dataCont.detailsJsf" class="content-details"></div>
        <div v-show="Intro" v-dompurify-html="dataCont.courseJsf" class="contetn-Intro"></div>
        <div v-show="EvaluaJsf" v-dompurify-html="dataCont.userEvaluateJsf" class="contetn-Intro"></div>
      </div>
    </div>
  </div>
</template>

<script>
import Api from '@/api'
import utils from '@/utils/utils'
export default {
  name: 'index',
  props: {
    ids: {
      type: Number,
      default: 0
    }
  },
  data() {
    return {
      activeIndex: '1',
      LoadingOne: false,
      details: true,
      Intro: false,
      EvaluaJsf: false,
      dataCont: ''
    }
  },
  mounted() {
    this.getList()
  },
  methods: {
    sendMessage() {
      this.$emit('sendMessage')
    },
    //去购买
    purchase(item) {
      window.open(item.url, '_blank')
    },
    //数据获取
    getList() {
      this.LoadingOne = true //数据加载动画
      Api.BackStageAppContent.UserAppCenterGet({ id: this.ids }).then(row => {
        if (row.success) {
          row.data.name = utils.htmlDecode(row.data.name)
          row.data.number = utils.htmlDecode(row.data.number)
          row.data.introduce = utils.htmlDecode(row.data.introduce)
          row.data.detailsJsf = utils.htmlDecode(row.data.detailsJsf)
          row.data.courseJsf = utils.htmlDecode(row.data.courseJsf)
          row.data.userEvaluateJsf = utils.htmlDecode(row.data.userEvaluateJsf)
          this.dataCont = row.data
          this.LoadingOne = false //数据加载动画
        }
      }).catch((e) => { this.$showErrorMsg(e) })
    },

    handleSelect(key, keyPath) {
      switch (key) {
        case '1':
          this.details = true
          this.Intro = false
          this.EvaluaJsf = false
          break
        case '2':
          this.EvaluaJsf = false
          this.details = false
          this.Intro = true
          break
        case '3':
          this.EvaluaJsf = true
          this.details = false
          this.Intro = false
          break
      }
    }
  }




}
</script>

<style scoped lang="scss">
@import "@/assets/stylus/main.scss";
  .Intro{
    width: 100%;
    min-height: 600px;
    background: #fff;
    padding: 30px 0;
    .Intro-container{
      width: 85%;
      margin: 0 auto;
      .container-title{
        width: 100%;
        height: 120px;
        display: flex;
        .title-left{
          width: 120px;
          height: 120px;
          border-radius: 4px;
          overflow: hidden;
          img{
            width: 120px;
            height: 120px;
            object-fit: cover;
          }
        }
        .title-right{
          width: calc(100% - 120px);
          margin-left: 15px;
          h2{
            font-size: 24px;
            color: #333333;
            margin-top: 5px;
          }
          p{
            width: 100%;
            font-size: 14px;
            color: #666666;
            text-align: left;
            line-height: 26px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
          }
          button{
            width: 180px;
            height: 40px;
            background-image: linear-gradient(270deg, $--gl-hoverBlue 0%,  $--gl-blue 100%);
            border-radius: 4px;
            border: none;
            outline: none;
            margin-top: 10px;
            font-size: 14px;
            color: #fff;
            cursor: pointer;
          }
        }
      }
      .container-content{
        width: 100%;
        margin-top: 30px;
        padding-bottom: 60px;
        .information-nav {
          margin-bottom: 20px;
          .nav-menu {
            li {
              height: 35px;
              line-height: 30px;
            }
          }
        }
        .content-details{
          width: 100%;
        }
        .contetn-Intro{
          width: 100%;
        }
      }
    }
  }
</style>
