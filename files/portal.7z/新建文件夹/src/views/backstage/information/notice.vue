<template>
  <div class="notice">

    <div v-if="noticeCont" class="notice-content">
      <div class="knowledge-title">
        <div>
          <span @click="draftsClick">
            <i class="lui-icon-document-empty"></i>草稿箱
          </span>
        </div>
        <div></div>
        <div></div>
      </div>

      <div class="notice-add">
        <div
          class="add-button"
          @click="handleAddClick">
          <span class="lui-icon-plus"></span>
          <span>新建公告</span>
        </div>
      </div>
      <lui-table
        v-loading="listLoading"
        :data="tableData"
        class="notice-table"
        style="width: 85%;margin: 0 auto;">
        <template slot="empty">
          <showEmptyImage></showEmptyImage>
        </template>
        <lui-table-column
          prop="id"
          label="ID"
          width="90"
          show-overflow-tooltip>
        </lui-table-column>

        <lui-table-column
          prop="title"
          label="公告标题"
          show-overflow-tooltip>
        </lui-table-column>
        <lui-table-column
          prop="text"
          label="公告正文">
          <template slot-scope="{row}">
            <p class="table-p">{{ row.text }}</p>
          </template>
        </lui-table-column>

        <lui-table-column
          prop="noticeUrl"
          show-overflow-tooltip
          label="公告链接">
        </lui-table-column>


        <lui-table-column
          prop="position"
          width="100"
          show-overflow-tooltip
          label="公告位置">
          <template v-slot="{row}">
            <p v-if="row.position===1" class="table-p">官网</p>
            <p v-else class="table-p">产品首页</p>
          </template>
        </lui-table-column>

        <lui-table-column
          width="80"
          prop="showFlag"
          label="是否显示">
          <template slot-scope="scope">
            <lui-switch
              v-model="scope.row.showFlag"
              active-circle-class="1"
              active-color="rgba(60,110,240,.2)"
              inactive-color="rgba(142,145,152,.2)"
              @change="setIfShowClick(scope.row)">
            </lui-switch>
          </template>
        </lui-table-column>

        <lui-table-column
          width="80"
          label="是否置顶">
          <template slot-scope="{row}">
            <lui-switch
              v-model="row.topFlag"
              active-circle-class="1"
              active-color="rgba(60,110,240,.2)"
              inactive-color="rgba(142,145,152,.2)"
              @change="placementClick(row)">
            </lui-switch>
          </template>
        </lui-table-column>

        <lui-table-column
          prop="releaseTime"
          width="170"
          label="修改时间"
          show-overflow-tooltip>
        </lui-table-column>

        <lui-table-column
          prop="updateUser"
          width="100"
          label="操作人"
          show-overflow-tooltip>
        </lui-table-column>

        <lui-table-column
          prop="date"
          width="135"
          label="操作">
          <template slot-scope="{row}">
            <lui-button type="text" @click="getClik(row)">查看</lui-button>
            <lui-button type="text" @click="editClick(row)">编辑</lui-button>
            <lui-button type="text" @click="deleteClick(row)">删除</lui-button>
          </template>
        </lui-table-column>
      </lui-table>
      <div v-show="totals>10" class="notice-pagination">
        <lui-pagination
          background
          :current-page.sync="pageNum"
          layout="prev, pager, next, sizes, jumper"
          :total="totals"
          @size-change="sizeChange"
          @current-change="handleSizeChange"
        ></lui-pagination>
      </div>
    </div>

    <!--    新增编辑模块-->
    <AddNotice v-if="addShow" :header-user-name="headerUserName" @event1="changeAdd($event)"></AddNotice>

    <!--    草稿箱-->
    <Drafts v-if="draftShow" @eventDrafts="draftsChange($event)"></Drafts>
    <!--    详情-->
    <lui-dialog
      :visible.sync="centerDialogVisible"
      width="60%"
      top="10vh"
      :close-on-click-modal="false"
      :lock-scroll="false"
      :append-to-body="true"
      custom-class="dialog_mask"
      title="公告详情">
      <lui-form
        ref="ruleForm"
        label-width="150px"
        class="demo-ruleForm">
        <lui-row
          :gutter="20"
          class="scrollBar"
          style="width: 95%;height: 500px;overflow-y: auto;margin-left: 5%;padding-right: 5%;">
          <div class="dialog-title">{{ ruleForm.title }}</div>
          <div
            class="dialog-time"
            style="font-size: 13px;color: #999;margin-top: 10px;">{{ ruleForm.time }}</div>
          <div
            v-dompurify-html="ruleForm.content"
            class="dialog-content"
            style="margin-top: 10px;"></div>
        </lui-row>
      </lui-form>
    </lui-dialog>
  </div>
</template>

<script>
import Api from '@/api'
import utils from '@/utils/utils'
import showEmptyImage from '@/components/common/showEmptyImage/index.vue'
import AddNotice from './noticeAdd'
import Drafts from './noticeDrafts'
export default {
  name: 'index',
  components: {
    showEmptyImage,
    AddNotice,
    Drafts
  },
  data() {
    return {
      headerUserName: null,
      draftShow: false,
      addShow: false,
      noticeCont: true,
      activeIndex: '3',
      value1: true,
      dialogTableVisible: false,
      dialogFormVisible: false,
      pageSize: 10,
      pageNum: 1,
      totals: 0,
      listLoading: true,
      dataText: '',
      centerDialogVisible: false,
      tableData: [],
      ruleForm: {
        title: '',
        time: '',
        content: ''
      }
    }
  },
  mounted() {
    this.GetList()
  },
  methods: {
    //接收草稿箱传参
    draftsChange(data) {
      if (!data) {
        this.noticeCont = true
        this.draftShow = false
        const params = { //传参给上级父组件
          show: true,
          arrInt: '3'
        }
        this.$emit('event1', params)
        this.GetList()
      }
    },
    //接收新增编辑子组建参数改变状态
    changeAdd(data) {
      if (!data) {
        this.noticeCont = true
        this.addShow = false
        const params = { //传参给上级父组件
          show: true,
          arrInt: '3'
        }
        this.$emit('event1', params)
        this.GetList()
      }
    },
    draftsClick() { //进入草稿箱
      this.$emit('event1', false)
      this.draftShow = true
      this.noticeCont = false
    },
    // 数据是否显示
    setIfShowClick(row) {
      Api.BackStageNotice.manageNoticeSetIfShow({
        id: row.id,
        showFlag: row.showFlag ? 1 : 0
      }).then(() => {
        this.$showSuccessMsg('设置成功')
      }).catch((e) => {
        this.$showErrorMsg(e)
        this.listLoading = true
        this.GetList()
      })
    },
    //是否置顶
    placementClick(row) {
      Api.BackStageNotice.manageNoticePlacement({
        id: row.id,
        topFlag: row.topFlag ? 1 : 0
      }).then(() => {
        this.$showSuccessMsg('设置成功')
      }).catch((e) => {
        row.topFlag = false
        this.$showErrorMsg(e)
      })
    },
    //数据查看
    getClik(row) {
      this.listLoading = true
      this.ruleForm = {
        title: '',
        time: '',
        content: ''
      }
      Api.BackStageNotice.manageInfoById({ id: row.id }).then(rows => {
        if (rows.success) {
          const cont = rows.data.content ? utils.htmlDecode(rows.data.content) : ''
          this.ruleForm.title = rows.data.title ? utils.htmlDecode(rows.data.title) : ''
          this.ruleForm.time = rows.data.updateTime ? rows.data.updateTime : ''
          this.ruleForm.content = cont
          this.centerDialogVisible = true
          this.listLoading = false
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
        this.listLoading = false
      })
      //  待定页面
    },
    //数据编辑
    editClick(row) {
      // this.$router.push({ path: '/information/notice/AddNotice', query: { id: row.id }})
      this.headerUserName = row.id
      this.$emit('event1', false)
      this.addShow = true
      this.noticeCont = false
    },
    //删除数据
    deleteClick(row) {
      this.$alert('<p style="font-size: 18px;color:#333">确认删除此条公告吗?</p><p style="font-size: 13px;color: #666">删除后，公告的相关内容信息将无法恢复</p>', '', {
        dangerouslyUseHTMLString: true,
        type: 'warning',
        center: true
      }).then(() => {
        Api.BackStageNotice.manageNoticeDel({ id: row.id }).then(row => {
          if (row.success) {
            this.$message({
              message: '删除成功',
              type: 'success'
            })
            this.GetList()
          }
        }).catch((e) => {
          this.$showErrorMsg(e)
        })
      })
    },
    //分页条数改变
    sizeChange(val) {
      this.pageSize = val
      this.GetList()
    },
    //翻页-----根据页码变换
    handleSizeChange(val) {
      this.pageNum = val
      this.GetList()
    },
    //公告列表
    GetList() {
      this.listLoading = true
      Api.BackStageNotice.manageNoticeList({
        pageNum: this.pageNum,
        pageSize: this.pageSize,
        stageFlag: 1
      }).then(response => {
        if (response.success) {
          for (let i = 0; i < response.data.length; i++) {
            response.data[i].title = utils.htmlDecode(response.data[i].title)
            response.data[i].text = utils.htmlDecode(response.data[i].text)
            if (response.data[i].showFlag === 0) {
              response.data[i].showFlag = false
            } else {
              response.data[i].showFlag = true
            }
            if (response.data[i].topFlag === 0) {
              response.data[i].topFlag = false
            } else {
              response.data[i].topFlag = true
            }
          }
          this.tableData = response.data
          this.totals = response.total
          this.listLoading = false
        }
      }).catch(e => {
        this.$showErrorMsg(e)
      })
    },
    //新增公告
    handleAddClick() {
      this.headerUserName = null
      this.$emit('event1', false)
      this.addShow = true
      this.noticeCont = false
    }
  }
}
</script>

<style scoped lang="scss" rel="stylesheet/scss">
@import "@/assets/stylus/main.scss";
.notice{
  background: #fff;
  width: 100%;
  min-height: 600px;
  padding-bottom: 26px;
  //padding-top: 20px;
  position: relative;
  .information-nav{
    width: 85%;
    margin: 0 auto;
    margin-bottom: 20px;
    .nav-menu{
      li{
        font-size: 14px;
      }
    }
  }

  .knowledge-title {
    width: 85%;
    height: 40px;
    margin: 0 auto;
    display: flex;
    justify-content: space-between;
    justify-items: center;
    div {
      font-size: 16px;
      span:nth-child(1) {
        font-size: 12px;
        cursor: pointer;
        display: inline-block;
        width: 120px;
        height: 30px;
        border: 1px solid #e9e9e9;
        border-radius: 3px;
        color: #434343;
        line-height: 30px;
        text-align: center;
        i {
          font-size: 12px;
          padding-right: 5px;
        }
      }
    }
  }
  .notice-add{
    width: 85%;
    height: 50px;
    position: absolute;
    top: 89px;
    left: 7.5%;
    z-index: 1;
    .add-button{
      background: #fff;
      width: 99.8%;
      height: 50px;
      display: flex;
      cursor: pointer;
      justify-content: center;
      align-items: center;
      border: 1px dashed #c2c2c2;
      box-sizing: border-box;
      span{
        display: inline-block;
        height: 20px;
        line-height: 20px;
        font-size: 14px;
        color: #333;
      }
      span:nth-child(1){
        font-size: 12px;
        color: $--gl-blue;
        line-height: 18px;
        margin-right: 6px;
      }
    }
    .add-button:hover{
      background: #e7f0f6;
      border: 1px dashed $--gl-blue;
      span{
        display: inline-block;
        height: 20px;
        line-height: 20px;
        font-size: 14px;
        color: $--gl-blue;
      }
      span:nth-child(1){
        font-size: 12px;
        color: $--gl-blue;
        line-height: 18px;
        margin-right: 6px;
      }
    }
  }
  .notice-pagination{
    width: 100%;
    margin-top: 73px;
    text-align: center;
  }
  .table-link{
    overflow: hidden;
    text-overflow:ellipsis;
    white-space: nowrap;
  }
  .table-p{
    overflow: hidden;
    text-overflow:ellipsis;
    white-space: nowrap;
    cursor: pointer;
    padding-right: 15px;
  }
  .table-icon{
    display: flex;
    justify-content: space-between;
    span{
      color: #1d76a8;
      cursor: pointer;
    }
  }
  .link-hover{
    text-decoration:underline;
  }
  .dialog-img{
    width: 100%;
    height: 100%;
    overflow: hidden;
    img{
      width: 100%;
      height: 100%;
      object-fit: cover;
    }
  }
}
/deep/ .lui-table__body{
  margin-top: 50px;
}
.dialog-title{
  cursor: pointer;
  font-size: 20px;
  color: #333;
  font-weight: 500;
  &:hover{
    color: $--gl-blue;
  }
}


</style>
