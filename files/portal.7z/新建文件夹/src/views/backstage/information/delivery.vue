<template>
  <div class="delivery">
    <div class="delivery-add">
      <div
        class="add-button"
        @click="addClick">
        <span class="lui-icon-plus"></span>
        <span>精准投放</span>
      </div>
    </div>
    <lui-table
      v-loading="listLoading"
      :data="tableData"
      style="width: 85.5%;margin: 0 auto;">
      <template slot="empty">
        <showEmptyImage></showEmptyImage>
      </template>
      <lui-table-column
        prop="id"
        label="ID"
        width="70"
        show-overflow-tooltip>
      </lui-table-column>
      <lui-table-column
        prop="putExplain"
        show-overflow-tooltip
        label="投放说明">
      </lui-table-column>
      <lui-table-column
        prop="pinSumOfPackage"
        label="投放PIN包"
        width="95"
      >
        <template slot-scope="{row}">
          <p class="table-p" @click="downloadClick(row)"><img src="@/assets/svg/download.svg" alt="" style="margin-right: 10px;">下载</p>
        </template>
      </lui-table-column>
      <lui-table-column
        prop="putPreviewUrl"
        width="90"
        label="轮播预览">
        <template slot-scope="{row}">
          <div
            v-if="row.putPreviewUrl!=null"
            v-viewer
            class="images">
            <lui-tooltip
              class="item"
              effect="dark"
              content="点击预览"
              placement="bottom">
              <img
                :src="row.putPreviewUrl"
                style="width: 60px;height: 30px;object-fit: cover;cursor: pointer" />
            </lui-tooltip>
          </div>
        </template>
      </lui-table-column>
      <lui-table-column
        prop="alreadyPutPinSum"
        width="100"
        label="已投放利率">
        <template slot-scope="{row}">
          <p v-if="row.pinSumOfPackage==null || row.pinSumOfPackage==undefined || row.pinSumOfPackage==0" class="table-p">0%</p>
          <p v-else class="table-p">{{ ((row.alreadyPutPinSum!=null && row.alreadyPutPinSum!=undefined ) ? row.alreadyPutPinSum : 0) / row.pinSumOfPackage * 100 }}%</p>
        </template>
      </lui-table-column>
      <lui-table-column
        prop="jumpUrl"
        label="详情地址"
        show-overflow-tooltip>
      </lui-table-column>
      <lui-table-column
        prop="previewFileType"
        width="85"
        label="投放情况">
        <template slot-scope="{row}">
          <div style="cursor: pointer;" @click="getlook(row)">
            <span class="lui-icon-search"></span>
            <span style="padding-left: 10px;">查看</span>
          </div>
          <a v-show="false" ref="transportDownloadLook" class="download" href="#" download=""></a>
        </template>
      </lui-table-column>
      <lui-table-column
        prop="startTime"
        label="生效时段"
        show-overflow-tooltip>

      </lui-table-column>
      <lui-table-column
        prop="updateTime"
        label="修改时间"
        show-overflow-tooltip>
      </lui-table-column>
      <lui-table-column
        prop="updateUser"
        width="120"
        label="操作人"
        show-overflow-tooltip>
      </lui-table-column>
      <lui-table-column
        prop="date"
        width="95"
        label="操作">
        <template slot-scope="{row}">
          <lui-button type="text" @click="editClick(row)">编辑</lui-button>
          <lui-button type="text" @click="deleteClick(row)">删除</lui-button>
        </template>
      </lui-table-column>
    </lui-table>
    <div v-show="totals>10" class="delivery-pagination">
      <lui-pagination
        background
        :current-page.sync="pageNum"
        :page-sizes="[10, 20, 50, 70, 100]"
        layout="prev, pager, next, sizes, jumper"
        :total="totals"
        @size-change="sizeChange"
        @current-change="handleSizeChange"
      >
      </lui-pagination>
    </div>
    <!--  新增编辑弹窗-->
    <lui-dialog
      :visible.sync="centerDialogVisible"
      width="60%"
      top="10vh"
      :close-on-click-modal="false"
      custom-class="dialog_mask"
      title="精准投放配置">
      <lui-form
        ref="ruleForm"
        :model="ruleForm"
        :rules="rules"
        label-width="150px"
        class="demo-ruleForm">
        <lui-row :gutter="20">
          <lui-col :span="20">
            <lui-form-item
              label="投放说明"
              prop="putExplain">
              <lui-input
                v-model="ruleForm.putExplain"
                placeholder="请输入投放说明"></lui-input>
            </lui-form-item>
            <lui-form-item
              label="投放时间"
              prop="time">
              <lui-date-picker
                v-model="ruleForm.time"
                type="datetimerange"
                range-separator="-"
                start-placeholder="开始日期"
                end-placeholder="结束日期"
                @change="dateChangebirthday">
              </lui-date-picker>
            </lui-form-item>
            <lui-form-item label="PIN包" prop="previewFileType">
              <lui-radio-group v-model="ruleForm.number" size="big">
                <!--<div class="type-dlown"><lui-button @click="downloadAddClick">下载模板</lui-button></div>-->
                <div class="type-dlown">
                  <div class="button">
                    <lui-button @click="downloadAddClick">下载模板</lui-button>
                  </div>
                  <div v-if="editShow!==true">
                    <div v-if="fileDate===''" class="buttonfile">
                      <lui-button>上传文件</lui-button>
                      <input type="file" multiple="multiple" name="file" @change="importData" />
                    </div>
                    <div v-else class="buttonfile">
                      <p><i class="lui-icon-document-copy" style="margin-right: 8px;"></i><span style="display: inline-block;width: 183px;">{{ fileDate }}</span><i class="lui-icon-error" @click="errorClick"></i></p>
                    </div>
                  </div>
                </div>
                <a v-show="false" ref="transportDownloadAddLink" class="download" href="#" download=""></a>
              </lui-radio-group>
            </lui-form-item>
            <lui-form-item label="投放内容" class="upload_imgs" prop="putPreviewUrl">
              <lui-upload
                class="avatar-uploader"
                :action="baseURL+'img/upload'"
                accept=".jpg,.png,.gif"
                :show-file-list="false"
                :on-success="handleAvatarSuccess"
                :before-upload="beforeAvatarUpload">
                <img v-if="ruleForm.putPreviewUrl" :src="ruleForm.putPreviewUrl" class="avatar">
                <div v-else slot="trigger" v-loading="loadingimg" class="add_contract">
                  <div class="contract_box">
                    <i class="lui-icon-plus avatar-uploader-icon"></i>
                  </div>
                </div>
              </lui-upload>
              <div v-if="ruleForm.putPreviewUrl" class="mask_background">
                <div class="mask_background_icon">
                  <lui-image
                    style="width: 20px; height: 20px"
                    :src="imgIcon"
                    :preview-src-list="srcList">
                  </lui-image>
                  <i class="lui-icon-delete" @click="deleteImg"></i>
                </div>
              </div>
            </lui-form-item>

            <lui-form-item
              label="跳转链接"
              prop="jumpUrl">
              <lui-input
                v-model.trim="ruleForm.jumpUrl"
                placeholder="请输入链接地址">
              </lui-input>
            </lui-form-item>
          </lui-col>
        </lui-row>
      </lui-form>
      <div
        slot="footer"
        class="dialog-footer"
        style="text-align: center">
        <lui-button @click="resetForm('ruleForm')">取 消</lui-button>
        <lui-button type="primary" style="background: $--gl-blue " :loading="loadingBut" @click="submitForm('ruleForm')">确 定</lui-button>
      </div>
    </lui-dialog>
  </div>
</template>

<script>
import http from '@/lib/http'
import Api from '@/api'
import utils from '@/utils/utils'
import axios from 'axios'
import { exportExcel } from '@/utils/downloadRequest'
import showEmptyImage from '@/components/common/showEmptyImage/index.vue'
import imgster from '@/assets/img/icon-looks.png'
export default {
  name: 'index',
  components: {
    showEmptyImage
  },
  data() {
    return {
      loadingimg: false,
      loadingBut: false,
      baseURL: http.baseContextUrl,
      imgIcon: imgster,
      srcList: [],
      fileDate: '',
      xslx: true,
      listLoading: true,
      fileList: [], //上传列表
      activeIndex: '6',
      value1: true,
      editShow: false, //true 编辑 false新增
      dialogTableVisible: false,
      dialogFormVisible: false,
      centerDialogVisible: false,
      pageSize: 10,
      pageNum: 1,
      totals: 0,
      dialogImageUrl: '',
      dialogVisible: false,
      disabled: false,
      hideUpload: false,
      limitCount: 1,
      ruleForm: {
        time: '', //结束时间
        pinPackage: '', //上传文件
        previewFileType: '', //文件类型
        putExplain: '', //投放说明
        putPreviewUrl: '', //投放内容
        startTime: '',
        endTime: '',
        jumpUrl: '' //跳转地址
      },
      rules: {
        time: [{ required: true, message: '请选择投放时间', trigger: 'blur' }],
        previewFileType: [{ required: false, message: '请上传文件类型', trigger: 'blur' }],
        putExplain: [{ required: false, message: '请输入投放说明', trigger: 'blur' }],
        putPreviewUrl: [{ required: true, message: '请上传投放内容', trigger: 'change' }],
        jumpUrl: [{ required: true, message: '请输入详情地址', trigger: 'blur' }]
      },
      tableData: []
    }
  },
  mounted() {
    this.getList()
  },
  methods: {
    //查看
    getlook(row) {
      const actionurl = this.baseURL + Api.BackStageDelivery.deliveryDownView
      const param = {}
      param.accuratePutId = row.id
      exportExcel(actionurl, param)
    },
    //投放包下载
    downloadClick(row) {
      const actionUrl = this.baseURL + Api.BackStageDelivery.deliveryDownloadPinPackage
      const param = {}
      param.accuratePutId = row.id
      exportExcel(actionUrl, param)
    },
    //新增下载
    downloadAddClick() {
      const actionUrl = this.baseURL + Api.BackStageDelivery.deliveryDownloadTemplate
      exportExcel(actionUrl)
    },
    //上传PIN包
    errorClick() {
      this.fileDate = ''
    },
    //导入模板
    importData(event) {
      const formData = new FormData()
      formData.append('file', event.target.files[0])
      this.fileDate = event.target.files[0].name
      this.ruleForm.pinPackage = event.target.files[0]
    },
    //点击条数出发
    sizeChange(val) {
      this.pageSize = val
      this.getList()
    },
    //时间格式转换
    dateChangebirthday(val) { //时间
      this.ruleForm.startTime = this.dateBlock(val[0])
      this.ruleForm.endTime = this.dateBlock(val[1])
    },
    //列表页
    getList() {
      this.listLoading = true
      Api.BackStageDelivery.deliveryListPage({
        pageSize: this.pageSize,
        pageNum: this.pageNum
      }).then(row => {
        if (row.success) {
          for (let i = 0; i < row.data.length; i++) {
            row.data[i].putExplain = utils.htmlDecode(row.data[i].putExplain)
          }
          this.tableData = row.data
          this.totals = row.total
          this.listLoading = false
        }
      }).catch((e) => { this.$showErrorMsg(e) })
    },
    //翻页-----根据页码变换
    handleSizeChange(val) {
      this.pageNum = val
      this.getList()
    },
    //编辑
    editClick(row) {
      this.editShow = true
      this.centerDialogVisible = true
      this.srcList.push(row.putPreviewUrl)
      this.ruleForm = {
        time: '',
        previewFileType: '', //文件类型
        putExplain: '', //投放说明
        putPreviewUrl: '', //投放内容
        startTime: '',
        endTime: '',
        id: '',
        jumpUrl: ''
      }
      //编辑数据回显
      this.ruleForm = {
        time: [row.startTime, row.endTime],
        previewFileType: row.previewFileType, //文件类型
        putExplain: row.putExplain, //投放说明
        putPreviewUrl: row.putPreviewUrl, //投放内容
        startTime: row.startTime,
        endTime: row.endTime,
        id: row.id,
        jumpUrl: row.jumpUrl
      }
    },
    //新增
    addClick() {
      this.fileDate = ''
      //当打开新增编辑窗口清空没有清掉的数据
      this.ruleForm = {
        time: '', //结束时间
        pinPackage: '', //上传文件
        previewFileType: '', //文件类型
        putExplain: '', //投放说明
        putPreviewUrl: '', //投放内容
        startTime: '',
        endTime: '',
        jumpUrl: ''
      }
      this.editShow = false
      this.centerDialogVisible = true
    },
    //新增保存
    submitForm(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          this.loadingBut = true
          if (this.editShow) { //编辑
            Api.BackStageDelivery.deliveryEdit({
              endTime: this.ruleForm.endTime,
              id: this.ruleForm.id,
              previewFileType: this.ruleForm.previewFileType,
              putExplain: this.ruleForm.putExplain,
              putPreviewUrl: this.ruleForm.putPreviewUrl,
              startTime: this.ruleForm.startTime,
              jumpUrl: this.ruleForm.jumpUrl
            }).then(row => {
              if (row.success) {
                this.centerDialogVisible = false
                this.editShow = false
                this.$refs[formName].resetFields()
                this.$showSuccessMsg('编辑成功')
                this.loadingBut = false
                this.getList()
              } else {
                this.loadingBut = false
              }
            }).catch((e) => {
              this.loadingBut = false
              this.$showErrorMsg(e)
            })
          } else { //新增
            const formData = new FormData()
            formData.append('endTime', this.ruleForm.endTime)
            formData.append('pinPackage', this.ruleForm.pinPackage)
            formData.append('previewFileType', this.ruleForm.previewFileType)
            formData.append('putExplain', this.ruleForm.putExplain)
            formData.append('putPreviewUrl', this.ruleForm.putPreviewUrl)
            formData.append('startTime', this.ruleForm.startTime)
            formData.append('jumpUrl', this.ruleForm.jumpUrl)
            const instance = axios.create({
              widthCredentials: true
            })
            instance.post('/manage/accuratePut/addAccuratePutWithPin', formData).then(res => {
              if (res.data.success) {
                this.$refs[formName].resetFields()
                this.centerDialogVisible = false
                this.$showSuccessMsg('新增成功')
                this.loadingBut = false
                this.getList()
              } else {
                this.loadingBut = false
                this.$showErrorMsg(res.data.errMessage)
              }
            }).catch((e) => {
              this.loadingBut = false
              this.$showErrorMsg(e)
            })
          }
        } else {
          return
        }
      })
    },
    //新建取消按钮
    resetForm(formName) {
      this.$refs[formName].resetFields()
      this.centerDialogVisible = false //关闭弹窗
      this.srcList = []
    },
    //删除
    deleteClick(row) {
      this.$alert('<p style="font-size: 18px;color:#333">确认删除此条投放吗?</p><p style="font-size: 13px;color: #666">删除后，精准投放的相关内容信息将无法恢复</p>', '', {
        dangerouslyUseHTMLString: true,
        type: 'warning',
        center: true
      }).then(() => {
        Api.BackStageDelivery.deliveryDel({
          ids: [row.id]
        }).then(row => {
          if (row.success) {
            this.$message({
              message: '删除成功',
              type: 'success'
            })
            this.getList()
          }
        }).catch((e) => { this.$showErrorMsg(e) })
      })
    },
    //图片上传开始==========》删除
    deleteImg() {
      this.ruleForm.putPreviewUrl = ''
      this.srcList = [] //清空图片预览
    },
    beforeAvatarUpload(file) {

      const isLt2M = file.size / 1024 / 1024 < 5
      if (!isLt2M) {
        this.$message.error('上传头像图片大小不能超过 5MB!')
        return isLt2M
      } else {
        this.loadingimg = true
        this.loadingBut = true
      }
    },
    handleAvatarSuccess(res, file) {
      this.ruleForm.previewFileType = file.raw.type
      this.loadingimg = false
      this.loadingBut = false
      this.imageUrl = URL.createObjectURL(file.raw)
      this.ruleForm.putPreviewUrl = res.data
      this.srcList.push(this.ruleForm.putPreviewUrl)
    },
    //图片上传结束
    dateBlock(row) {
      const daterc = row
      if (daterc != null) {
        const dateMat = new Date(daterc)
        const year = dateMat.getFullYear()
        let month = dateMat.getMonth() + 1
        let day = dateMat.getDate()
        let hh = dateMat.getHours()
        let mm = dateMat.getMinutes()
        let ss = dateMat.getSeconds()
        if (month < 10) month = '0' + month
        if (day < 10) day = '0' + day
        if (hh < 10) hh = '0' + hh
        if (mm < 10) mm = '0' + mm
        if (ss < 10) ss = '0' + ss
        const timeFormat = year + '-' + month + '-' + day + ' ' + hh + ':' + mm + ':' + ss
        return timeFormat
      }
    }
  }
}
</script>

<style scoped lang="scss" rel="stylesheet/scss">
@import "@/assets/stylus/main.scss";
.delivery{
  background: #fff;
  width: 100%;
  min-height: 600px;
  padding-bottom: 26px;
  //padding-top: 20px;
  position: relative;
  .information-nav{
    width: 85%;
    margin: 0 auto;
    margin-bottom: 20px;
    .nav-menu{
      li{
        font-size: 14px;
      }
    }
  }
  /deep/ .loadingimg {
    top: 50%;
    margin-top: -30px;
    width: 128px;
    text-align: center;
    position: absolute;
  }
  .delivery-add{
    width: 85.1%;
    height: 50px;
    position: absolute;
    top: 49px;
    left: 7.5%;
    z-index: 1;
    .add-button{
      background: #fff;
      width: 100%;
      height: 50px;
      display: flex;
      cursor: pointer;
      justify-content: center;
      align-items: center;
      border: 1px dashed #c2c2c2;
      span{
        display: inline-block;
        height: 20px;
        line-height: 20px;
        font-size: 14px;
        color: #333;
      }
      span:nth-child(1){
        font-size: 12px;
        color: $--gl-blue;
        line-height: 18px;
        margin-right: 6px;
      }
    }
    .add-button:hover{
      background: #e7f0f6;
      border: 1px dashed $--gl-blue;
      span{
        display: inline-block;
        height: 20px;
        line-height: 20px;
        font-size: 14px;
        color: $--gl-blue;
      }
      span:nth-child(1){
        font-size: 12px;
        color: $--gl-blue;
        line-height: 18px;
        margin-right: 6px;
      }
    }
  }
  .delivery-pagination{

    width: 100%;
    margin-top: 73px;
    text-align: center;
  }
  .table-link{
    overflow: hidden;
    text-overflow:ellipsis;
    white-space: nowrap;
  }
  .table-p{
    overflow: hidden;
    text-overflow:ellipsis;
    white-space: nowrap;
    cursor: pointer;
    padding-right: 15px;
  }
  .table-icon{
    display: flex;
    justify-content: space-between;
    span{
      color: #1d76a8;
      cursor: pointer;
    }
  }
  .dialog-img{
    width: 100%;
    height: 100%;
    overflow: hidden;
    img{
      width: 100%;
      height: 100%;
      object-fit: cover;
    }
  }
}
/deep/ .lui-table__body{
  margin-top: 46px;
}


/deep/ .lui-date-editor--datetimerange.lui-input__inner {
  width: 450px;
}

.type-dlown{
  display: flex;
  button{
    width: 220px;
    margin-right: 10px;
  }

  .buttonfile{
    width: 220px;
    height: 30px;
    position: relative;
    input{
      width: 220px;
      height: 30px;
      position: absolute;
      top: 0;
      left: 0;
      opacity: 0;
    }
    p{
      height: 30px;
      line-height: 30px;
      font-size: 14px;
      color: #666;
      display: flex;
      align-items: center;
      span{
        overflow: hidden;
        text-overflow:ellipsis;
        white-space: nowrap;
      }
    }
  }
 }

//  图片上传
/deep/ .add_contract{
  width: 128px;
  height: 78px;
  position: relative;
  top: 1px;
  left: 1px;
  z-index: 1;
}
/deep/ .avatar-uploader .lui-upload {
  border: 1px dashed #d9d9d9;
  border-radius: 6px;
  cursor: pointer;
  position: relative;
  overflow: hidden;
}
.avatar-uploader .lui-upload:hover {
  border-color: #3C6EF0;
}
.avatar-uploader-icon {
  font-size: 28px;
  color: #999;
  width: 128px;
  height: 78px;
  line-height: 78px;
  text-align: center;
}
.avatar {
  width: 128px;
  height: 78px;
  object-fit: cover;
  display: block;
}
.mask_pic{
  width: 128px;
  height: 78px;
  position: relative;
  .mask{
    position: absolute;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    background: rgba(0,0,0,0.1);
    display: none;
  }
  &:hover{
    .mask{
      display: block;
    }
  }
}
.upload_imgs{
  position: relative;
}
.mask_background{
  width: 128px;
  height: 78px;
  position: absolute;
  top: 0;
  left: 0;
  z-index: 100;
  border-radius: 4px;
  overflow: hidden;
  .mask_background_icon{
    width: 128px;
    height: 78px;
    i{
      display: none;
    }
    /deep/ .lui-image__preview{
      display: none;
    }
    &:hover{
      background: rgba(0,0,0,0.2);
      display: flex;
      justify-content: center;
      align-items: center;
      i{
        display: inline-block;
        cursor: pointer;
        font-size: 20px;
        margin-left: 10px;
        &:hover{
          color: #0e6596;
        }
      }
      /deep/ .lui-image__preview{
        display: inline-block;
        cursor: pointer;
        margin-right: 10px;
      }
    }
  }

}

@media screen and (max-width: 1366px) {
  /deep/ .lui-table th>.cell {
    position: relative;
    word-wrap: normal;
    text-overflow: ellipsis;
    display: inline-block;
    vertical-align: middle;
    width: 100%;
    font-size: 12px;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    font-weight: 400;
  }
}
</style>
