<template>
  <div class="AddNotice">
    <div class="AddNotic-title">
      <span @click="backClick">返回</span>
      <span>{{ titleName }}</span>
      <span></span>
    </div>
    <div class="AddNotic-content">
      <lui-row>
        <lui-col :span="24">
          <lui-form
            ref="ruleForm"
            :model="ruleForm"
            :rules="rules"
            label-width="100px"
            class="demo-ruleForm"
          >
            <lui-form-item label="应用ID" prop="ids">
              <lui-input v-model="ruleForm.ids" placeholder="请输入应用ID"></lui-input>
            </lui-form-item>

            <lui-form-item label="应用名称" prop="name">
              <lui-input v-model="ruleForm.name" placeholder="请输入应用名称"></lui-input>
            </lui-form-item>

            <lui-form-item label="应用介绍" prop="introduce">
              <lui-input v-model="ruleForm.introduce" placeholder="请输入应用介绍"></lui-input>
            </lui-form-item>

            <lui-form-item
              label="图标上传"
              class="upload_imgs"
              prop="picture">
              <lui-upload
                class="avatar-uploader"
                :action="baseURL+'img/upload'"
                accept=".jpg,.png,.gif"
                :show-file-list="false"
                :on-success="handleAvatarSuccess"
                :before-upload="beforeAvatarUpload">
                <img
                  v-if="ruleForm.picture"
                  :src="ruleForm.picture"
                  class="avatar">
                <div
                  v-else
                  slot="trigger"
                  v-loading="loadingimg"
                  class="add_contract">
                  <div class="contract_box">
                    <i class="lui-icon-plus avatar-uploader-icon"></i>
                  </div>
                </div>
              </lui-upload>
              <div
                v-if="ruleForm.picture"
                class="mask_background">
                <div class="mask_background_icon">
                  <lui-image
                    style="width: 20px; height: 20px"
                    :src="imgIcon"
                    :preview-src-list="srcList">
                  </lui-image>
                  <i
                    class="lui-icon-delete"
                    @click="deleteImg"></i>
                </div>
              </div>
            </lui-form-item>

            <lui-form-item
              label="应用链接"
              prop="url">
              <lui-input
                v-model.trim="ruleForm.url"
                placeholder="请输入链接地址">
              </lui-input>
            </lui-form-item>

            <lui-form-item
              label="应用详情"
              prop="detailsJsf">
              <div class="information-nav">
                <lui-menu
                  :default-active="activeIndex"
                  class="lui-menu-demo nav-menu"
                  mode="horizontal"
                  @select="handleSelect">
                  <lui-menu-item index="1">应用详情</lui-menu-item>
                  <lui-menu-item index="2">使用教程</lui-menu-item>
                  <lui-menu-item index="3">用户评价</lui-menu-item>
                </lui-menu>
                <div class="line"></div>
              </div>

              <div v-show="detailsJsf" style="margin-top: 20px;">
                <tinymce-editor
                  ref="editor"
                  v-model="ruleForm.detailsJsf"
                  :height="300">
                </tinymce-editor>
              </div>
              <div v-show="courseJsf" style="margin-top: 20px;">
                <tinymce-editor
                  ref="editor"
                  v-model="ruleForm.courseJsf"
                  :height="300">
                </tinymce-editor>
              </div>
              <div v-show="userEvaluateJsf" style="margin-top: 20px;">
                <tinymce-editor
                  ref="editor"
                  v-model="ruleForm.userEvaluateJsf"
                  :height="300">
                </tinymce-editor>
              </div>
            </lui-form-item>

            <!--            <lui-form-item label="是否显示" prop="enabled">-->
            <!--              <lui-radio-group v-model="ruleForm.enabled">-->
            <!--                <lui-radio :label="1" class="button_radio">是</lui-radio>-->
            <!--                <lui-radio :label="0" class="button_radio">否</lui-radio>-->
            <!--              </lui-radio-group>-->
            <!--            </lui-form-item>-->

            <div class="ruleForm-button">
              <lui-button :loading="listLoading" type="primary" @click="submitForm('ruleForm')">确定</lui-button>
              <lui-button @click="centerDialogVisible=true">预览</lui-button>
              <lui-button v-if="buttonShow" @click="buttonClicks('ruleForm')">存到草稿箱</lui-button>
              <!--              <lui-checkbox-group v-model="ruleForm.stage" size="big">-->
              <!--              <lui-checkbox-button v-if="buttonShow" @click="buttonClicks('ruleForm')">存到草稿箱</lui-checkbox-button>-->
              <!--              </lui-checkbox-group>-->
            </div>
          </lui-form>
        </lui-col>
      </lui-row>
    </div>

    <!--        详情-->
    <lui-dialog
      :visible.sync="centerDialogVisible"
      width="85%"
      top="10vh"
      :close-on-click-modal="false"
      custom-class="dialog_mask"
      title="应用详情">
      <div class="Intro">
        <div class="Intro-container">
          <div class="container-title">
            <div class="title-left">
              <img :src="ruleForm.picture" alt="">
            </div>
            <div class="title-right">
              <h2>{{ ruleForm.name }}</h2>
              <p>{{ ruleForm.introduce }}</p>
              <button>去购买</button>
            </div>
          </div>

          <div class="container-content">
            <div class="information-nav">
              <lui-menu
                :default-active="activeIndexGet"
                class="lui-menu-demo nav-menu"
                mode="horizontal"
                @select="handleGet">
                <lui-menu-item index="1">产品详情</lui-menu-item>
                <lui-menu-item index="2">使用教程</lui-menu-item>
                <lui-menu-item index="3">用户评价</lui-menu-item>
              </lui-menu>
              <div class="line"></div>
            </div>

            <div v-show="details" v-dompurify-html="ruleForm.detailsJsf" class="content-details"></div>

            <div v-show="Intro" v-dompurify-html="ruleForm.courseJsf" class="contetn-Intro"></div>

            <div v-show="EvaluaJsf" v-dompurify-html="ruleForm.userEvaluateJsf" class="contetn-Intro"></div>
          </div>
        </div>
      </div>
    </lui-dialog>
  </div>
</template>

<script>
import http from '@/lib/http'
import Api from '@/api'
import utils from '@/utils/utils'
import TinymceEditor from '@/components/shared/TinymceEditor'
import imgster from '@/assets/img/icon-looks.png'
export default {
  name: '',
  components: {
    TinymceEditor
  },
  props: {
    headerUserName: {
      type: Number,
      default: null
    }
  },


  data() {
    return {
      activeIndex: '1',
      activeIndexGet: '1',
      details: true,
      Intro: false,
      detailsJsf: true,
      courseJsf: false,
      EvaluaJsf: false,
      userEvaluateJsf: false,
      imgIcon: imgster,
      srcList: [],
      loadingimg: false, //update img loading
      listLoading: false, //button loading
      titleName: '新增应用',
      baseURL: http.baseContextUrl,
      edit: false, //判断是否编辑
      buttonShow: true, //草稿控制按钮
      centerDialogVisible: false,
      Ids: '', //地址栏参数获取
      ruleForm: {
        ids: '', //ID
        name: '', //应用名称
        introduce: '', //应用介绍
        picture: '', //图片上传
        url: '', //链接地址
        detailsJsf: '', //应用详情
        courseJsf: '', //使用教程
        enabled: '', //是否显示
        userEvaluateJsf: '', //评价
        stage: ''
      },
      rules: {
        ids: [{ required: true, message: '请输入应用ID', trigger: 'blur' }],
        name: [{ required: true, message: '请输入应用名称', trigger: 'blur' }],
        introduce: [{ required: true, message: '请输入应用介绍', trigger: 'blur' }],
        picture: [{ required: true, message: '请上传图标', trigger: 'change' }],
        url: [{ required: true, message: '请输入链接地址', trigger: 'blur' }],
        enabled: [{ required: true, message: '请选择是否显示', trigger: 'change' }],
        details: [{ required: false, message: '请输入应用详情', trigger: 'blur,change' }],
        course: [{ required: false, message: '请输入应用详情', trigger: 'blur,change' }],
        evaluate: [{ required: false, message: '请输入用户评价', trigger: 'blur,change' }]
      }
    }
  },
  mounted() {
    //根据id判断 if地址栏有ID则是编辑 else则是新增
    this.Ids = this.headerUserName
    if (this.Ids !== undefined && this.Ids !== null && this.Ids !== '') {
      this.edit = true
      this.buttonShow = false
      this.titleName = '编辑应用'
      Api.BackStageAppContent.appCenterGet({ id: this.Ids }).then(rows => {
        if (rows.success) {
          this.ruleForm = {
            ids: utils.htmlDecode(rows.data.number), //ID
            name: utils.htmlDecode(rows.data.name), //应用名称
            introduce: utils.htmlDecode(rows.data.introduce), //应用介绍
            picture: rows.data.icon, //图片上传
            url: rows.data.url, //链接地址
            detailsJsf: utils.htmlDecode(rows.data.detailsJsf), //应用详情
            courseJsf: utils.htmlDecode(rows.data.courseJsf), //使用教程
            enabled: rows.data.enabled, //是否显示
            userEvaluateJsf: utils.htmlDecode(rows.data.userEvaluateJsf), //评价
            stage: rows.data.stage ? false : true
          }
          this.srcList.push(rows.data.icon) //回显查看按钮显示问题
        }
      }).catch((e) => {})
    }

  },
  methods: {
    //数据查看
    getClik() {
      this.centerDialogVisible = true
    },
    // 保存到草稿
    buttonClicks(formName) {
      this.$alert('<p style="font-size: 18px;color:#333">确认存到草稿箱吗?</p>', '', {
        dangerouslyUseHTMLString: true,
        type: 'warning',
        center: true
      }).then(() => {
        // this.submitForm(formName)
        this.$refs.ruleForm.clearValidate('ids')
        this.$refs.ruleForm.clearValidate('picture')
        this.$refs.ruleForm.clearValidate('name')
        this.$refs.ruleForm.clearValidate('introduce')
        this.$refs.ruleForm.clearValidate('url')

        const params = {}
        params.number = this.ruleForm.ids
        params.name = this.ruleForm.name
        params.enabled = 0
        params.icon = this.ruleForm.picture
        params.introduce = this.ruleForm.introduce
        params.url = this.ruleForm.url
        //应用详情
        params.details = this.ruleForm.detailsJsf.replace(/<[^>]*>|/g, '')
        params.detailsJsf = this.ruleForm.detailsJsf
        //应用教程
        params.course = this.ruleForm.courseJsf.replace(/<[^>]*>|/g, '')
        params.courseJsf = this.ruleForm.courseJsf
        //应用评价
        params.userEvaluate = this.ruleForm.userEvaluateJsf.replace(/<[^>]*>|/g, '')
        params.userEvaluateJsf = this.ruleForm.userEvaluateJsf
        params.stage = this.ruleForm.stage ? 0 : 1

        Api.BackStageAppContent.appCenterCreate(params).then(row => {
          if (row.success) {
            this.$showSuccessMsg('存入草稿')
            this.listLoading = false
            this.$emit('event1', false) //传参给父组件改变状态
          }
        }).catch((e) => {
          this.$showErrorMsg(e)
          this.listLoading = false
        })


      }).catch(() => {
        this.ruleForm.stageFlag = false
        this.$message.error('存入草稿箱失败，请稍后再试')
      })
    },
    submitForm(formName) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          this.listLoading = true
          if (this.edit) { //编辑
            const params = {}
            params.number = this.ruleForm.ids
            params.name = this.ruleForm.name
            params.enabled = this.ruleForm.enabled
            params.icon = this.ruleForm.picture
            params.introduce = this.ruleForm.introduce
            params.url = this.ruleForm.url
            params.id = this.Ids
            //应用详情
            params.details = this.ruleForm.detailsJsf.replace(/<[^>]*>|/g, '')
            params.detailsJsf = this.ruleForm.detailsJsf
            //应用教程
            params.course = this.ruleForm.courseJsf.replace(/<[^>]*>|/g, '')
            params.courseJsf = this.ruleForm.courseJsf
            //应用评价
            params.userEvaluate = this.ruleForm.userEvaluateJsf.replace(/<[^>]*>|/g, '')
            params.userEvaluateJsf = this.ruleForm.userEvaluateJsf
            params.stage = this.ruleForm.stage ? 0 : 1

            Api.BackStageAppContent.appCenterEdit(params).then(row => {
              if (row.success) {
                this.$showSuccessMsg('编辑成功')
                this.listLoading = false
                this.$emit('event1', false) //传参给父组件改变状态
              }
            }).catch((e) => {
              this.$showErrorMsg(e)
              this.listLoading = false
            })
          } else { //新增
            const params = {}
            params.number = this.ruleForm.ids
            params.name = this.ruleForm.name
            params.enabled = 0
            params.icon = this.ruleForm.picture
            params.introduce = this.ruleForm.introduce
            params.url = this.ruleForm.url
            //应用详情
            params.details = this.ruleForm.detailsJsf.replace(/<[^>]*>|/g, '')
            params.detailsJsf = this.ruleForm.detailsJsf
            //应用教程
            params.course = this.ruleForm.courseJsf.replace(/<[^>]*>|/g, '')
            params.courseJsf = this.ruleForm.courseJsf
            //应用评价
            params.userEvaluate = this.ruleForm.userEvaluateJsf.replace(/<[^>]*>|/g, '')
            params.userEvaluateJsf = this.ruleForm.userEvaluateJsf
            params.stage = this.ruleForm.stage ? 0 : 1

            Api.BackStageAppContent.appCenterCreate(params).then(row => {
              if (row.success) {
                this.$showSuccessMsg('新增成功')
                this.listLoading = false
                this.$emit('event1', false) //传参给父组件改变状态
              }
            }).catch((e) => {
              this.$showErrorMsg(e)
              this.listLoading = false
            })
          }
        } else {
          this.ruleForm.stageFlag = false
          return false
        }
      })
    },
    backClick() {
      this.$emit('event1', false) //传参给父组件改变状态
    },
    /*update imgage*/
    handleAvatarSuccess(res, file) {
      this.loadingimg = false
      this.imageUrl = URL.createObjectURL(file.raw)
      this.ruleForm.picture = res.data
      this.srcList.push(this.ruleForm.picture)
      this.$refs.ruleForm.clearValidate('picture')
    },
    beforeAvatarUpload(file) {
      const isLt2M = file.size / 1024 / 1024 < 5
      if (!isLt2M) {
        this.$message.error('上传头像图片大小不能超过 5MB!')
        return isLt2M
      } else {
        this.loadingimg = true
      }
    },
    //图片删除
    deleteImg() {
      this.ruleForm.picture = ''
      this.srcList = [] //清空图片预览
    },
    //输入框控制
    handleSelect(key, keyPath) {
      switch (key) {
        case '1':
          this.detailsJsf = true
          this.courseJsf = false
          this.userEvaluateJsf = false
          break
        case '2':
          this.detailsJsf = false
          this.courseJsf = true
          this.userEvaluateJsf = false
          break
        case '3':
          this.detailsJsf = false
          this.courseJsf = false
          this.userEvaluateJsf = true
          break
      }
    },
    // 详情查看
    handleGet(key, keyPath) {
      switch (key) {
        case '1':
          this.details = true
          this.Intro = false
          this.EvaluaJsf = false
          break
        case '2':
          this.details = false
          this.EvaluaJsf = false
          this.Intro = true
          break
        case '3':
          this.details = false
          this.Intro = false
          this.EvaluaJsf = true
          break
      }
    }
  }
}
</script>

<style scoped lang="scss">
@import "@/assets/stylus/main.scss";
  .AddNotice {
      background: #fff;
      width: 100%;
      padding-bottom: 26px;
      padding-top: 20px;
      .AddNotic-title {
          width: 80%;
          margin: 0 auto;
          padding-bottom: 10px;
          border-bottom: 1px solid #D9D9D9;
          display: flex;
          justify-content: space-between;
          span {
              color: #333;
          }
          span:nth-child(1) {
              display: inline-block;
              width: 70px;
              height: 30px;
              border: 1px solid #D9D9D9;
              border-radius: 4px;
              line-height: 30px;
              text-align: center;
              font-size: 12px;
              cursor: pointer;
          }
          span:nth-child(2) {
              font-size: 14px;
          }
      }
      .AddNotic-content {
          width: 800px;
          margin: 0 auto;
          margin-top: 50px;
      }
  }
  .information-nav {
      .nav-menu {
          li {
              height: 35px;
              line-height: 30px;
          }
      }
  }
  .ruleForm-button {
      width: 100%;
      display: flex;
      justify-content: center;
      margin-top: 50px;
  }

  .lui-row {
      margin-bottom: 20px;
      &:last-child {
          margin-bottom: 0;
      }
  }

  .lui-col {
      border-radius: 4px;
  }

  .bg-purple-dark {
      background: #99a9bf;
  }

  .bg-purple {
      background: #d3dce6;
  }

  .bg-purple-light {
      background: #e5e9f2;
  }

  .grid-content {
      border-radius: 4px;
      min-height: 36px;
  }

  .row-bg {
      padding: 10px 0;
      background-color: #f9fafc;
  }
  /deep/ .lui-checkbox-button:last-child .lui-checkbox-button__inner {
      border-radius: 4px;
  }
  .dialog-title{
      cursor: pointer;
      font-size: 20px;
      color: #333;
      font-weight: 500;
      &:hover{
          color: $--gl-blue;
      }
  }

  //  图片上传
  /deep/ .add_contract{
      width: 128px;
      height: 78px;
      position: relative;
      top: 1px;
      left: 1px;
      z-index: 1;
  }
  /deep/ .avatar-uploader .lui-upload {
      border: 1px dashed #d9d9d9;
      border-radius: 6px;
      cursor: pointer;
      position: relative;
      overflow: hidden;
  }
  .avatar-uploader .lui-upload:hover {
      border-color: #3C6EF0;
  }
  .avatar-uploader-icon {
      font-size: 28px;
      color: #999;
      width: 128px;
      height: 78px;
      line-height: 78px;
      text-align: center;
  }
  .avatar {
      width: 128px;
      height: 78px;
      object-fit: cover;
      display: block;
  }
  .mask_pic{
      width: 128px;
      height: 78px;
      position: relative;
      .mask{
          position: absolute;
          top: 0;
          bottom: 0;
          left: 0;
          right: 0;
          background: rgba(0,0,0,0.1);
          display: none;
      }
      &:hover{
          .mask{
              display: block;
          }
      }
  }
  .upload_imgs{
      position: relative;
  }
  .mask_background{
      width: 128px;
      height: 78px;
      position: absolute;
      top: 0;
      left: 0;
      z-index: 100;
      border-radius: 4px;
      overflow: hidden;
      .mask_background_icon{
          width: 128px;
          height: 78px;
          i{
              display: none;
              color: $--gl-blue
          }
          /deep/ .lui-image__preview{
              display: none;
          }
          &:hover{
              background: rgba(225,225,225,0.7);
              display: flex;
              justify-content: center;
              align-items: center;
              i{
                  display: inline-block;
                  cursor: pointer;
                  font-size: 20px;
                  margin-left: 10px;
                  &:hover{
                      color: #0e6596;
                  }
              }
              /deep/ .lui-image__preview{
                  display: inline-block;
                  cursor: pointer;
                  margin-right: 10px;
              }
          }
      }

  }
  //详情预览
  .Intro{
      width: 100%;
      background: #fff;
      overflow-y: auto;
      padding: 30px 0;
      .Intro-container{
          width: 85%;
          margin: 0 auto;
          .container-title{
              width: 100%;
              height: 120px;
              display: flex;
              .title-left{
                  min-width: 120px;
                  height: 120px;
                  border-radius: 4px;
                  overflow: hidden;
                  img{
                      width: 120px;
                      height: 120px;
                      object-fit: cover;
                  }
              }
              .title-right{
                  width: calc(100% - 120px);
                  margin-left: 15px;
                  h2{
                      font-size: 24px;
                      color: #333333;
                      margin-top: 5px;
                  }
                  p{
                      width: 100%;
                      font-size: 14px;
                      color: #666666;
                      text-align: left;
                      line-height: 26px;
                      white-space: nowrap;
                      overflow: hidden;
                      text-overflow: ellipsis;
                  }
                  button{
                      width: 180px;
                      height: 40px;
                      background-image: linear-gradient(270deg, $--gl-hoverBlue 0%,  $--gl-blue 100%);
                      border-radius: 4px;
                      border: none;
                      outline: none;
                      margin-top: 10px;
                      font-size: 14px;
                      color: #fff;
                      cursor: pointer;
                  }
              }
          }
          .container-content{
              width: 100%;
              height: 300px;
              margin-top: 30px;
              .information-nav {
                  margin-bottom: 20px;
                  .nav-menu {
                      li {
                          height: 35px;
                          line-height: 30px;
                      }
                  }
              }
              .content-details{
                  width: 100%;
                  overflow-y: auto;

              }
              .contetn-Intro{
                  width: 100%;
              }
          }
      }
  }

</style>
