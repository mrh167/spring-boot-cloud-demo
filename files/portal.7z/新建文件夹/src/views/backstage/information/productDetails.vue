<template>
  <div class="index">
    <div v-show="isShow" class="app-center">
      <div class="contation">
        <div class="contation-title">
          <h2>数字化供应链计划平台</h2>
          <span></span>
        </div>
        <div class="contation-banner">
          <img src="@/assets/img/backstage/banner.png" alt="">
        </div>
      </div>

      <div class="main">
        <div class="contation-title">
          <h2>核心产品</h2>
          <p>大数据与智能算法相结合，需求和计划相结合，通过多个维度建立决策机制</p>
          <span></span>
        </div>
        <div class="arrow-left" :class="{'active-arrow': countLeft === 0}" @click="handleCaseLeft()"><i class="lui-icon-arrow-left"></i></div>
        <div class="arrow-right" :class="{'active-arrow': countRight === 0}" @click="handleCaseRight()"><i class="lui-icon-arrow-right"></i></div>
        <div class="core-case">
          <div class="case-content-wrap">
            <div class="case-content" :style="{transform: 'translate3d('+partnerTranslateX+'px,0,0)'}">
              <div v-for="(item, index) in partnerSwiperList" :key="index" class="case-item" :class="{'active-partner': partnerIndex === item.ids}">
                <h2 :class="{'active-title': partnerIndex === item.ids}">{{ item.name }}</h2>
                <p :class="{'active-case': partnerIndex === item.ids}">依托大数据和算法能力提供多维度预测方案</p>
                <span :class="{'active-centent': partnerIndex === item.ids}">{{ item.introduce }}</span>
                <div :class="{'active-button': partnerIndex === item.ids}">
                  <span class="span1" @click="getLookClick(item)">了解详情</span>
                  <span class="span2" @click="purchase(item)">去购买</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="footer">
        <div class="contation-title">
          <h2>智能商务仓</h2>
          <p>享有商务仓高品质服务的优势服务外，从规划、计划、履约结合智能决策工具升级供应链</p>
          <span></span>
        </div>
        <div class="footer-wapper">
          <div class="wapper-img">
            <img src="@/assets/img/backstage/banner_3.png" alt="">
          </div>
        </div>
      </div>
    </div>
    <div v-if="!isShow">
      <introduction :ids="Ids" @sendMessage="message"></introduction>
    </div>
  </div>

</template>
<script>
import Api from '@/api'
import utils from '@/utils/utils'
import introduction from './Introduction.vue'
export default {
  components: {
    introduction
  },
  data() {
    return {

      Ids: '',
      isShow: true,
      partnerTranslateX: 0,
      countLeft: 0,
      countRight: 0,
      isClickLeft: false,
      isClickRight: true,
      pageSize: 10,
      pageNum: 1,
      totals: 0,
      partnerSwiperList: [],
      swiperList: [],
      listData: [],
      storeyIndex: 1,
      partnerIndex: 0
    }
  },
  created() {
    this.getList()
    document.documentElement.scrollTop = 0
    if (this.$route.query.id) {
      this.Ids = this.$route.query.id
      this.isShow = false
    }
  },
  methods: {
    message() {
      this.isShow = true
    },
    //查看详情
    getLookClick(item) {
      if (!item.url) {
        return
      }
      this.Ids = item.id
      this.isShow = false
    },
    //去购买
    purchase(item) {
      if (!item.url) {
        return
      }
      window.open(item.url, '_blank')
    },
    // 列表获取
    getList() {
      Api.BackStageAppContent.UserAppCenterList({
        pageNum: this.pageNum, //页
        pageSize: this.pageSize //条数
      }).then(row => {
        if (row.success) {
          for (let i = 0; i < this.listData.length; i++) {
            row.data.push(this.listData[i])
          }
          for (let i = 0; i < row.data.length; i++) {
            row.data[i].name = row.data[i].name ? utils.htmlDecode(row.data[i].name) : row.data[i].name
            row.data[i].number = row.data[i].number ? utils.htmlDecode(row.data[i].number) : row.data[i].number
            row.data[i].introduce = row.data[i].introduce ? utils.htmlDecode(row.data[i].introduce) : row.data[i].introduce
            row.data[i].ids = i
          }
          this.swiperList = row.data
          this.totals = row.total
          this.LoadingOne = false
          this.countRight = this.swiperList.length - 1
          this.partnerSwiperList = this.swiperList.slice(0, 10)
        }
      }).catch((e) => { this.$showErrorMsg(e) })
    },

    handleCaseRight() {
      if (this.countRight > 0) {
        this.partnerIndex += 1
        this.partnerSwiperList = this.swiperList.slice(0, this.swiperList.length)
        const temp = this.partnerSwiperList.slice(0, this.partnerIndex)
        this.partnerSwiperList = [...this.partnerSwiperList, ...temp]
        this.countRight = this.countRight - 1
        this.countLeft = this.countLeft + 1
        this.partnerTranslateX = (-355 - 24) * this.countLeft
      }
    },
    handleCaseLeft() {
      if (this.countLeft > 0) {
        this.partnerIndex -= 1
        this.countLeft = this.countLeft - 1
        this.countRight = this.countRight + 1
        this.partnerTranslateX = (-355 - 24) * this.countLeft
      }
    }
  }
}
</script>

<style lang="scss" scoped>
@import "@/assets/stylus/main";
  .index{
    width: 100%;
    overflow: hidden;
    background: #fff;
    .app-center{
      border-radius: 4px;
      .contation{
        // width: 1340px;
        margin: 0 200px;
        .contation-title{
          padding-top: 40px;
          text-align: center;
          h2{
            font-size: 24px;
            color: #333333;
            letter-spacing: 0;
            line-height: 24px;
            text-align: center;
            font-weight: 600;
          }
          span{
            margin-top: 20px;
            display: inline-block;
            width: 50px;
            height: 4px;
            background: $--gl-blue;
            border-radius: 2px;
          }
        }
        .contation-banner{
          margin-top: 88px;
          width: 100%;
          img{
            width: 100%;
          }
        }
      }

      .main{
        width: 100%;
        height: 600px;
        background: #FAFAFA;
        position: relative;
        .contation-title{
          padding-top: 40px;
          text-align: center;
          margin-bottom: 20px;
          h2{
            font-size: 24px;
            color: #333333;
            letter-spacing: 0;
            line-height: 24px;
            text-align: center;
            font-weight: 600;
          }
          p{
            margin-top: 10px;
            font-size: 12px;
            color: #999999;
            line-height: 12px;
          }
          span{
            margin-top: 20px;
            display: inline-block;
            width: 50px;
            height: 4px;
            background: $--gl-blue;
            border-radius: 2px;
          }
        }

        .core-case{
          position: absolute;
          left: 156px;
          right: 156px;
          margin: 0 auto;
          overflow: hidden;
          .case-content-wrap{
            width: 1514px;
            position: relative;
            margin: 0 auto;
            height: 424px;
            overflow: hidden;
            background: url("../../../assets/img/backstage/banner_1.png") no-repeat;
            background-size: 100% 100%;
            display: flex;
            align-items: center;
          }
          /*------------------------------------------------------------*/
          .case-content{
            position: relative;
            display: flex;
            align-items: center;
            .case-item{
              width:355px;
              height:290px;
              margin-right: 24px;
              background: #FFFFFF;
              box-shadow: 0 2px 10px 0 rgba(115,114,114,0.19);
              border-radius: 4px;
              padding: 40px 47px;
              h2{
                font-size: 16px;
                font-weight: 600;
                color: #333333;
                letter-spacing: 0;
                line-height: 18px;
                padding-bottom: 18px;
                text-overflow: ellipsis;
                overflow: hidden;
                white-space: nowrap;
              }
              p{
                font-size: 12px;
                color: #999999;
                letter-spacing: 0;
                line-height: 18px;
                padding-bottom: 20px;
              }
              span{
                height: 80px;
                overflow: hidden;
                text-overflow: ellipsis;
                display: -webkit-box;
                -webkit-line-clamp: 3;
                -webkit-box-orient: vertical;
                color: #666;
                line-height: 26px;
                font-size: 14px;
              }
              div{
                display: flex;
                align-items: center;
                .span1{
                  display: inline-block;
                  width: 88px;
                  height: 30px;
                  background: rgba(255,255,255,0.20);
                  border: 1px solid $--gl-blue;;
                  border-radius: 4px;
                  text-align: center;
                  line-height: 30px;
                  font-size: 14px;
                  color: $--gl-blue;
                  box-sizing: border-box;
                  margin-top: 32px;
                  cursor: pointer;
                }
                .span2{
                  margin-top: 32px;
                  display: inline-block;
                  width: 88px;
                  height: 32px;
                  border-radius: 4px;
                  text-align: center;
                  line-height: 32px;
                  font-size: 14px;
                  color: #fff;
                  background: $--gl-blue;
                  margin-left: 16px;
                  cursor: pointer;
                }
              }
              .active-title{
                font-size: 18px;
                font-weight: 600;
                color: #fff;
                letter-spacing: 0;
                line-height: 18px;
                padding-bottom: 18px;
                text-overflow: ellipsis;
                overflow: hidden;
                white-space: nowrap;
              }
              .active-case{
                opacity: 0.6;
                font-size: 12px;
                color: #FFFFFF;
                text-align: justify;
                line-height: 12px;
              }
              .active-centent{
                font-size: 14px;
                color: #FFFFFF;
                text-align: justify;
                line-height: 26px;
                overflow: hidden;
                text-overflow: ellipsis;
                display: -webkit-box;
                -webkit-line-clamp: 5;
                -webkit-box-orient: vertical;
                height: 128px;
              }
              .active-button{
                .span1{
                  display: inline-block;
                  width: 88px;
                  height: 30px;
                  background: rgba(255,255,255,0.20);
                  border: 1px solid #fff;
                  border-radius: 4px;
                  text-align: center;
                  line-height: 30px;
                  font-size: 14px;
                  color: #fff;
                  box-sizing: border-box;
                  margin-top: 32px;
                  cursor: pointer;
                }
                .span2{
                  margin-top: 32px;
                  display: inline-block;
                  width: 88px;
                  height: 32px;
                  border-radius: 4px;
                  text-align: center;
                  line-height: 32px;
                  font-size: 14px;
                  color: $--gl-blue;
                  background: #fff;
                  margin-left: 16px;
                  cursor: pointer;
                }
              }
              .active-case-title{
                opacity: 0.5;
                font-size: 12px;
                color: #000;
                letter-spacing: 0;
                line-height: 12px;
              }
            }
            .active-partner{
              background-image: linear-gradient(270deg, $--gl-hoverBlue 0%, $--gl-blue 100%);
              width: 355px;
              height: 360px;
            }
          }
        }
        .arrow-left{
          position: absolute;
          left: 48px;
          top: 310px;
          width: 60px;
          height: 60px;
          border-radius: 50%;
          background: $--gl-hoverBlue;
          display: flex;
          align-items: center;
          justify-content: center;
          cursor: pointer;
          i{
            font-size: 20px;
            color: #fff;
          }
        }
        .arrow-right{
          position: absolute;
          right: 48px;
          top: 310px;
          width: 60px;
          height: 60px;
          border-radius: 50%;
          background: $--gl-hoverBlue;
          display: flex;
          align-items: center;
          justify-content: center;
          cursor: pointer;
          i{
            font-size: 20px;
            color: #fff;
          }
        }
        .active-arrow{
          cursor: not-allowed;
          opacity: 0.3;
        }
      }
      .footer{
        width: 100%;
        background: #ffffff;
        padding-bottom: 70px;
        border-radius: 0 0 4px 4px;
        .contation-title{
          padding-top: 40px;
          text-align: center;
          margin-bottom: 40px;
          h2{
            font-size: 24px;
            color: #333333;
            letter-spacing: 0;
            line-height: 24px;
            text-align: center;
            font-weight: 600;
          }
          p{
            margin-top: 10px;
            font-size: 12px;
            color: #999999;
            line-height: 12px;
          }
          span{
            margin-top: 20px;
            display: inline-block;
            width: 50px;
            height: 4px;
            background: $--gl-blue;
            border-radius: 2px;
          }
        }
        .footer-wapper{
          // width: 1340px;
          // margin: 0 auto;
          margin: 0 200px;
          .wapper-img{
            width: 100%;
            img{
              width: 100%;

            }
          }
        }
      }
    }
  }
</style>
