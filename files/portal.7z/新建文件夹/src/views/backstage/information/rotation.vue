<template>
  <div class="rotation">
    <div class="rotation-add">
      <div
        class="add-button"
        @click="addClick">
        <span class="lui-icon-plus"></span>
        <span>新建轮播图</span>
      </div>
    </div>
    <lui-table
      v-loading="listLoading"
      :data="tableData"
      class="rotation-table"
      style="width: 85%;margin: 0 auto; ">
      <template slot="empty">
        <showEmptyImage></showEmptyImage>
      </template>
      <lui-table-column
        width="100"
        prop="id"
        label="ID"
        show-overflow-tooltip>
      </lui-table-column>
      <lui-table-column
        prop="brief"
        label="轮播简介"
        show-overflow-tooltip>
      </lui-table-column>
      <lui-table-column
        prop="position"
        label="轮播位置">
        <template slot-scope="{row}">
          <p v-if="row.position==='1'" class="table-p">官网</p>
          <p v-else class="table-p">产品首页</p>
        </template>
      </lui-table-column>
      <lui-table-column
        prop="picture"
        width="80"
        label="轮播预览">
        <template slot-scope="{row}">
          <div
            v-if="row.picture!=null"
            v-viewer
            class="images">
            <lui-tooltip
              class="item"
              effect="dark"
              content="点击预览"
              placement="bottom">
              <img
                :src="row.picture"
                style="width: 60px;height: 30px;object-fit: cover;cursor: pointer" />
            </lui-tooltip>
          </div>
        </template>
      </lui-table-column>
      <lui-table-column
        width="80"
        label="是否显示">
        <template slot-scope="{row}">
          <lui-switch
            v-model="row.enabled"
            active-circle-class="1"
            active-color="rgba(60,110,240,.2)"
            inactive-color="rgba(142,145,152,.2)"
            @change="setIfShowClick(row)">
          </lui-switch>
        </template>
      </lui-table-column>
      <lui-table-column
        prop="number"
        label="轮播排序"
        show-overflow-tooltip>
      </lui-table-column>
      <lui-table-column
        prop="url"
        label="跳转链接">
        <template slot-scope="{row}">
          <lui-tooltip
            v-if="row.url!==''"
            class="item"
            effect="dark"
            :content="row.url"
            placement="bottom-start">
            <div class="table-link">
              <a
                :href="row.url"
                style="text-decoration: underline;"
                class="link-hover">{{ row.url }}</a>
            </div>
          </lui-tooltip>
          <div v-else class="table-link">-</div>
        </template>
      </lui-table-column>
      <lui-table-column
        prop="updateTime"
        width="165"
        label="修改时间"
        show-overflow-tooltip>
      </lui-table-column>
      <lui-table-column
        prop="updateUser"
        label="操作人"
        show-overflow-tooltip>
      </lui-table-column>
      <lui-table-column
        prop="date"
        width="100"
        label="操作">
        <template slot-scope="{row}">
          <lui-button type="text" @click="editClick(row)">编辑</lui-button>
          <lui-button type="text" @click="deleteClick(row)">删除</lui-button>
        </template>
      </lui-table-column>
    </lui-table>
    <div
      v-show="totals>10"
      class="rotation-pagination">
      <lui-pagination
        background
        :current-page.sync="pageNum"
        :page-sizes="[10, 20, 50, 70, 100]"
        layout="prev, pager, next, sizes, jumper"
        :total="totals"
        @current-change="handleSizeChange"
        @size-change="sizeChange">
      </lui-pagination>
    </div>
    <!--  添加修改-->
    <lui-dialog
      :visible.sync="centerDialogVisible"
      width="60%"
      top="10vh"
      :show-close="false"
      :close-on-click-modal="false"
      custom-class="dialog_mask"
      title="轮播图配置">
      <lui-form
        ref="ruleForm"
        :model="ruleForm"
        :rules="rules"
        label-width="150px"
        class="demo-ruleForm">
        <lui-row :gutter="20">
          <lui-col :span="20">
            <lui-form-item
              label="轮播简介"
              prop="brief">
              <lui-input
                v-model="ruleForm.brief"
                placeholder="请输入轮播简介"></lui-input>
            </lui-form-item>
            <lui-form-item
              label="轮播位置"
              prop="position">
              <lui-select v-model="ruleForm.position" placeholder="请选择轮播位置" style="width: 100%;" @change="postionClick">
                <lui-option label="官网" value="1"></lui-option>
                <lui-option label="产品首页" value="2"></lui-option>
              </lui-select>
            </lui-form-item>

            <lui-form-item
              label="是否显示"
              prop="enabled">
              <lui-switch
                v-model="ruleForm.enabled"
                active-circle-class="1"
                active-color="rgba(60,110,240,.2)"
                inactive-color="rgba(142,145,152,.2)">
              </lui-switch>
            </lui-form-item>

            <lui-form-item
              label="轮播排序"
              prop="number">
              <lui-radio-group
                v-model="ruleForm.number"
                size="big"
                @change="numberClick">
                <lui-radio-button label="1"></lui-radio-button>
                <lui-radio-button label="2"></lui-radio-button>
                <lui-radio-button label="3"></lui-radio-button>
                <lui-radio-button label="4"></lui-radio-button>
                <lui-radio-button label="5"></lui-radio-button>
                <lui-radio-button label="6"></lui-radio-button>
              </lui-radio-group>
            </lui-form-item>

            <lui-form-item
              label="上传文件"
              class="upload_imgs"
              prop="picture">
              <lui-upload
                class="avatar-uploader"
                :action="baseURL+'img/upload'"
                accept=".jpg,.png,.gif"
                :show-file-list="false"
                :on-success="handleAvatarSuccess"
                :before-upload="beforeAvatarUpload">
                <img
                  v-if="ruleForm.picture"
                  :src="ruleForm.picture"
                  class="avatar">
                <div
                  v-else
                  slot="trigger"
                  v-loading="loadingimg"
                  class="add_contract">
                  <div class="contract_box">
                    <i class="lui-icon-plus avatar-uploader-icon"></i>
                  </div>
                </div>
              </lui-upload>
              <div
                v-if="ruleForm.picture"
                class="mask_background">
                <div class="mask_background_icon">
                  <lui-image
                    style="width: 20px; height: 20px"
                    :src="imgIcon"
                    :preview-src-list="srcList">
                  </lui-image>
                  <i
                    style="color: #0D6CA2"
                    class="lui-icon-delete"
                    @click="deleteImg"></i>
                </div>
              </div>
            </lui-form-item>

            <lui-form-item
              label="跳转链接"
              prop="url">
              <lui-input
                v-model.trim="ruleForm.url"
                placeholder="请输入链接地址">
              </lui-input>
            </lui-form-item>
          </lui-col>
        </lui-row>
      </lui-form>

      <div
        slot="footer"
        class="dialog-footer"
        style="text-align: center">
        <lui-button @click="resetForm('ruleForm')">取 消</lui-button>
        <lui-button
          :loading="loadingBut"
          type="primary"
          @click="submitForm('ruleForm')">确 定</lui-button>
      </div>

    </lui-dialog>
  </div>
</template>

<script>
import http from '@/lib/http'
import Api from '@/api'
import showEmptyImage from '@/components/common/showEmptyImage/index.vue'
import utils from '@/utils/utils'
import imgster from '@/assets/img/icon-looks.png'
export default {
  name: 'index',
  components: {
    showEmptyImage
  },
  data() {
    return {
      options: [{
        value: '1',
        label: '官网'
      }, {
        value: '2',
        label: '产品首页'
      }],
      loadingimg: false,
      loadingBut: false,
      imgIcon: imgster,
      srcList: [],
      baseURL: http.baseContextUrl,
      activeIndex: '1',
      dialogTableVisible: false,
      dialogFormVisible: false,
      centerDialogVisible: false,
      listLoading: true,
      totals: 0,
      pageNum: 1, //页
      pageSize: 10, //条数
      dialogImageUrl: '',
      dialogVisible: false,
      disabled: false,
      hideUpload: false,
      limitCount: 1,
      tableData: [],
      ruleForm: {
        brief: '', // 简介
        position: '', //位置
        enabled: false, //是否启用
        number: '', //位置下图片轮播顺利
        picture: '', //图片
        url: '' //链接
      },
      rules: {
        brief: [{ required: true, message: '请输入轮播简介', trigger: 'blur' }],
        position: [{ required: true, message: '请选择轮播位置', trigger: 'blur,change' }],
        enabled: [{ required: true, message: '是否显示', trigger: 'change' }],
        number: [{ required: true, message: '轮播排序', trigger: 'blur,change' }],
        picture: [{ required: true, message: '请上传图片', trigger: 'blur' }],
        url: [{ required: false, message: '请输入链接', trigger: 'change' }]
      },
      edit: false
    }
  },
  mounted() {
    this.getList()
  },
  methods: {
    //分页条数改变
    sizeChange(val) {
      this.pageSize = val
      this.getList()
    },
    //图片删除
    deleteImg() {
      this.ruleForm.picture = ''
      this.srcList = [] //清空图片预览
    },
    beforeAvatarUpload(file) {
      const isLt2M = file.size / 1024 / 1024 < 5
      if (!isLt2M) {
        this.$message.error('上传头像图片大小不能超过 5MB!')
        return isLt2M
      } else {
        this.loadingimg = true
        this.loadingBut = true
      }
    },
    //新增保存
    submitForm(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          this.loadingBut = true
          if (this.ruleForm.enabled) {
            this.ruleForm.enabled = 1
          } else {
            this.ruleForm.enabled = 0
          }
          if (this.edit) { //修改
            Api.BackStageRotation.bannerEdit({
              id: this.ruleForm.id,
              brief: this.ruleForm.brief, // 简介
              position: this.ruleForm.position, //位置
              enabled: this.ruleForm.enabled, //是否启用
              number: this.ruleForm.number, //位置下图片轮播顺利
              picture: this.ruleForm.picture, //图片
              url: this.ruleForm.url //链接
            }).then(row => {
              if (row.success) {
                this.$refs[formName].resetFields()
                this.centerDialogVisible = false //关闭弹窗
                this.edit = false
                this.getList()
                this.loadingBut = false
              }
            }).catch((e) => {
              this.loadingBut = false
              this.ruleForm.enabled = false
              this.$showErrorMsg(e)
            })
          } else { //新增
            Api.BackStageRotation.bannerAdd({
              brief: this.ruleForm.brief, // 简介
              position: this.ruleForm.position, //位置
              enabled: this.ruleForm.enabled, //是否启用
              number: this.ruleForm.number, //位置下图片轮播顺利
              picture: this.ruleForm.picture, //图片
              url: this.ruleForm.url //链接
            }).then(row => {
              if (row.success) {
                this.$refs[formName].resetFields()
                this.centerDialogVisible = false //关闭弹窗
                this.getList()
                this.loadingBut = false
              }
            }).catch((e) => {
              this.loadingBut = false
              this.ruleForm.enabled = false
              this.$showErrorMsg(e)
            })
          }
        } else {
          return
        }
      })
    },
    //新建取消按钮
    resetForm(formName) {
      this.$refs[formName].resetFields()
      this.centerDialogVisible = false //关闭弹窗
      this.srcList = []
    },
    // 获取列表
    getList() {
      this.listLoading = true
      Api.BackStageRotation.bannerListPage({
        pageSize: this.pageSize,
        pageNum: this.pageNum
      }).then(row => {
        if (row.success) {
          for (let i = 0; i < row.data.length; i++) {
            row.data[i].brief = utils.htmlDecode(row.data[i].brief)
            if (row.data[i].enabled === 0) {
              row.data[i].enabled = false
            } else {
              row.data[i].enabled = true
            }
          }
          this.tableData = row.data
          this.totals = row.total
          this.listLoading = false
        }
      }).catch((e) => { this.$showErrorMsg(e) })
    },
    //翻页-----根据页码变换
    handleSizeChange(val) {
      this.pageNum = val
      this.getList()
    },
    //是否显示
    setIfShowClick(row) {
      Api.BackStageRotation.bannerSetIfShow({
        enabled: row.enabled ? 1 : 0,
        id: row.id
      }).then(() => {
        this.$showSuccessMsg('设置成功')
      }).catch((e) => {
        this.getList()
        this.$showErrorMsg(e)
      })
    },
    //添加
    addClick() {
      this.centerDialogVisible = true
      this.edit = false
      // this.$refs.formName.resetFields()

      this.ruleForm = {
        brief: '', // 简介
        position: '', //位置
        enabled: false, //是否启用
        number: '', //位置下图片轮播顺利
        picture: '', //图片
        url: '' //链接
      }
    },
    //修改
    editClick(row) {
      // Api.BackStageRotation.bannerGet({id:row.id}).then(row=>{}).catch((e)=>{})
      this.centerDialogVisible = true
      this.edit = true
      this.ruleForm = {
        id: row.id,
        brief: row.brief, // 简介
        position: row.position, //位置
        enabled: row.enabled, //是否启用
        number: row.number, //位置下图片轮播顺利
        picture: row.picture, //图片
        url: row.url //链接
      }
      this.srcList.push(this.ruleForm.picture)
    },

    //删除
    deleteClick(row) {
      this.$alert('<p style="font-size: 18px;color:#333">确认删除此条轮播图吗?</p><p style="font-size: 13px;color: #666">删除后，轮播图的相关内容信息将无法恢复</p>', '', {
        dangerouslyUseHTMLString: true,
        type: 'warning',
        center: true
      }).then(() => {
        Api.BackStageRotation.bannerDelete({ id: row.id }).then(() => {
          this.$showSuccessMsg('删除成功')
          this.getList()
        }).catch((e) => { this.$showErrorMsg(e) })
      })
    },

    postionClick() {
      this.$refs.ruleForm.clearValidate('position')
    },

    numberClick() {
      this.$refs.ruleForm.clearValidate('number')
    },
    handleAvatarSuccess(res, file) {
      this.loadingimg = false
      this.loadingBut = false
      this.imageUrl = URL.createObjectURL(file.raw)
      this.ruleForm.picture = res.data
      this.srcList.push(this.ruleForm.picture)
      // this.$refs.ruleForm[''].clearValidate
      this.$refs.ruleForm.clearValidate('picture')
    }
  }
}
</script>
<style scoped lang="scss" rel="stylesheet/scss">
@import "@/assets/stylus/main.scss";
.rotation{
  background: #fff;
  width: 100%;
  min-height: 600px;
  padding-bottom: 26px;
  //padding-top: 20px;
  position: relative;

  .information-nav{
    width: 85%;
    margin: 0 auto;
    margin-bottom: 20px;
    .nav-menu{
      li{
        font-size: 14px;
      }
    }
  }
  .rotation-add{
    width: 85%;
    height: 50px;
    position: absolute;
    top: 49px;
    left: 7.5%;
    z-index: 1;
    .add-button{
      background: #fff;
      width: 99.8%;
      height: 50px;
      display: flex;
      cursor: pointer;
      justify-content: center;
      align-items: center;
      border: 1px dashed #c2c2c2;
      span{
        display: inline-block;
        height: 20px;
        line-height: 20px;
        font-size: 14px;
        color: #333;
      }
      span:nth-child(1){
        font-size: 12px;
        color: $--gl-blue;
        line-height: 18px;
        margin-right: 6px;
      }
    }
    .add-button:hover{
      background: #e7f0f6;
      border: 1px dashed $--gl-blue;
      span{
        display: inline-block;
        height: 20px;
        line-height: 20px;
        font-size: 14px;
        color: $--gl-blue;
      }
      span:nth-child(1){
        font-size: 12px;
        color: $--gl-blue;
        line-height: 18px;
        margin-right: 6px;
      }
    }
  }

  .rotation-pagination{
    width: 100%;
    margin-top: 73px;
    text-align: center;
  }
  .table-link{
    overflow: hidden;
    text-overflow:ellipsis;
    white-space: nowrap;
  }
  .table-p{
    overflow: hidden;
    text-overflow:ellipsis;
    white-space: nowrap;
    cursor: pointer;
    padding-right: 15px;
  }
  .table-icon{
    display: flex;
    justify-content: space-between;
    span{
      color: #1d76a8;
      cursor: pointer;
    }
  }
  .dialog-img{
    width: 100%;
    height: 100%;
    overflow: hidden;
    img{
      width: 100%;
      height: 100%;
      object-fit: cover;
    }
  }
}
/deep/ .lui-table__body{
  margin-top: 50px;
}
/deep/ .lui-radio-button__orig-radio:checked+.lui-radio-button__inner {
  color: #FFF;
  background-color: #3c6ef0;
  border-color: #3c6ef0;
  -webkit-box-shadow: -1px 0 0 0 #3c6ef0;
  box-shadow: -1px 0 0 0 #3c6ef0;
  padding-left: 25px;
  padding-right: 25px;
  border-radius: 4px;
}
/deep/ .lui-radio-button--big .lui-radio-button__inner {
  padding: 12px 15px;
  font-size: 14px;
  border-radius: 4px;
  margin-left: 7px;
  margin-right: 7px;
  padding-left: 25px;
  padding-right: 25px;
  border: 1px solid #ccc;
}
/deep/ .lui-radio-button--big .lui-radio-button__inner:nth-child(1) {
  margin-left: 0;
}
/deep/ .lui-radio-button--big .lui-radio-button__inner:nth-child(6) {
  margin-right: 0;
}
/deep/ .add_contract{
  width: 128px;
  height: 78px;
  position: relative;
  top: 1px;
  left: 1px;
  z-index: 1;
}
/deep/ .avatar-uploader .lui-upload {
  border: 1px dashed #d9d9d9;
  border-radius: 6px;
  cursor: pointer;
  position: relative;
  overflow: hidden;
}
.avatar-uploader .lui-upload:hover {
  border-color: #3C6EF0;
}
.avatar-uploader-icon {
  font-size: 28px;
  color: #999;
  width: 128px;
  height: 78px;
  line-height: 78px;
  text-align: center;
}
.avatar {
  width: 128px;
  height: 78px;
  object-fit: cover;
  display: block;
}
.mask_pic{
  width: 128px;
  height: 78px;
  position: relative;
  .mask{
    position: absolute;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    background: rgba(0,0,0,0.1);
    display: none;
  }
 &:hover{
   .mask{
     display: block;
   }
 }
}
.upload_imgs{
  position: relative;
}
.mask_background{
  width: 128px;
  height: 78px;
  position: absolute;
  top: 0;
  left: 0;
  z-index: 100;
  border-radius: 4px;
  overflow: hidden;
  .mask_background_icon{
    width: 128px;
    height: 78px;
    i{
      display: none;
    }
    /deep/ .lui-image__preview{
      display: none;
    }
    &:hover{
      background: rgba(255,255,255,0.7);
      display: flex;
      justify-content: center;
      align-items: center;
      i{
        display: inline-block;
        cursor: pointer;
        font-size: 20px;
        margin-left: 10px;
        &:hover{
          color: #0e6596;
        }
      }
      /deep/ .lui-image__preview{
        display: inline-block;
        cursor: pointer;
        margin-right: 10px;
      }
    }
  }
}
// /deep/ .lui-button--primary {
//   color: #FFF;
//   background-color: $--gl-blue;
//   border-color: $--gl-blue;
// }
</style>
