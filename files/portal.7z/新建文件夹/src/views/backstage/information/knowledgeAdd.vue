<template>
  <div class="AddNotice">
    <div class="AddNotic-title">
      <span @click="backClick">返回</span>
      <span>{{ Tinytitle }}</span>
      <span></span>
    </div>

    <div class="AddNotic-content">
      <lui-row>
        <lui-col :span="24">
          <lui-form
            ref="ruleForm"
            :model="ruleForm"
            :rules="rules"
            label-width="100px"
            class="demo-ruleForm"
          >
            <lui-form-item label="一级目录" prop="name">
              <lui-input v-model="ruleForm.name" placeholder="请输入一级目录"></lui-input>
            </lui-form-item>

            <lui-form-item label="正文内容" prop="content">
              <div>
                <!--<tinymce v-model="ruleForm.content" :height="300" />-->
                <tinymce-editor
                  ref="editor"
                  v-model="ruleForm.content"
                  :height="300"
                  plugins="lists table textcolor wordcount contextmenu colorpicker link image code powerpaste"
                  toolbar="undo redo | formatselect | bold italic forecolor | fontsizeselect fontselect | lineheightselect | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link unlink image | lists table | removeformat | pastetext | code">
                </tinymce-editor>
              </div>
            </lui-form-item>

            <lui-form-item v-show="showEdit" label="是否显示" prop="enabled">
              <lui-radio-group v-model="ruleForm.enabled">
                <lui-radio :label="1" class="button_radio">是</lui-radio>
                <lui-radio :label="0" class="button_radio">否</lui-radio>
              </lui-radio-group>
            </lui-form-item>

            <div class="ruleForm-button">
              <lui-button type="primary" :loading="listLoading" @click="submitForm('ruleForm')">确定</lui-button>
              <lui-button style="margin-right: 15px;" @click="centerDialogVisible=true">预览</lui-button>

              <lui-checkbox-group v-if="buttonShow" v-model="ruleForm.stageFlag" size="big">
                <lui-checkbox-button @change="buttonClicks('ruleForm')">存到草稿箱</lui-checkbox-button>
              </lui-checkbox-group>

            </div>
          </lui-form>
        </lui-col>
      </lui-row>
    </div>

    <!--    详情-->
    <lui-dialog
      :visible.sync="centerDialogVisible"
      width="50%"
      top="10vh"
      :close-on-click-modal="false"
      custom-class="dialog_mask"
      title="一级目录">
      <lui-form label-width="150px" class="demo-ruleForm">
        <lui-row :gutter="20" class="scrollBar" style="width: 95%;height: 500px;overflow-y: auto;margin-left: 5%;padding-right: 5%;">
          <div class="dialog-title">{{ ruleForm.name }}</div>
          <div v-dompurify-html="ruleForm.content" class="dialog-content" style="margin-top: 10px;"></div>
        </lui-row>
      </lui-form>
    </lui-dialog>
  </div>
</template>

<script>
import http from '@/lib/http'
import Api from '@/api'
import utils from '@/utils/utils'
import tinymce from 'tinymce/tinymce'
import TinymceEditor from '@/components/shared/TinymceEditor'

const cityOptions = ['存到草稿箱']
export default {
  name: '',
  components: {
    // Tinymce
    TinymceEditor
  },
  props: {
    headerUserName: {
      type: Number,
      default: null
    }
  },
  data() {
    return {
      listLoading: false,
      baseURL: http.baseContextUrl,
      centerDialogVisible: false,
      ruleForm: {
        name: '',
        content: '',
        enabled: '',
        stageFlag: ''
      },
      cities: cityOptions,
      checkboxGroup1: ['存到草稿箱'],
      rules: {
        name: [{ required: true, message: '请输入一级目录', trigger: 'blur' }],
        content: [
          { required: true, message: '请输入正文内容', trigger: 'blur' }
        ],
        enabled: [{ required: true, message: '请选择状态', trigger: 'change' }]
      },
      Ids: '',
      edit: false,
      buttonShow: true,
      showEdit: true,
      Tinytitle: '新增一级目录'
    }
  },
  mounted() {
    //根据id判断 if地址栏有ID则是编辑 else则是新增
    this.Ids = this.headerUserName
    if (this.Ids !== undefined && this.Ids !== null && this.Ids !== '') {
      this.edit = true
      this.Tinytitle = '编辑一级目录'
      this.showEdit = false
      this.buttonShow = false
      Api.BackStageKnowledge.knowledgeByid({ id: this.Ids }).then(rows => {
        if (rows.success) {
          this.ruleForm = {
            name: utils.htmlDecode(rows.data.label),
            content: utils.htmlDecode(rows.data.helpContent),
            enabled: rows.data.showFlag ? 1 : 0,
            stageFlag: rows.data.draftFlag ? false : true
          }
        } else {
          this.$showErrorMsg(rows.errMessage)
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
      })
    }
  },
  methods: {
    //数据查看
    getClik() {
      this.centerDialogVisible = true
    },
    buttonClicks(formName) {
      this.$alert('<p style="font-size: 18px;color:#333">确认存到草稿箱吗?</p>', '', {
        dangerouslyUseHTMLString: true,
        type: 'warning',
        center: true
      }).then(() => {
        this.submitForm(formName)
      }).catch(() => {
        this.ruleForm.stageFlag = false
        this.$message.error('存入草稿箱失败，请稍后再试')
      })
    },
    submitForm(formName) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          this.listLoading = true
          //将富文本内容转换为纯文本
          const text = tinymce.activeEditor.getContent({ 'format': 'text' })
          if (this.edit) { //编辑
            const params = {}
            params.label = this.ruleForm.name
            params.file = this.ruleForm.content
            params.helpText = text
            params.draftFlag = this.ruleForm.stageFlag ? 0 : 1
            params.level = 1
            // params.showFlag = this.ruleForm.enabled //编辑隐藏是否显示字段
            params.id = this.Ids
            Api.BackStageKnowledge.knowledgeEdit(params).then(row => {
              if (row.success) {
                this.$showSuccessMsg('编辑成功')
                this.$emit('event1', false)
                this.$bus.$emit('updateSearchHelp')//勿删，导航栏同步更新菜单
                this.listLoading = false
              } else {
                this.$showErrorMsg(row.errMessage)
              }
            }).catch((e) => {
              this.listLoading = false
              this.$showErrorMsg(e)
            })
          } else { //新增
            const params = {}
            params.label = this.ruleForm.name
            params.file = this.ruleForm.content
            params.helpText = text
            params.draftFlag = this.ruleForm.stageFlag ? 0 : 1
            params.level = 1
            params.pid = 0
            params.showFlag = this.ruleForm.enabled
            Api.BackStageKnowledge.knowledgeCreate(params).then(row => {
              if (row.success) {
                this.$showSuccessMsg('新增成功')
                this.$emit('event1', false)
                this.$bus.$emit('updateSearchHelp')//勿删，导航栏同步更新菜单
                this.listLoading = false
              } else {
                this.$showErrorMsg(row.errMessage)
              }
            }).catch(e => {
              this.listLoading = false
              this.$showErrorMsg(e)
            })
          }
        } else {
          this.ruleForm.stageFlag = false
          return false
        }
      })
    },
    backClick() {
      this.$emit('event1', false)
    }
  }
}
</script>

<style scoped lang="scss" rel="stylesheet">
 @import "@/assets/stylus/main.scss";
.AddNotice {
    background: #fff;
    width: 100%;
    padding-bottom: 26px;
    padding-top: 20px;
    .AddNotic-title {
        width: 80%;
        margin: 0 auto;
        padding-bottom: 10px;
        border-bottom: 1px solid #D9D9D9;
        display: flex;
        justify-content: space-between;
        span {
            color: #333;
        }
        span:nth-child(1) {
            display: inline-block;
            width: 70px;
            height: 30px;
            border: 1px solid #D9D9D9;
            border-radius: 4px;
            line-height: 30px;
            text-align: center;
            font-size: 12px;
            cursor: pointer;
        }
        span:nth-child(2) {
            font-size: 14px;
        }
    }
    .AddNotic-content {
        width: 800px;
        margin: 0 auto;
        margin-top: 50px;
    }
}

.ruleForm-button {
    width: 100%;
    display: flex;
    justify-content: center;
    margin-top: 50px;
}

.lui-row {
    margin-bottom: 20px;
    &:last-child {
        margin-bottom: 0;
    }
}

.lui-col {
    border-radius: 4px;
}

.bg-purple-dark {
    background: #99a9bf;
}

.bg-purple {
    background: #d3dce6;
}

.bg-purple-light {
    background: #e5e9f2;
}

.grid-content {
    border-radius: 4px;
    min-height: 36px;
}

.row-bg {
    padding: 10px 0;
    background-color: #f9fafc;
}
/deep/ .lui-checkbox-button:last-child .lui-checkbox-button__inner {
    border-radius: 4px;
}
.dialog-title{
    cursor: pointer;
    font-size: 20px;
    color: #333;
    font-weight: 500;
    &:hover{
        color: $--gl-blue;
    }
}

</style>
