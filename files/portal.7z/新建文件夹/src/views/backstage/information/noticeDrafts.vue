<template>
  <div class="drafts">
    <div v-if="darftsMain" class="darfts-main">
      <div class="drafts-title">
        <div>
          <span @click="backClick">返回</span>
        </div>
        <div>草稿箱</div>
        <div></div>
      </div>
      <lui-table
        v-loading="listLoading"
        :data="tableData"
        class="dartfs-table"
        style="width: 85%;margin: 0 auto;">
        <template slot="empty">
          <showEmptyImage></showEmptyImage>
        </template>
        <lui-table-column
          prop="id"
          label="ID"
          width="90"
          show-overflow-tooltip>
        </lui-table-column>

        <lui-table-column
          prop="title"
          label="公告标题"
          show-overflow-tooltip>
        </lui-table-column>
        <lui-table-column
          show-overflow-tooltip
          prop="text"
          label="公告正文">
        </lui-table-column>

        <lui-table-column
          prop="noticeUrl"
          label="公告链接"
          show-overflow-tooltip>
        </lui-table-column>

        <lui-table-column
          prop="updateTime"
          width="170"
          label="修改时间"
          show-overflow-tooltip>
        </lui-table-column>

        <lui-table-column
          prop="updateUser"
          label="操作人"
          show-overflow-tooltip>
        </lui-table-column>

        <lui-table-column
          prop="date"
          width="135"
          label="操作">
          <template slot-scope="{row}">
            <lui-button type="text" @click="getClik(row)">查看</lui-button>
            <lui-button type="text" @click="editClick(row)">编辑</lui-button>
            <lui-button type="text" @click="deleteClick(row)">删除</lui-button>
          </template>
        </lui-table-column>
      </lui-table>
      <div v-show="totals>10" class="drafts-pagination">
        <lui-pagination
          background
          :current-page.sync="pageNum"
          :page-sizes="[10, 20, 50, 70, 100]"
          layout="prev, pager, next, sizes, jumper"
          :total="totals"
          @current-change="handleSizeChange"
          @size-change="sizeChange"
        ></lui-pagination>
      </div>
    </div>

    <!--    详情-->
    <lui-dialog
      :visible.sync="centerDialogVisible"
      width="60%"
      top="10vh"
      :close-on-click-modal="false"
      :lock-scroll="false"
      :append-to-body="true"
      custom-class="dialog_mask"
      title="公告详情">
      <lui-form
        ref="ruleForm"
        label-width="150px"
        class="demo-ruleForm">
        <lui-row
          :gutter="20"
          class="scrollBar"
          style="width: 95%;height: 500px;overflow-y: auto;margin-left: 5%;padding-right: 5%;">
          <div
            class="dialog-title">{{ ruleForm.title }}</div>
          <div
            class="dialog-time"
            style="font-size: 13px;color: #999;margin-top: 10px;">{{ ruleForm.time }}</div>
          <div
            v-dompurify-html="ruleForm.content"
            class="dialog-content"
            style="margin-top: 10px;"></div>
        </lui-row>
      </lui-form>
    </lui-dialog>

    <DarftsEdit v-if="darftsEditShow" :header-user-name="headerUserName" @eventDraftsEdit="draftsEditChange($event)"></DarftsEdit>
  </div>
</template>

<script>
import Api from '@/api'
import utils from '@/utils/utils'
import showEmptyImage from '@/components/common/showEmptyImage/index.vue'
import DarftsEdit from './noticeDraftsAdd'
export default {
  name: 'index',
  components: {
    showEmptyImage,
    DarftsEdit
  },
  data() {
    return {
      headerUserName: null,
      darftsEditShow: false,
      darftsMain: true,
      pageNum: 1,
      pageSize: 10,
      totals: 0,
      tableData: [],
      listLoading: true,
      centerDialogVisible: false,
      ruleForm: {
        title: '',
        time: '',
        content: ''
      }
    }
  },
  mounted() {
    this.getList()
  },
  methods: {
    //接收子组建传参
    draftsEditChange(data) {
      if (!data) {
        this.darftsMain = true
        this.darftsEditShow = data
        this.getList()
      }
    },
    //返回上一级
    backClick() {
      // this.$router.back()
      this.$emit('eventDrafts', false)
    },
    //编辑
    editClick(row) {
      this.headerUserName = row.id
      this.darftsEditShow = true
      this.darftsMain = false
      // this.$router.push({ 'path': '/information/notice/draftsEdit', query: { id: row.id }})
    },
    //删除数据
    deleteClick(row) {
      this.$alert('<p style="font-size: 18px;color:#333">确认删除此条公告吗?</p><p style="font-size: 13px;color: #666">删除后，公告的相关内容信息将无法恢复</p>', '', {
        dangerouslyUseHTMLString: true,
        type: 'warning',
        center: true
      }).then(() => {
        Api.BackStageNotice.manageNoticeDel({ id: row.id }).then(row => {
          if (row.success) {
            this.$message({
              message: '删除成功',
              type: 'success'
            })
            this.getList()
          } else {
            this.$message.error('删除失败，请稍后再试')
          }
        }).catch((e) => {
          this.$showErrorMsg(e)
        })
      })
    },
    //显示
    // 数据是否显示
    setIfShowClick(row) {
      Api.BackStageNotice.manageNoticeSetIfShow({
        id: row.id,
        showFlag: row.showFlag ? 1 : 0
      }).then(() => {
        this.$showSuccessMsg('设置成功')
      }).catch((e) => {
        row.showFlag = false
        this.$showErrorMsg(e)
      })
    },
    //是否置顶
    placementClick(row) {
      Api.BackStageNotice.manageNoticePlacement({
        id: row.id,
        topFlag: row.topFlag ? 1 : 0
      }).then(() => {
        this.$showSuccessMsg('设置成功')
      }).catch((e) => {
        row.topFlag = false
        this.$showErrorMsg(e)
      })
    },
    getClik(row) {
      this.listLoading = true
      this.ruleForm = {
        title: '',
        time: '',
        content: ''
      }
      Api.BackStageNotice.manageInfoById({ id: row.id }).then(rows => {
        if (rows.success) {
          const cont = this.html_decode(rows.data.content)
          this.ruleForm.title = utils.htmlDecode(rows.data.title)
          this.ruleForm.time = rows.data.updateTime
          this.ruleForm.content = cont
          this.centerDialogVisible = true
          this.listLoading = false
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
        this.listLoading = false
      })
    },
    //列表
    getList() {
      Api.BackStageNotice.manageNoticeList({
        pageSize: this.pageSize,
        pageNum: this.pageNum,
        stageFlag: 0
      }).then(row => {
        if (row.success) {
          for (let i = 0; i < row.data.length; i++) {
            row.data[i].text = utils.htmlDecode(row.data[i].text)
            row.data[i].title = utils.htmlDecode(row.data[i].title)
            if (row.data[i].showFlag === 0) {
              row.data[i].showFlag = false
            } else {
              row.data[i].showFlag = true
            }
          }
          this.tableData = row.data
          this.totals = row.total
          this.listLoading = false
        } else {
          this.$showErrorMsg(row.errMessage)
        }
      }).catch((e) => { this.$showErrorMsg(e) })
    },
    //分页条数改变
    sizeChange(val) {
      this.pageSize = val
      this.getList()
    },
    //翻页-----根据页码变换
    handleSizeChange(val) {
      this.pageNum = val
      this.getList()
    },
    //数据查看
    html_decode(str) { //html转义
      let s = ''
      if (str.length === 0) return ''
      s = str.replace(/&amp;/g, '&')
      s = s.replace(/&lt;/g, '<')
      s = s.replace(/&gt;/g, '>')
      s = s.replace(/&nbsp;/g, ' ')
      s = s.replace(/&#39;/g, "\'")
      s = s.replace(/&quot;/g, '"')
      s = s.replace(/< img/g, '<img')
      s = s.replace(/<br\/>/g, '\n')
      return s
    }
  }
}
</script>

<style scoped lang="scss" rel="stylesheet/scss">

@import "@/assets/stylus/main.scss";
.drafts{
  background: #fff;
  width: 100%;
  min-height: 600px;
  padding-bottom: 26px;
  padding-top: 35px;
}
.icon-buttons{
  display: flex;
  justify-content: space-between;
  span{
    cursor: pointer;
    color: $--gl-blue;
  }
}
.table-icon{
  display: flex;
  justify-content: space-between;
  span{
    color: #1d76a8;
    cursor: pointer;
  }
}
.table-link{
  overflow: hidden;
  text-overflow:ellipsis;
  white-space: nowrap;
}
.drafts-title{
  width: 85%;
  height: 40px;
  margin: 0 auto;
  display: flex;
  justify-content: space-between;
  justify-items: center;
}
.drafts-title div{
  font-size: 16px;
}
.drafts-title span:nth-child(1){
  font-size: 12px;
  cursor: pointer;
  display: inline;
  padding: 4px 17px;
  border: 1px solid #e9e9e9;
  border-radius: 3px;
  color: #999
}
.drafts-pagination{
  width: 100%;
  margin-top: 73px;
  text-align: center;
}
.table-p{
  overflow: hidden;
  text-overflow:ellipsis;
  white-space: nowrap;
  cursor: pointer;
  padding-right: 15px;
}
.dialog-title{
  cursor: pointer;
  font-size: 20px;
  color: #333;
  font-weight: 500;
  &:hover{
    color: $--gl-blue;
  }
}

.dartfs-table {
  /deep/ .lui-table__body-wrapper{
    margin-top: -50px;
  }
}
</style>
