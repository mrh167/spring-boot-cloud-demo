<template>
  <div class="AddNotice">
    <div class="AddNotic-title">
      <span @click="backClick">返回</span>
      <span>{{ titleName }}</span>
      <span></span>
    </div>

    <div v-loading="loadingPage" class="AddNotic-content">
      <lui-row>
        <lui-col :span="24">
          <lui-form
            ref="ruleForm"
            :model="ruleForm"
            :rules="rules"
            label-width="100px"
            class="demo-ruleForm"
          >
            <lui-form-item label="公告名称" prop="name">
              <lui-input
                v-model="ruleForm.name"
                maxlength="32"
                show-word-limit
                placeholder="请输入公告名称"></lui-input>
            </lui-form-item>

            <lui-form-item
              label="公告位置"
              prop="position">
              <lui-select v-model="ruleForm.position" placeholder="请选择轮播位置" style="width: 100%;" @change="postionClick">
                <lui-option label="官网" value="1"></lui-option>
                <lui-option label="产品首页" value="2"></lui-option>
              </lui-select>
            </lui-form-item>

            <lui-form-item
              label="上传文件"
              class="upload_imgs"
              prop="picture">
              <lui-upload
                class="avatar-uploader"
                :action="baseURL+'img/upload'"
                accept=".jpg,.png,.gif"
                :show-file-list="false"
                :on-success="handleAvatarSuccess"
                :before-upload="beforeAvatarUpload">
                <img
                  v-if="ruleForm.picture"
                  :src="ruleForm.picture"
                  class="avatar">
                <div
                  v-else
                  slot="trigger"
                  v-loading="loadingimg"
                  class="add_contract">
                  <div class="contract_box">
                    <i class="lui-icon-plus avatar-uploader-icon"></i>
                  </div>
                </div>
              </lui-upload>
              <div
                v-if="ruleForm.picture"
                class="mask_background">
                <div class="mask_background_icon">
                  <lui-image
                    style="width: 20px; height: 20px"
                    :src="imgIcon"
                    :preview-src-list="srcList">
                  </lui-image>
                  <i
                    style="color: #0D6CA2"
                    class="lui-icon-delete"
                    @click="deleteImg"></i>
                </div>
              </div>
            </lui-form-item>

            <lui-form-item label="公告正文" prop="content">
              <div>
                <!--<tinymce v-model="ruleForm.content" :height="300" />-->
                <tinymce-editor
                  ref="editor"
                  v-model="ruleForm.content"
                  :height="300">
                </tinymce-editor>
              </div>
            </lui-form-item>

            <lui-form-item label="是否生效" prop="enabled">
              <lui-radio-group v-model="ruleForm.enabled">
                <lui-radio :label="1" class="button_radio">是</lui-radio>
                <lui-radio :label="0" class="button_radio">否</lui-radio>
              </lui-radio-group>
            </lui-form-item>

            <lui-form-item label="跳转链接" prop="jump">
              <lui-input v-model.trim="ruleForm.jump" placeholder="请输入链接地址">
              </lui-input>
            </lui-form-item>

            <div class="ruleForm-button">
              <lui-button :loading="listLoading" type="primary" @click="submitForm('ruleForm')">确定</lui-button>
              <lui-button style="margin-right: 15px;" @click="centerDialogVisible=true">预览</lui-button>

              <lui-checkbox-group v-model="ruleForm.stageFlag" size="big">
                <lui-checkbox-button v-if="buttonShow" :loading="listLoading" @change="buttonClicks('ruleForm')">存到草稿箱</lui-checkbox-button>
              </lui-checkbox-group>

            </div>
          </lui-form>
        </lui-col>
      </lui-row>
    </div>

    <!--    详情-->
    <lui-dialog
      :visible.sync="centerDialogVisible"
      width="60%"
      top="10vh"
      :close-on-click-modal="false"
      custom-class="dialog_mask"
      title="公告">
      <lui-form label-width="150px" class="demo-ruleForm">
        <lui-row :gutter="20" class="scrollBar" style="width: 95%;height: 500px;overflow-y: auto;margin-left: 5%;padding-right: 5%;">
          <div class="dialog-title">{{ ruleForm.name }}</div>
          <div v-dompurify-html="ruleForm.content" class="dialog-content" style="margin-top: 10px;"></div>
        </lui-row>
      </lui-form>
    </lui-dialog>
  </div>
</template>

<script>
import http from '@/lib/http'
import Api from '@/api'
import utils from '@/utils/utils'
import tinymce from 'tinymce/tinymce'
import TinymceEditor from '@/components/shared/TinymceEditor'
import imgster from '@/assets/img/icon-looks.png'
const cityOptions = ['存到草稿箱']
export default {
  name: '',
  components: {
    TinymceEditor
  },
  props: {
    headerUserName: {
      type: Number,
      default: null
    }
  },
  data() {
    return {
      imgIcon: imgster,
      loadingimg: false,
      loadingPage: false,
      srcList: [],
      listLoading: false,
      titleName: '新增公告',
      baseURL: http.baseContextUrl,
      centerDialogVisible: false,
      ruleForm: {
        name: '',
        position: '',
        content: '',
        enabled: '',
        jump: '',
        stageFlag: '',
        picture: ''
      },
      cities: cityOptions,
      checkboxGroup1: ['存到草稿箱'],
      rules: {
        position: [{ required: true, message: '请选择公告位置', trigger: 'change' }],
        picture: [{ required: true, message: '请上传图片', trigger: 'blur' }],
        name: [{ required: true, message: '请输入活动名称', trigger: 'blur' }],
        content: [
          { required: true, message: '请输入公告正文', trigger: 'blur' }
        ],
        enabled: [{ required: true, message: '请选择状态', trigger: 'change' }],
        jump: [{ required: false, message: '请输入跳转链接', trigger: 'blur' }]
      },
      Ids: '',
      edit: false,
      buttonShow: true
    }
  },
  mounted() {
    //根据id判断 if地址栏有ID则是编辑 else则是新增
    this.Ids = this.headerUserName
    if (this.Ids !== undefined && this.Ids !== null && this.Ids !== '') {
      this.edit = true
      this.loadingPage = true
      this.buttonShow = false
      this.titleName = '编辑公告'
      Api.BackStageNotice.manageInfoById({ id: this.Ids }).then(rows => {
        if (rows.success) {
          this.ruleForm = {
            name: utils.htmlDecode(rows.data.title),
            content: utils.htmlDecode(rows.data.content),
            position: rows.data.position.toString(),
            picture: rows.data.thumbnail,
            enabled: rows.data.showFlag ? 1 : 0,
            jump: rows.data.noticeUrl,
            stageFlag: rows.data.stageFlag ? false : true
          }
          this.srcList.push(this.ruleForm.picture)
          this.loadingPage = false
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
        this.loadingPage = false
      })
    }
  },
  methods: {
    //图片删除
    deleteImg() {
      this.ruleForm.picture = ''
      this.srcList = [] //清空图片预览
    },
    handleAvatarSuccess(res, file) {
      this.loadingimg = false
      this.loadingBut = false
      this.imageUrl = URL.createObjectURL(file.raw)
      this.ruleForm.picture = res.data
      this.srcList.push(this.ruleForm.picture)
      this.$refs.ruleForm.clearValidate('picture')
    },
    beforeAvatarUpload(file) {
      const isLt2M = file.size / 1024 / 1024 < 5
      if (!isLt2M) {
        this.$message.error('上传头像图片大小不能超过 5MB!')
        return isLt2M
      } else {
        this.loadingimg = true
        this.loadingBut = true
      }
    },
    //轮播位置序言中
    postionClick() {
      this.$refs.ruleForm.clearValidate('position')
    },
    //数据查看
    getClik() {
      this.centerDialogVisible = true
    },
    buttonClicks(formName) {
      this.$alert('<p style="font-size: 18px;color:#333">确认存到草稿箱吗?</p>', '', {
        dangerouslyUseHTMLString: true,
        type: 'warning',
        center: true
      }).then(() => {
        this.submitForm(formName, 1)
      }).catch(() => {
        this.ruleForm.stageFlag = false
        this.$message.error('存入草稿箱失败，请稍后再试')
      })
    },
    submitForm(formName, type) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          //将富文本内容转换为纯文本
          const text = tinymce.activeEditor.getContent({ 'format': 'text' })
          //检测表情
          let param = text
          const regRule = /\uD83C[\uDF00-\uDFFF]|\uD83D[\uDC00-\uDE4F]/g
          if (param.match(regRule)) {
            param = param.replace(/\uD83C[\uDF00-\uDFFF]|\uD83D[\uDC00-\uDE4F]/g, '')
          }
          //检测表情
          this.listLoading = true
          if (this.edit) { //编辑
            const params = {}
            params.title = this.ruleForm.name
            params.id = this.Ids
            params.text = param
            params.showFlag = this.ruleForm.enabled
            params.noticeUrl = this.ruleForm.jump
            params.file = this.ruleForm.content
            params.abstracts = param.substring(0, 29)
            params.thumbnail = this.ruleForm.picture
            params.position = this.ruleForm.position
            params.stageFlag = this.ruleForm.stageFlag ? 0 : 1
            Api.BackStageNotice.manageNoticeEdit(params).then(row => {
              if (row.success) {
                this.$showSuccessMsg('修改成功')
                this.listLoading = false
                this.$emit('event1', false) //传参给父组件改变状态
              }
            }).catch((e) => {
              this.$showErrorMsg(e)
              this.listLoading = false
            })
          } else { //新增

            const params = {}
            params.title = this.ruleForm.name
            params.text = param
            params.showFlag = this.ruleForm.enabled
            params.noticeUrl = this.ruleForm.jump
            params.file = this.ruleForm.content
            params.abstracts = param.substring(1, 30)
            params.thumbnail = this.ruleForm.picture
            params.position = this.ruleForm.position
            params.stageFlag = this.ruleForm.stageFlag ? 0 : 1
            Api.BackStageNotice.manageNoticeAdd(params).then(row => {
              if (row.success) {
                if (type === 1) {
                  this.$showSuccessMsg('存入草稿')
                } else {
                  this.$showSuccessMsg('新增成功')
                }
                this.listLoading = false
                this.$emit('event1', false)
              }
            }).catch(e => {
              this.$showErrorMsg(e)
              this.listLoading = false
            })
          }
        } else {
          this.ruleForm.stageFlag = false
          return false
        }
      })
    },
    backClick() {
      this.$emit('event1', false)
    }
  }
}
</script>

<style scoped lang="scss" rel="stylesheet">

@import "@/assets/stylus/main.scss";


.AddNotice {
    background: #fff;
    width: 100%;
    padding-bottom: 26px;
    padding-top: 50px;
    .AddNotic-title {
        width: 80%;
        margin: 0 auto;
        padding-bottom: 10px;
        border-bottom: 1px solid #D9D9D9;
        display: flex;
        justify-content: space-between;
        span {
            color: #333;
        }
        span:nth-child(1) {
            display: inline-block;
            width: 70px;
            height: 30px;
            border: 1px solid #D9D9D9;
            border-radius: 4px;
            line-height: 30px;
            text-align: center;
            font-size: 12px;
            cursor: pointer;
        }
        span:nth-child(2) {
            font-size: 14px;
        }
    }
    .AddNotic-content {
        width: 800px;
        margin: 0 auto;
        margin-top: 50px;
    }
}

.ruleForm-button {
    width: 100%;
    display: flex;
    justify-content: center;
    margin-top: 50px;
}

.lui-row {
    margin-bottom: 20px;
    &:last-child {
        margin-bottom: 0;
    }
}

.lui-col {
    border-radius: 4px;
}

.bg-purple-dark {
    background: #99a9bf;
}

.bg-purple {
    background: #d3dce6;
}

.bg-purple-light {
    background: #e5e9f2;
}

.grid-content {
    border-radius: 4px;
    min-height: 36px;
}

.row-bg {
    padding: 10px 0;
    background-color: #f9fafc;
}
/deep/ .lui-checkbox-button:last-child .lui-checkbox-button__inner {
    border-radius: 4px;
}
.dialog-title{
    cursor: pointer;
    font-size: 20px;
    color: #333;
    font-weight: 500;
    &:hover{
        color: $--gl-blue;
    }
}

//  图片上传
/deep/ .add_contract{
    width: 128px;
    height: 78px;
    position: relative;
    top: 1px;
    left: 1px;
    z-index: 1;
}
/deep/ .avatar-uploader .lui-upload {
    border: 1px dashed #d9d9d9;
    border-radius: 6px;
    cursor: pointer;
    position: relative;
    overflow: hidden;
}
.avatar-uploader .lui-upload:hover {
    border-color: #3C6EF0;
}
.avatar-uploader-icon {
    font-size: 28px;
    color: #999;
    width: 128px;
    height: 78px;
    line-height: 78px;
    text-align: center;
}
.avatar {
    width: 128px;
    height: 78px;
    object-fit: cover;
    display: block;
}
.mask_pic{
    width: 128px;
    height: 78px;
    position: relative;
    .mask{
        position: absolute;
        top: 0;
        bottom: 0;
        left: 0;
        right: 0;
        background: rgba(0,0,0,0.1);
        display: none;
    }
    &:hover{
        .mask{
            display: block;
        }
    }
}
.upload_imgs{
    position: relative;
}
.mask_background{
    width: 128px;
    height: 78px;
    position: absolute;
    top: 0;
    left: 0;
    z-index: 100;
    border-radius: 4px;
    overflow: hidden;
    .mask_background_icon{
        width: 128px;
        height: 78px;
        i{
            display: none;
        }
        /deep/ .lui-image__preview{
            display: none;
        }
        &:hover{
            background: rgba(0,0,0,0.2);
            display: flex;
            justify-content: center;
            align-items: center;
            i{
                display: inline-block;
                cursor: pointer;
                font-size: 20px;
                margin-left: 10px;
                &:hover{
                    color: #0e6596;
                }
            }
            /deep/ .lui-image__preview{
                display: inline-block;
                cursor: pointer;
                margin-right: 10px;
            }
        }
    }

}

</style>
