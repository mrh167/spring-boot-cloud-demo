<template>
  <div class="knowledge">
    <div v-if="noticeCont">
      <div class="knowledge-title">
        <div>
          <span @click="draftsClick">
            <i class="lui-icon-document-empty"></i>草稿箱
          </span>
        </div>
        <div></div>
        <div></div>
      </div>

      <div class="rotation-add">
        <div
          class="add-button"
          @click="addClick">
          <span class="lui-icon-plus"></span>
          <span>新增一级目录</span>
        </div>
      </div>
      <lui-table
        ref="table"
        v-loading="LoadingOne"
        :data="tableData"
        style="width: 85%;margin: 0 auto "
        :expand-row-keys="expands"
        :row-key="getRowKeys"
        @expand-change="exChange"
      >
        <template slot="empty">
          <showEmptyImage></showEmptyImage>
        </template>
        <!--二级目录开始-->
        <lui-table-column
          prop="childer"
          type="expand">
          <template slot-scope="props">
            <div class="rotation-add-two">
              <div
                class="add-button"
                @click="twoAddition(props.row.id)">
                <span class="lui-icon-plus"></span>
                <span>新增二级目录</span>
              </div>
            </div>
            <lui-table
              ref="tableTwo"
              v-loading="LoadingTwo"
              :data="childers.data"
              :expand-row-keys="expandsThree"
              :row-key="getRowKeyThree"
              style="margin-top: -20px;width: 100%;"
              @expand-change="exChangeThree">
              <template slot="empty">
                <!--              <showEmptyImage class="showEmpty"></showEmptyImage>-->
              </template>
              <!--三级目录开始-->
              <!--            <lui-table-column-->
              <!--              prop="childer"-->
              <!--              type="expand">-->
              <!--              <template slot-scope="{row}">-->
              <!--                <div class="rotation-add-two">-->
              <!--                  <div-->
              <!--                    class="add-button"-->
              <!--                    @click="thrteeAddition(row.id)">-->
              <!--                    <span class="lui-icon-plus"></span>-->
              <!--                    <span>新增三级目录</span>-->
              <!--                  </div>-->
              <!--                </div>-->
              <!--                <lui-table-->
              <!--                  v-loading="LoadingThree"-->
              <!--                  :data="childersThree.data"-->
              <!--                  style="margin-top: -20px; width: 100%;">-->
              <!--                  <template slot="empty">-->
              <!--                    <showEmptyImage></showEmptyImage>-->
              <!--                  </template>-->

              <!--                  <lui-table-column-->
              <!--                    prop="id"-->
              <!--                    label="三级目录ID"-->
              <!--                    width="120">-->
              <!--                    <template slot-scope="{row}">-->
              <!--                      <p class="table-p">{{ row.id }}</p>-->
              <!--                    </template>-->
              <!--                  </lui-table-column>-->
              <!--                  <lui-table-column-->
              <!--                    prop="label"-->
              <!--                    label="三级目录名称">-->
              <!--                    <template slot-scope="{row}">-->
              <!--                      <p class="table-p">{{ row.label }}</p>-->
              <!--                    </template>-->
              <!--                  </lui-table-column>-->
              <!--                  <lui-table-column-->
              <!--                    width="80"-->
              <!--                    label="是否显示">-->
              <!--                    <template slot-scope="{row}">-->
              <!--                      <lui-switch-->
              <!--                        v-model="row.showFlag"-->
              <!--                        active-circle-class="1"-->
              <!--                        active-color="rgba(60,110,240,.2)"-->
              <!--                        inactive-color="rgba(142,145,152,.2)"-->
              <!--                        @change="switchClickThree(row)">-->
              <!--                      </lui-switch>-->
              <!--                    </template>-->
              <!--                  </lui-table-column>-->

              <!--                  <lui-table-column-->
              <!--                    width="180"-->
              <!--                    label="操作时间">-->
              <!--                    <template slot-scope="{row}">-->
              <!--                      <p class="table-p">{{ row.updateTime }}</p>-->
              <!--                    </template>-->
              <!--                  </lui-table-column>-->

              <!--                  <lui-table-column label="操作人" width="120">-->
              <!--                    <template slot-scope="{row}">-->
              <!--                      <p class="table-p">{{ row.updateUser }}</p>-->
              <!--                    </template>-->
              <!--                  </lui-table-column>-->

              <!--                  <lui-table-column-->
              <!--                    width="150"-->
              <!--                    label="操作">-->
              <!--                    <template slot-scope="{row}">-->
              <!--                      <div class="knowledge-caozuo">-->
              <!--                        <span>-->
              <!--                          <lui-tooltip-->
              <!--                            class="item"-->
              <!--                            effect="dark"-->
              <!--                            content="置顶"-->
              <!--                            placement="bottom">-->
              <!--
                                              @click="topClickThree(row)" />-->
              <!--                          </lui-tooltip>-->
              <!--                        </span>-->
              <!--                        <span>-->
              <!--                          <lui-tooltip-->
              <!--                            class="item"-->
              <!--                            effect="dark"-->
              <!--                            content="查看"-->
              <!--                            placement="bottom">-->
              <!--                            <img-->
              <!--                              src="../../../../assets/img/icon-looks.png"-->
              <!--                              alt-->
              <!--                              @click="getClikThree(row)" />-->
              <!--                          </lui-tooltip>-->
              <!--                        </span>-->
              <!--                        <span>-->
              <!--                          <lui-tooltip-->
              <!--                            class="item"-->
              <!--                            effect="dark"-->
              <!--                            content="编辑"-->
              <!--                            placement="bottom">-->
              <!--                            <img-->
              <!--                              src="../../../../assets/img/icon－edit.png"-->
              <!--                              alt-->
              <!--                              @click="editClickThree(row)" />-->
              <!--                          </lui-tooltip>-->
              <!--                        </span>-->
              <!--                        <span>-->
              <!--                          <lui-tooltip-->
              <!--                            class="item"-->
              <!--                            effect="dark"-->
              <!--                            content="删除"-->
              <!--                            placement="bottom">-->
              <!--                            <img-->
              <!--                              src="../../../../assets/img/icon－dele.png"-->
              <!--                              alt-->
              <!--                              @click="delClickThree(row)" />-->
              <!--                          </lui-tooltip>-->
              <!--                        </span>-->
              <!--                      </div>-->
              <!--                    </template>-->
              <!--                  </lui-table-column>-->
              <!--                </lui-table>-->
              <!--                <div v-show="childersThree.total>0" class="knowledge-pagination-two">-->
              <!--                  <lui-pagination-->
              <!--                    background-->
              <!--                    :current-page.sync="pageNumThree"-->
              <!--                    :page-sizes="[5, 10, 20, 30, 40]"-->
              <!--                    :page-size.sync="pageSizeThree"-->
              <!--                    layout="prev, pager, next, sizes, jumper"-->
              <!--                    :total="childersThree.total"-->
              <!--                    @current-change="handleSizeChangeThree"-->
              <!--                    @size-change="sizeChangeThree"-->
              <!--                  >-->
              <!--                  </lui-pagination>-->
              <!--                </div>-->
              <!--              </template>-->

              <!--            </lui-table-column>-->
              <!--三级目录结束-->

              <lui-table-column
                prop="id"
                label="二级目录ID"
                width="120"
                show-overflow-tooltip>
              </lui-table-column>
              <lui-table-column
                prop="label"
                label="二级目录名称"
                show-overflow-tooltip>
              </lui-table-column>
              <lui-table-column
                width="80"
                label="是否显示">
                <template slot-scope="{row}">
                  <lui-switch
                    v-model="row.showFlag"
                    active-circle-class="1"
                    active-color="rgba(60,110,240,.2)"
                    inactive-color="rgba(142,145,152,.2)"
                    @change="switchClickTwo(row)">
                  </lui-switch>
                </template>
              </lui-table-column>

              <lui-table-column
                prop="updateTime"
                width="180"
                label="操作时间"
                show-overflow-tooltip>
              </lui-table-column>

              <lui-table-column
                label="操作人"
                width="120"
                
                prop="updateUser"
                show-overflow-tooltip>
              </lui-table-column>

              <lui-table-column
                width="175"
                label="操作">
                <template slot-scope="{row}">
                  <lui-button type="text" @click="topClickTwo(row)">置顶</lui-button>
                  <lui-button type="text" @click="getClikTwo(row)">查看</lui-button>
                  <lui-button type="text" @click="editClickTwo(row)">编辑</lui-button>
                  <lui-button type="text" @click="delClickTwo(row)">删除</lui-button>
                </template>
              </lui-table-column>
            </lui-table>
            <div v-show="childers.total>5" class="knowledge-pagination-two">
              <lui-pagination
                background
                :current-page.sync="pageNumtwo"
                :page-sizes="[5, 10, 20, 30, 40]"
                :page-size.sync="pageSizetwo"
                layout="prev, pager, next, sizes, jumper"
                :total="childers.total"
                @current-change="handleSizeChangeTwo"
                @size-change="sizeChangeTwo"
              >
              </lui-pagination>
            </div>
          </template>
        </lui-table-column>
        <!--二级目录结束-->
        <lui-table-column
          prop="id"
          label="一级ID"
          width="120"
          show-overflow-tooltip>
          <!-- <template slot-scope="{row}">
            <p class="table-p">{{ row.id }}</p>
          </template> -->
        </lui-table-column>
        <lui-table-column
          prop="label"
          label="一级目录名称"
          show-overflow-tooltip>
          <!-- <template slot-scope="{row}">
            <lui-tooltip
              class="item"
              effect="dark"
              :content="row.label"
              placement="bottom-start">
              <p class="table-p">{{ row.label }}</p>
            </lui-tooltip>
          </template> -->
        </lui-table-column>
        <lui-table-column
          min-width="80"
          label="是否显示">
          <template slot-scope="{row}">
            <lui-switch
              v-model="row.showFlag"
              active-circle-class="1"
              active-color="rgba(60,110,240,.2)"
              inactive-color="rgba(142,145,152,.2)"
              @change="switchClick(row)">
            </lui-switch>
          </template>
        </lui-table-column>

        <lui-table-column
          width="170"
          prop="updateTime"
          label="操作时间"
          show-overflow-tooltip>
          <!-- <template slot-scope="{row}">
            <p class="table-p">{{ row.updateTime }}</p>
          </template> -->
        </lui-table-column>

        <lui-table-column label="操作人" width="120">
          <template slot-scope="{row}">
            <lui-tooltip
              class="item"
              effect="dark"
              :content="row.updateUser"
              placement="bottom-start">
              <p class="table-p">{{ row.updateUser }}</p>
            </lui-tooltip>
          </template>
        </lui-table-column>

        <lui-table-column
          width="240"
          label="操作">
          <template slot-scope="{row}">
            <lui-button type="text" @click="topClick(row)">置顶</lui-button>
            <lui-button type="text" @click="getClik(row)">查看</lui-button>
            <lui-button type="text" @click="toogleExpand(row)">二级目录</lui-button>
            <lui-button type="text" @click="editClick(row)">编辑</lui-button>
            <lui-button type="text" @click="delClick(row)">删除</lui-button>
          </template>
        </lui-table-column>
      </lui-table>

      <div v-show="totals>10" class="knowledge-pagination">
        <lui-pagination
          background
          :current-page.sync="pageNum"
          :page-sizes="[10, 20, 50, 70, 100]"
          layout="prev, pager, next, sizes, jumper"
          :total="totals"
          @current-change="handleSizeChange"
          @size-change="sizeChange"
        >
        </lui-pagination>
      </div>
    </div>
    <!--新增一级目录-->
    <AddKnowledgs v-if="addShow" :header-user-name="headerUserName" @event1="change($event)"></AddKnowledgs>
    <!--    新增二级目录-->
    <AddSecond v-if="addSecond" :header-user-name="headerUserName" @event1="change($event)"></AddSecond>
    <!--  草稿箱-->
    <Drafts v-if="draftShow" @eventDrafts="draftsChange($event)"></Drafts>
    <!--    详情-->
    <lui-dialog
      :visible.sync="centerDialogVisible"
      width="60%"
      top="10vh"
      :close-on-click-modal="false"
      custom-class="dialog_mask"
      title="目录详情">
      <lui-form
        ref="ruleForm"
        label-width="150px"
        class="demo-ruleForm">
        <lui-row
          :gutter="20"
          class="scrollBar"
          style="width: 95%;height: 500px;overflow-y: auto;margin-left: 5%;padding-right: 5%;">
          <div
            class="dialog-title">{{ ruleForm.title }}</div>
          <div
            class="dialog-time"
            style="font-size: 13px;color: #999;margin-top: 10px;">{{ ruleForm.time }}</div>
          <div
            v-dompurify-html="ruleForm.content"
            class="dialog-content"
            style="margin-top: 10px"></div>
        </lui-row>
      </lui-form>
    </lui-dialog>
  </div>
</template>

<script>
import Api from '@/api'
import utils from '@/utils/utils'
import showEmptyImage from '@/components/common/showEmptyImage/index.vue'
import AddKnowledgs from './knowledgeAdd'
import AddSecond from './knowledgeAddTwo'
import Drafts from './knowledgeDrafts'

export default {
  name: 'index',
  components: {
    showEmptyImage,
    AddKnowledgs,
    AddSecond,
    Drafts
  },
  data() {
    return {
      draftShow: false,
      headerUserName: null,
      noticeCont: true,
      addShow: false,
      addSecond: false,
      LoadingOne: false,
      LoadingTwo: false,
      LoadingThree: false,
      activeIndex: '2',
      centerDialogVisible: false,
      totals: 0,
      pageNum: 1, //页
      pageSize: 10, //条数
      tableData: [], //一级数据
      totalstwo: 0,
      pageNumtwo: 1, //页
      pageSizetwo: 5, //条数
      pids: '',
      childers: '', //二级数据
      expands: [], //只展开一行放入当前行id
      expandsThree: [], //只展开一行放入当前行id===>二级表格
      getRowKeys: (row) => { ///获取当前行id
        return row.id //这里看这一行中需要根据哪个属性值是id
      },
      childersThree: '', //三级数据
      threeId: '', //三级ID
      totalsThree: 0,
      pageNumThree: 1, //页
      pageSizeThree: 5, //条数
      getRowKeyThree: (row) => { ///获取二级表格当前行id
        return row.id //这里看这一行中需要根据哪个属性值是id
      },
      ruleForm: {
        title: '',
        time: '',
        content: ''
      }
    }
  },
  mounted() {
    // 一级列表获取
    this.getListOne()
  },
  methods: {

    //接收草稿箱传参
    draftsChange(data) {
      if (!data) {
        this.noticeCont = true
        this.draftShow = false
        const params = { //传参给上级父组件
          show: true,
          arrInt: '2'
        }
        this.$emit('event1', params)
        this.getListOne()
      }
    },
    //接受子组建参数改变状态
    change(data) {
      if (!data) {
        this.noticeCont = true
        this.addShow = false
        this.addSecond = false
        const params = { //传参给上级父组件
          show: true,
          arrInt: '2'
        }
        this.$emit('event1', params)
        this.getListOne()
        this.getList()
        this.$bus.emit('updateSearchHelp')
      }
    },

    draftsClick() { //草稿箱
      this.$emit('event1', false)
      this.draftShow = true
      this.noticeCont = false
    },
    toogleExpand(row) {
      const $table = this.$refs.table
      $table.toggleRowExpansion(row)
    },

    //查看
    getClikLook(row) { //数据查看
      this.ruleForm = {
        title: '',
        time: '',
        content: ''
      }
      Api.BackStageKnowledge.knowledgeByid({ id: row.id }).then(rows => {
        if (rows.success) {
          const cont = utils.htmlDecode(rows.data.helpContent)
          this.ruleForm.title = utils.htmlDecode(rows.data.label)
          this.ruleForm.time = rows.data.updateTime
          this.ruleForm.content = cont
          this.centerDialogVisible = true
        } else {
          this.$showErrorMsg(row.errMessage)
        }
      }).catch((e) => { this.$showErrorMsg(e) })
      //  待定页面
    },
    //删除
    del(row, obj) {
      this.$alert('<p style="font-size: 18px;color:#333">确认删除此条目录吗?</p><p style="font-size: 13px;color: #666">删除后，目录的相关内容信息将无法恢复</p>', '', {
        dangerouslyUseHTMLString: true,
        type: 'warning',
        center: true
      }).then(() => {
        Api.BackStageKnowledge.knowledgeDele({ id: row.id }).then(row => {
          if (row.success) {
            this.$bus.$emit('updateSearchHelp')//勿删，导航栏同步更新菜单
            this.$showSuccessMsg('删除成功')
            if (obj === 1) { //一级
              this.getListOne()
            } else if (obj === 2) {
              this.getList()
            } else {
              this.getListThree()
            }
          }
        }).catch((e) => { this.$showErrorMsg(e) })
      })
    },
    //置顶
    top(row, obj) { //置顶
      Api.BackStageKnowledge.knowledgeTop({ id: row.id }).then(row => {
        if (row.success) {
          this.$showSuccessMsg('置顶成功')
          if (obj === 1) {
            this.getListOne()
          } else if (obj === 2) {
            this.getList()
          } else {
            this.getListThree()
          }
        } else {
          this.$showErrorMsg(row.errMessage)
        }
      }).catch((e) => { this.$showErrorMsg(e) })
    },
    //显示
    switchs(row, obj) { //显示
      Api.BackStageKnowledge.knowledgeShow({
        id: row.id,
        showFlag: row.showFlag ? 1 : 0
      }).then(() => {
        this.$bus.emit('updateSearchHelp') //刷新菜单
        this.$showSuccessMsg('设置成功')
        if (obj === 1) {
          this.LoadingOne = false
        } else if (obj === 2) {
          this.LoadingTwo = false
        } else {
          this.LoadingThree = false
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
        if (obj === 1) {
          this.LoadingOne = true
          this.getListOne() //一级目录
        } else if (obj === 2) {
          this.LoadingTwo = true
          this.getList() //二级目录
        } else {
          this.LoadingThree = true
          this.getListThree() //三级目录
        }

      })
    },
    //==================================================一级目录
    //添加
    addClick() { //添加
      // this.$router.push({ 'path': '/information/FirstAddition' })
      this.headerUserName = null
      this.$emit('event1', false)
      this.addShow = true
      this.noticeCont = false
    },
    editClick(row) { //修改
      // this.$router.push({ 'path': '/information/FirstAddition', query: { id: row.id }})
      this.headerUserName = row.id
      this.$emit('event1', false)
      this.addShow = true
      this.noticeCont = false
    },
    delClick(row) { //删除
      this.del(row, 1)
    },
    topClick(row) { //置顶
      this.top(row, 1)
    },
    switchClick(row) { //是否显示
      this.LoadingOne = true
      this.switchs(row, 1)
    },
    getClik(row) {
      this.getClikLook(row)
    },

    // 一级列表获取
    getListOne() {
      this.LoadingOne = true
      Api.BackStageKnowledge.knowledgeList({
        pageSize: this.pageSize,
        pageNum: this.pageNum,
        level: 1,
        pid: 0
      }).then(row => {
        if (row.success) {
          for (let i = 0; i < row.data.length; i++) {
            row.data[i].label = utils.htmlDecode(row.data[i].label)
            row.data[i].childer = {}
            if (row.data[i].showFlag === 0) {
              row.data[i].showFlag = false
            } else {
              row.data[i].showFlag = true
            }
          }
          this.tableData = row.data
          this.totals = row.total
          this.LoadingOne = false
        }
      }).catch((e) => { this.$showErrorMsg(e) })
    },
    //分页条数改变
    sizeChange(val) {
      this.pageSize = val
      this.getListOne()
    },
    //翻页-----根据页码变换
    handleSizeChange(val) {
      this.pageNum = val
      this.getListOne()
    },

    //================================================================二级目录
    toogleExpandThree(row) { //点击查看3级目录
      const $table = this.$refs.tableTwo
      $table.toggleRowExpansion(row)
    },
    topClickTwo(row) { //置顶
      this.top(row, 2)
    },
    delClickTwo(row) { //删除
      this.del(row, 2)
    },
    switchClickTwo(row) { //显示
      this.switchs(row, 2)
    },
    editClickTwo(row) { //编辑
      const params = {}
      params.id = row.id
      params.type = 1
      this.headerUserName = params
      this.$emit('event1', false)
      this.addSecond = true
      this.noticeCont = false
    },
    twoAddition(row) { //新增
      const params = {}
      params.id = row
      this.headerUserName = params
      this.$emit('event1', false)
      this.addSecond = true
      this.noticeCont = false
    },
    getClikTwo(row) {
      this.getClikLook(row)
    },
    exChange(row, rowList) {
      var that = this
      if (rowList.length) { // 只展开一行//说明展开了
        that.expands = []
        if (row) {
          that.expands.push(row.id)// 只展开当前行id
        }
        that.pageSizetwo = 5
        that.pageNumtwo = 1
        that.pids = row.id
        that.childers = row
        that.getList() // 这里可以调用接口数据渲染
      } else { // 说明收起了
        that.expands = []
      }
    },
    getList() {
      this.LoadingTwo = true
      Api.BackStageKnowledge.knowledgeList({
        pageSize: this.pageSizetwo,
        pageNum: this.pageNumtwo,
        level: 2,
        pid: this.pids
      }).then(row => {
        if (row.success) {
          for (let i = 0; i < row.data.length; i++) {
            row.data[i].label = utils.htmlDecode(row.data[i].label)
            if (row.data[i].showFlag === 0) {
              row.data[i].showFlag = false
            } else {
              row.data[i].showFlag = true
            }
          }
          this.childers = row
          this.LoadingTwo = false
        }
      }).catch((e) => {})
    },
    //分页条数改变
    sizeChangeTwo(val) {
      this.pageSizetwo = val
      this.getList()
    },
    //翻页-----根据页码变换
    handleSizeChangeTwo(val) {
      this.pageNumtwo = val
      this.getList()
    },
    //============================================================================三级目录
    thrteeAddition(row) { //新增
      this.$router.push({ 'path': '/information/ThreeAddition', query: { id: row }})
    },
    editClickThree(row) { //编辑row
      this.$router.push({ 'path': '/information/ThreeAddition', query: { id: row.id, type: 1 }})
    },

    topClickThree(row) { //置顶
      this.top(row, 3)
    },
    delClickThree(row) { //删除
      this.del(row, 3)
    },
    switchClickThree(row) { //显示
      this.switchs(row, 3)
    },
    exChangeThree(row, rowList) {
      var that = this
      if (rowList.length) { // 只展开一行//说明展开了
        that.expandsThree = []
        if (row) {
          that.expandsThree.push(row.id)// 只展开当前行id
        }
        that.pageSizeThree = 5
        that.pageNumThree = 1
        that.threeId = row.id
        that.childersThree = row
        that. getListThree() // 这里可以调用接口数据渲染

      } else { // 说明收起了
        that.expandsThree = []
      }
    },
    getListThree() {
      this.LoadingThree = true
      Api.BackStageKnowledge.knowledgeList({
        pageSize: this.pageSizeThree,
        pageNum: this.pageNumThree,
        level: 3,
        pid: this.threeId
      }).then(row => {
        if (row.success) {
          for (let i = 0; i < row.data.length; i++) {
            if (row.data[i].showFlag === 0) {
              row.data[i].showFlag = false
            } else {
              row.data[i].showFlag = true
            }
          }
          this.childersThree = row
          this.LoadingThree = false
        }
      }).catch((e) => {})
    },
    //分页条数改变
    sizeChangeThree(val) {
      this.pageSizeThree = val
      this.getListThree()
    },
    //翻页-----根据页码变换
    handleSizeChangeThree(val) {
      this.pageNumThree = val
      this.getListThree()
    }

  }
}
</script>

<style scoped lang="scss" rel="stylesheet/scss">
@import "@/assets/stylus/main.scss";


.knowledge {
    background: #fff;
    width: 100%;
    min-height: 600px;
    padding-bottom: 26px;
    //padding-top: 20px;
    position: relative;
    .rotation-add{
        width: 85%;
        height: 50px;
        position: absolute;
        top: 88px;
        left: 7.5%;
        z-index: 1;
        .add-button{
            background: #fff;
            width: 100%;
            height: 50px;
            display: flex;
            cursor: pointer;
            justify-content: center;
            align-items: center;
            border: 1px dashed #c2c2c2;
            span{
                display: inline-block;
                height: 20px;
                line-height: 20px;
                font-size: 14px;
                color: #333;
            }
            span:nth-child(1){
                font-size: 12px;
                color: $--gl-blue;
                line-height: 18px;
                margin-right: 6px;
            }
        }
        .add-button:hover{
            background: #e7f0f6;
            border: 1px dashed $--gl-blue;
            span{
                display: inline-block;
                height: 20px;
                line-height: 20px;
                font-size: 14px;
                color: $--gl-blue;
            }
            span:nth-child(1){
                font-size: 12px;
                color: $--gl-blue;
                line-height: 18px;
                margin-right: 6px;
            }
        }
    }
    .information-nav {
        width: 85%;
        margin: 0 auto;
        margin-bottom: 20px;
        .nav-menu {
            li {
                font-size: 14px;
            }
        }
    }
    .knowledge-title {
        width: 85%;
        height: 40px;
        margin: 0 auto;
        display: flex;
        justify-content: space-between;
        justify-items: center;
        div {
            font-size: 16px;
            span:nth-child(1) {
                font-size: 12px;
                cursor: pointer;
                display: inline-block;
                width: 120px;
                height: 30px;
                border: 1px solid #e9e9e9;
                border-radius: 3px;
                color: #434343;
                line-height: 30px;
                text-align: center;
                i {
                    font-size: 12px;
                    padding-right: 5px;
                }
            }
        }
    }
    .knowledge-pagination {
        width: 100%;
        margin-top: 73px;
        text-align: center;
    }
    .table-p {
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        cursor: pointer;
        padding-right: 15px;
    }
    .knowledge-caozuo {
        display: flex;
        justify-content: space-between;
        align-items: center;
        cursor: pointer;
    }
}
.dialog-title{
    cursor: pointer;
    font-size: 20px;
    color: #333;
    font-weight: 500;
    &:hover{
        color: $--gl-blue;
    }
}

/deep/ .lui-table__body{
    margin-top: 50px;
}
.knowledge .rotation-add-two {
    width: 100%;
    height: 50px;
    position: absolute;
    top: 48px;
    /* left: 10%; */
    z-index: 1;
    .add-button{
        background: #fff;
        width: 100%;
        height: 50px;
        display: flex;
        cursor: pointer;
        justify-content: center;
        align-items: center;
        border: 1px dashed #c2c2c2;
        span{
            display: inline-block;
            height: 20px;
            line-height: 20px;
            font-size: 14px;
            color: #333;
        }
        span:nth-child(1){
            font-size: 12px;
            color: $--gl-blue;
            line-height: 18px;
            margin-right: 6px;
        }
    }
    .add-button:hover{
        background: #e7f0f6;
        border: 1px dashed $--gl-blue;
        span{
            display: inline-block;
            height: 20px;
            line-height: 20px;
            font-size: 14px;
            color: $--gl-blue;
        }
        span:nth-child(1){
            font-size: 12px;
            color: $--gl-blue;
            line-height: 18px;
            margin-right: 6px;
        }
    }
}
.knowledge .knowledge-pagination-two{
    width: 100%;
    margin-top: 30px;
    text-align: center;
}
/deep/ .lui-table__expanded-cell[class*=cell] {
     padding: 20px 0;
}

</style>
