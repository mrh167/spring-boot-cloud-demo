<template>
  <div class="workApproval">
    <!-- 暂无数据展示 -->
    <div v-if="pageNullShow" class="pageNullShow">
      <div class="imgBox">
        <img src="@/assets/img/tableBanner.png" alt="">
        <p>暂无数据</p>
      </div>
    </div>

    <div v-else>
      <div v-if="editableTabs.length>0" id="bar" class="container-nav">
        <!-- 解决页面没有加载出来还能吸顶问题   当条件满足barFixed == true && loadingPage==false 开启吸顶模式 -->
        <div :class="barFixed == true && loadingPage==false ? 'isFixed' :''">
          <lui-tabs v-model="editableTabsValue" @tab-click="handleClick">
            <lui-tab-pane
              v-for="(item) in editableTabs"
              :key="item.code"
              :label="item.tabName"
              :name="item.code">
              <template slot="label">
                {{ item.tabName }}
                <lui-badge v-if="item.pendingNum>0" :value="item.pendingNum" :max="99" class="item" />
              </template>
            </lui-tab-pane>
          </lui-tabs>
        </div>

        <!-- 筛选条件 如果没有则隐藏该功能 -->
        <div v-loading="loadingPage" class="container-body" style="min-height: 150px">
          <Search
            v-if="showTable"
            :table-search="tableSearch"
            @handleSearch="searchClick"
            @handleQueryUnit="handleQueryUnit"
            @handleChanges="handleChanges"
            @handleSelect="handleSelect" />
        </div>
      </div>
      <!-- 列表数据 如果没有则隐藏该功能 -->
      <div

        class="container-content">
        <ButtonList
          v-if="buttonShow"
          :table-button="tableButton"
          @handelClick="handelClick" />

        <ButtonList
          v-else />
        <!-- 表格列表 -->
        <flight-table
          v-if="showTable"
          :loading-show="loadingShow"
          :table-data="tableData"
          :page-size="pageSize"
          :page-num="pageNum"
          :columns="columns"
          @handleSelectionChange="handleSelectionChange"
          @handleEdit="handleEdit" />
        <!-- 翻页 -->
        <pagination
          v-if="pageShow && showTable"
          :page-sizes="pageSizes"
          :total="total"
          :page-size="pageSize"
          @handleSizeChange="handleSizeChange"
          @handleCurrentChange="handleCurrentChange" />
      </div>

    </div>


    <!-- 详情 -->
    <lui-dialog
      v-if="dialogVisible"
      :visible.sync="dialogVisible"
      width="70%"
      top="10vh"
      :close-on-click-modal="false"
      title="详情">
      <lui-row>
        <lui-col :span="24"><h1 class="h1">{{ detailsText.title }}</h1></lui-col>
      </lui-row>
      <!-- 主表数据 -->
      <lui-row>
        <lui-col v-for="(item,index) in mainColList" :key="index" :span="12" class="col-span">
          <span class="title-span">{{ item.name }}：</span>
          <span class="title-span">{{ item.code }}</span>
        </lui-col>
      </lui-row>
      <!-- 附件 -->
      <lui-row>
        <lui-col v-for="(item,index) in detailsText.attachments" :key="index" :span="12" class="col-span">
          <span class="title-span">附件：</span>
          <a :href="item.fileUrl" class="title-span">{{ item.fileName }}</a>
        </lui-col>
      </lui-row>
      <!-- 子表动态表格 -->
      <div v-for="(item,index) in getDetailColumns" :key="index">
        <p class="table-title">{{ item[0].title }}</p>
        <flight-table
          :table-data="getDetailTable[index]"
          :columns="item"
        ></flight-table>
      </div>
      <!-- 审批记录 -->
      <div style="margin-top: 50px;">
        <flight-table
          :table-data="approveNodeTable"
          :columns="approveNodeColumns"
        ></flight-table>
      </div>

      <div style="margin-top:20px">
        <p style="margin-bottom: 10px;">审批意见</p>
        <lui-input
          v-model="comments"
          style="width: 50%;"
          type="textarea"
          :rows="2"
          maxlength="50"
          show-word-limit
          placeholder="请输入审批意见">
        </lui-input>
      </div>
      <span slot="footer" class="dialog-footer">
        <lui-button :disabled="approveNodeJson.state!==0" type="primary" @click="handleClickBy(1)">通 过</lui-button>
        <lui-button :disabled="approveNodeJson.state!==0" type="danger" @click="handleClickBy(3)">驳 回</lui-button>
        <lui-button @click="dialogVisible=false">关 闭</lui-button>
      </span>
    </lui-dialog>
    <!-- 批量操作 -->
    <lui-dialog
      :visible.sync="deletedVisible"
      width="55%"
      top="10vh"
      :close-on-click-modal="false"
      :title="titleTop">
      <lui-table
        :data="deletedData"
        size="mini"
        border
        style="width: 100%">
        <lui-table-column
          align="center"
          label="序号"
          width="50">
          <template v-slot="scope">
            <span>{{ scope.$index+1 }}</span>
          </template>
        </lui-table-column>
        <lui-table-column
          align="center"
          prop="tip"
          width="175"
          label="申请单号">
        </lui-table-column>
        <lui-table-column
          align="center"
          prop="msg"
          label="提示信息">
        </lui-table-column>
      </lui-table>
    </lui-dialog>

    <div v-if="loadingst" class="mask">
      <div class="mask-box">
        <p class="spanIcon"><i class="lui-icon-loading"></i></p>
        <p>{{ branches }} / {{ article }}</p>
        <p>{{ content }}</p>
      </div>
    </div>
  </div>
</template>

<script async>
import Search from './components/search'
import ButtonList from '@/components/common/button'
import pagination from '@/components/common/pagination'
import flightTable from '@/components/common/table'
import utils from '@/utils/utils'
import { mapGetters } from 'vuex'
import Api from '@/api'
const d = new Date()
let date1 = d.getFullYear() + '-' + (d.getMonth() > 8 ? d.getMonth() + 1 : '0' + (d.getMonth() + 1)) + '-' + (d.getDate() > 9 ? d.getDate() : '0' + d.getDate()) + ' ' + '23' + ':' + '59' + ':' + '59'
let date0 = d.getFullYear() + '-' + (d.getMonth() > 8 ? d.getMonth() + 1 : '0' + (d.getMonth() + 1)) + '-' + '01' + ' ' + '00' + ':' + '00' + ':' + '00'
export default {
  components: {
    Search,
    flightTable,
    ButtonList,
    pagination
  },
  data() {
    return {
      pageNullShow: false,
      buttonShow: true,
      loadingst: false,
      pageShow: true,
      multipleSelection: [],
      deletedData: [], //错误数据
      deletedVisible: false,
      titleTop: '',
      pendingNum: 0, // 当前气泡
      timer: null,
      showTable: true,
      loadingPage: false,
      bizNo: '',
      comments: '', //审批意见
      billTypeCode: '',
      barFixed: false,
      editableTabsValue: '', //tabs默认值
      editableTabs: [],
      clientHeight: 0,
      scrollTop: 0,
      tableSearch: [],
      pageSize: 10,
      pageNum: 1,
      pageSizes: [10, 20, 50, 100],
      total: 0,
      tableData: [],
      columns: [],
      loadingShow: false,
      dataJson: {}, //获取文本检索框信息
      dynamicParams: [],
      dialogVisible: false,
      detailsText: {},
      mainColList: [],
      getDetailTable: [],
      getDetailColumns: [],
      approveNodeTable: [],
      approveNodeJson: {},
      deptNo: '', //事业部
      dataType: 1, //分类
      applicantNo: '', // 申请单号
      applicant: '', //申请人
      applicantTime: [date0, date1], // 申请时间
      processInstanceNo: '', // 审批单号
      tableButton: [
        {
          label: '批量通过',
          type: 'primary',
          id: '1'
        },
        {
          label: '批量驳回',
          id: '3',
          type: 'danger'
        }
      ],
      approveNodeColumns: [ //详情底部table格式
        {
          id: 'text',
          type: 'text',
          label: '任务名称',
          prop: 'nodeDisplayName'
        },
        {
          id: 'text',
          type: 'text',
          label: '审批人编码',
          prop: 'approver'
        },
        {
          id: 'text',
          type: 'text',
          label: '审批人名称',
          prop: 'approverName'
        },
        {
          id: 'text',
          type: 'text',
          label: '审批状态',
          prop: 'stateName'
        },
        {
          id: 'text',
          type: 'text',
          label: '审批意见',
          prop: 'comment'
        },
        {
          id: 'text',
          type: 'text',
          label: '审批完成时间',
          prop: 'finishTime'
        }
      ],
      dataWork: [],
      items: null,
      branches: 0,
      article: 0, //总共上传数量
      content: '操作中...'
    }
  },
  computed: {
    ...mapGetters(['getIsBookmark']) //vuex 获取收藏夹是否展开  用于菜单吸顶功能
  },
  watch: {
    //当收藏夹发生变化时触发 判断吸顶高度
    'getIsBookmark': function(val) {
      const isFixed = document.getElementsByClassName('isFixed')[0]
      if (isFixed) {
        if (val) {
          isFixed.style.top = 110 + 'px'
        } else {
          isFixed.style.top = 60 + 'px'
        }
      }
    }
  },
  mounted() {
    // tabs 加载
    this.getTab()
    //接口实时刷新
    this.dynamePun()
    // this.setLoading()
    // if ('WebSocket' in window) {
    //   // const websocket = new WebSocket()
    //   console.log('link success')
    // } else {
    //   alert('Not support websocket')
    // }
  },
  destroyed() { // 销毁滑动事件
    let box = document.getElementsByClassName('main-wrapper')[0]
    box.removeEventListener('scroll', this.handleScroll, true)
    //销毁定时器
    clearInterval(this.timer) //清空定时器
    this.timer = null
    //进度加载
    clearInterval(this.items)
    this.items = null
  },
  methods: {

    handleChanges(item, val) {
      if (item.value === 'dataType') {
        if (val !== 1) {
          this.buttonShow = false
        } else {
          this.buttonShow = true
        }
      }
    },


    setLoading() {
      this.loadingst = true
      clearInterval(this.timer) //清空定时器
      this.timer = null
      clearInterval(this.items)
      this.items = null
      //定义秒速
      let cont = 500
      // if (this.article <= 3) {
      //   cont = 2000
      // } else if (this.article > 3 && this.article <= 5) {
      //   cont = 1800
      // } else if (this.article > 5 && this.article <= 10) {
      //   cont = 1700
      // } else {
      //   cont = 1600
      // }

      this.items = setInterval(() => {
        this.branches++
        if (this.branches === this.article) {
          this.content = '操作完成'
        }
        if (this.branches > this.article) {
          this.branches = this.article
          clearInterval(this.items)
          this.items = null
          this.dynamePun()
          this.loadingst = false
          if (this.dataWork.errorCount > 0) {
            this.deletedData = this.dataWork.detaileds
            this.deletedVisible = true
          } else {
            this.$showSuccessMsg('操作成功')
            this.dynamicListPage()
          }
          return
        }
      }, cont)
    },
    //实时数据
    dynamePun() {
      clearInterval(this.timer) //清空定时器
      this.timer = null
      this.timer = setInterval(() => {
        Api.WorkApproval.dynamicTabs().then(res => {
          if (res.success) {
            this.editableTabs = res.data
            for (let i in res.data) {
              // 判断当前标签页
              if (this.editableTabsValue === res.data[i].code) {
                // 如果当前气泡值不等于当前气泡值说明数据需要更新
                if (this.pendingNum !== res.data[i].pendingNum) {
                  // 更新当前气泡值
                  this.pendingNum = res.data[i].pendingNum
                  // 刷新列表
                  this.dynamicListPage()
                }
              }
            }
          }
        }).catch((e) => { this.$showErrorMsg(e) })
        this.dynamePun()
      }, 3500)
    },
    //批量通过、驳回
    handelClick(val) {
      if (this.multipleSelection.length === 0) {
        this.$showErrorMsg('请选择数据')
        return
      }
      //定时加载需要
      this.article = this.multipleSelection.length
      this.content = '操作中...'
      this.branches = 0
      let title = ''
      if (val.type === '1') {
        this.titleTop = '批量通过错误信息提示'
        title = '确定批量通过吗？'
      } else {
        this.titleTop = '批量驳回错误信息提示'
        title = '确定批量驳回吗？'
      }
      this.$alert('<p style="font-size: 18px;color:#333">' + title + '</p><p style="font-size: 13px;color: #666"></p>', '', {
        dangerouslyUseHTMLString: true,
        type: 'warning',
        center: true
      }).then(() => {
        var crrId = []
        for (let i = 0; i < this.multipleSelection.length; i++) {
          crrId.push(this.multipleSelection[i].bizNo)
        }
        // -----------------------
        const params = {}
        params.approvalResult = Number(val.type)
        params.comments = null
        params.bizNoList = crrId
        //进度加载
        this.setLoading()
        Api.WorkApproval.submitApprovalBatch(params).then(res => {
          if (res.success) {
            this.dataWork = res.data
            // if (res.data.errorCount > 0) {
            //   this.deletedData = res.data.detaileds
            //   this.deletedVisible = true
            // } else {
            //   this.$showSuccessMsg('操作成功')
            // }
          }
        }).catch((e) => { this.$showErrorMsg(e) })
      }).catch(() => {})
    },
    //多选
    handleSelectionChange(val) {
      this.multipleSelection = val.val
    },
    //枚举接口
    enumQuery() {
      Api.Common.enumQuery({ code: 'dataType' }).then(res => {
        if (res.success) {
          this.tableSearch.forEach(item => {
            if (item.value === 'dataType') {
              this.dataType = res.data[0].code
              item.children = res.data
            }
          })
        }
      }).catch((e) => { this.$showErrorMsg(e) })
    },
    //事业部
    queryDept() {
      Api.Common.queryDept().then(res => {
        if (res.success) {
          this.tableSearch.forEach(item => {
            if (item.value === 'deptNo') {
              item.children = res.data
            }
          })
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
      })
    },

    //动态页签获取
    getTab() {
      Api.WorkApproval.dynamicTabs().then(res => {
        if (res.success) {
        //如果为空则退出
          if (res.data.length < 1) {
            this.pageNullShow = true
            return
          } else {
            this.pageNullShow = false
          }

          this.editableTabs = res.data
          //初始化页面默认值
          this.editableTabsValue = res.data.length > 0 ? res.data[0].code : ''
          //获取气泡值
          this.pendingNum = res.data.length > 0 ? res.data[0].pendingNum : 0
          //当页面加载渲染查询条件
          this.dynamicFilterBox(this.editableTabsValue)
          //如果title tab 不为空的时候开启菜单吸顶模式
          if (this.editableTabs.length > 0) {
            this.scrollPage()
          }
        }
      }).catch((e) => { this.$showErrorMsg(e) })
    },
    //点击动态菜单切换条件
    handleClick(targetName) {
      this.buttonShow = true
      // 点击切换获取当前气泡值
      this.pendingNum = this.editableTabs[targetName.index].pendingNum
      //点击tabs 时重新加载页面搜索条件
      this.dynamicFilterBox(targetName.name)
      //切换时页面高度初始化
      document.getElementsByClassName('container-content')[0].style.minHeight = 400 + 'px'
      //当点击tabs切换页面的时候页面置顶
      document.getElementsByClassName('main-wrapper')[0].scrollTop = 0
      //关闭吸顶
      this.barFixed = false
      // 重新刷新表格
      this.showTable = false
    },
    //动态查询过滤条件
    dynamicFilterBox(val) {
      this.loadingPage = true
      this.pageNum = 1
      this.pageSize = 10
      //查询当前页面表格title
      this.tableSearch = [ //页面固定检索模块
        { //分类
          label: '分类',
          type: 'select',
          value: 'dataType',
          children: [],
          name: 'name',
          code: 'code',
          inpWidth: 220,
          searchType: '2'
        },
        { //事业部
          label: '事业部',
          type: 'select',
          value: 'deptNo',
          children: [],
          name: 'deptName',
          code: 'deptNo',
          inpWidth: 220,
          searchType: '2'
        },
        { //申请时间
          label: '申请时间',
          type: 'date',
          format: 'yyyy-MM-dd', //显示类型
          valueFormat: 'yyyy-MM-dd HH:mm:ss', //输出类型
          value: 'applicantTime',
          separator: '~',
          displayType: 'daterange',
          startPlaceholder: '开始时间',
          endPlaceholder: '结束时间',
          inpWidth: 220,
          searchType: '2'
        },
        { //申请人
          label: '申请人账号',
          type: 'input',
          value: 'applicant',
          inpWidth: 220,
          searchType: '2'
        },
        { //申请单号
          label: '申请单号',
          type: 'input',
          value: 'applicantNo',
          inpWidth: 220,
          searchType: '2'
        },
        { //审批单号
          label: '审批单号',
          type: 'input',
          value: 'processInstanceNo',
          inpWidth: 220,
          searchType: '2'
        }
      ]
      //加载表头
      this.dynamicTitle(val)
      //加载枚举值
      this.enumQuery()
      this.queryDept()
      // 将搜索条件动态push到页面
      Api.WorkApproval.dynamicFilterBox({ code: val }).then(res => {
        if (res.success) {
          for (let i = 0, arr = res.data; i < arr.length; i++) {
            let obj = {}
            //页面动态检索模块
            switch (arr[i].filterType) {
              case 1: //下拉列表
                obj = {
                  label: arr[i].name,
                  type: 'select',
                  value: arr[i].code,
                  children: [],
                  name: 'name',
                  code: 'code',
                  inpWidth: 220,
                  searchType: arr[i].searchType,
                  filterType: arr[i].filterType
                }
                //动态下拉菜单赋值
                Api.WorkApproval.query({
                  domain: arr[i].domain,
                  refCode: arr[i].refCode
                }).then(res => {
                  if (res.success) {
                    obj.children = res.data
                  }
                }).catch((e) => { this.$showErrorMsg(e) })
                this.tableSearch.push(obj)
                break
              case 2: //文本框
                obj = {
                  label: arr[i].name,
                  type: 'input',
                  value: arr[i].code,
                  inpWidth: 220,
                  searchType: arr[i].searchType,
                  filterType: arr[i].filterType
                }
                this.tableSearch.push(obj)
                break
              case 3: //文本框检索
                obj = {
                  label: arr[i].name,
                  type: 'autocomplete',
                  value: arr[i].code,
                  inpWidth: 220,
                  domain: arr[i].domain,
                  refCode: arr[i].refCode,
                  searchType: arr[i].searchType,
                  filterType: arr[i].filterType
                }
                this.tableSearch.push(obj)
                break
            }
          }
        }
      }).catch((e) => { this.$showErrorMsg(e) })
    },
    //动态表头数据
    dynamicTitle(val) {
      this.columns = [
        {
          id: 'selection',
          type: 'selection',
          label: '',
          fixed: 'left',
          prop: ''
        },
        {
          id: 'number',
          type: 'number',
          label: '序号',
          prop: '',
          fixed: 'left',
          width: 55
        }
      ]
      Api.WorkApproval.dynamicTitle({ code: val }).then(res => {
        if (res.success) {
          this.billTypeCode = res.data.billTypeCode
          //动态表头赋值
          for (let i = 0, title = res.data.dynamicTitleList; i < title.length; i++) {
            let obj = {}
            obj.id = 'text'
            obj.type = 'text'
            obj.label = title[i].name
            obj.prop = title[i].prop
            this.columns.push(obj)
          }
          //操作按钮
          const operating = {
            id: 'button',
            type: 'button',
            label: '操作',
            fixed: 'right',
            width: '80',
            list: [
              {
                id: 'details',
                name: '详情',
                type: 'text',
                size: ''
              }
            ]
          }
          this.columns.push(operating)
          //表格动态表格数据
          this.dynamicListPage()
        }
      }).catch((e) => {})
    },
    //动态表格数据列表
    dynamicListPage() {
      this.showTable = true
      this.loadingShow = true
      const params = {}
      params.pageNum = this.pageNum
      params.pageSize = this.pageSize
      params.billTypeCode = this.billTypeCode
      params.dynamicParams = this.dynamicParams
      params.deptNo = this.deptNo
      params.dataType = this.dataType//分类
      params.applicantNo = this.applicantNo // 申请单号
      params.applicant = this.applicant // 申请人
      // params.applicantTime = this.applicantTime // 申请时间

      let str = null
      if (this.applicantTime) {
        str = this.applicantTime[1].split(' ')
        str[1] = '23:59:59'
      }
      params.applicantTimeFrom = this.applicantTime ? this.applicantTime[0] : ''
      params.applicantTimeTo = this.applicantTime ? str[0] + ' ' + str[1] : ''
      params.processInstanceNo = this.processInstanceNo // 审批单号
      Api.WorkApproval.dynamicListPage(params).then(res => {
        if (res.success) {
          this.loadingShow = false
          this.tableData = res.dynamicData
          this.total = res.total
          this.loadingPage = false
          this.pageShow = true
        }
      }).catch((e) => {
        this.loadingShow = false
        this.loadingPage = false
        this.$showErrorMsg(e)
      })
    },
    //通过 -- 驳回
    handleClickBy(val) {
      const params = {}
      params.approvalResult = val //审批结果
      params.approveId = this.approveNodeJson.approveId//审批任务id
      params.approver = this.approveNodeJson.approver //审批人
      // params.args = '' //待更新上下文
      params.bizNo = this.bizNo //业务主键
      params.comments = this.comments //审批意见
      let title = ''
      if (val === 1) {
        title = '确定审批通过吗？'
      } else {
        title = '确定审批驳回吗？'
      }
      this.$alert('<p style="font-size: 18px;color:#333">' + title + '</p><p style="font-size: 13px;color: #666"></p>', '', {
        dangerouslyUseHTMLString: true,
        type: 'warning',
        center: true
      }).then(() => {
        Api.WorkApproval.submitApproval(params).then(res => {
          if (res.success) {
            this.$showSuccessMsg('操作成功')
            //关闭弹窗
            this.dialogVisible = false
            setTimeout(() => {
              this.dynamicListPage()
            }, 1000)

          }
        }).catch((e) => { this.$showErrorMsg(e) })
      }).catch(() => {})
    },
    //表格点击操作
    handleEdit(row) {
      // 申请单主题	jmeReqName	String	无	是
      // 申请单备注	jmeReqComments	String	无	否
      // 主表数据	  jmeMainColList	List<String>	所有的业务字段均使用“字段名:字段值”格式	是
      // 子表数据	  jmeSubFormList	List<JmeSubForm>	无	否
      // 附件	      jmeFiles	List<JmeFile>	无
      this.bizNo = row.index.bizNo
      this.detailsText = {}
      if (row.row === 'details') { //详情
        this.comments = ''
        this.loadingShow = true
        this.mainColList = []
        this.getDetailColumns = []
        this.getDetailTable = []
        const params = {}
        params.bizNo = row.index.bizNo
        Api.ManageApproval.getDetail(params).then(res => {
          if (res.success) {
            this.dialogVisible = true
            this.detailsText = res.data.oa
            this.approveNodeJson = res.data.approveNodeList[res.data.approveNodeList.length - 1]
            this.approveNodeTable = res.data.approveNodeList //审批状态列表
            for (let i in this.approveNodeTable) {
              this.approveNodeTable[i].comment = this.approveNodeTable[i].comment ? utils.htmlDecode(this.approveNodeTable[i].comment) : ''
            }
            //主表操作
            for (let i = 0, arr = this.detailsText.mainColList; i < arr.length; i++) {
              let obj = null
              const str = {}
              obj = arr[i].split(':')
              //判断数组大于2则为时间格式 利用拼接法进行拼接
              if (obj.length > 2) {
                let e = ''
                for (let j = 1; j < obj.length; j++) {
                  e += obj[j] + ':'
                }
                //删除时间最后一个冒号
                obj[1] = e.substr(0, e.length - 1)
                //将时间转换为正常时间格式
                obj[1] = this.dateFun(obj[1])
              }
              //将字段赋值
              str.name = obj[0]
              str.code = obj[1]
              this.mainColList.push(str)
            }
            //子表表格数据显示
            for (let i = 0, str = this.detailsText.subFormList; i < str.length; i++) {
              let brr = []
              for (let j = 0, arr = str[i].dynamicTitleList; j < arr.length; j++) {
                let obj = {}
                obj.title = str[i].subReqName
                obj.id = 'text'
                obj.type = 'text'
                obj.label = arr[j].name
                obj.prop = arr[j].prop
                brr.push(obj)
              }
              this.getDetailTable.push(str[i].dynamicData)
              this.getDetailColumns.push(brr)
            }
            this.loadingShow = false
          } else {
            this.$showErrorMsg(res.errMessage)
            this.dialogVisible = false
            this.loadingShow = false
          }
        }).catch((e) => {
          this.$showErrorMsg(e)
          this.dialogVisible = false
          this.loadingShow = false
        })
      }
    },
    //页码更改
    handleSizeChange(val) {
      this.pageSize = val
      this.dynamicListPage()
    },
    //翻页
    handleCurrentChange(val) {
      this.pageNum = val
      this.dynamicListPage()
    },
    //时间处理
    dateFun(val) {
      let d = new Date(val)
      if (!isNaN(d)) {
        let datetime = d.getFullYear() + '-' + (d.getMonth() > 8 ? d.getMonth() + 1 : '0' + (d.getMonth() + 1)) + '-' + (d.getDate() > 9 ? d.getDate() : '0' + d.getDate()) + ' ' + (d.getHours() > 9 ? d.getHours() : '0' + d.getHours()) + ':' + (d.getMinutes() > 9 ? d.getMinutes() : '0' + d.getMinutes()) + ':' + (d.getSeconds() > 9 ? d.getSeconds() : '0' + d.getSeconds())
        return datetime
      } else {
        return val
      }
    },
    //查询点击
    searchClick(val) {
      //如果是待审批状态显示批量按钮
      if (val.dataType === 1) {
        this.buttonShow = true
      }
      this.pageShow = false
      //点击查询时刷新气泡值
      this.dynamicParams = []
      this.deptNo = val.deptNo //事业部
      this.dataType = val.dataType //分类
      this.applicantNo = val.applicantNo // 申请单号
      this.applicant = val.applicant //申请人
      this.applicantTime = val.applicantTime // 申请时间
      this.processInstanceNo = val.processInstanceNo // 审批单号
      this.pageNum = 1
      this.pageSize = 10
      for (var i in val) {
        if (val[i] !== '') {
          if (i !== 'deptNo' && i !== 'dataType' && i !== 'applicantNo' && i !== 'applicant' && i !== 'applicantTime' && i !== 'processInstanceNo') {
            const obj = {}
            obj.fieldName = i
            obj.fieldValue = val[i]
            for (let j = 0; j < this.tableSearch.length; j++) {
              if (i === this.tableSearch[j].value) { //判断code 值是否一样
                obj.searchType = this.tableSearch[j].searchType
                obj.filterType = this.tableSearch[j].filterType
              }
            }
            this.dynamicParams.push(obj)
          }
        }
      }
      this.dynamicListPage()
    },
    //-------------------------------------文本检索
    //筛选动态模糊搜索获取焦点
    handleSelect(item) {
      this.dataJson = item
    },
    // 动态筛选模糊下拉搜索
    handleQueryUnit(queryString, cb, item) {
      Api.WorkApproval.query({
        domain: this.dataJson.domain,
        refCode: this.dataJson.refCode,
        filterConditions: [
          {
            'field': this.dataJson.value,
            'operator': '=',
            'value': queryString
          }
        ]
      }).then((res) => {
        if (res.success) {
          var results = []
          if (res.data.length > 0) {
            for (let i = 0, len = res.data.length; i < len; i++) {
              res.data[i].value = res.data[i].name
            }
            results = res.data
          }
          cb(results)
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
      })
    },
    //---------------------------------------菜单吸顶
    //开启吸顶模式
    scrollPage() {
      let box = document.getElementsByClassName('main-wrapper')[0]
      box.addEventListener('scroll', this.handleScroll, true)
    },
    //菜单吸顶
    handleScroll() {
      const scrollTop = document.getElementsByClassName('main-wrapper')[0]
      if (this.editableTabs.length > 0) {
        var { offsetTop } = document.getElementById('bar')
      }
      const body = document.getElementsByClassName('container-content')[0]
      //解决吸顶页面抖动
      //原因页面不够长吸不上，解决方法在原有页面加高控制

      if (scrollTop.clientHeight - body.clientHeight > 170 && scrollTop.clientHeight - body.clientHeight < 400) {
        body.style.minHeight = (body.clientHeight + 10) + 'px'
        body.style.height = 100 + '%'
      }
      //符合条件吸顶
      scrollTop.scrollTop > offsetTop ? this.barFixed = true : this.barFixed = false
      const isFixed = document.getElementsByClassName('isFixed')[0]
      if (isFixed) {
        if (this.getIsBookmark) {
          isFixed.style.top = 110 + 'px'
        } else {
          isFixed.style.top = 60 + 'px'
        }
      }
    }
  }
}
</script>

<style lang="scss" scoped="scoped">
@import './common/common';
</style>
