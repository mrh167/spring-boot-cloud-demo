<template>
  <div class="container">
    <div class="information-nav">
      <!-- 查询条件 -->
      <Search
        :table-search="tableSearch"
        @handleSearch="searchClick" />
    </div>
    <div class="container-content">
      <ButtonList />
      <!-- 表格列表 -->
      <flight-table
        :loading-show="loadingShow"
        :table-data="tableData"
        :page-size="pageSize"
        :page-num="pageNum"
        :columns="columns"
        @handleEdit="handleEdit" />
      <!-- 翻页 -->
      <pagination
        v-if="pageShow"
        :page-sizes="pageSizes"
        :total="total"
        :page-size="pageSize"
        @handleSizeChange="handleSizeChange"
        @handleCurrentChange="handleCurrentChange" />
    </div>
    <!-- 详情 -->
    <lui-dialog
      v-if="dialogVisible"
      :visible.sync="dialogVisible"
      width="70%"
      top="10vh"
      :close-on-click-modal="false"
      title="详情">
      <lui-row>
        <lui-col :span="24"><h1 class="h1">{{ detailsText.title }}</h1></lui-col>
      </lui-row>
      <!-- 主表数据 -->
      <lui-row>
        <lui-col v-for="(item,index) in mainColList" :key="index" :span="12" class="col-span">
          <span class="title-span">{{ item.name }}：</span>
          <span class="title-span">{{ item.code }}</span>
        </lui-col>
      </lui-row>
      <!-- 附件 -->
      <lui-row>
        <lui-col v-for="(item,index) in detailsText.attachments" :key="index" :span="12" class="col-span">
          <span class="title-span">附件：</span>
          <a :href="item.fileUrl" class="title-span">{{ item.fileName }}</a>
        </lui-col>
      </lui-row>
      <!-- 子表动态表格 -->
      <div v-for="(item,index) in getDetailColumns" :key="index">
        <p class="table-title">{{ item[0].title }}</p>
        <flight-table
          :table-data="getDetailTable[index]"
          :columns="item"
        ></flight-table>
      </div>
      <!-- 审批记录 -->
      <div style="margin-top: 50px;">
        <flight-table
          :table-data="approveNodeTable"
          :columns="approveNodeColumns"
        ></flight-table>
      </div>
      <div style="margin-top:20px">
        <p style="margin-bottom: 10px;">审批意见</p>
        <lui-input
          v-model="comments"
          style="width: 50%;"
          type="textarea"
          :rows="2"
          maxlength="50"
          show-word-limit
          placeholder="请输入审批意见">
        </lui-input>
      </div>
      <span slot="footer" class="dialog-footer">
        <lui-button :disabled="approveNodeJson.state!==0" type="primary" @click="handleClickBy(1)">通 过</lui-button>
        <lui-button :disabled="approveNodeJson.state!==0" type="danger" @click="handleClickBy(3)">驳 回</lui-button>
        <lui-button @click="dialogVisible=false">关 闭</lui-button>
      </span>
    </lui-dialog>
  </div>
</template>

<script async>
import flightTable from '@/components/common/table'
import Search from './components/search'
import pagination from '@/components/common/pagination'
import ButtonList from '@/components/common/button'
import utils from '@/utils/utils'
import Api from '@/api'
const d = new Date()
let date1 = d.getFullYear() + '-' + (d.getMonth() > 8 ? d.getMonth() + 1 : '0' + (d.getMonth() + 1)) + '-' + (d.getDate() > 9 ? d.getDate() : '0' + d.getDate()) + ' ' + '23' + ':' + '59' + ':' + '59'
let date0 = d.getFullYear() + '-' + (d.getMonth() > 8 ? d.getMonth() + 1 : '0' + (d.getMonth() + 1)) + '-' + '01' + ' ' + '00' + ':' + '00' + ':' + '00'
export default {
  name: 'index',
  components: {
    Search,
    flightTable,
    ButtonList,
    pagination
  },
  data() {
    return {
      approveNodeTable: [],
      comments: '', //审批意见
      approveNodeColumns: [
        {
          id: 'text',
          type: 'text',
          label: '任务名称',
          prop: 'nodeDisplayName'
        },
        {
          id: 'text',
          type: 'text',
          label: '审批人编码',
          prop: 'approver'
        },
        {
          id: 'text',
          type: 'text',
          label: '审批人名称',
          prop: 'approverName'
        },
        {
          id: 'text',
          type: 'text',
          label: '审批状态',
          prop: 'stateName'
        },
        {
          id: 'text',
          type: 'text',
          label: '审批意见',
          prop: 'comment'
        },
        {
          id: 'text',
          type: 'text',
          label: '审批完成时间',
          prop: 'finishTime'
        }
      ],
      getDetailTable: [],
      getDetailColumns: [],
      mainColList: [],
      detailsText: {},
      loadingShow: false,
      dialogVisible: false,
      tableData: [],
      multipleSelection: [],
      pageShow: true, //刷新翻页
      pageSizes: [10, 20, 50, 100],
      total: 0,
      pageNum: 1,
      pageSize: 10,
      queryCriteria: {
        applicantTime: [date0, date1]
      }, //查询条件
      enumQueryList: [],
      bizNo: '',
      approveNodeJson: {},
      tableSearch: [
        {
          label: '事业部',
          type: 'select',
          value: 'deptNo',
          children: [],
          name: 'deptName',
          code: 'deptNo',
          inpWidth: 220
        },
        {
          label: '审批单号',
          type: 'input',
          value: 'processInstanceNo',
          inpWidth: 220
        },
        {
          label: '审批业务类型',
          type: 'select',
          value: 'billTypeCode',
          children: [],
          name: 'name',
          code: 'code',
          inpWidth: 220
        },
        {
          label: '申请单号',
          type: 'input',
          value: 'applicantNo',
          inpWidth: 220
        },
        {
          label: '审批状态',
          type: 'select',
          value: 'state',
          children: [],
          name: 'code',
          code: 'name',
          inpWidth: 220
        },
        {
          label: '审批人',
          type: 'input',
          value: 'approver',
          inpWidth: 220
        },
        {
          label: '申请时间',
          type: 'date',
          displayType: 'daterange',
          separator: '~',
          value: 'applicantTime',
          format: 'yyyy-MM-dd', //显示类型
          valueFormat: 'yyyy-MM-dd HH:mm:ss', //输出类型
          inpWidth: 220,
          startPlaceholder: '开始时间',
          endPlaceholder: '结束时间'
        }
      ],
      columns: [
        {
          id: 'number',
          type: 'number',
          label: '序号',
          prop: '',
          fixed: 'left',
          width: 55
        },
        {
          id: 'text',
          type: 'text',
          label: '事业部编码',
          prop: 'deptNo'
        },
        {
          id: 'text',
          type: 'text',
          label: '事业部名称',
          prop: 'deptName'
        },
        {
          id: 'text',
          type: 'text',
          label: '审批单号',
          prop: 'processInstanceNo'
        },
        {
          id: 'text',
          type: 'text',
          label: '申请单号',
          prop: 'applicantNo'
        },
        {
          id: 'text',
          type: 'text',
          label: '审批业务类型',
          prop: 'billTypeName'
        },
        {
          id: 'text',
          type: 'text',
          label: '审批状态',
          prop: 'stateName'
        },
        {
          id: 'text',
          type: 'text',
          label: '审批节点',
          prop: 'nodeDisplayName'
        },
        {
          id: 'text',
          type: 'text',
          label: '审批人',
          prop: 'approverName'
        },
        {
          id: 'text',
          type: 'text',
          label: '申请人',
          prop: 'applicant'
        },
        {
          id: 'text',
          type: 'text',
          label: '申请时间',
          prop: 'applicantTime'
        },
        {
          id: 'button',
          type: 'button',
          label: '操作',
          fixed: 'right',
          width: '80',
          list: [
            {
              id: 'details',
              name: '详情',
              type: 'text',
              size: ''
            }
          ]
        }
      ],
      timer: null,
      dateNum: 0
    }
  },
  destroyed() { // 销毁滑动事件
    clearInterval(this.timer) //清空定时器
    this.timer = null
  },
  mounted() {
    this.queryDept()
    this.enumQuery()
    this.getSelectBill()
  },
  methods: {
    setDate() {
      if (this.dateNum >= 3) {
        clearInterval(this.timer) //清空定时器
        this.timer = null
        return
      }
      this.timer = setInterval(() => {
        this.dateNum++
        this.getList()
        this.setDate()
      }, 3000)
    },

    //-------------------------------------基础数据---------------------------------------
    //审批状态
    enumQuery() {
      Api.Common.enumQuery({ code: 'approvalState' }).then(res => {
        if (res.success) {
          this.tableSearch.forEach(item => {
            if (item.value === 'state') {
              this.enumQueryList = res.data
              item.children = res.data
              this.getList()
            }
          })
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
      })
    },
    // 查询审批业务类型
    getSelectBill() {
      Api.StartApproval.selectBillType().then(res => {
        if (res.success) {
          this.tableSearch.forEach(item => {
            if (item.value === 'billTypeCode') {
              item.children = res.data
            }
          })
        }
      }).catch((e) => {
        console.error(e)
      })
    },
    //事业部
    queryDept() {
      Api.Common.queryDept().then(res => {
        if (res.success) {
          this.tableSearch.forEach(item => {
            if (item.value === 'deptNo') {
              item.children = res.data
            }
          })
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
      })
    },
    //----------------------------------------------------------------------------

    //通过 -- 驳回
    handleClickBy(val) {
      this.dateNum = 0
      const params = {}
      params.approvalResult = val //审批结果
      params.approveId = this.approveNodeJson.approveId//审批任务id
      params.approver = this.approveNodeJson.approver //审批人
      // params.args = '' //待更新上下文
      params.bizNo = this.bizNo //业务主键
      params.comments = this.comments //审批意见
      if (val === 1) { //通过
        this.$alert('<p style="font-size: 18px;color:#333">确定审批通过吗？</p><p style="font-size: 13px;color: #666"></p>', '', {
          dangerouslyUseHTMLString: true,
          type: 'warning',
          center: true
        }).then(() => {
          Api.WorkApproval.submitApproval(params).then(res => {
            if (res.success) {
              this.$showSuccessMsg('操作成功')
              //关闭弹窗
              this.dialogVisible = false
              this.setDate()
            }
          }).catch((e) => { this.$showErrorMsg(e) })
        }).catch(() => {})
      } else { // 驳回
        this.$alert('<p style="font-size: 18px;color:#333">确定审批驳回吗？</p><p style="font-size: 13px;color: #666">驳回后审批流将直接结束</p>', '', {
          dangerouslyUseHTMLString: true,
          type: 'warning',
          center: true
        }).then(() => {
          Api.WorkApproval.submitApproval(params).then(res => {
            if (res.success) {
              this.$showSuccessMsg('操作成功')
              //关闭弹窗
              this.dialogVisible = false
              this.setDate()
            }
          }).catch((e) => { this.$showErrorMsg(e) })
        }).catch(() => {})
      }
    },
    //数据列表
    getList() {
      clearInterval(this.timer) //清空定时器
      this.timer = null
      this.loadingShow = true
      const params = {}
      params.pageNum = this.pageNum
      params.pageSize = this.pageSize
      params.deptNo = this.queryCriteria.deptNo
      params.processInstanceNo = this.queryCriteria.processInstanceNo
      params.billTypeCode = this.queryCriteria.billTypeCode
      params.applicantNo = this.queryCriteria.applicantNo //申请单号
      params.state = this.queryCriteria.state //申批状态
      params.approver = this.queryCriteria.approver //审批人
      let str = null
      if (this.queryCriteria.applicantTime) {
        str = this.queryCriteria.applicantTime[1].split(' ')
        str[1] = '23:59:59'
      }
      params.applicantTimeFrom = this.queryCriteria.applicantTime ? this.queryCriteria.applicantTime[0] : ''//申请开始时间
      params.applicantTimeTo = this.queryCriteria.applicantTime ? str[0] + ' ' + str[1] : '' //申请结束时间
      Api.ManageApproval.pageList(params).then(res => {
        if (res.success) {
          this.pageShow = true
          for (let i of res.data) {
            for (let j of this.enumQueryList) {
              if (i.state === j.name) {
                i.stateName = j.code
              }
            }
          }
          this.tableData = res.data
          this.loadingShow = false
          this.total = res.total
        }
      }).catch((e) => {
        this.loadingShow = false
        this.$showErrorMsg(e)
      })
    },
    //查询条件
    searchClick(val) {
      this.pageShow = false
      this.pageNum = 1
      this.pageSize = 10
      this.queryCriteria = val
      this.getList()
    },
    //时间处理
    dateFun(val) {
      let d = new Date(val)
      if (!isNaN(d)) {
        let datetime = d.getFullYear() + '-' + (d.getMonth() > 8 ? d.getMonth() + 1 : '0' + (d.getMonth() + 1)) + '-' + (d.getDate() > 9 ? d.getDate() : '0' + d.getDate()) + ' ' + (d.getHours() > 9 ? d.getHours() : '0' + d.getHours()) + ':' + (d.getMinutes() > 9 ? d.getMinutes() : '0' + d.getMinutes()) + ':' + (d.getSeconds() > 9 ? d.getSeconds() : '0' + d.getSeconds())
        return datetime
      } else {
        return val
      }
    },
    //表格操作子组建返回数据
    handleEdit(row) {
      // 申请单主题	jmeReqName	String	无	是
      // 申请单备注	jmeReqComments	String	无	否
      // 主表数据	  jmeMainColList	List<String>	所有的业务字段均使用“字段名:字段值”格式	是
      // 子表数据	  jmeSubFormList	List<JmeSubForm>	无	否
      // 附件	      jmeFiles	List<JmeFile>	无
      if (row.row === 'details') { //详情
        this.loadingShow = true
        this.comments = ''
        this.mainColList = []
        this.getDetailColumns = []
        const params = {}
        this.bizNo = row.index.bizNo
        params.bizNo = row.index.bizNo
        Api.ManageApproval.getDetail(params).then(res => {
          if (res.success) {
            this.dialogVisible = true
            this.detailsText = res.data.oa
            this.approveNodeJson = res.data.approveNodeList[res.data.approveNodeList.length - 1]
            this.approveNodeTable = res.data.approveNodeList //审批状态列表
            for (let i in this.approveNodeTable) {
              this.approveNodeTable[i].comment = this.approveNodeTable[i].comment ? utils.htmlDecode(this.approveNodeTable[i].comment) : ''
            }
            //主表操作
            for (let i = 0, arr = this.detailsText.mainColList; i < arr.length; i++) {
              const obj = null
              const str = {}
              // eslint-disable-next-line no-const-assign
              obj = arr[i].split(':')
              //判断数组大于2则为时间格式 利用拼接法进行拼接
              if (obj.length > 2) {
                const e = ''
                // eslint-disable-next-line no-const-assign
                for (const j = 1; j < obj.length; j++) {
                  // eslint-disable-next-line no-const-assign
                  e += obj[j] + ':'
                }
                //删除时间最后一个冒号
                obj[1] = e.substr(0, e.length - 1)
                //将时间转换为正常时间格式
                obj[1] = this.dateFun(obj[1])
              }
              //将字段赋值
              str.name = obj[0]
              str.code = obj[1]
              this.mainColList.push(str)
            }
            //子表表格数据显示
            for (let i = 0, str = this.detailsText.subFormList; i < str.length; i++) {
              let brr = []
              for (let j = 0, arr = str[i].dynamicTitleList; j < arr.length; j++) {
                let obj = {}
                obj.title = str[i].subReqName
                obj.id = 'text'
                obj.type = 'text'
                obj.label = arr[j].name
                obj.prop = arr[j].prop
                brr.push(obj)
              }
              this.getDetailTable.push(str[i].dynamicData)
              this.getDetailColumns.push(brr)
            }
            this.loadingShow = false
          } else {
            this.$showErrorMsg(res.errMessage)
            this.loadingShow = false
          }
        }).catch((e) => {
          this.$showErrorMsg(e)
          this.loadingShow = false
        })
      }
    },
    //页码更改
    handleSizeChange(val) {
      this.pageSize = val
      this.getList()
    },
    //翻页
    handleCurrentChange(val) {
      this.pageNum = val
      this.getList()
    }
  }
}
</script>

<style lang="scss" scoped="scoped">
@import './common/common';
</style>
