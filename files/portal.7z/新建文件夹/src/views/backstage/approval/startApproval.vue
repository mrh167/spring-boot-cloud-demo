<template>
  <div class="container">
    <div class="container-content">
      <!-- 顶部按钮 -->
      <button-list
        :table-button="tableButton"
        @handelClick="handelClick"
        @uploadSuccess="getList" />
      <!-- 表格 -->
      <flight-table
        :loading-show="loadingShow"
        :table-data="tableData"
        :columns="columns"
        :page-size="pageSize"
        :page-num="pageNum"
        @handleSelectionChange="handleSelectionChange"
        @handleEdit="handleEdit" />

      <!-- 翻页 -->
      <pagination
        :page-sizes="pageSizes"
        :total="total"
        :page-size="pageSize"
        @handleSizeChange="handleSizeChange"
        @handleCurrentChange="handleCurrentChange" />
    </div>
    <!-- 新增 -->
    <lui-dialog
      v-if="dialogVisible"
      :visible.sync="dialogVisible"
      width="70%"
      top="10vh"
      :close-on-click-modal="false"
      :title="dialogTitle">
      <!-- 新增内容 -->
      <lui-form
        ref="ruleForm"
        :model="ruleForm"
        :rules="rules"
        label-width="130px"
        class="demo-ruleForm">
        <div class="ruleForm-title">
          <lui-row>
            <lui-col :span="12">
              <lui-form-item
                label="来源系统"
                prop="domain">
                <lui-input
                  v-model.trim="ruleForm.domain"
                  maxlength="45"
                  show-word-limit
                  :disabled="editShow"
                  onkeyup="value=value.replace(/[^a-zA-Z0-9-_.:]+/g,'')"
                  placeholder="请输入来源系统">
                </lui-input>
              </lui-form-item>
            </lui-col>
            <lui-col :span="12">
              <lui-form-item
                label="审批业务类型"
                prop="billTypeName">
                <lui-input
                  v-model.trim="ruleForm.billTypeName"
                  maxlength="10"
                  show-word-limit
                  :disabled="editShow"
                  placeholder="请输入审批业务类型">
                </lui-input>
              </lui-form-item>
            </lui-col>
          </lui-row>
          <lui-row>
            <lui-col :span="12">
              <lui-form-item
                label="工作台名称"
                prop="tabName">
                <lui-input
                  v-model.trim="ruleForm.tabName"
                  maxlength="10"
                  show-word-limit
                  :disabled="editShow"
                  placeholder="请输入工作台名称">
                </lui-input>
              </lui-form-item>
            </lui-col>

            <lui-col :span="12">
              <lui-form-item
                label="业务单据"
                prop="name">
                <lui-input
                  v-model.trim="ruleForm.name"
                  maxlength="20"
                  show-word-limit
                  :disabled="editShow"
                  placeholder="请输入业务单据名称">
                </lui-input>
              </lui-form-item>
            </lui-col>
          </lui-row>
          <lui-row>
            <lui-col :span="12">
              <lui-form-item
                label="说明"
                prop="description">
                <lui-input
                  v-model.trim="ruleForm.description"
                  type="textarea"
                  maxlength="50"
                  rows="2"
                  show-word-limit
                  :disabled="editShow"
                  placeholder="请输入说明内容">
                </lui-input>
              </lui-form-item>
            </lui-col>
            <lui-col :span="12">
              <lui-form-item
                label="审批业务校验"
                prop="isCheck">
                <lui-radio-group
                  v-model="ruleForm.isCheck"
                  :disabled="editShow">
                  <lui-radio :label="1" class="button_radio">是</lui-radio>
                  <lui-radio :label="0" class="button_radio">否</lui-radio>
                </lui-radio-group>
              </lui-form-item>
            </lui-col>
          </lui-row>
          <lui-row>
            <lui-col :span="12">
              <lui-form-item
                label="列表字段配置">
              </lui-form-item>
            </lui-col>
          </lui-row>
          <lui-row>
            <lui-col :span="24">
              <lui-table
                ref="dialogTable2"
                :data="ruleForm.metaAttribute"
                style="width: 100%"
                border
                height="400">
                <template slot="empty">
                  <showEmptyImage></showEmptyImage>
                </template>
                <lui-table-column
                  label="序号"
                  fixed="left"
                  align="center"
                  width="50">
                  <template v-slot="scope">
                    <span>{{ scope.$index+1 }}</span>
                  </template>
                </lui-table-column>
                <lui-table-column
                  label="字段"
                  prop="code"
                  min-width="170">
                  <template v-slot="{row}">
                    <lui-input
                      v-model.trim="row.code"
                      :disabled="details"
                      placeholder="请输入字段">
                    </lui-input>
                  </template>
                </lui-table-column>
                <lui-table-column
                  label="显示名称"
                  prop="name"
                  min-width="170">
                  <template v-slot="{row}">
                    <lui-input
                      v-model.trim="row.name"
                      :disabled="details"
                      placeholder="请输入显示名称">
                    </lui-input>
                  </template>
                </lui-table-column>
                <lui-table-column
                  label="筛选类型"
                  prop="filterType"
                  min-width="170">
                  <template v-slot="{row}">
                    <lui-select
                      v-model="row.filterType"
                      :disabled="details"
                      style="width: 100%;"
                      placeholder="请选择筛选类型">
                      <lui-option
                        v-for="item in selectDomain"
                        :key="item.code"
                        :label="item.name"
                        :value="item.code">
                      </lui-option>
                    </lui-select>
                  </template>
                </lui-table-column>
                <lui-table-column
                  label="检索类型"
                  prop="searchType"
                  min-width="170">
                  <template v-slot="{row}">
                    <lui-select
                      v-model="row.searchType"
                      :disabled="details"
                      style="width: 100%;"
                      placeholder="请选择检索类型">
                      <lui-option
                        v-for="item in searchTypeList"
                        :key="item.code"
                        :label="item.name"
                        :value="item.code">
                      </lui-option>
                    </lui-select>
                  </template>
                </lui-table-column>
                <lui-table-column
                  label="参照编码"
                  prop="refCode"
                  min-width="170">
                  <template v-slot="{row}">
                    <lui-input
                      v-model.trim="row.refCode"
                      :disabled="details"
                      placeholder="请输入筛选接口">
                    </lui-input>
                  </template>
                </lui-table-column>
                <lui-table-column
                  label="token"
                  prop="refCode"
                  min-width="170">
                  <template v-slot="{row}">
                    <lui-input
                      v-model.trim="row.token"
                      :disabled="details"
                      placeholder="请输入token">
                    </lui-input>
                  </template>
                </lui-table-column>
                <lui-table-column
                  label="操作"
                  fixed="right"
                  align="center"
                  width="50">
                  <template v-slot="scope">
                    <lui-button :disabled="details" type="text" icon="lui-icon-delete" @click="handleTableDel(scope.row,scope.$index)"></lui-button>
                  </template>
                </lui-table-column>
              </lui-table>
              <lui-button v-if="!details" icon="lui-icon-plus" class="table-puls" @click="handleNodeAdd(ruleForm.metaAttribute)"></lui-button>
            </lui-col>
          </lui-row>
        </div>
      </lui-form>
      <!-- 页脚按钮 -->
      <span slot="footer" class="dialog-footer">
        <lui-button @click="dialogVisible=false">取 消</lui-button>
        <lui-button v-if="!details" type="primary" :loading="loadingButton" @click="submitForm('ruleForm')">提 交</lui-button>
      </span>
    </lui-dialog>
    <!-- 删除 -->
    <lui-dialog
      :visible.sync="deletedVisible"
      width="50%"
      top="10vh"
      :close-on-click-modal="false"
      title="删除结果反馈">
      <lui-table
        :data="deletedData"
        size="mini"
        border
        style="width: 100%">
        <lui-table-column
          align="center"
          label="序号"
          width="50">
          <template v-slot="scope">
            <span>{{ scope.$index+1 }}</span>
          </template>
        </lui-table-column>
        <lui-table-column
          align="center"
          prop="msg"
          label="删除明细">
        </lui-table-column>
      </lui-table>
    </lui-dialog>
  </div>
</template>

<script async>
import flightTable from '@/components/common/table'
import showEmptyImage from '@/components/common/showEmptyImage/index.vue'
import ButtonList from '@/components/common/button'
import pagination from '@/components/common/pagination'
import utils from '@/utils/utils'
import Api from '@/api'
export default {
  name: 'startApproval',
  components: {
    flightTable,
    ButtonList,
    showEmptyImage,
    pagination
  },
  data() {
    return {
      deletedVisible: false,
      deletedData: [],
      dialogVisible: false,
      dialogTitle: '审批接入配置',
      loadingButton: false,
      details: false, //查看
      editShow: false,
      domainList: [],
      selectDomain: [],
      searchTypeList: [],
      ruleForm: {},
      rules: {
        billTypeName: [{ required: true, message: '请输入审批业务类型', trigger: ['blur', 'change'] }],
        tabName: [{ required: true, message: '请输入工作台名称', trigger: ['blur', 'change'] }],
        domain: [{ required: true, message: '请输入来源系统', trigger: ['blur', 'change'] }],
        name: [{ required: true, message: '请输入业务单据', trigger: ['blur', 'change'] }],
        isCheck: [{ required: true, message: '请选择审批业务校验', trigger: ['blur', 'change'] }]
      },
      tableButton: [
        {
          label: '手工删除',
          type: 'primary',
          id: 'delet'
        },
        {
          label: '手工添加',
          id: 'add',
          type: 'primary'
        }
      ],
      multipleSelection: [], //手工删除传参
      loadingShow: false,
      tableData: [],
      pageSizes: [10, 20, 50, 100],
      total: 0,
      pageNum: 1,
      pageSize: 10,
      columns: [
        {
          id: 'selection',
          type: 'selection',
          label: '',
          fixed: 'left',
          prop: ''
        },
        {
          id: 'number',
          type: 'number',
          label: '序号',
          fixed: 'left',
          width: 55
        },
        {
          id: 'text',
          type: 'text',
          label: '审批业务类型',
          prop: 'billTypeName'
        },
        {
          id: 'text',
          type: 'text',
          label: '工作台名称',
          prop: 'tabName'
        },
        {
          id: 'text',
          type: 'text',
          label: '业务单据',
          prop: 'name'
        },
        {
          id: 'text',
          type: 'text',
          label: '说明',
          prop: 'description'
        },
        {
          id: 'text',
          type: 'text',
          label: '修改人',
          prop: 'updateUser'
        },
        {
          id: 'text',
          type: 'text',
          label: '修改时间',
          prop: 'updateTime'
        },
        {
          id: 'text',
          type: 'text',
          label: '创建时间',
          prop: 'createTime'
        },
        {
          id: 'button',
          type: 'button',
          label: '操作',
          fixed: 'right',
          width: '100',
          list: [
            {
              id: 'details',
              name: '详情',
              type: 'text',
              size: ''
            },
            {
              id: 'edit',
              name: '编辑',
              type: 'text',
              size: ''
            }
          ]
        }
      ]
    }
  },
  mounted() {
    this.getList() //数据列表
    this.selectFilterType() //查询筛选
    this.setDomain() //系统来源
    this.query()
  },
  methods: {
  //-----------------------------------------------------------------------------------
  //枚举接口---->检索类型
    query() {
      Api.Common.enumQuery({ code: 'searchType' }).then(res => {
        if (res.success) {
          this.searchTypeList = res.data
        }
      }).catch((e) => { this.$showErrorMsg(e) })
    },
    //详情
    handleEdit(row) {
      this.loadingShow = true
      Api.StartApproval.detail({
        code: row.index.code
      }).then(res => {
        if (res.success) {
          this.loadingShow = false
          this.dialogVisible = true
          this.loadingButton = false
          res.data.description = res.data.description ? utils.htmlDecode(res.data.description) : ''

          this.ruleForm = res.data

          switch (row.row) {
            case 'edit':
              sessionStorage.setItem('testNode', JSON.stringify(res.data))
              this.details = false
              this.editShow = true
              break
            case 'details':
              this.details = true
              this.editShow = true
              break
          }
        } else {
          this.$showErrorMsg(res.errMessage)
          this.loadingShow = false
        }
      }).catch((e) => {
        this.loadingShow = false
        this.$showErrorMsg(e)
      })
    },
    //表格数据
    getList() {
      this.loadingShow = true
      const params = {}
      params.pageNum = this.pageNum
      params.pageSize = this.pageSize
      Api.StartApproval.pageList(params).then(res => {
        if (res.success) {

          this.tableData = res.data
          this.total = res.total
          this.loadingShow = false
        } else {
          this.$showErrorMsg(res.errMessage)
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
      })
    },
    //页码更改
    handleSizeChange(val) {
      this.pageSize = val
      this.getList()
    },
    //翻页
    handleCurrentChange(val) {
      this.pageNum = val
      this.getList()
    },
    //判断字段配置是否已填写
    dataJudgment() {
      if (this.ruleForm.metaAttribute.length > 0) {
        for (let i = 0, len = this.ruleForm.metaAttribute; i < len.length; i++) {
          if (len[i].code === '' || len[i].name === '' || len[i].filterType === '' || len[i].refCode === '') {
            return '请完善字段配置第 ' + (i + 1) + ' 条信息'
          }
        }
      }
    },

    //新增保存
    submitForm(ruleForm) {
      this.$refs[ruleForm].validate((valid) => {
        if (valid) {
          if (this.dataJudgment() !== undefined) {
            return this.$showErrorMsg(this.dataJudgment())
          }
          this.loadingButton = true
          if (this.editShow) { //编辑
            const dataObj = JSON.parse(sessionStorage.getItem('testNode'))
            if (this.ruleForm.metaAttribute.length !== dataObj.metaAttribute.length) {
              this.ruleForm.entityCode = this.ruleForm.code
              Api.StartApproval.update(this.ruleForm).then(res => {
                if (res.success) {
                  this.dialogVisible = false
                  this.loadingButton = false
                  this.getList()
                  this.$showSuccessMsg('编辑成功')
                } else {
                  this.loadingButton = false
                  this.$showErrorMsg(res.errMessage)
                }
              }).catch((e) => {
                this.loadingButton = false
                this.$showErrorMsg(e)
              })
            } else {
              for (let i in this.ruleForm.metaAttribute) {
                if (dataObj.metaAttribute[i].code !== this.ruleForm.metaAttribute[i].code ||
                    dataObj.metaAttribute[i].name !== this.ruleForm.metaAttribute[i].name ||
                    dataObj.metaAttribute[i].refCode !== this.ruleForm.metaAttribute[i].refCode ||
                    dataObj.metaAttribute[i].token !== this.ruleForm.metaAttribute[i].token ||
                    dataObj.metaAttribute[i].filterType !== this.ruleForm.metaAttribute[i].filterType ||
                    dataObj.metaAttribute[i].searchType !== this.ruleForm.metaAttribute[i].searchType) {
                  this.ruleForm.entityCode = this.ruleForm.code
                  Api.StartApproval.update(this.ruleForm).then(res => {
                    if (res.success) {
                      this.dialogVisible = false
                      this.loadingButton = false
                      this.getList()
                      this.$showSuccessMsg('编辑成功')
                    } else {
                      this.loadingButton = false
                      this.$showErrorMsg(res.errMessage)
                    }
                  }).catch((e) => {
                    this.loadingButton = false
                    this.$showErrorMsg(e)
                  })
                  return
                } else {
                  this.dialogVisible = false
                  this.loadingButton = false
                }
              }
            }
          } else { //新增
            Api.StartApproval.save(this.ruleForm).then(res => {
              if (res.success) {
                this.dialogVisible = false
                this.loadingButton = false
                this.getList()
                this.$showSuccessMsg('新增成功')
              } else {
                this.loadingButton = false
                this.$showErrorMsg(res.errMessage)
              }
            }).catch((e) => {
              this.loadingButton = false
              this.$showErrorMsg(e)
            })
          }
        }
      })
    },
    // 数据操作按钮
    handelClick(item) {
      switch (item.type) {
        case 'add': //新增
          this.dialogVisible = true
          this.loadingButton = false
          this.details = false
          this.editShow = false
          this.dialogTitle = '审批接入配置'
          this.ruleForm = {
            billTypeName: '', //审批业务类型
            tabName: '', //工作台名称
            domain: '', //来源系统
            name: '', //业务单据
            isCheck: 0, //审批业务校验
            description: '',
            //列表字段配置
            metaAttribute: [
              {
                code: '', //字段
                name: '', //显示名称
                filterType: '', //筛选类型
                refCode: '', //参照编码
                token: ''
              }
            ]
          }
          this.$nextTick(() => {
            this.$refs['ruleForm'].clearValidate()
          })
          break
        case 'delet': //删除
          if (this.multipleSelection.length === 0) {
            this.$showErrorMsg('请选择数据')
            return
          }
          var crrId = []
          for (let i = 0; i < this.multipleSelection.length; i++) {
            crrId.push(this.multipleSelection[i].code)
          }
          this.delete(crrId)
          break
      }
    },
    //  删除方法
    delete(row) {
      this.$alert('<p style="font-size: 18px;color:#333">确认要删除选中记录吗?</p><p style="font-size: 13px;color: #666">删除后，此条记录的相关内容信息将无法恢复</p>', '', {
        dangerouslyUseHTMLString: true,
        type: 'warning',
        center: true
      }).then(() => {
        Api.StartApproval.deleteById({ codes: row }).then(res => {
          if (res.success) {
            if (res.data.errorCount > 0) {
              this.deletedData = res.data.detaileds
              this.deletedVisible = true
              this.getList()
            } else {
              this.$showSuccessMsg('删除成功')
              this.getList()
            }
          } else {
            this.$showErrorMsg(res.errMessage)
          }
        }).catch((e) => {
          this.$showErrorMsg(e)
        })
      }).catch(() => {})
    },
    //多选
    handleSelectionChange(val) {
      this.multipleSelection = val.val
    },
    //新增查询筛选条件
    selectFilterType() {
      Api.StartApproval.selectFilterType().then(res => {
        if (res.success) {
          this.selectDomain = res.data
        }
      }).catch((e) => {})
    },
    //新增系统来源条件
    setDomain() {
      Api.StartApproval.setDomain().then(res => {
        if (res.success) {
          this.domainList = res.data
        }
      }).catch((e) => {})
    },
    //新增表格数据
    handleNodeAdd(tableData) {
      if (this.dataJudgment() !== undefined) {
        return this.$showErrorMsg(this.dataJudgment())
      }
      const obj = {
        code: '', //字段
        name: '', //显示名称
        filterType: '', //筛选类型
        refCode: '' //参照编码
      }
      tableData.push(obj)
      //table 新增时将滚动条固定底部
      this.$nextTick((e) => {
        this.$refs.dialogTable2.bodyWrapper.scrollTop = this.$refs.dialogTable2.bodyWrapper.scrollHeight
      })
    },
    //删除新增列表字段配置table数据 ---如果表格数据为空直接删除 否则提示删除
    handleTableDel(row, index) {
      // 如果已经有值则判断是否删除  没值直接则删除
      if (row.code !== '' || row.name !== '' || row.filterType !== '' || row.refCode !== '' || row.token !== '') {
        this.$alert('<p style="font-size: 18px;color:#333">确定删除此条配置吗？</p><p style="font-size: 13px;color: #666"></p>', '', {
          dangerouslyUseHTMLString: true,
          type: 'warning',
          center: true
        }).then(() => {
          this.ruleForm.metaAttribute.splice(index, 1)
        }).catch(() => {})
      } else {
        this.ruleForm.metaAttribute.splice(index, 1)
      }
    }
  }
}
</script>
<style lang="scss" scoped="scoped">
@import './common/common'
</style>
