<template>
  <div class="container">
    <div class="information-nav">
      <!-- 查询条件 -->
      <Search
        :table-search="tableSearch"
        @handleSearch="searchClick"
        @handleQueryUnit="handleQueryUnit" />
    </div>
    <div class="container-content">
      <!-- 按钮 -->
      <ButtonList
        :table-button="tableButton"
        @handelClick="handelClick"
        @uploadSuccess="getList" />
      <!-- 表格列表 -->
      <flight-table
        :loading-show="loadingShow"
        :table-data="tableData"
        :columns="columns"
        :page-size="pageSize"
        :page-num="pageNum"
        @handleSelectionChange="handleSelectionChange"
        @handleEdit="handleEdit" />
      <!-- 翻页 -->
      <pagination
        v-if="pageShow"
        :page-sizes="pageSizes"
        :total="total"
        :page-size="pageSize"
        @handleSizeChange="handleSizeChange"
        @handleCurrentChange="handleCurrentChange" />
    </div>
    <!-- 新增条件 -->
    <lui-dialog
      v-if="dialogVisible"
      :visible.sync="dialogVisible"
      width="50%"
      top="10vh"
      :close-on-click-modal="false"
      :title="dialogTitle">
      <lui-form
        ref="ruleForm"
        :model="ruleForm"
        :rules="rules"
        label-width="130px"
        class="demo-ruleForm">
        <lui-form-item
          label="审批业务类型"
          prop="billTypeCode">
          <lui-select
            v-model="ruleForm.billTypeCode"
            placeholder="请选择审批业务类型"
            style="width: 100%;"
            :disabled="editShow"
            @change="handelSelectBillType">
            <lui-option
              v-for="item in selectBillType"
              :key="item.code"
              :label="item.name"
              :value="item.code"
            >
            </lui-option>
          </lui-select>
        </lui-form-item>
        <lui-form-item
          label="配置维度"
          prop="configType">
          <lui-radio-group
            v-model="ruleForm.configType"
            :disabled="editShow">
            <lui-radio :label="1" class="button_radio">商家</lui-radio>
            <lui-radio :label="0" class="button_radio">默认</lui-radio>
          </lui-radio-group>
        </lui-form-item>
        <lui-form-item
          v-if="ruleForm.configType"
          label="商家"
          prop="sellerName">
          <lui-autocomplete
            v-model.trim="ruleForm.sellerName"
            :disabled="editShow"
            style="width: 100%;"
            class="inline-input"
            :fetch-suggestions="(queryString,cd)=>{queryUnit(queryString,cd)}"
            placeholder="请输入搜索商家"
            @select="handleSelect">
          </lui-autocomplete>
        </lui-form-item>
        <lui-form-item
          label="审批流程编码"
          prop="flowCode">
          <lui-input
            v-model.trim="ruleForm.flowCode"
            :disabled="details"
            placeholder="请输入审批流程编码">
          </lui-input>
        </lui-form-item>
        <lui-form-item
          label="审批流程版本"
          prop="flowVersion">
          <lui-input
            v-model.trim="ruleForm.flowVersion"
            :disabled="details"
            placeholder="请输入审批流程版本">
          </lui-input>
        </lui-form-item>
        <lui-form-item
          label="审批流程变量"
          prop="flowVariable">
          <lui-input
            v-model.trim="ruleForm.flowVariable"
            :disabled="details"
            placeholder="请输入JSON格式 如 {discount:0.8}">
          </lui-input>

        </lui-form-item>
        <lui-form-item
          label="说明"
          prop="description">
          <lui-input
            v-model.trim="ruleForm.description"
            type="textarea"
            :disabled="details"
            placeholder="请输入说明内容"
            maxlength="50"
            rows="3"
            show-word-limit></lui-input>
        </lui-form-item>
      </lui-form>
      <!-- 页脚按钮 -->
      <span slot="footer" class="dialog-footer">
        <lui-button @click="dialogVisible=false">取 消</lui-button>
        <lui-button v-if="!details" type="primary" :loading="loadingButton" @click="submitForm('ruleForm')">提 交</lui-button>
      </span>
    </lui-dialog>
  </div>
</template>

<script async>
import flightTable from '@/components/common/table'
import pagination from '@/components/common/pagination'
import Search from '@/components/common/search'
import ButtonList from '@/components/common/button'
import utils from '@/utils/utils.js'
import Api from '@/api'
export default {
  name: 'depioyApproval',
  components: {
    Search,
    flightTable,
    ButtonList,
    pagination
  },
  data() {
    return {
      ruleForm: {},
      rules: {
        billTypeCode: [{ required: true, message: '请选择审批业务类型', trigger: ['blur', 'change'] }],
        configType: [{ required: true, message: '请选择配置维度', trigger: ['blur', 'change'] }],
        sellerName: [{ required: true, message: '请选择商家', trigger: ['blur', 'change'] }],
        flowCode: [{ required: true, message: '请输入审批流程编码', trigger: ['blur', 'change'] }],
        isCheck: [{ required: true, message: '请选择审批业务校验', trigger: ['blur', 'change'] }],
        flowVersion: [{ required: true, message: '请输入审批流程版本', trigger: ['blur', 'change'] }]
      },
      flowVariableList: [],
      dialogTitle: '审批流程配置',
      loadingButton: false,
      dialogVisible: false,
      loadingShow: false,
      tableData: [{}],
      multipleSelection: [],
      pageSizes: [10, 20, 50, 100],
      total: 0,
      pageNum: 1,
      pageSize: 10,
      pageShow: true, //刷新页码
      billTypeCode: '', //审批业务类型编码
      flowCode: '', //流程编码
      details: false, //查看
      editShow: false, //编辑
      sellerNoOrName: '', //商家编码或名称
      selectBillType: [], //业务类型
      tableSearch: [
        {
          label: '审批业务类型',
          type: 'select',
          value: 'billTypeCode',
          children: [],
          code: 'code',
          name: 'name',
          inpWidth: 220
        },
        {
          label: '商家',
          type: 'autocomplete',
          value: 'sellerName',
          inpWidth: 220,
          placeholder: '请输入商家名称 / 编码'
        },
        {
          label: '审批流程编码',
          type: 'input',
          value: 'flowCode',
          inpWidth: 220
        }
      ],
      tableButton: [
        {
          label: '手工删除',
          type: 'primary',
          id: 'delet'
        },
        {
          label: '手工添加',
          id: 'add',
          type: 'primary'
        }

      ],
      columns: [
        {
          id: 'selection',
          type: 'selection',
          label: '',
          fixed: 'left',
          prop: ''
        },
        {
          id: 'number',
          type: 'number',
          label: '序号',
          prop: '',
          fixed: 'left',
          width: 55
        },
        {
          id: 'text',
          type: 'text',
          label: '商家编码',
          prop: 'sellerNo'
        },
        {
          id: 'text',
          type: 'text',
          label: '商家名称',
          prop: 'sellerName'
        },
        {
          id: 'text',
          type: 'text',
          label: '审批业务类型',
          prop: 'billTypeName'
        },
        {
          id: 'text',
          type: 'text',
          label: '配置维度',
          prop: 'configTypeName'
        },
        {
          id: 'text',
          type: 'text',
          label: '审批流程编码',
          prop: 'flowCode'
        },
        {
          id: 'text',
          type: 'text',
          label: '审批流程版本',
          prop: 'flowVersion'
        },
        {
          id: 'text',
          type: 'text',
          label: '审批流程变量',
          prop: 'flowVariable'
        },
        {
          id: 'text',
          type: 'text',
          label: '说明',
          prop: 'description'
        },
        {
          id: 'text',
          type: 'text',
          label: '修改人',
          prop: 'updateUser'
        },
        {
          id: 'text',
          type: 'text',
          label: '修改时间',
          prop: 'updateTime'
        },
        {
          id: 'text',
          type: 'text',
          label: '创建人',
          prop: 'createUser'
        },
        {
          id: 'text',
          type: 'text',
          label: '创建时间',
          prop: 'createTime'
        },
        {
          id: 'button',
          type: 'button',
          label: '操作',
          fixed: 'right',
          width: '100',
          list: [
            {
              id: 'details',
              name: '详情',
              type: 'text',
              size: ''
            },
            {
              id: 'edit',
              name: '编辑',
              type: 'text',
              size: ''
            }
          ]
        }
      ]
    }
  },
  mounted() {
    this.getList()
    this.getSelectBill()
  },
  methods: {
    //表格操作子组建返回数据
    handleEdit(row) {
      this.loadingShow = true
      Api.DeployApproval.getDetail({
        bizNo: row.index.bizNo
      }).then(res => {
        if (res.success) {
          res.data.flowVariable = res.data.flowVariable ? utils.htmlDecode(res.data.flowVariable) : ''
          this.ruleForm = res.data
          this.loadingButton = false
          this.dialogVisible = true
          this.loadingShow = false
          res.data.description = res.data.description ? utils.htmlDecode(res.data.description) : ''
          this.ruleForm = res.data
          switch (row.row) {
            case 'edit':
              sessionStorage.setItem('testNode', JSON.stringify(res.data))
              this.details = false
              this.editShow = true
              break
            case 'details':
              this.details = true
              this.editShow = true
              break
          }
        } else {
          this.$showErrorMsg(res.errMessage)
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
      })
    },
    //新增新增业务类型选择
    handelSelectBillType(val) {
      var obj = {} //多条件查找
      obj = this.selectBillType.find(function(item) {
        return item.code === val
      })
      this.ruleForm.billTypeName = obj.name
    },
    //商家选择
    handleSelect(val) {
      this.ruleForm.sellerNo = val.sellerNo
    },
    // 列表下拉模糊搜索
    queryUnit(queryString, cb) {
      Api.DeployApproval.dropdownSellers({
        keywords: queryString
      }).then((res) => {
        if (res.success) {
          var results = []
          if (res.data.length > 0) {
            for (let i = 0, len = res.data.length; i < len; i++) {
              res.data[i].value = res.data[i].sellerName + '【' + res.data[i].sellerNo + '】'
            }
            results = res.data
          } else {
            this.ruleForm.sellerNo = ''
          }
          cb(results)
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
      })
    },
    // 查询审批业务类型
    getSelectBill() {
      Api.StartApproval.selectBillType().then(res => {
        if (res.success) {
          this.selectBillType = res.data
          this.tableSearch.forEach(item => {
            if (item.value === 'billTypeCode') {
              item.children = res.data
            }
          })
        }
      }).catch((e) => {
        console.error(e)
      })
    },
    //新增编辑保存
    submitForm(ruleForm) {
      this.$refs[ruleForm].validate((valid) => {
        if (valid) {
          this.loadingButton = true
          if (this.ruleForm.configType === 1) {
            this.ruleForm.sellerName = this.ruleForm.sellerName.split('【')[0]
          }
          if (this.editShow) { //编辑
            const dataObj = JSON.parse(sessionStorage.getItem('testNode'))
            if (this.ruleForm.flowCode !== dataObj.flowCode || this.ruleForm.flowVersion !== dataObj.flowVersion || this.ruleForm.flowVariable !== dataObj.flowVariable || this.ruleForm.description !== dataObj.description) {
              Api.DeployApproval.editSave(this.ruleForm).then(res => {
                if (res.success) {
                  this.$showSuccessMsg('编辑成功')
                  this.loadingButton = false
                  this.dialogVisible = false
                  this.getList()
                } else {
                  this.$showErrorMsg(res.errMessage)
                  this.loadingButton = false
                }
              }).catch((e) => {
                this.$showErrorMsg(e)
                this.loadingButton = false
              })
            } else {
              this.loadingButton = false
              this.dialogVisible = false
            }
          } else { //新增
            Api.DeployApproval.add(this.ruleForm).then(res => {
              if (res.success) {
                this.$showSuccessMsg('新增成功')
                this.loadingButton = false
                this.dialogVisible = false
                this.getList()
              } else {
                this.$showErrorMsg(res.errMessage)
                this.loadingButton = false
              }
            }).catch((e) => {
              this.$showErrorMsg(e)
              this.loadingButton = false
            })
          }
        }
      })
    },
    //数据列表
    getList() {
      this.loadingShow = true
      const params = {}
      params.pageNum = this.pageNum
      params.pageSize = this.pageSize
      params.billTypeCode = this.billTypeCode //审批业务类型编码
      params.flowCode = this.flowCode //流程编码
      params.sellerNoOrName = this.sellerNoOrName //商家编码或名称
      Api.DeployApproval.listPage(params).then(res => {
        if (res.success) {
          this.pageShow = true
          res.data.forEach(item => {
            item.configTypeName = item.configType ? '商家' : '默认'
            item.flowVariable = item.flowVariable ? utils.htmlDecode(item.flowVariable) : ''
            item.description = item.description ? utils.htmlDecode(item.description) : ''
          })
          this.tableData = res.data
          this.total = res.total
          this.loadingShow = false
        } else {
          this.$showErrorMsg(res.errMessage)
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
      })
    },
    //查询条件
    searchClick(val) {
      this.pageShow = false
      this.billTypeCode = val.billTypeCode
      this.sellerNoOrName = val.sellerName
      this.flowCode = val.flowCode
      this.pageNum = 1
      this.pageSize = 10
      this.getList()
    },
    //模糊下拉搜索
    handleQueryUnit(queryString, cb) {
      Api.DeployApproval.dropdownSellers({
        keywords: queryString
      }).then((res) => {
        if (res.success) {
          var results = []
          if (res.data.length > 0) {
            for (let i = 0, len = res.data.length; i < len; i++) {
              res.data[i].value = res.data[i].sellerName
            }
            results = res.data
          }
          cb(results)
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
      })
    },
    // 数据操作按钮
    handelClick(item) {
      switch (item.type) {
        case 'add':
          this.dialogVisible = true
          this.loadingButton = false
          this.details = false
          this.editShow = false
          this.ruleForm = {
            billTypeName: '', //审批业务类型
            configType: 0,
            sellerName: '', //商家名称
            sellerNo: '', //商家编码
            description: '', //说明
            flowVersion: '', //流程版本
            flowVariable: '', //流程变量
            flowCode: '', //流程编码
            billTypeCode: ''//审批业务类型编码
          }
          this.$nextTick(() => {
            this.$refs['ruleForm'].clearValidate()
          })
          break
        case 'delet':
          if (this.multipleSelection.length === 0) {
            this.$showErrorMsg('请选择数据')
            return
          }
          var crrId = []
          for (let i = 0; i < this.multipleSelection.length; i++) {
            crrId.push(this.multipleSelection[i].bizNo)
          }
          this.delete(crrId)
          break
      }
    },
    //  删除方法
    delete(row) {
      this.$alert('<p style="font-size: 18px;color:#333">确认删除此条消息吗?</p><p style="font-size: 13px;color: #666">删除后，此条消息的相关内容信息将无法恢复</p>', '', {
        dangerouslyUseHTMLString: true,
        type: 'warning',
        center: true
      }).then(() => {
        Api.DeployApproval.deleteBatch({ bizNos: row }).then(res => {
          if (res.success) {
            this.$showSuccessMsg('删除成功')
            this.getList()
          } else {
            this.$showErrorMsg(res.errMessage)
          }
        }).catch((e) => {
          this.$showErrorMsg(e)
        })
      }).catch(() => {})
    },
    //多选
    handleSelectionChange(val) {
      this.multipleSelection = val.val
    },
    //页码更改
    handleSizeChange(val) {
      this.pageSize = val
      this.getList()
    },
    //翻页
    handleCurrentChange(val) {
      this.pageNum = val
      this.getList()
    }
  }
}
</script>

<style lang="scss" scoped="scoped">
  @import './common/common';
</style>
