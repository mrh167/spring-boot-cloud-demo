<template>
  <div class="tenant">
    <div class="rotation-add">
      <div
        class="add-button"
        @click="addClick">
        <span class="lui-icon-plus"></span>
        <span>新建租户</span>
      </div>
    </div>
    <lui-table v-loading="listLoading" :data="tableData" style="width: 85%;margin: 0 auto ">
      <template slot="empty">
        <showEmptyImage></showEmptyImage>
      </template>
      <lui-table-column
        prop="id"
        label="ID"
        width="120"
        show-overflow-tooltip>
      </lui-table-column>
      <lui-table-column
        prop="jdPin"
        show-overflow-tooltip
        label="京东PIN">
      </lui-table-column>
      <lui-table-column
        prop="erpNo"
        show-overflow-tooltip
        label="管理员ERP">
      </lui-table-column>

      <lui-table-column
        label="是否生效">
        <template slot-scope="{row}">
          <lui-switch
            v-model="row.status"
            active-circle-class="1"
            active-color="rgba(60,110,240,.2)"
            inactive-color="rgba(142,145,152,.2)"
            @change="setIfShowClick(row)">
          </lui-switch>
        </template>
      </lui-table-column>

      <lui-table-column
        prop="jdPost"
        show-overflow-tooltip
        label="岗位">
      </lui-table-column>

      <lui-table-column label="部门">
        <template slot-scope="{row}">
          <p class="table-p">{{ row.deptNo }}</p>
        </template>
      </lui-table-column>

      <lui-table-column width="170" label="修改时间">
        <template slot-scope="{row}">
          <p class="table-p">{{ row.updateTime }}</p>
        </template>
      </lui-table-column>

      <lui-table-column label="操作人" prop="updateUser" show-overflow-tooltip>
      </lui-table-column>

      <lui-table-column prop="date" width="80" label="操作">
        <template slot-scope="{row}">
          <div class="table-icon">
            <span @click="editClick(row)">
              <lui-tooltip
                class="item"
                effect="dark"
                content="编辑"
                placement="bottom">
                <img
                  src="../../../assets/img/icon-edit.png"
                  alt />
              </lui-tooltip>
            </span>
            <span @click="deleteClick(row)">
              <lui-tooltip
                class="item"
                effect="dark"
                content="删除"
                placement="bottom">
                <img
                  src="../../../assets/img/icon-delet.png"
                  alt />
              </lui-tooltip>
            </span>
          </div>
        </template>
      </lui-table-column>
    </lui-table>
    <div v-show="totals>10" class="tenant-pagination">
      <lui-pagination
        background
        :current-page.sync="pageNum"
        :page-sizes="[10, 20, 50, 70, 100]"
        layout="prev, pager, next, sizes, jumper"
        :total="totals"
        @current-change="handleSizeChange"
        @size-change="sizeChange"
      >
      </lui-pagination>
    </div>

    <!--  添加修改-->
    <lui-dialog
      :visible.sync="centerDialogVisible"
      width="50%"
      top="10vh"
      :show-close="false"
      :close-on-click-modal="false"
      custom-class="dialog_mask"
      title="租户维护">
      <lui-form
        ref="ruleForm"
        :model="ruleForm"
        :rules="rules"
        label-width="150px"
        class="demo-ruleForm">
        <lui-row :gutter="20">
          <lui-col :span="20">
            <lui-form-item
              label="京东PIN"
              prop="jdPin">
              <lui-input
                v-model="ruleForm.jdPin"
                placeholder="请输入京东PIN"></lui-input>
            </lui-form-item>

            <lui-form-item
              label="管理员ERP"
              prop="erpNo">
              <lui-select
                v-model="accountList"
                multiple
                filterable
                allow-create
                default-first-option
                placeholder="请输入绑定账号名称，最多10条"
                :multiple-limit="10"
                :popper-append-to-body="false">
                <lui-option
                  v-for="item in accountOptions"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value">
                </lui-option>
              </lui-select>
            </lui-form-item>

            <lui-form-item
              label="是否显示"
              prop="status">
              <lui-radio-group v-model="ruleForm.status">
                <lui-radio
                  :label="1"
                  class="button_radio">是</lui-radio>
                <lui-radio
                  :label="0"
                  class="button_radio">否</lui-radio>
              </lui-radio-group>
            </lui-form-item>

            <lui-form-item
              label="岗位"
              prop="jobPost">
              <lui-input
                v-model="ruleForm.jobPost"
                placeholder="请输入岗位"></lui-input>
            </lui-form-item>

            <lui-form-item
              label="部门"
              prop="deptNo">
              <lui-input
                v-model="ruleForm.deptNo"
                placeholder="请输入部门"></lui-input>
            </lui-form-item>

          </lui-col>
        </lui-row>
      </lui-form>

      <div
        slot="footer"
        class="dialog-footer"
        style="text-align: center">
        <lui-button @click="resetForm('ruleForm')">取 消</lui-button>
        <lui-button
          type="primary"
          :loading="loadingBut"
          @click="submitForm('ruleForm')">确 定</lui-button>
      </div>

    </lui-dialog>
  </div>
</template>

<script>
import Api from '@/api'
import showEmptyImage from '@/components/common/showEmptyImage/index.vue'
export default {
  name: 'index',
  components: {
    showEmptyImage
  },
  data() {
    return {
      listLoading: true,
      loadingBut: false,
      totals: 0,
      pageNum: 1, //页
      pageSize: 10, //条数
      tableData: [],
      centerDialogVisible: false,
      ruleForm: {
        jdPin: '', //PIN
        erpNo: '', //erp
        status: '', //状态
        jobPost: '', //岗位
        deptNo: '' //部门
      },
      rules: {
        jdPin: [{ required: true, message: '请输入京东PIN', trigger: 'blur' }],
        erpNo: [{ required: true, message: '请输入管理员ERP', trigger: 'blur' }],
        status: [{ required: true, message: '请选择状态', trigger: 'change' }],
        jobPost: [{ required: false, message: '请输入岗位', trigger: 'blur' }],
        deptNo: [{ required: false, message: '请输入部门', trigger: 'blur' }]
      },
      accountOptions: [],
      accountList: [],
      edit: false
    }
  },
  mounted() {
    this.getList()
  },
  methods: {
    //新增保存
    submitForm(formName) {
      this.ruleForm.erpNo = this.accountList.toString()
      this.$refs[formName].validate((valid) => {
        if (valid) {
          this.loadingBut = true
          if (this.edit) { //编辑
            Api.BackStageTenant.tenantEdit({
              id: this.ruleForm.id,
              jdPin: this.ruleForm.jdPin, //PIN
              erpNo: this.ruleForm.erpNo, //erp
              status: this.ruleForm.status, //状态
              jobPost: this.ruleForm.jobPost, //岗位
              deptNo: this.ruleForm.deptNo //部门
            }).then(row => {
              if (row.success) {
                this.$message({
                  message: '编辑成功',
                  type: 'success'
                })
                this.centerDialogVisible = false //关闭弹窗
                this.getList()
                this.loadingBut = false
              }
            }).catch((e) => {
              this.$showErrorMsg(e)
              this.loadingBut = false
            })
          } else {
            // 新增
            Api.BackStageTenant.tenantAdd({
              jdPin: this.ruleForm.jdPin, //PIN
              erpNo: this.ruleForm.erpNo, //erp
              status: this.ruleForm.status, //状态
              jobPost: this.ruleForm.jobPost, //岗位
              deptNo: this.ruleForm.deptNo //部门
            }).then(row => {
              if (row.success) {
                this.$message({
                  message: '新增成功',
                  type: 'success'
                })
                this.centerDialogVisible = false //关闭弹窗
                this.getList()
                this.loadingBut = false
              }
            }).catch((e) => {
              this.loadingBut = false
              this.$showErrorMsg(e)
            })
          }
        } else {
          return
        }
      })
    },
    //新建取消按钮
    resetForm(formName) {
      this.$refs[formName].resetFields()
      this.centerDialogVisible = false //关闭弹窗
    },
    addClick() {
      this.centerDialogVisible = true
      this.edit = false
      this.ruleForm = {
        jdPin: '', //PIN
        erpNo: '', //erp
        status: 1, //状态
        jobPost: '', //岗位
        deptNo: '' //部门
      }
      this.accountList = []
    },
    //修改
    editClick(row) {
      this.centerDialogVisible = true //open弹窗
      this.edit = true
      this.ruleForm = {
        id: row.id,
        jdPin: row.jdPin, //PIN
        erpNo: row.erpNo, //erp
        status: row.status ? 1 : 0, //状态
        jobPost: row.jobPost, //岗位
        deptNo: row.deptNo //部门
      }
      this.accountList = row.erpNo.split(',')
    },
    //是否显示
    setIfShowClick(row) {
      Api.BackStageTenant.tenantEdit({
        id: row.id,
        status: row.status ? 1 : 0 //状态
      }).then(() => {
        this.$showSuccessMsg('设置成功')
        this.getList()
      }).catch((e) => {
        this.$showErrorMsg(e)
      })
    },
    deleteClick(row) {
      this.$alert('<p style="font-size: 18px;color:#333">确认删除此条租户信息吗?</p><p style="font-size: 13px;color: #666">删除后，此条租户的相关内容信息将无法恢复</p>', '', {
        dangerouslyUseHTMLString: true,
        confirmButtonClass: 'btnFalses',
        cancelButtonClass: 'lui-button--primary',
        type: 'warning',
        center: true
      }).then(() => {
        Api.BackStageTenant.tenantDel({ id: row.id }).then(row => {
          if (row.success) {
            this.$showSuccessMsg('删除成功')
            this.getList()
          } else {
            this.$message.error('删除失败，请稍后再试')
          }
        }).catch((e) => { this.$showErrorMsg(e) })
      })
    },
    // 获取列表
    getList() {
      this.listLoading = true
      Api.BackStageTenant.tenantList({
        pageSize: this.pageSize,
        pageNum: this.pageNum
      }).then(row => {
        if (row.success) {
          for (let i = 0; i < row.data.length; i++) {
            if (row.data[i].status === 0) {
              row.data[i].status = false
            } else {
              row.data[i].status = true
            }
          }
          this.tableData = row.data
          this.totals = row.total
          this.listLoading = false
        }
      }).catch((e) => { this.$showErrorMsg(e) })
    },
    //翻页-----根据页码变换
    handleSizeChange(val) {
      this.pageNum = val
      this.getList()
    },
    //分页条数改变
    sizeChange(val) {
      this.pageSize = val
      this.getList()
    }
  }
}
</script>
<style lang="scss">
  .tenant {
      .lui-select-dropdown{
        border: 0;
        .lui-select-dropdown__empty{
          display: none!important;
        }
    }
  }
</style>
<style scoped lang="scss">
@import "@/assets/stylus/main.scss";
  .tenant {
    background: #fff;
    min-height: 600px;
    width: 100%;
    padding-bottom: 26px;
    padding-top: 35px;
    position: relative;
    .rotation-add{
      width: 85%;
      height: 50px;
      position: absolute;
      top: 82px;
      left: 7.5%;
      z-index: 1;
      .add-button{
        background: #fff;
        width: 99.7%;
        height: 50px;
        display: flex;
        cursor: pointer;
        justify-content: center;
        align-items: center;
        border: 1px dashed #c2c2c2;
        span{
          display: inline-block;
          height: 20px;
          line-height: 20px;
          font-size: 14px;
          color: #333;
        }
        span:nth-child(1){
          font-size: 12px;
          color: $--gl-blue;
          line-height: 18px;
          margin-right: 6px;
        }
      }
      .add-button:hover{
        background: #e7f0f6;
        border: 1px dashed $--gl-blue;
        span{
          display: inline-block;
          height: 20px;
          line-height: 20px;
          font-size: 14px;
          color: $--gl-blue;
        }
        span:nth-child(1){
          font-size: 12px;
          color: $--gl-blue;
          line-height: 18px;
          margin-right: 6px;
        }
      }
    }
    .tenant-pagination {
      width: 100%;
      margin-top: 73px;
      text-align: center;
    }
    .table-p {
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      cursor: pointer;
      padding-right: 15px;
    }
    .table-icon{
      display: flex;
      justify-content: space-between;
      span{
        color: #1d76a8;
        cursor: pointer;
      }
    }
  }

  /deep/ .lui-table__body{
    margin-top: 50px;
  }
  /deep/ .lui-select {
    display: inline-block;
    width: 100%;
    position: relative;
  }

  @media screen and (max-width: 1366px) {
    /deep/ .lui-table th>.cell {
      position: relative;
      word-wrap: normal;
      text-overflow: ellipsis;
      display: inline-block;
      vertical-align: middle;
      width: 100%;
      font-size: 12px;
      -webkit-box-sizing: border-box;
      box-sizing: border-box;
      font-weight: 400;
    }
  }
</style>
