<template>
  <div class="configure">
    <div class="configure-title">
      <div class="title-text">筛选搜索</div>
      <div class="title-serch">
        <div class="serch-left">

          <div class="select-content">
            <span class="content-title">商家编码</span>
            <lui-input
              v-model="sellerNo"
              clearable
              style="width: 180px;"
              placeholder="请输入商家编码"
            ></lui-input>
          </div>

          <div class="select-content">
            <span class="content-title">商家名称</span>
            <lui-input
              v-model="sellerName"
              clearable
              style="width: 180px;"
              placeholder="请输入商家名称"
            ></lui-input>
          </div>

          <div class="select-content">
            <span class="content-title content-title-last">VSC商家类型</span>
            <lui-select
              v-model="vscSellerType"
              style="width: 180px"
              clearable
              placeholder="请选择VSC商家类型">
              <lui-option
                v-for="(item,index) in sellerTypeList"
                :key="index"
                :label="item.name"
                :value="item.code">
              </lui-option>
            </lui-select>
          </div>

        </div>
        <div class="serch-right">
          <lui-button type="primary" style="width: 80px;" @click="getList()">查询</lui-button>
          <lui-button style="width: 80px;" @click="handleClose">重置</lui-button>
        </div>
      </div>
    </div>
    <div class="master-container">
      <div class="container-top">
        <div class="container-top-left">
          <span class="header-border"></span>
          <span class="header-title">数据列表</span>
        </div>
        <div class="container-top-right">
          <lui-button type="primary" @click="download">批量下载</lui-button>
          <button-list :buttons="buttons" :check-dept-no="checkDeptNo" @uploadSuccess="getList"></button-list>
          <lui-button type="primary" @click="handleDelete">手工删除</lui-button>
          <lui-button type="primary" @click="handleAdd">手工添加</lui-button>
        </div>
      </div>

      <div class="container-table">
        <div class="container-table-cont">
          <lui-table
            v-loading="LoadingTable"
            :data="tableData"
            border
            style="width: 100%"
            @selection-change="handleSelectionChange">
            <template slot="empty">
              <showEmptyImage></showEmptyImage>
            </template>
            <lui-table-column
              align="center"
              fixed="left"
              type="selection"
              width="50"
              show-overflow-tooltip>
            </lui-table-column>

            <lui-table-column
              prop="sellerNo"
              min-width="170"
              label="商家编码"
              show-overflow-tooltip>
            </lui-table-column>

            <lui-table-column
              prop="sellerName"
              min-width="170"
              label="商家名称"
              show-overflow-tooltip>
            </lui-table-column>

            <lui-table-column
              prop="vscSellerTypeDesc"
              label="VSC商家类型"
              min-width="170"
              show-overflow-tooltip>
            </lui-table-column>

            <lui-table-column
              prop="updateUser"
              label="修改人"
              min-width="170"
              show-overflow-tooltip>
            </lui-table-column>

            <lui-table-column
              prop="updateTime"
              label="修改时间"
              width="170"
              show-overflow-tooltip>
            </lui-table-column>

            <lui-table-column
              fixed="right"
              width="100"
              align="center"
              label="操作">
              <template v-slot="{row}">
                <div class="table-button">
                  <lui-button type="text" @click="handleEdit(row,1)">编辑</lui-button>
                  <lui-button type="text" @click="handleEdit(row,2)">查看</lui-button>
                </div>
              </template>
            </lui-table-column>
          </lui-table>
        </div>
        <div v-show="tableData.length>0" class="knowledge-pagination">
          <lui-pagination
            background
            :current-page.sync="pageNum"
            :page-sizes="[10, 20, 50, 70, 100]"
            layout="prev, pager, next, sizes, jumper"
            :total="totals"
            @current-change="handleSizeChange"
            @size-change="sizeChange">
          </lui-pagination>
        </div>
      </div>
    </div>

    <lui-dialog
      :visible.sync="centerDialogVisible"
      width="40%"
      top="10vh"
      :close-on-click-modal="false"
      custom-class="dialog_mask"
      :title="stateTitle">
      <lui-form
        ref="ruleForm"
        :model="ruleForm"
        :rules="rules"
        label-width="120px"
        class="demo-ruleForm">
        <lui-form-item
          label="商家编码"
          prop="sellerNo">
          <lui-input

            v-model.trim="ruleForm.sellerNo"
            :disabled="showEdit"
            placeholder="请输入商家编码"
            maxlength="30"
            @input="e => ruleForm.sellerNo = numberStringForbid (e)">
          </lui-input>
        </lui-form-item>

        <lui-form-item
          label="商家名称"
          prop="sellerName">
          <lui-input
            v-model.trim="ruleForm.sellerName"
            :disabled="disabledPre"
            maxlength="50"
            placeholder="请输入商家名称"
            @input="e => ruleForm.sellerName = specialForbid (e)">
          </lui-input>
        </lui-form-item>

        <lui-form-item
          label="VSC商家类型"
          prop="vscSellerType">
          <lui-select
            v-model="ruleForm.vscSellerType"
            :disabled="disabledPre"
            style="width: 100%;"
            placeholder="请选择VSC商家类型">
            <lui-option
              v-for="(item,index) in sellerTypeList"
              :key="index"
              :label="item.name"
              :value="item.code">
            </lui-option>
          </lui-select>
        </lui-form-item>
      </lui-form>

      <span slot="footer" class="dialog-footer">
        <lui-button @click="centerDialogVisible=false">取 消</lui-button>
        <lui-button v-if="!disabledPre" type="primary" :loading="loadingButton" @click="submitForm('ruleForm')">提 交</lui-button>
      </span>
    </lui-dialog>
  </div>
</template>

<script>
import Api from '@/api'
import showEmptyImage from '@/components/common/showEmptyImage/index.vue'
import ButtonList from '@/views/common/ButtonList'
import http from '@/lib/http'
import { exportExcel } from '@/utils/downloadRequest' //下载

const buttons = {
  upload: {
    noAsync: true,
    maxM: 10,
    uploadtips: '只能上传xlsx文件，文件大小不超过10M',
    label: '批量上传',
    uploadConfig: {
      uploadActionUrl: http.baseContextUrl + 'system/sellerWhitelist/upload'
    },
    templateUrl: http.baseContextUrl + 'system/sellerWhitelist/downloadTemplate'
  }
}
export default {
  name: 'configure.veu',
  components: {
    showEmptyImage,
    ButtonList
  },
  data() {
    return {
      baseURL: http.baseContextUrl,
      //-----------------------新增、编辑
      disabledPre: false, //预览是否禁用
      showEdit: false, //控制新增编辑状态 true/编辑    false/新增
      stateTitle: '新增商家分类管理',
      centerDialogVisible: false,
      loadingButton: false, //提交按钮状态
      ruleForm: {
        sellerNo: '',
        sellerName: '',
        vscSellerType: ''
      },
      rules: {
        sellerNo: [{ required: true, message: '请输入商家编码', trigger: ['blur', 'change'] }],
        sellerName: [{ required: true, message: '请输入商家名称', trigger: ['blur', 'change'] }],
        vscSellerType: [{ required: true, message: '请选择vsc商家类型', trigger: ['blur', 'change'] }]
      },
      sellerTypeList: [],

      //-----------------------列表
      checkDeptNo: false, //默认false表示不上传事业部
      buttons,
      sellerNo: '',
      sellerName: '',
      vscSellerType: '',
      value: '',
      LoadingTable: false,
      totals: 0,
      pageNum: 1, //页
      pageSize: 10, //条数
      tableData: [],
      multipleSelection: [] //全选反选
    }
  },
  mounted() {
    this.query()
    this.getList()
  },
  methods: {
    //枚举获取
    query() {
      Api.BusinessSort.query({
        code: 'vscSellerType'
      }).then(res => {
        if (res.success) {
          this.sellerTypeList = res.data
        }
      }).catch(() => {})
    },
    //---------------------------------------------------------新增、编辑
    handleEdit(row, type) {
      this.showEdit = true
      this.LoadingTable = true
      this.centerDialogVisible = true

      if (type === 1) { //编辑
        this.stateTitle = '编辑商家分类管理信息'
        this.disabledPre = false
      } else { //预览
        this.stateTitle = '预览商家分类管理信息'
        this.disabledPre = true
      }
      Api.BusinessSort.getDetail({
        sellerNo: row.sellerNo
      }).then(res => {
        if (res.success) {
          this.ruleForm.sellerNo = res.data.sellerNo ? res.data.sellerNo : ''
          this.ruleForm.sellerName = res.data.sellerName ? res.data.sellerName : ''
          this.ruleForm.vscSellerType = res.data.vscSellerType ? res.data.vscSellerType : ''
          this.LoadingTable = false
        } else {
          this.$showErrorMsg(res.errorMessage)
          this.LoadingTable = false
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
        this.LoadingTable = false
      })
    },
    handleAdd() {
      this.ruleForm.sellerNo = ''
      this.ruleForm.sellerName = ''
      this.ruleForm.vscSellerType = ''
      this.showEdit = false
      this.disabledPre = false
      this.centerDialogVisible = true
      this.stateTitle = '新增商家分类管理信息'
      this.$nextTick(() => {
        this.$refs['ruleForm'].clearValidate()
      })
    },

    //提交
    submitForm(ruleForm) {
      this.$refs[ruleForm].validate((valid) => {
        if (valid) {
          this.loadingButton = true
          if (this.showEdit) { //编辑
            Api.BusinessSort.edit(this.ruleForm).then(res => {
              if (res.success) {
                this.$showSuccessMsg('编辑成功')
                this.loadingButton = false
                this.centerDialogVisible = false
                this.getList()
              } else {
                this.$showErrorMsg(res.errorMessage)
                this.loadingButton = false
              }
            }).catch((e) => {
              this.$showErrorMsg(e)
              this.loadingButton = false
            })
          } else { //新增
            Api.BusinessSort.add(this.ruleForm).then(res => {
              if (res.success) {
                this.$showSuccessMsg('新增成功')
                this.loadingButton = false
                this.centerDialogVisible = false
                this.getList()
              } else {
                this.$showErrorMsg(res.errorMessage)
                this.loadingButton = false
              }
            }).catch((e) => {
              this.$showErrorMsg(e)
              this.loadingButton = false
            })
          }
        }
      })
    },

    //---------------------------------------------------------列表页
    //列表数据
    getList() {
      this.LoadingTable = true
      const params = {}
      params.pageNum = this.pageNum
      params.pageSize = this.pageSize
      params.sellerNo = this.sellerNo
      params.sellerName = this.sellerName
      params.vscSellerType = this.vscSellerType
      Api.BusinessSort.listPage(params).then(res => {
        if (res.success) {
          this.tableData = res.data
          this.totals = res.total
          this.LoadingTable = false
        } else {
          this.$showErrorMsg(res.errMesage)
          this.LoadingTable = false
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
        this.LoadingTable = false
      })
    },
    //重置搜索条件
    handleClose() {
      this.sellerNo = ''
      this.sellerName = ''
      this.vscSellerType = ''
      this.getList()
    },
    //全选反选
    handleSelectionChange(val) {
      this.multipleSelection = val
    },
    //分页条数改变
    sizeChange(val) {
      this.pageSize = val
      this.getList()
    },
    //翻页-----根据页码变换
    handleSizeChange(val) {
      this.pageNum = val
      this.getList()
    },

    //下载模版
    download() {
      const params = {}
      params.sellerNo = this.sellerNo
      params.sellerName = this.sellerName
      params.vscSellerType = this.vscSellerType

      const actionUrl = this.baseURL + Api.BusinessSort.download
      exportExcel(actionUrl, params)
    },
    //手工删除
    handleDelete() {
      if (this.multipleSelection.length === 0) {
        this.$showErrorMsg('请选择数据')
        return
      }
      const crrId = []
      for (let i = 0; i < this.multipleSelection.length; i++) {
        crrId.push(this.multipleSelection[i].sellerNo)
      }
      this.delete(crrId)
    },
    //  删除方法
    delete(row) {
      this.$alert('<p style="font-size: 18px;color:#333">确认删除此条消息吗?</p><p style="font-size: 13px;color: #666">删除后，此条消息的相关内容信息将无法恢复</p>', '', {
        dangerouslyUseHTMLString: true,
        type: 'warning',
        center: true
      }).then(() => {
        Api.BusinessSort.delete({
          sellerNoList: row
        }).then(res => {
          if (res.success) {
            this.$showSuccessMsg('删除成功')
            this.getList()
          } else {
            this.$showErrorMsg(res.errorMessage)
          }
        }).catch((e) => {
          this.$showErrorMsg(e)
        })
      }).catch(() => {})
    }
  }
}
</script>

<style scoped lang="scss">
@import '@/assets/stylus/main';
.table-p {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  cursor: pointer;
  padding-right: 15px;
}
.configure{
  .configure-title{
    padding: 30px 30px;
    background: #ffffff;
    width: 100%;
    box-shadow: 2px 2px 7px 2px #ccc;
    border-radius: 0 0 4px 4px;
    .title-text{
      font-size: 16px;
      font-weight: 600;
    }
    .title-serch{
      width: 100%;
      .serch-left{
        margin-bottom: 20px;
        width: 100%;
        display: flex;
        flex-wrap: wrap;
        .select-content{
          margin-top: 20px;
          width: 300px;
          .content-title{
            display: inline-block;
            width: 80px;
            text-align: right;
            margin-right: 10px;
            font-size: 14px;
            color: #333;
          }
          .content-title-last{
            display: inline-block;
            width: 100px;
            text-align: right;
            margin-right: 10px;
            font-size: 14px;
            color: #333;
          }
        }
      }
    }
    .serch-right{
      display: flex;
      align-items: flex-end;
      justify-content: flex-end;
      width: 100%;
    }
  }
  .master-container{
    width: 100%;
    background: #ffffff;
    margin-top: 20px;
    border-radius: 4px;
    box-shadow: 2px 2px 7px 2px #ccc;
    .container-top{
      width: 100%;
      padding-top: 30px;
      padding-bottom: 30px;
      display: flex;
      justify-content: space-between;
      .container-top-left{
        .header-border{
          width: 3px;
          height: 13px;
          display: inline-block;
          margin-left: 20px;
          margin-right: 8px;
        }
        .header-title{
          font-weight: 600;
          font-size: 16px;
          color: #333;
        }
      }
      .container-top-right{
        padding-right: 30px;
        .button-upload{
          position: relative;
          overflow: hidden;
          input{
            position: absolute;
            top: 0;
            bottom: 0;
            left: 0;
            right: 0;
            opacity: 0;
          }
        }
      }
    }
    .container-table{
      width: 100%;
      padding-left: 24px;
      padding-right: 24px;
      padding-bottom: 30px;
      .container-table-cont{
        min-height: 300px;
        .table-look{
          cursor: pointer;
          color: $--gl-blue;
          font-size: 14px;
          font-weight: 500;
        }
        .table-button{
          display: flex;
          justify-content: space-around;
        }
        .table-p {
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
          cursor: pointer;
          padding-right: 15px;
        }
      }
      .knowledge-pagination {
        width: 100%;
        margin-top: 20px;
        text-align: right;
      }
    }
  }
}
</style>
