<template>
  <div class="container">
    <div class="information-nav">
      <!-- 查询条件 -->
      <Search
        :table-search="tableSearch"
        @handleSearch="searchClick">
      </Search>
    </div>
    <div class="container-content">
      <!-- 按钮 -->
      <ButtonList
        :table-button="tableButton"
        @handelClick="handelClick"></ButtonList>
      <!-- 表格列表 -->
      <div class="container-table">
        <lui-table
          v-loading="LoadingTable"
          :data="tableData"
          border
          style="width: 100%"
          :header-cell-style="{background:'#D9F0FE',color:'#23252C'}"
          @selection-change="handleSelectionChange">
          <template slot="empty">
            <showEmptyImage></showEmptyImage>
          </template>
          <lui-table-column
            fixed="left"
            align="center"
            type="selection"
            width="50"
            show-overflow-tooltip>
          </lui-table-column>
          <lui-table-column
            prop="sellerNo"
            min-width="170"
            fixed="left"
            label="商家编码"
            show-overflow-tooltip>
          </lui-table-column> 

          <lui-table-column
            prop="sellerName"
            min-width="160"
            fixed="left"
            label="商家名称"
            show-overflow-tooltip>
          </lui-table-column>

          <lui-table-column
            prop="applyAccount"
            min-width="160"
            label="申请人"
            show-overflow-tooltip>
          </lui-table-column> 

          <lui-table-column
            prop="applyTime"
            min-width="160"
            label="申请时间"
            show-overflow-tooltip>
          </lui-table-column> 

          <lui-table-column
            prop="approveStatus"
            min-width="160"
            label="状态"
            show-overflow-tooltip>
            <template v-slot="{row}">
              <span v-for="(item,index) in statusList" :key="index">
                <span v-if="row.approveStatus===item.code">{{ item.desc }}</span>
              </span>
            </template>
          </lui-table-column> 

          <lui-table-column
            prop="approver"
            min-width="160"
            label="审批人"
            show-overflow-tooltip>
          </lui-table-column> 

          <lui-table-column
            prop="approveTime"
            min-width="160"
            label="审批时间"
            show-overflow-tooltip>
          </lui-table-column>
            
          <lui-table-column
            v-if="getAccount.userApplyOpenPermission || getAccount.userApplyClosePermission"
            width="120"
            align="center"
            fixed="right"
            label="操作">
            <template v-slot="{row}">
              <div>
                <lui-button v-if="(row.approveStatus === 'PENDING' || row.approveStatus === 'CLOSED') && getAccount.userApplyOpenPermission" type="text" @click="handelclickBar(row,true)">开启</lui-button>
                <lui-button v-if="(row.approveStatus === 'PENDING' || row.approveStatus === 'OPEN') && getAccount.userApplyClosePermission" type="text" @click="handelclickBar(row,false)">关闭</lui-button>
              </div>
            </template>
          </lui-table-column>
        </lui-table>
      </div>
     
      <!-- 翻页 -->
      <pagination
        v-if="paginationShow"
        :page-sizes="pageSizes"
        :total="total"
        :page-size="pageSize"
        @handleSizeChange="handleSizeChange"
        @handleCurrentChange="handleCurrentChange" />
    </div>
  </div>
</template>

<script>
import Search from '@/components/common/search'
import showEmptyImage from '@/components/common/showEmptyImage/index.vue'
import Api from '@/api'
import http from '@/lib/http'
import { mapGetters } from 'vuex'
import pagination from '@/components/common/pagination'
import ButtonList from '@/components/common/button'
export default {
  name: 'index',
  components: {
    Search,
    ButtonList,
    showEmptyImage,
    pagination
  },
  data() {
    return {
      buttonPermission: false,
      getAccount: {},
      multipleSelection: [],
      LoadingTable: false,
      paginationShow: true,
      applyAccount: '',
      approveStatus: '',
      sellerNo: '',
      sellerName: '',
      statusList: [],
      tableData: [],
      pageSizes: [10, 20, 50, 100],
      total: 0,
      pageNum: 1,
      pageSize: 10,
      tableButton: [
        {
          label: '返回',
          id: 'back',
          type: 'danger'
        }
      ],
      tableSearch: [
        {
          label: '商家编码',
          type: 'input',
          value: 'sellerNo',
          inpWidth: 220 //输入框长度
        }, 
        {
          label: '商家名称',
          type: 'input',
          value: 'sellerName',
          inpWidth: 220 //输入框长度
        },
        {
          label: '申请人',
          type: 'input',
          value: 'applyAccount',
          inpWidth: 220 //输入框长度
        },
        {
          label: '状态',
          type: 'select',
          value: 'approveStatus',
          children: [],
          code: 'code',
          name: 'desc',
          width: '110px',
          inpWidth: 220
        }
      ]
    }
  },
  computed: {
    ...mapGetters(['getButtonPermission'])
  },
  created() {
    this.getAccount = JSON.parse(sessionStorage.getItem('merchantsAccount'))
  },
  mounted() {
    this.getButton()
    this.getList() //数据列表
    this.listOpenChannelEnum() //状态
  },
  methods: {
    getButton() { //判断删除按钮是否显示
      const obj = {
        label: '手工删除',
        type: 'primary',
        id: 'del'
      }
      if (this.getButtonPermission) { //显示删除
        this.tableButton.unshift(obj)
      }
    },
    //全选反选
    handleSelectionChange(val) {
      this.multipleSelection = val
    },
    //状态
    listOpenChannelEnum() {
      Api.Merchants.listOpenChannelEnum().then(res => {
        if (res.success) {
          this.statusList = res.data
          //状态下拉赋值
          this.tableSearch.forEach(res => {
            if (res.value === 'approveStatus') {
              res.children = this.statusList
            }
          })
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
      })
    },


    //数据列表
    getList() {
      this.LoadingTable = true
      const params = {}
      params.pageNum = this.pageNum
      params.pageSize = this.pageSize
      params.approveStatus = this.approveStatus
      params.applyAccount = this.applyAccount
      params.sellerName = this.sellerName
      params.sellerNo = this.sellerNo
      Api.Merchants.listAll(params).then(res => {
        if (res.success) {
          this.tableData = res.data
          this.total = res.total
          this.LoadingTable = false
          this.paginationShow = true
        } else {
          this.LoadingTable = false
          this.$showErrorMsg(res.errMessage || '请求失败！')
        }
      }).catch((e) => { 
        this.LoadingTable = false
        this.$showErrorMsg(e || '请求失败！') 
      })
    },
    //开启关闭按钮
    handelclickBar(row, type) {
      if (type) { //开启
        const params = {}
        params.enable = type
        params.keyList = [{
          applyAccount: row.applyAccount ? row.applyAccount : '',
          id: row.id ? row.id : ''
        }]
        Api.Merchants.enable(params).then(res => {
          if (res.success) {
            this.$showSuccessMsg('开启成功')
            //刷新列表页
            this.getList()
          } else {
            this.$showErrorMsg(res.errMessage)
          }
        }).catch((e) => {
          this.$showErrorMsg(e || '请求错误')
        })
      } else { //关闭
        const params = {}
        params.enable = type
        params.keyList = [{
          applyAccount: row.applyAccount ? row.applyAccount : '',
          id: row.id ? row.id : ''
        }]
        Api.Merchants.enableBatchClose(params).then(res => {
          if (res.success) {
            this.$showSuccessMsg('关闭成功')
            //刷新列表页
            this.getList()
          } else {
            this.$showErrorMsg(res.errMessage)
          }
        }).catch((e) => {
          this.$showErrorMsg(e || '请求错误')
        })
      }
    },
    // BUTTON 操作
    handelClick(item) {
      switch (item.type) { //返回上一页
        case 'back':
          this.$router.push({ path: '/merchants' })
          break
        case 'del':
          if (this.multipleSelection.length === 0) {
            this.$showErrorMsg('请选择数据')
            return
          } else {
            var crrId = []
            for (let i = 0; i < this.multipleSelection.length; i++) {
              const obj = {}
              obj.id = this.multipleSelection[i].id
              obj.sellerNo = this.multipleSelection[i].sellerNo
              crrId.push(obj)
              this.delete(crrId)
            }
          }
          break
      }
    },
    //  删除方法
    delete(row) {
      this.$confirm('是否删除该数据?', '温馨提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        Api.Merchants.delete({ keyList: row }).then(res => {
          if (res.success) {
            this.$showSuccessMsg('删除成功')
            this.getList()
          } else {
            this.$showErrorMsg(res.errMessage)
          }
        }).catch((e) => {
          this.$showErrorMsg(e)
        })
      }).catch((e) => { console.error('已取消') })
    },
    //查询条件
    searchClick(val) {
      this.paginationShow = false
      this.approveStatus = val.approveStatus
      this.applyAccount = val.applyAccount
      this.sellerName = val.sellerName
      this.sellerNo = val.sellerNo
      this.pageNum = 1
      this.pageSize = 10
      this.getList() //重新刷新列表
    },    
    //页码更改
    handleSizeChange(val) {
      this.pageSize = val
      this.getList()
    },
    //翻页
    handleCurrentChange(val) {
      this.pageNum = val
      this.getList()
    }
  }
}
</script>

<style lang="scss" scoped="scoped">
  .container{
    width: 100%;
    .information-nav{
      box-shadow: 2px 2px 7px 2px #ccc;
      border-radius: 0 0 4px 4px;
      width: 100%;
      background: #ffffff;
      margin-bottom: 20px;
    }
    .container-content{
      background: #fff;
      width: 100%;
      border-radius: 4px;
      box-shadow: 2px 2px 7px 2px #ccc;
      // margin-top: 20px;
      padding: 0 25px 25px 25px;
      /*border: 1px solid red;*/
    }
    .container-table{
      margin-bottom: 25px;
    }
  }
</style>
