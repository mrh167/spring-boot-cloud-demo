<template>
  <div class="container">
    <div class="information-nav">
      <!-- 查询条件 -->
      <Search
        :table-search="tableSearch"
        @handleSearch="searchClick">
      </Search>
    </div>
    <div class="container-content">
      <!-- 按钮 -->
      <ButtonList
        :buttons="buttons"
        :configdept-no="deptNo.split('&')[0]"
        :configdept-name="deptNo.split('&')[1]"
        :check-dept-no="checkDeptNo"
        :table-button="tableButton"
        @handelClick="handelClick"
        @uploadSuccess="getList"></ButtonList>
      <!-- 表格列表 -->
      <flight-table
        :loading-show="loadingShow"
        :table-data="tableData"
        :columns="columns"
        :page-size="pageSize"
        :page-num="pageNum"
        @handleSelectionChange="handleSelectionChange" />
      <!-- 翻页 -->
      <pagination
        :page-sizes="pageSizes"
        :total="total"
        :page-size="pageSize"
        @handleSizeChange="handleSizeChange"
        @handleCurrentChange="handleCurrentChange" />
    </div>
  </div>
</template>

<script>
import Api from '@/api'
import flightTable from '@/components/common/table'
import Search from '@/components/common/search'
import http from '@/lib/http'
import pagination from '@/components/common/pagination'
import { exportExcel } from '@/utils/downloadRequest'
import ButtonList from '@/components/common/button'
const buttons = {
  upload: {
    noAsync: true,
    maxM: 10,
    uploadtips: '只能上传xlsx文件，文件大小不超过10M',
    label: '批量解绑',
    uploadConfig: {
      uploadActionUrl: http.baseContextUrl + '上传接口地址'
    },
    templateUrl: http.baseContextUrl + '下载接口地址'
  }
}
export default {
  name: 'index',
  components: {
    Search,
    flightTable,
    ButtonList,
    pagination
  },
  data() {
    return {
      dialogVisible: false,
      dialogTitle: '新增VSC商家分类信息',
      editShow: false,
      detailsShow: false,
      details: false,
      loadingButton: false,
      baseURL: http.baseContextUrl,
      buttons,
      deptNo: '',
      ruleForm: {},
      rules: {
        domain: [{ required: true, message: '请输入VSC商家类型编码', trigger: ['blur', 'change'] }],
        domain1: [{ required: true, message: '请输入VSC商家类型', trigger: ['blur', 'change'] }]
      },
      loadingShow: false,
      tableData: [],
      multipleSelection: [],
      pageSizes: [10, 20, 50, 100],
      total: 0,
      pageNum: 1,
      pageSize: 10,
      checkDeptNo: false, //默认false表示不上传事业部
      tableSearchObiect: {},
      tableSearch: [
        {
          label: '商家编码',
          type: 'input',
          value: 'sellerNo',
          inpWidth: 220 //输入框长度
        },
        {
          label: '商家名称',
          type: 'input',
          value: 'sellerName',
          inpWidth: 220 //输入框长度
        },
        {
          label: '事业部编码',
          type: 'input',
          value: 'deptNo',
          inpWidth: 220 //输入框长度
        },
        {
          label: '事业部名称',
          type: 'input',
          value: 'deptName',
          inpWidth: 220 //输入框长度
        },
        {
          label: '签约区域',
          type: 'select',
          value: 'registerRegion',
          children: [],
          code: 'code',
          name: 'desc',
          width: '110px',
          inpWidth: 220
        },
        {
          label: 'MTD周转',
          type: 'temperature',
          value: 'mtdTurnover',
          inpWidth: 220, //输入框长度
          left: {
            inpWidth: 92, //输入框长度
            placeholder: '开始',
            value: 'mtdTurnoverStart',
            onkeyup: "value=value.replace(/[^\d]/g,'')"
          },
          content: {
            value: '~'
          },
          right: {
            inpWidth: 92, //输入框长度
            placeholder: '结束',
            value: 'mtdTurnoverEnd'
          }
        },
        {
          label: '现货率',
          type: 'temperature',
          value: 'spotRate',
          inpWidth: 220, //输入框长度
          left: {
            inpWidth: 92, //输入框长度
            placeholder: '起始',
            value: 'spotRateStart',
            onkeyup: "value=value.replace(/[^\d]/g,'')"
          },
          content: {
            value: '~'
          },
          right: {
            inpWidth: 92, //输入框长度
            placeholder: '终止',
            value: 'spotRateEnd'
          }
        },
        {
          label: '滞销库存占比',
          type: 'temperature',
          maxlength: 30,
          inpWidth: 220, //输入框长度
          left: {
            inpWidth: 92, //输入框长度
            placeholder: '起始',
            value: 'unsalableStockRateStart',
            onkeyup: "value=value.replace(/[^\d]/g,'')"
          },
          content: {
            value: '~'
          },
          right: {
            inpWidth: 92, //输入框长度
            placeholder: '终止',
            value: 'unsalableStockRateEnd'
          }
        }
      ],
      tableButton: [
        {
          label: '批量下载',
          id: 'download',
          type: 'primary'
        }
      ],
      columns: [
        {
          id: 'selection',
          type: 'selection',
          label: '',
          fixed: 'left',
          width: '50',
          prop: '',
          align: 'center'
        },
        {
          id: 'text',
          type: 'text',
          label: '商家编码',
          width: '170',
          prop: 'sellerNo'
        },
        {
          id: 'text',
          type: 'text',
          label: '商家名称',
          width: '170',
          prop: 'sellerName'
        },
        {
          id: 'text',
          type: 'text',
          label: '事业部编码',
          width: '170',
          prop: 'deptNo'
        },
        {
          id: 'text',
          type: 'text',
          label: '事业部名称',
          width: '170',
          prop: 'deptName'
        },
        {
          id: 'text',
          type: 'text',
          label: '签约区域',
          width: '170',
          prop: 'registerRegion'
        },
        {
          id: 'text',
          type: 'text',
          label: 'MTD周转',
          width: '170',
          prop: 'mtdTurnover'
        },
        {
          id: 'text',
          type: 'text',
          label: '件数周转',
          width: '170',
          prop: 'turnover'
        },
        {
          id: 'text',
          type: 'text',
          label: '现货率',
          width: '170',
          prop: 'spotRate'
        },
        {
          id: 'text',
          type: 'text',
          label: '缺货商品数量',
          width: '170',
          prop: 'shortSupplySkuNum'
        },
        {
          id: 'text',
          type: 'text',
          label: '预计7日销售损失金额',
          width: '170',
          prop: 'shortSupplyAmount'
        },
        {
          id: 'text',
          type: 'text',
          label: '即将缺货商品数量',
          width: '170',
          prop: 'aboutShortSkuNum'
        },
        {
          id: 'text',
          type: 'text',
          label: '滞销库存占比',
          width: '170',
          prop: 'unsalableStockRate'
        },
        {
          id: 'text',
          type: 'text',
          label: '滞销商品数量',
          width: '170',
          prop: 'unsaleSkuNum'
        },
        {
          id: 'text',
          type: 'text',
          label: '滞销库存价值',
          width: '170',
          prop: 'unsaleAmount'
        },
        {
          id: 'text',
          type: 'text',
          label: '不动销商品数量',
          width: '170',
          prop: 'noSaleSkuNum'
        },
        {
          id: 'text',
          type: 'text',
          label: '不动销商品价值',
          width: '170',
          prop: 'noSaleStockAmount'
        }
      ]

    }
  },
  mounted() {
    this.regionEnum()
    this.getList()
  },
  methods: {
    //区域列表
    regionEnum() {
      Api.Merchants.regionEnum().then(res => {
        if (res.success) {
          this.regionList = res.data
          this.tableSearch.forEach(item => {
            if (item.value === 'registerRegion') {
              item.children = res.data
            }
          })
        } else {
          this.$showErrorMsg(res.errMessage)
        }
      }).catch((e) => {
        console.error(e)
      })
    },
    //数据列表
    getList() {
      this.loadingShow = true
      const params = {}
      params.pageNum = this.pageNum
      params.pageSize = this.pageSize
      params.sellerNo = this.tableSearchObiect.sellerNo || ''
      params.sellerName = this.tableSearchObiect.sellerName || ''
      params.deptNo = this.tableSearchObiect.deptNo || ''
      params.deptName = this.tableSearchObiect.deptName || ''
      params.registerRegion = this.tableSearchObiect.registerRegion || ''
      params.mtdTurnoverStart = this.tableSearchObiect.mtdTurnoverStart || ''
      params.mtdTurnoverEnd = this.tableSearchObiect.mtdTurnoverEnd || ''
      params.spotRateStart = this.tableSearchObiect.spotRateStart || ''
      params.spotRateEnd = this.tableSearchObiect.spotRateEnd || ''
      params.unsalableStockRateStart = this.tableSearchObiect.unsalableStockRateStart || ''
      params.unsalableStockRateEnd = this.tableSearchObiect.unsalableStockRateEnd || ''
      Api.Merchants.sellerList(params).then(res => {
        if (res.success) {
          this.tableData = res.data
          this.total = res.total
          this.loadingShow = false
        } else {
          this.loadingShow = false
          this.$showErrorMsg(res.errMessage)
        }
      }).catch((e) => {
        this.loadingShow = false
        this.$showErrorMsg(e)
      })
    },
    // 数据操作按钮
    handelClick(item) {
      if (item.type === 'download') {
        var params = {}
        params.sellerNo = this.tableSearchObiect.sellerNo || ''
        params.sellerName = this.tableSearchObiect.sellerName || ''
        params.deptNo = this.tableSearchObiect.deptNo || ''
        params.deptName = this.tableSearchObiect.deptName || ''
        params.registerRegion = this.tableSearchObiect.registerRegion || ''
        params.mtdTurnoverStart = this.tableSearchObiect.mtdTurnoverStart || ''
        params.mtdTurnoverEnd = this.tableSearchObiect.mtdTurnoverEnd || ''
        params.spotRateStart = this.tableSearchObiect.spotRateStart || ''
        params.spotRateEnd = this.tableSearchObiect.spotRateEnd || ''
        params.unsalableStockRateStart = this.tableSearchObiect.unsalableStockRateStart || ''
        params.unsalableStockRateEnd = this.tableSearchObiect.unsalableStockRateEnd || ''
        var actionUrl = this.baseURL + Api.Merchants.sellerdownload
        exportExcel(actionUrl, params)
      }
    },
    //查询条件
    searchClick(val) { 
      this.tableSearchObiect = val
      this.pageNum = 1
      this.pageSize = 10
      this.getList() 
    },
    //多选
    handleSelectionChange(val) {
      this.multipleSelection = val.val
    },
    //页码更改
    handleSizeChange(val) {
      this.pageSize = val
      this.getList()
    },
    //翻页
    handleCurrentChange(val) {
      this.pageNum = val
      this.getList()
    }
  }
}
</script>

<style lang="scss" scoped="scoped">
  .container{
    width: 100%;
    .information-nav{
      box-shadow: 2px 2px 7px 2px #ccc;
      border-radius: 0 0 4px 4px;
      width: 100%;
      background: #ffffff;
      margin-bottom: 20px;
    }
    .container-content{
      background: #fff;
      width: 100%;
      border-radius: 4px;
      box-shadow: 2px 2px 7px 2px #ccc;
      // margin-top: 20px;
      padding: 0 25px 25px 25px;
      /*border: 1px solid red;*/
    }
  }
</style>
