<template>
  <div class="container">
    <div class="container-content">
      <!-- 按钮 -->
      <ButtonList
        :buttons="buttons"
        :configdept-no="deptNo.split('&')[0]"
        :configdept-name="deptNo.split('&')[1]"
        :check-dept-no="checkDeptNo"
        :table-button="tableButton"
        @handelClick="handelClick"
        @uploadSuccess="getList" />
      <!-- 表格列表 -->
      <flight-table
        :loading-show="loadingShow"
        :table-data="tableData"
        :columns="columns"
        :page-size="pageSize"
        :page-num="pageNum"
        @handleSelectionChange="handleSelectionChange"
        @handleEdit="handleEdit" />
      <!-- 翻页 -->
      <pagination
        :page-sizes="pageSizes"
        :total="total"
        :page-size="pageSize"
        @handleSizeChange="handleSizeChange"
        @handleCurrentChange="handleCurrentChange" />
    </div>
  </div>
</template>

<script>
import flightTable from '@/components/common/table'
import http from '@/lib/http'
import pagination from '@/components/common/pagination'

import ButtonList from '@/components/common/button'
const buttons = {
  upload: {
    noAsync: true,
    maxM: 10,
    uploadtips: '只能上传xlsx文件，文件大小不超过10M',
    label: '批量解绑',
    uploadConfig: {
      uploadActionUrl: http.baseContextUrl + 'sync/syncSettledLog'
    }
    // templateUrl: http.baseContextUrl + 'baseGoodsInfo/downloadTemplate'
  }
}
export default {
  name: 'index',
  components: {
    flightTable,
    ButtonList,
    pagination
  },
  data() {
    return {
      editShow: false,
      detailsShow: false,
      details: false,
      loadingButton: false,
      buttons,
      deptNo: '',
      loadingShow: false,
      tableData: [],
      multipleSelection: [],
      pageSizes: [10, 20, 50, 100],
      total: 0,
      pageNum: 1,
      pageSize: 10,
      checkDeptNo: false, //默认false表示不上传事业部
      tableButton: [
        {
          label: '批量上传',
          id: 'upload',
          type: 'primary'
        }
      ],
      columns: [
        {
          id: 'selection',
          type: 'selection',
          label: '',
          fixed: 'left',
          width: '50',
          prop: '',
          align: 'center'
        },
        {
          id: 'text',
          type: 'text',
          label: '数据列表',
          fixed: false,
          width: '170',
          prop: 'billTypeName',
          align: 'left'
        },
        {
          id: 'button',
          type: 'button',
          label: '操作',
          fixed: 'right',
          width: '100',
          align: 'center',
          list: [
            {
              id: 'details',
              name: '详情',
              type: 'text',
              size: ''
            },
            {
              id: 'edit',
              name: '编辑',
              type: 'text',
              size: ''
            }
          ]
        }
      ]

    }
  },
  methods: {
    //button 数据操作按钮
    handelClick(val) {
      console.log(val, 'val')
    },
    //数据列表
    getList() {

    },
    handleEdit() {},
    //多选
    handleSelectionChange(val) {
      this.multipleSelection = val.val
    },
    //页码更改
    handleSizeChange(val) {
      this.pageSize = val
      this.getList()
    },
    //翻页
    handleCurrentChange(val) {
      this.pageNum = val
      this.getList()
    },
    // 表格点击
    handleClickTable(val) {},
    //class 赋值
    handleClassName(val) {},
    //表格模糊下拉
    handleQueryUnit(queryString, cb) {}
  }
}
</script>

<style lang="scss" scoped="scoped">
  .container{
    width: 100%;
    .information-nav{
      box-shadow: 2px 2px 7px 2px #ccc;
      border-radius: 0 0 4px 4px;
      width: 100%;
      background: #ffffff;
      margin-bottom: 20px;
    }
    .container-content{
      background: #fff;
      width: 100%;
      border-radius: 4px;
      box-shadow: 2px 2px 7px 2px #ccc;
      // margin-top: 20px;
      padding: 0 25px 25px 25px;
      /*border: 1px solid red;*/
    }
  }
</style>
