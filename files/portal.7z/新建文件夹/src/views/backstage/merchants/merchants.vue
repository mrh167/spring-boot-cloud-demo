<template>
  <div class="warpper">
    <div v-if="applicantShow" class="container">
      <div class="information-nav">
        <!-- 查询条件 -->
        <Search
          :table-search="tableSearch"
          @handleSearch="handelSearchClick"
          @handelValue="handelValue">
        </Search>
      </div>
      <div class="container-content">
        <!-- 按钮 -->
        <ButtonList
          :buttons="buttons"
          :configdept-no="deptNo.split('&')[0]"
          :configdept-name="deptNo.split('&')[1]"
          :check-dept-no="checkDeptNo"
          :table-button="tableButton"
          @handelClick="handelClick"
          @uploadSuccess="getList"></ButtonList>
        <!-- 表格列表 -->
        <div class="container-table">
          <lui-table
            v-loading="LoadingTable"
            :data="tableData"
            border
            style="width: 100%"
            :header-cell-style="{background:'#D9F0FE',color:'#23252C'}"
            @selection-change="handleSelectionChange">
            <template slot="empty">
              <showEmptyImage></showEmptyImage>
            </template>
            <lui-table-column
              fixed="left"
              align="center"
              type="selection"
              width="50"
              show-overflow-tooltip>
            </lui-table-column>

            <lui-table-column
              prop="sellerNo"
              min-width="160"
              fixed="left"
              label="商家编码"
              show-overflow-tooltip>
            </lui-table-column> 

            <lui-table-column
              prop="sellerName"
              min-width="160"
              fixed="left"
              label="商家名称">
              <template v-slot="{row}">
                <p v-if="row.openStatus === 5" type="text" class="decoration" @click="updateSelectSeller(row)">{{ row.sellerName }}</p>
                <p v-else class="decoration2">{{ row.sellerName }}</p>
              </template>
            </lui-table-column>
                      
            <lui-table-column
              prop="deptList"
              min-width="160"
              fixed="left"
              label="事业部">
              <!-- <template v-slot="{row}">
                <p v-for="(item,index) in row.deptList" :key="index">{{ item.deptNo }}</p>
              </template> -->

              <template v-slot="{row}">
                <lui-popover
                  placement="right"
                  width="550"
                  trigger="hover">
                  <div class="hoverDeptNo">
                    <div class="hoverDeptNoTitle">
                      <div>序号</div>
                      <div>事业部编码</div>
                      <div>事业部名称</div>
                    </div>
                    <div v-for="(item,index) in row.deptList" :key="index" class="hoverDeptNoBody" @click="handelDept(item)">
                      <div>{{ index + 1 }}</div>
                      <div>{{ item.deptNo }}</div>
                      <lui-tooltip v-if="getBLen(item.deptName)>20" class="item" effect="dark" :content="item.deptName" placement="top">
                        <div class="deptClass">{{ item.deptName }}</div>
                      </lui-tooltip>

                      <div v-else>{{ item.deptName }}</div>

                    </div>
                  </div>
                  <div slot="reference" class="refeSpan">
                    <span 
                      v-for="(item,index) in row.deptList"
                      :key="index" 
                      class="span">{{ item.deptNo }}<i v-if="index!== row.deptList.length-1">，</i></span>
                  </div>
                </lui-popover>
              </template>

            </lui-table-column>

            <!-- <lui-table-column
              prop="deptList"
              min-width="160"
              label="事业部名称">
              <template v-slot="{row}">
                <div class="table-div">
                  <p v-for="(item,index) in row.deptList" :key="index" @click="handelDept(item)">{{ item.deptName }}</p>
                </div>
              </template>
            </lui-table-column> -->
            <!-- 一期新增 -->
            <lui-table-column
              prop="applyAccount"
              min-width="160"
              label="申请人"
              show-overflow-tooltip>
            </lui-table-column> 

            <lui-table-column
              prop="regionAccount"
              min-width="160"
              label="销售ERP"
              show-overflow-tooltip>
            </lui-table-column> 

            <lui-table-column
              prop="applyTime"
              min-width="160"
              label="申请时间"
              show-overflow-tooltip>
            </lui-table-column> 

            <lui-table-column
              prop="approver"
              min-width="160"
              label="审批人"
              show-overflow-tooltip>
            </lui-table-column> 

            <lui-table-column
              prop="approveTime"
              min-width="160"
              label="审批时间"
              show-overflow-tooltip>
            </lui-table-column>
            <!-- 一期结束 -->

            

            <lui-table-column
              prop="bdOwnerNo"
              min-width="160"
              label="青龙业主号">
              <template v-slot="{row}">
                <lui-popover
                  placement="right"
                  width="350"
                  trigger="hover">
                  <div class="hoverDiv">
                    <div class="hoverDivTitle">
                      <div>序号</div>
                      <div>青龙业主号</div>
                    </div>
                    <div v-for="(item,index) in row.bdOwnerNoList" :key="index" class="hoverDivBody">
                      <div>{{ index + 1 }}</div>
                      <div>{{ item }}</div>
                    </div>
                  </div>
                  <div slot="reference" class="refeSpan">
                    <span 
                      v-for="(item,index) in row.bdOwnerNoList"
                      :key="index" 
                      class="span">{{ item }}<i v-if="index!== row.bdOwnerNoList.length-1">，</i></span>
                  </div>
                </lui-popover>
              </template>
            </lui-table-column>

            <lui-table-column
              prop="deptList"
              min-width="160"
              label="签约区域"
              show-overflow-tooltip>
              <template v-slot="{row}">
                <span v-for="(item,index) in row.registerRegion" :key="index">
                  <span v-for="(res,index2) in regionList" :key="index2">
                    <span v-if="item === res.code"> {{ res.desc }}<i v-if="index!== row.registerRegion.length-1">，</i></span>
                  </span>
                </span>
              </template>
            </lui-table-column>
            
            <lui-table-column
              prop="openStatus"
              min-width="160"
              label="开通状态">
              <template v-slot="{row}">
                <div v-if="row.openStatus === 2" class="status">
                  <span><i style="background:#FFB601"></i></span>
                  <span>待审核</span>
                </div>
                <div v-else-if="row.openStatus === 3" class="status">
                  <span><i style="background:#EB4E4E"></i></span>
                  <span>待申请</span>
                </div>
                <div v-else-if="row.openStatus === 4" class="status">
                  <span><i style="background:#1854F3"></i></span>
                  <span>已关闭</span>
                </div>
                <div v-else-if="row.openStatus === 5" class="status">
                  <span><i style="background:#00D5A3"></i></span>
                  <span>使用中</span>
                </div>
                <div v-else-if="row.openStatus === 6" class="status">
                  <span><i style="background:#969FAA"></i></span>
                  <span>已过期</span>
                </div>
              </template>
            </lui-table-column>

            <lui-table-column
              prop="startTime"
              width="160"
              label="开始时间">
              <template v-slot="{row}">
                <lui-date-picker
                  v-if="row.isSet"
                  v-model="row.startTime"
                  style="width:135px"
                  type="date"
                  :picker-options="row.pickerBeginDateBefore"
                  value-format="yyyy-MM-dd HH:mm:ss"
                  placeholder="选择开通日期"
                  @change="handleStartTime(row)">
                </lui-date-picker>
                <p v-else>{{ row.startTime.slice(0,11) }}</p>
              </template>
            </lui-table-column>

            <lui-table-column
              prop="endTime"
              min-width="160"
              label="结束时间">
              <template v-slot="{row}">
                <lui-date-picker
                  v-if="row.isSet"
                  v-model="row.endTime"
                  style="width:135px"
                  type="date"
                  :picker-options="row.pickerBeginDateAfter"
                  value-format="yyyy-MM-dd HH:mm:ss"
                  placeholder="选择结束日期"
                  @change="handleEndTime(row)">
                </lui-date-picker>
                <span v-else>{{ row.endTime.slice(0,11) }}</span>
              </template>
            </lui-table-column>

            <lui-table-column
              prop="openChannel"
              min-width="160"
              label="开通渠道">
              <template v-slot="{row}">
                <div v-if="row.openChannel === 1" class="status">线上申请</div>
                <div v-if="row.openChannel === 2" class="status">签约开通</div>
                <div v-if="row.openChannel === 3" class="status">手动开通</div>
              </template>
            </lui-table-column>

            <lui-table-column
              prop="useVersion"
              min-width="160"
              label="使用版本">
              <template v-slot="{row}">
                <div v-if="row.isSet">
                  <lui-select 
                    v-model="row.useVersion"
                    placeholder="请选择使用版本">
                    <lui-option
                      v-for="item in menuVersionList"
                      :key="item.code"
                      :label="item.desc"
                      :value="item.code">
                    </lui-option>
                  </lui-select>
                </div>
                <div v-else>
                  <p 
                    v-for="(item,index) in menuVersionList" 
                    :key="index">
                    <span v-if="item.code === row.useVersion">{{ item.desc }}</span>
                  </p>
                </div>
              
              </template>
            </lui-table-column>

            <lui-table-column
              prop="vscFlagSwitch"
              min-width="160"
              label="是否VSC运营">
              <template v-slot="{row}">
                <div v-if="row.isSet">
                  <lui-switch
                    v-model="row.vscFlagSwitch">
                  </lui-switch>
                </div>
                <div v-else>
                  <span>{{ row.vscFlagSwitch ? '是' : '否' }}</span>
                </div>
              </template>
            </lui-table-column>

            <lui-table-column
              prop="updateUser"
              min-width="160"
              label="操作人"
              show-overflow-tooltip>
            </lui-table-column>

            <lui-table-column
              prop="updateTime"
              min-width="160"
              label="操作时间"
              show-overflow-tooltip>
            </lui-table-column>

            <lui-table-column
              prop="contractList"
              min-width="160"
              label="主合同编码">
              <template v-slot="{row}">

                <lui-popover
                  placement="right"
                  width="350"
                  trigger="hover">
                  <div class="hoverDiv">
                    <div class="hoverDivTitle">
                      <div>序号</div>
                      <div>主合同编号</div>
                    </div>
                    <div v-for="(item,index) in row.contractList" :key="index" class="hoverDivBody" @click="handelContract(item)">
                      <div>{{ index + 1 }}</div>
                      <div>{{ item.contractCode }}</div>
                    </div>
                  </div>
                  <div slot="reference" class="refeSpan">
                    <span 
                      v-for="(item,index) in row.contractList"
                      :key="index" 
                      class="span"
                      @click="handelContract(item)">{{ item.contractCode }}<i v-if="index!== row.contractList.length-1">，</i></span>
                  </div>
                </lui-popover>
              </template>
            </lui-table-column>
            
            <lui-table-column
              v-if="getAccount.sellerSettledEditPermission || getAccount.sellerSettledApprovePermission"
              prop="deptNo"
              :width="getAccount.sellerSettledApprovePermission && getAccount.sellerSettledEditPermission ? 140 : 100"
              align="center"
              fixed="right"
              label="操作">
              <template v-slot="{row}">
                <div v-if="row.isSet">
                  <lui-button type="text" @click="handelPreservation(row)">保存</lui-button>
                  <lui-button type="text" @click="handelCancel(row)">取消</lui-button>
                </div>
                <div v-else>
                  <lui-button v-if="getAccount.sellerSettledApprovePermission" type="text" :disabled="( row.openStatus === 2 || row.openStatus === 3 ||row.openStatus === 4 )? false : true" @click="handelEnable(row,true)">开启</lui-button>
                  <lui-button v-if="getAccount.sellerSettledApprovePermission" type="text" :disabled="( row.openStatus === 2 ) ? false : true" @click="handelEnable(row,false)">关闭</lui-button>
                  <lui-button v-if="getAccount.sellerSettledEditPermission" type="text" @click="handelEdit(row)">编辑</lui-button>
                </div>
              
              </template>
            </lui-table-column>
          </lui-table>
        </div>
        <!-- 翻页 -->
        <pagination
          v-if="paginationShow"
          :page-sizes="pageSizes"
          :total="total"
          :page-size="pageSize"
          @handleSizeChange="handleSizeChange"
          @handleCurrentChange="handleCurrentChange" />
      </div>
      <!-- 合同明细 -->
      <lui-dialog
        :visible.sync="dialogVisibleContract"
        width="40%"
        top="10vh"
        :close-on-click-modal="false"
        title="合同明细">
        <lui-form
          ref="contractForm"
          :model="contractForm"
          label-width="140px"
          class="demo-ruleForm">
          <div class="ruleForm-title">
            <lui-row>
              <lui-col :span="24">
                <lui-form-item
                  label="合同编码"
                  prop="contractCode">
                  <lui-input
                    v-model.trim="contractForm.contractCode"
                    disabled>
                  </lui-input>
                </lui-form-item>
              </lui-col>
            </lui-row>
            <lui-row>
              <lui-col :span="24">
                <lui-form-item
                  label="合同名称"
                  prop="clientCode">
                  <lui-input
                    v-model.trim="contractForm.clientCode"
                    disabled>
                  </lui-input>
                </lui-form-item>
              </lui-col>
            </lui-row>
            <lui-row>
              <lui-col :span="24">
                <lui-form-item
                  label="主合同开始时间"
                  prop="startTime">
                  <lui-input
                    v-model.trim="contractForm.startTime"
                    disabled>
                  </lui-input>
                </lui-form-item>
              </lui-col>
            </lui-row>
            <lui-row>
              <lui-col :span="24">
                <lui-form-item
                  label="主合同结束时间"
                  prop="endTime">
                  <lui-input
                    v-model.trim="contractForm.endTime"
                    disabled>
                  </lui-input>
                </lui-form-item>
              </lui-col>
            </lui-row>
          </div>
        </lui-form>
        <!-- 页脚按钮 -->
        <span slot="footer" class="dialog-footer">
          <lui-button @click="dialogVisibleContract=false">取 消</lui-button>
        </span>
      </lui-dialog>
      <!-- 事业部明细 -->
      <lui-dialog
        v-if="dialogVisible"
        :visible.sync="dialogVisible"
        width="40%"
        top="10vh"
        :close-on-click-modal="false"
        title="事业部明细">
        <lui-form
          ref="deptForm"
          :model="deptForm"
          label-width="140px"
          class="demo-ruleForm">
          <div class="ruleForm-title">
            <lui-row>
              <lui-col :span="24">
                <lui-form-item
                  label="事业部编码"
                  prop="deptNo">
                  <lui-input
                    v-model.trim="deptForm.deptNo"
                    disabled>
                  </lui-input>
                </lui-form-item>
              </lui-col>
            </lui-row>
            <lui-row>
              <lui-col :span="24">
                <lui-form-item
                  label="事业部名称"
                  prop="deptName">
                  <lui-input
                    v-model.trim="deptForm.deptName"
                    disabled>
                  </lui-input>
                </lui-form-item>
              </lui-col>
            </lui-row>
            <lui-row>
              <lui-col :span="24">
                <lui-form-item
                  label="集团销售"
                  prop="groupAccount">
                  <lui-input
                    v-model.trim="deptForm.groupAccount"
                    disabled>
                  </lui-input>
                </lui-form-item>
              </lui-col>
            </lui-row>
            <lui-row>
              <lui-col :span="24">
                <lui-form-item
                  label="区域销售"
                  prop="regionAccount">
                  <lui-input
                    v-model.trim="deptForm.regionAccount"
                    disabled>
                  </lui-input>
                </lui-form-item>
              </lui-col>
            </lui-row>
            <!-- <lui-row>
            <lui-col :span="24">
              <lui-form-item
                label="商家类型"
                prop="eclpSellerType">
                <lui-input
                  v-model.trim="deptForm.eclpSellerType"
                  disabled>
                </lui-input>
              </lui-form-item>
            </lui-col>
          </lui-row> -->
            <lui-row>
              <lui-col :span="24">
                <lui-form-item
                  label="是否智能商务仓"
                  prop="businessClass">
                  <lui-checkbox v-model="deptForm.businessClass"></lui-checkbox>
                </lui-form-item>
              </lui-col>
            </lui-row>
          </div>
        </lui-form>
        <!-- 页脚按钮 -->
        <span slot="footer" class="dialog-footer">
          <lui-button @click="dialogVisible=false">取 消</lui-button>
          <lui-button type="primary" @click="handelSubmit()">确 定</lui-button>
        </span>
      </lui-dialog>
    </div>
    <div v-else class="applicant">
      <!-- <applicantBar 
        :get-account="getAccount"
        @eventBack="hadelBack">
      </applicantBar> -->
    </div>
  </div>
  
</template>

<script>
import Api from '@/api'
// import applicantBar from './common/index'
import showEmptyImage from '@/components/common/showEmptyImage/index.vue'
import Search from '@/components/common/search'
import http from '@/lib/http'
import pagination from '@/components/common/pagination'
import ButtonList from '@/components/common/button'
import { exportExcel } from '@/utils/downloadRequest'
import { mapGetters } from 'vuex'
import $ from 'jquery'
const buttons = {
  upload: {
    noAsync: true,
    maxM: 10,
    uploadtips: '只能上传xlsx文件，文件大小不超过10M',
    label: '批量解绑',
    uploadConfig: {
      uploadActionUrl: http.baseContextUrl + '上传接口地址'
    },
    templateUrl: http.baseContextUrl + '下载接口地址'
  }
}
export default {
  name: 'index',   
  components: {
    Search,
    ButtonList,
    pagination,
    showEmptyImage
    // applicantBar
  },
  data() {
    return {
      buttonPermission: false,
      applicantShow: true,
      paginationShow: true,
      getAccount: {},
      userInfo: '',
      nowTimeNew: '', //ajax获取时间
      contractForm: {}, //合同详情
      deptForm: {}, //事业部详情
      bdOwnerNo: '', // 青龙业主号
      deptName: '', //事业部名称
      deptNo: '', //事业部编码
      openChannel: '', // 开通渠道
      openStatus: '', //  开通状态
      registerRegion: '', // 签约区域
      sellerName: '', // 商家名称
      sellerNo: '', // 商家编码
      total: 0,
      pageNum: 1,
      pageSize: 10,
      menuVersionList: [], //版本列表
      regionList: [], //区域列表
      statusEnumList: [], //状态列表
      channelEnumList: [], //渠道列表
      dialogVisibleContract: false,
      baseURL: http.baseContextUrl,
      LoadingTable: false,
      dialogVisible: false,
      buttons,
      tableData: [],
      multipleSelection: [],
      pageSizes: [10, 20, 50, 100],
      checkDeptNo: false, //默认false表示不上传事业部
      tableSearch: [
        {
          label: '商家编码',
          type: 'input',
          value: 'sellerNo',
          inpWidth: 220 //输入框长度
        },
        {
          label: '商家名称',
          type: 'input',
          value: 'sellerName',
          inpWidth: 220 //输入框长度
        },
        {
          label: '事业部编码',
          type: 'input',
          value: 'deptNo',
          inpWidth: 220
        },
        {
          label: '事业部名称',
          type: 'input',
          value: 'deptName',
          inpWidth: 220 //输入框长度
        },
        {
          label: '青龙业主号',
          type: 'input',
          value: 'bdOwnerNo',
          inpWidth: 220 //输入框长度
        },
        {
          label: '签约区域',
          type: 'select',
          value: 'registerRegion',
          children: [],
          code: 'code',
          name: 'desc',
          width: '110px',
          inpWidth: 220
        },
        {
          label: '开通状态',
          type: 'select',
          value: 'openStatus',
          children: [],
          code: 'code',
          name: 'desc',
          width: '110px',
          inpWidth: 220
        },
        {
          label: '开通渠道',
          type: 'select',
          value: 'openChannel',
          children: [],
          code: 'code',
          name: 'desc',
          width: '110px',
          inpWidth: 220
        },
        { //开始时间
          label: '开始时间',
          type: 'date',
          format: 'yyyy-MM-dd', //显示类型
          valueFormat: 'yyyy-MM-dd HH:mm:ss', //输出类型
          value: 'startTime',
          maxlength: false,
          pickerOptions: {},
          inpWidth: 220
        },
        { //结束时间
          label: '结束时间',
          type: 'date',
          format: 'yyyy-MM-dd', //显示类型
          valueFormat: 'yyyy-MM-dd HH:mm:ss', //输出类型
          value: 'endTime',
          maxlength: false,
          pickerOptions: {},
          inpWidth: 220
        }
      ],
      tableButton: []
    }
  },
  computed: {
    ...mapGetters(['getUserInfo', 'getPublicPage', 'getButtonPermission'])
  },
  created() {
    this.getAccountAuth() //权限控制
  },
  mounted() {
    this.dataAjax()
    this.regionEnum() //区域
    this.menuVersion() //版本
    this.statusEnum() //开通状态
    this.channelEnum()//开通渠道    
    this.getList() //数据列表
  },
  methods: {
    //--------------------------------------一期新增
    getBLen(str) {
      if (str == null) return 0
      if (typeof str !== 'string') {
        str += ''
      }
      return str.replace(/[^x00-xff]/g, '01').length
    },
    //气泡
    countByBubble() {
      Api.Merchants.countByBubble().then(res => {
        if (res.success) {
          this.tableButton.forEach(item => {
            if (item.id === 'application') {
              item.value = res.data
            }
          })
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
      })
    },
    getButton() { //判断删除按钮是否显示
      const obj = {
        label: '手工删除',
        type: 'primary',
        id: 'deleted'
      }
      if (this.getButtonPermission) { //显示删除
        this.tableButton.unshift(obj)
      }
    },
    //权限控制
    getAccountAuth() {
      Api.Merchants.getAccountAuth().then(res => {
        if (res.success) {
          // res.data.userApplyClosePermission = false
          this.getAccount = res.data
          if (this.getAccount.sellerSettledApprovePermission) { //商家入驻审批权限 
            if (this.getAccount.sellerSettledEditPermission) { //是否有销售人员权限
              this.tableButton = [
                {
                  label: '批量下载',
                  id: 'download',
                  type: 'primary'
                },
                // { //手工删除暂时隐藏 
                //   label: '手工删除',
                //   type: 'primary',
                //   id: 'deleted'
                // },
                {
                  label: '批量通过',
                  id: 'adopt',
                  type: 'primary'
                }
                // {
                //   label: '批量关闭',
                //   id: 'close',
                //   type: 'danger'
                // }
              ]
            } else {
              this.tableButton = [
               
                {
                  label: '批量下载',
                  id: 'download',
                  type: 'primary'
                },
                {
                  label: '批量通过',
                  id: 'adopt',
                  type: 'primary'
                }
                // {
                //   label: '批量关闭',
                //   id: 'close',
                //   type: 'danger'
                // }
              ]
            }
          } else { //无商家入驻审批权限
            if (this.getAccount.sellerSettledEditPermission) { //是否有销售人员权限
              this.tableButton = [
                {
                  label: '批量下载',
                  id: 'download',
                  type: 'primary'
                }
                // { //手工删除暂时隐藏 
                //   label: '手工删除',
                //   type: 'primary',
                //   id: 'deleted'
                // }
              ]
            } else {
              this.tableButton = [
                {
                  label: '批量下载',
                  id: 'download',
                  type: 'primary'
                }
              ]
            }
          }
          if (this.getAccount.userApplySearchPermission) { // 账号申请查看权限
            const obj = {
              label: '账号申请',
              id: 'application',
              type: 'primary',
              genre: 'badge',
              value: 0,
              max: 99,
              dotType: 'danger'
            }
            this.getButton()
            this.tableButton.unshift(obj)
            
            this.countByBubble()
          }
        }
      }).catch((e) => { console.error(e) })
    },

    //气泡表格划过样式
    pointerStyle(row) {
      return 'cursor:pointer;'
    },
    //商家切换
    updateSelectSeller(item) {
      if (item.sellerNo === this.getUserInfo.sellerNo) {
        this.$showSuccessMsg('您已切换至当前商家！')
        return
      }
      const params = { sellerNo: item.sellerNo, sellerName: item.sellerName }
      Api.Merchants.SettledSeller(params).then((res) => {
        if (res.success) {
          sessionStorage.clear()
          this.$message({
            message: '成功切换到商家[' + item.sellerName + ']',
            type: 'success'
          })
          this.$router.push({ path: '/' })
          setTimeout(() => {
            window.location.reload()
          }, 800)
        } else {
          this.$showErrorMsg(res.errMessage || '商家切换失败')
        }
      }).catch((e) => {
        this.$showErrorMsg(e || '商家切换失败')
      })
    },

    //----------------------------------------------时间控制--------------------------------
    dataAjax() { //获取当前时间
      const now = new Date($.ajax({ async: false }).getResponseHeader('Date'))
      this.nowTimeNew = now.getTime()
    },
    handleStartTime(row) { //开始时间
      if (row.startTime) {
        //开始日期小于结束日期
        row.pickerBeginDateBefore = {
          disabledDate: (time) => {
            var end = new Date(row.endTime).getTime()
            if (end) {
              return (time.getTime() > new Date(row.endTime).getTime()) || (time.getTime() < (this.nowTimeNew - 8.64e7))
            } else {
              return (time.getTime() < (this.nowTimeNew - 8.64e7))
            }
          }
        }
        //结束日期小于开始日期
        row.pickerBeginDateAfter = {
          disabledDate: (time) => {
            var start = new Date(row.startTime).getTime() + 8.64e7
            if (start) {
              return time.getTime() < start
            }
          }
        }
      } else {
        //结束日期不能选今天之前包含今天
        row.pickerBeginDateAfter = {
          disabledDate: (time) => {
            return (time.getTime() < (this.nowTimeNew))
          }
        }
      }
    },
    handleEndTime(row) { //结束时间
      if (row.endTime) {
        //结束日期小于开始日期
        row.pickerBeginDateAfter = {
          disabledDate: (time) => {
            var start = new Date(row.startTime).getTime()
            if (start) {
              return time.getTime() < start
            }
          }
        }
        //开始日期小于结束日期
        row.pickerBeginDateBefore = {
          disabledDate: (time) => {
            var end = new Date(row.endTime).getTime()
            if (end) {
              return (time.getTime() > new Date(row.endTime).getTime() - 8.64e7) || (time.getTime() < (this.nowTimeNew - 8.64e7))
            }
          }
        }
      } else {
        row.pickerBeginDateBefore = {
          disabledDate: (time) => {
            return (time.getTime() < (this.nowTimeNew - 8.64e7))
          }
        }
      }
    },
    //----------------------------------------------------------------------------------------
    // 合同详情
    handelContract(row) {
      this.LoadingTable = true
      const params = {}
      params.contractCode = row.contractCode
      params.id = row.id
      Api.Merchants.getSettledContract(params).then(res => {
        if (res.success) {
          this.LoadingTable = false
          this.dialogVisibleContract = true
          this.contractForm = res.data
          //待编辑
        } else {
          this.LoadingTable = false
          this.$showErrorMsg(res.errMessage)
        }
      }).catch((e) => {
        this.LoadingTable = false
        this.$showErrorMsg(e)
      })
    },
    //事业部提交
    handelSubmit() {
      const params = {}
      params.deptNo = this.deptForm.deptNo
      params.enable = this.deptForm.businessClass
      params.sellerNo = this.deptForm.sellerNo
      Api.Merchants.setDeptBusiness(params).then(res => {
        if (res.success) {
          this.$showSuccessMsg('保存成功')
          this.getList()
        } else {
          this.$showErrorMsg(res.errMessage)
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
      })
      this.dialogVisible = false
    },
    // 开启关闭
    handelEnable(row, type) {
      const params = {}
      const obj = {}
      obj.id = row.id
      obj.sellerNo = row.sellerNo
      params.enable = type
      params.keyList = []
      params.keyList.push(obj)
      Api.Merchants.enableBatch(params).then(res => {
        if (res.success) {
          this.$showSuccessMsg(type ? '开启成功' : '关闭成功')
          this.getList()
        } else {
          this.$showErrorMsg(res.errMessage)
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
      })
    },
    handelValue(val) {
      this.pageNum = 1 
      this.pageSize = 10
      this.bdOwnerNo = val.bdOwnerNo ? val.bdOwnerNo : ''
      this.deptName = val.deptName ? val.deptName : ''
      this.deptNo = val.deptNo ? val.deptNo : ''
      this.openChannel = val.openChannel ? val.openChannel : ''
      this.openStatus = val.openStatus ? val.openStatus : ''
      this.registerRegion = val.registerRegion ? val.registerRegion : ''
      this.sellerName = val.sellerName ? val.sellerName : ''
      this.sellerNo = val.sellerNo ? val.sellerNo : '' 
      this.endTime = val.endTime ? val.endTime : '' 
      this.startTime = val.startTime ? val.startTime : '' 
      //搜索结束时间大于开始时间
      this.tableSearch.forEach(item => {
        if (item.value === 'endTime') {
          item.pickerOptions = {
            disabledDate: (time) => {
              var start = new Date(val.startTime).getTime() + 8.64e7
              if (start) {
                return time.getTime() < start
              }
            }
          }
        }
        //搜索开始时间小于结束时间
        if (item.value === 'startTime') {
          item.pickerOptions = {
            disabledDate: (time) => {
              var end = new Date(val.endTime).getTime()
              if (end) {
                return (time.getTime() > new Date(val.endTime).getTime() - 8.64e7)
              }
            }
          }
        }
      })
      
    },
    //查询条件
    handelSearchClick(val) {
      this.paginationShow = false
      this.pageNum = 1 
      this.pageSize = 10
      this.bdOwnerNo = val.bdOwnerNo ? val.bdOwnerNo : ''
      this.deptName = val.deptName ? val.deptName : ''
      this.deptNo = val.deptNo ? val.deptNo : ''
      this.openChannel = val.openChannel ? val.openChannel : ''
      this.openStatus = val.openStatus ? val.openStatus : ''
      this.registerRegion = val.registerRegion ? val.registerRegion : ''
      this.sellerName = val.sellerName ? val.sellerName : ''
      this.sellerNo = val.sellerNo ? val.sellerNo : '' 
      this.endTime = val.endTime ? val.endTime : '' 
      this.startTime = val.startTime ? val.startTime : '' 
      this.getList()
    },
    // 列表
    getList() {
      this.LoadingTable = true
      const params = {}
      params.pageNum = this.pageNum
      params.pageSize = this.pageSize
      params.bdOwnerNo = this.bdOwnerNo
      params.deptName = this.deptName
      params.deptNo = this.deptNo
      params.openChannel = this.openChannel
      params.openStatus = this.openStatus
      params.registerRegion = this.registerRegion
      params.sellerName = this.sellerName
      params.sellerNo = this.sellerNo
      params.endTime = this.endTime
      params.startTime = this.startTime
      Api.Merchants.listPage(params).then(res => {
        if (res.success) {
          this.LoadingTable = false
          // 当数据加载时时间控制
          for (let i = 0; i < res.data.length; i++) {
            res.data[i].isSet = false //控制是否编辑
            res.data[i].registerRegion = res.data[i].registerRegion.split(',')
            res.data[i].bdOwnerNoList = res.data[i].bdOwnerNo.split(',')
            res.data[i].vscFlagSwitch = res.data[i].vscFlag ? true : false
            res.data[i].pickerBeginDateBefore = {} //控制开始时间对象
            res.data[i].pickerBeginDateAfter = {} //控制结束时间对象
            //开始日期不能小于今天
            res.data[i].pickerBeginDateBefore = {
              disabledDate: (time) => {
                return (time.getTime() < (this.nowTimeNew - 8.64e7))
              }
            }
            //数据加载时当结束时间为true时且不能大于等于结束时间
            if (res.data[i].endTime) {
              res.data[i].pickerBeginDateBefore = {
                disabledDate: (time) => {
                  var end = new Date(res.data[i].endTime).getTime()
                  if (end) {
                    return (time.getTime() > new Date(res.data[i].endTime).getTime() - 8.64e7) || (time.getTime() < (this.nowTimeNew - 8.64e7))
                  }
                }
              }
            }
            //结束日期不能选今天之前包含今天
            res.data[i].pickerBeginDateAfter = {
              disabledDate: (time) => {
                return (time.getTime() < new Date(res.data[i].startTime).getTime() + 8.64e7) || time.getTime() < (this.nowTimeNew)
              }
            }
          }
          this.tableData = res.data
          this.total = res.total
          this.paginationShow = true
        } else {
          this.LoadingTable = false
          this.$showErrorMsg(res.errMessage)
        }
      }).catch((e) => {
        this.LoadingTable = false
        this.$showErrorMsg(e)
      })
    },
    //页码更改
    handleSizeChange(val) {
      this.pageSize = val
      this.getList()
    },
    //翻页
    handleCurrentChange(val) {
      this.pageNum = val
      this.getList()
    },
    //开通渠道
    channelEnum() {
      Api.Merchants.ChannelEnum().then(res => {
        if (res.success) {
          this.channelEnumList = res.data
          this.tableSearch.forEach(item => {
            if (item.value === 'openChannel') {
              item.children = res.data
            }
          })
        } else {
          this.$showErrorMsg(res.errMessage)
        }
      }).catch((e) => {
        console.error(e)
      })
    },
    //开通状态
    statusEnum() {
      Api.Merchants.StatusEnum().then(res => {
        if (res.success) {
          this.statusEnumList = res.data
          this.tableSearch.forEach(item => {
            if (item.value === 'openStatus') {
              item.children = res.data
            }
          })
        } else {
          this.$showErrorMsg(res.errMessage)
        }
      }).catch((e) => {
        console.error(e)
      })
    },
    //菜单版本
    menuVersion() {
      Api.Merchants.menuVersionEnum().then(res => {
        if (res.success) {
          this.menuVersionList = res.data
        } else {
          this.$showErrorMsg(res.errMessage)
        }
      }).catch((e) => {
        console.error(e)
      })
    },
    //区域列表
    regionEnum() {
      Api.Merchants.regionEnum().then(res => {
        if (res.success) {
          this.regionList = res.data
          this.tableSearch.forEach(item => {
            if (item.value === 'registerRegion') {
              item.children = res.data
            }
          })
        } else {
          this.$showErrorMsg(res.errMessage)
        }
      }).catch((e) => {
        console.error(e)
      })
    },
    // 数据操作按钮
    handelClick(item) {
      var crrId = []
      for (let i = 0; i < this.multipleSelection.length; i++) {
        const obj = {}
        obj.id = this.multipleSelection[i].id
        obj.sellerNo = this.multipleSelection[i].sellerNo
        crrId.push(obj)
      }
      switch (item.type) {
        case 'application': //账号申请
          // this.applicantShow = false
          sessionStorage.setItem('merchantsAccount', JSON.stringify(this.getAccount))
          this.$router.push({ path: '/accountApplication' }) 
          break
        case 'download'://批量下载
          var params = {}
          params.ids = []
          params.bdOwnerNo = this.bdOwnerNo
          params.deptName = this.deptName
          params.deptNo = this.deptNo
          params.openChannel = this.openChannel
          params.openStatus = this.openStatus
          params.registerRegion = this.registerRegion
          params.sellerName = this.sellerName
          params.sellerNo = this.sellerNo
          params.startTime = this.startTime
          params.endTime = this.endTime
          var actionUrl = this.baseURL + Api.Merchants.downloadBatch
          exportExcel(actionUrl, params)
          break
        case 'deleted'://批量删除
          if (this.multipleSelection.length === 0) {
            this.$showErrorMsg('请选择数据')
            return
          }
          this.delete(crrId)
          break
        case 'adopt':
          if (this.multipleSelection.length === 0) {
            this.$showErrorMsg('请选择数据')
            return
          }
          var obj = {}
          obj.enable = true
          obj.keyList = []
          obj.keyList = crrId
          Api.Merchants.enableBatch(obj).then(res => {
            if (res.success) {
              this.$showSuccessMsg('操作成功')
              this.getList()
            } else {
              this.$showErrorMsg(res.errMessage)
            }
          }).catch((e) => {
            this.$showErrorMsg(e)
          })
          break
        case 'close':
          if (this.multipleSelection.length === 0) {
            this.$showErrorMsg('请选择数据')
            return
          }
          var obj1 = {}
          obj1.enable = false
          obj1.keyList = []
          obj1.keyList = crrId
          Api.Merchants.enableBatch(obj1).then(res => {
            if (res.success) {
              this.$showSuccessMsg('操作成功')
              this.getList()
            } else {
              this.$showErrorMsg(res.errMessage)
            }
          }).catch((e) => {
            this.$showErrorMsg(e)
          })
          break
      }
    },
    //  删除方法
    delete(row) {
      this.$confirm('是否删除该数据?', '温馨提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        Api.Merchants.deleteBatch({ keyList: row }).then(res => {
          if (res.success) {
            this.$showSuccessMsg('删除成功')
            this.getList()
          } else {
            this.$showErrorMsg(res.errMessage)
          }
        }).catch((e) => {
          this.$showErrorMsg(e)
        })
      }).catch((e) => { console.error('已取消') })
    },
    //----------------------------------------------------------------------------------------
    //事业部详情
    handelDept(item) {
      this.LoadingTable = true
      const params = {}
      params.deptNo = item.deptNo
      params.id = item.id //待确定
      params.sellerNo = item.sellerNo
      Api.Merchants.getSettledDept(params).then(res => {
        if (res.success) {
          res.data.businessClass = res.data.businessClass ? true : false
          this.dialogVisible = true
          this.regionList.forEach(item => {
            if (item.code === res.data.registerRegion) {
              res.data.registerRegionName = item.desc
            }
          })
          this.deptForm = res.data
          this.LoadingTable = false
        } else {
          this.LoadingTable = false
        }
      }).catch((e) => {
        this.$showErrorMsg(e)
        this.LoadingTable = false
      })
    },
    // 表格保存
    handelPreservation(row) {
      if ((row.endTime === '' || row.endTime === null) || (row.startTime === '' || row.startTime === null)) {
        this.$showErrorMsg('请完善信息')
        return
      }
      this.$confirm('是否确认修改?', '温馨提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消'
        // type: 'warning'
      }).then(() => {
        const params = {}
        params.endTime = row.endTime
        params.id = row.id
        params.sellerNo = row.sellerNo
        params.startTime = row.startTime
        params.useVersion = row.useVersion
        params.vscFlag = row.vscFlagSwitch ? 1 : 0
        Api.Merchants.editSave(params).then(res => {
          if (res.success) {
            row.isSet = false
            this.$showSuccessMsg('保存成功')
            this.getList()
          } else {
            this.$showErrorMsg(res.errMessage)
          }
        }).catch((e) => {
          this.$showErrorMsg(e)
        })
      }).catch(() => {
        this.$showInfoMsg('取消保存')
      })
    },
    // 表格取消
    handelCancel(row) {
      row.isSet = false
      this.getList()
    },
    // 编辑
    handelEdit(row) {
      for (const i of this.tableData) {
        if (i.isSet) return this.$showWarningMsg('请先保存当前编辑项')
      }
      row.isSet = true
    },
    //多选
    handleSelectionChange(val) {
      this.multipleSelection = val
    }
  }
}
</script>
<style lang="scss" scoped="scoped">
@import "@/assets/stylus/main.scss";
  .container{
    width: 100%;
    .information-nav{
      box-shadow: 2px 2px 7px 2px #ccc;
      border-radius: 0 0 4px 4px;
      width: 100%;
      background: #ffffff;
      margin-bottom: 20px;
    }
    .container-content{
      background: #fff;
      width: 100%;
      border-radius: 4px;
      box-shadow: 2px 2px 7px 2px #ccc;
      .container-table{
        padding: 0 20px 20px 20px;
        .status{
          display: flex;
          align-items: center;
          span:nth-child(1){
            width: 15px;
            i{
              display: inline-block;
              width: 8px;
              height: 8px;
              border-radius: 50%;
            }
          }
        }
        .refeSpan{
          display: block;
          overflow: hidden;
          text-overflow:ellipsis;
          white-space: nowrap;
          cursor: pointer;
        }
        .span{
          color: $--gl-blue;
          cursor: pointer;
          &:hover{
            color: $--gl-hoverBlue;
          }
        }
        .table-div{
          p{
            color: $--gl-blue;
            cursor: pointer;
            &:hover{
              color: $--gl-hoverBlue;
            }
          }
        }
      }
    }
  }
  .decoration{
    text-decoration: underline;
    color: $--gl-blue;
    cursor: pointer;
    &:hover{
      color: $--gl-hoverBlue;
    }
  }
  .hoverDeptNo{
    max-height: 300px;
    overflow-y: scroll;
    .hoverDeptNoTitle{
      display: flex;
      height: 40px;
      align-items: center;
      background: #D9F0FE;
      div:nth-child(1){
        width: 50px;
        text-align: center;
        color:#23252C;
        background:#D9F0FE;
      }
      div:nth-child(2){
        width: 170px;
        text-align: center;
        color: #23252C;
        background:#D9F0FE;
      }
      div:nth-child(3){
        width: calc(100% - 220px);
        text-align: center;
        color: #23252C;
        background:#D9F0FE;
      }
    }
    .hoverDeptNoBody{
      cursor: pointer;
      display: flex;
      height: 40px;
      border-bottom: 1px solid #e0e0e0;
      div:nth-child(1){
        width: 50px;
        text-align: center;
        color: #333;
        line-height: 40px;
      }
      div:nth-child(2){
        width: 170px;
        line-height: 40px;
        text-align: center;
        color: #23252C;
      }
      div:nth-child(3){
        width: calc(100% - 220px);
        line-height: 40px;
        text-align: center;
        color: #23252C;
      }
      &:hover{
        div{
          background: #EFF3FE;
        }
      }
    }
  }



  .hoverDiv{
    max-height: 300px;
    overflow-y: scroll;
    .hoverDivTitle{
      display: flex;
      height: 40px;
      align-items: center;
      background: #D9F0FE;
      div:nth-child(1){
        width: 50px;
        text-align: center;
        color:#23252C;
        background:#D9F0FE;
      }
      div:nth-child(2){
        width: 100%;
        text-align: center;
        color: #23252C;
        background:#D9F0FE;
      }
    }
    .hoverDivBody{
      cursor: pointer;
      display: flex;
      height: 40px;
      border-bottom: 1px solid #e0e0e0;
      div:nth-child(1){
        width: 50px;
        text-align: center;
        color: #333;
        line-height: 40px;
      }
      div:nth-child(2){
        width: 100%;
        text-align: center;
        color: #333;
        line-height: 40px;
      }
      &:hover{
        div{
          background: #EFF3FE;
        }
      }
    }
  }
  .deptClass{
    border: 1px solid red;
    overflow: hidden;
    text-overflow:ellipsis;
    white-space: nowrap;
    padding-left: 20px;
  }
</style>
