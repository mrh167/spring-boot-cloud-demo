<template>
  <div
    v-if="isShow"
    id="app">
    <lui-container>
      <lui-aside
        :width="'auto'"
        class="aside-wrapper">
        <Aside
          :style="{ width: getIsIframe ? 'auto' : '0px' }"
          :is-collapse="isCollapse"></Aside>
      </lui-aside>
      <lui-container>
        <lui-header v-if="getIsIframe">
          <LayoutHeader></LayoutHeader>
          <Bookmark v-if="getIsBookmark"></Bookmark>
        </lui-header>
        <lui-main
          class="main-wrapper"
          :class="{ 'is-iframe': !getIsIframe, 'active-wrapper': !getIsBookmark, 'active-padding': $route.path === '/kaPanel' }">
          <LayoutContent>
            <div
              slot="content"
              class="page-content">
              <TabNav
                v-if="getIsIframe"
                v-show="$route.path != '/home' && $route.path != '/kaPanel' && $route.path != '/'"></TabNav>
              <div
                v-show="!isCollapse"
                class="page-mask"
                @mouseover="closeNav"></div>
              <router-view />
              <FooterBar></FooterBar>
            </div>
          </LayoutContent>
        </lui-main>
      </lui-container>
    </lui-container>
    <!-- 右侧回到顶部以及问题反馈模块 -->
    <feedbackPage feedback-show="feedbackShow"></feedbackPage>
  </div>
</template>

<script>

import Api from '@/api'
import LayoutHeader from '@/components/common/header/Header.vue'
import feedbackPage from '@/views/backstage/feedbackPage/index.vue' //右侧弹窗
import Aside from '@/components/common/aside/Aside.vue'
import LayoutContent from '@/components/common/content/Content.vue'
import Bookmark from '@/components/common/header/Bookmark.vue'
import TabNav from '@/components/common/header/tabNav.vue'
import FooterBar from '@/components/common/footer/Footer.vue'
// import FloatBar from '@/components/common/floatBar'
import { mapGetters } from 'vuex'
import $ from 'jquery'

export default {
  components: {
    LayoutHeader,
    Aside,
    LayoutContent,
    Bookmark,
    TabNav,
    FooterBar,
    feedbackPage
    // FloatBar
  },
  data() {
    return {
      feedbackShow: false,
      bussinessMaskTable: {},
      urlList: '',
      isShow: false,
      isLogin: false,
      isCollapse: true,
      headerWidth: '0',
      mainWidth: '264px',
      footerWidth: '264px',
      isMessage: false
    }
  },
  computed: {
    ...mapGetters(['getIsBookmark', 'getIsIframe'])
  },
  beforeCreate() {
    //勿删，重要点！ 当页面第一次加载时，需用window.location获取当前路由，其他平台跳转到portal直接进入各个页面时使用。
    if (window.location.href.includes('/#')) {
      let path = window.location.href.split('/#')
      window.sessionStorage.setItem('newPath', path[1].split('?')[0])
      //获取浏览器中portal参数，如果取到去掉侧边栏顶通
      console.log(path[1], 'path')
      if (path[1].indexOf('portal=1') !== -1) {
        console.log('嵌入到商家工作台')
        window.sessionStorage.setItem('isIframe', false)
        this.$store.dispatch('isIframe', false)
      } else {
        window.sessionStorage.setItem('isIframe', true)
        this.$store.dispatch('isIframe', true)
      }
    } else {
      window.sessionStorage.setItem('isIframe', true)
      this.$store.dispatch('isIframe', true)
    }

    const menuList = sessionStorage.getItem('getMenu') ? JSON.parse(sessionStorage.getItem('getMenu')) : ''
    if (!menuList) {
      this.$router.push({ path: '/' }) //清空上次记录的路由地址，做中转使用，防止闪现上次记录页面。
    }
  },
  created() {
    // this.getDomain()
    this.getCurrentLoginAccountType()
  },
  mounted() {
    let thls = this
    this.emitEvent() //初始化event事件
    window.addEventListener('message', function(event) {
      const data = event.data
      if (data.name) {
        console.log(data, '监听安利iframe事件')
        thls.$store.dispatch('changeTab', {
          title: data.name
        })
      }
    })
  },
  methods: {
    getDomain() {
      // const domain = utils.getDomainhost()
      //const domianUrl='jdwl.com'
      // if(domain === 'jdwl.com'){
      //     domianUrl = 'jdl.cn'
      // }
      // debugger
      // console.log(domianUrl)
      $.ajax({
        url: 'https://sso.jd.com/setCookie?t=sso.jdwl.com',
        type: 'GET',
        dataType: 'jsonp',
        success: function(data) {
          // console.log(data, 'jsonp')
        }
      })
    },
    //获取账号信息
    getType() {
      Api.Home.getVscSellerType()
        .then(res => {
          if (res.success) {
            this.$store.dispatch('VscSellerType', res.data)
            sessionStorage.setItem('VscSellerType', JSON.stringify(res.data))
          }
        })
        .catch(e => { })
    },

    //按钮级权限配置
    jurisdiction() {
      Api.Home.jurisdiction()
        .then(row => {
          this.$store.dispatch('isEclp', row.data)
        })
        .catch(e => {
          this.$showErrorMsg(e)
        })
    },
    //按钮级权限配置
    isEclpForNodeAndSupplier() {
      Api.Home.isEclpForNodeAndSupplier()
        .then(row => {
          this.$store.dispatch('isEclpForNodeAndSupplier', row.data)
        })
        .catch(e => {
          this.$showErrorMsg(e)
        })
    },
    //获取渠道类型 1运营 2商家 获取erp还是pin,登录时拿sso_service_ticket获取可以登录的标识sso.jdwl.com
    //唯一入口，为了支持ERP登录所有接口必须在这个接口成功返回后调用。
    getCurrentLoginAccountType() {
      Api.Home.getCurrentLoginAccountType()
        .then(res => {
          if (res.success) {
            let url = window.location.href
            if (url.indexOf('sso_service_ticket') !== -1) {
              url = url.replace(/(\?|#)[^'"]*/, '')
              window.history.pushState({}, 0, url)
            }
            this.isShow = true //当接口返回后，展示页面调用其他接口
            window.sessionStorage.setItem('accountType', res.data)
            this.$store.dispatch('accountType', res.data)
            this.getDomain()
            this.getType()
            this.jurisdiction()
            this.isEclpForNodeAndSupplier()
            setTimeout(() => {
              //当页面加载完再调用
              // this.calcHeight()
              this.feedbackShow = true
            }, 500)
          } else {
            this.isShow = false
            window.sessionStorage.setItem('accountType', res.data)
            this.$store.dispatch('accountType', res.data)
          }
        })
        .catch(e => {
          this.isShow = false
        })
    },
    closeNav() {
      //当鼠标离开菜单延迟收起
      setTimeout(() => {
        this.isCollapse = true
        this.$store.dispatch('firstMenuIndex', this.$route.meta.fid)
      }, 200)

      this.$store.dispatch('isChildren', {
        path: this.$route.path,
        state: false
      })
    },
    emitEvent() {
      this.$bus.on('changeAside', isCollapse => {
        this.isCollapse = isCollapse
      })
    }
  }
}
</script>

<style lang="scss">
@import './assets/stylus/reset';
@import './assets/stylus/main';
@import './assets/iconfont/iconfont.css';
@import './assets/stylus/common.scss';
#app {
  user-select: text;
  /*firefox浏览器*/
  -moz-user-select: text;
  /*safari、chrome浏览器*/
  -webkit-user-select: text;
  /*ie浏览器*/
  -ms-user-select: text;
  /*	Presto内核*/
  -o-user-select: text;
  /*KHTML内核*/

  -khtml-user-select: text;

  height: 100%;
  .lui-container {
    height: 100%;
    .main {
      .page-container {
        height: 100%;
        .page-content {
          position: relative;
          height: 100%;
          .index {
            height: calc(100% - 136px);
          }
          .page-mask {
            width: 100%;
            height: 100%;
            position: fixed;
            top: 60px;
            z-index: 1000;
          }
        }
      }
    }
  }
}

.custom-problemfeedback-dialog {
  .lui-dialog__body {
    padding: 20px;
  }
}

.lui-message {
  font-size: 12px !important;
  top: 20px !important;
}

.lui-main {
  padding: 12px;
}
.active-padding {
  padding: 0;
}
.main-wrapper {
  margin-top: 110px;
  margin-left: 64px;
  transition: all 0.3s ease-in-out;
}
.active-wrapper {
  margin-top: 60px;
}
.is-iframe {
  margin: 0 !important;
}
.footer-wrapper {
  padding: 0 15px;
  margin-left: 64px;
  transition: all 0.3s ease-in-out;

  .footer {
    padding: 15px;
    background-color: #ffffff;
    border-radius: 2px;
    box-shadow: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
  }
}
</style>
