//rem 转换
export function resetRem() {
  //获取html 元素
  let html = document.documentElement

  //判断如果是移动端 分辨率按375计算 PC端则1:1正常计算
  if (navigator.userAgent.match(/(iPhone|ipad|Android|ios)/i)) {
    html.style.fontSize = 100 * (html.clientWidth / 375) + 'px'
    window.onresize = () => {
      html.style.fontSize = 100 * (html.clientWidth / 375) + 'px'
    }
  } else {
    html.style.fontSize = 100 * (html.clientWidth / html.clientWidth) + 'px'
    window.onresize = () => {
      html.style.fontSize = 100 * (html.clientWidth / html.clientWidth) + 'px'
    }
  }
}
