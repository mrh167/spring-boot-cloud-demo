import Vue from 'vue'

//全局输入框特殊字符过滤
Vue.prototype.specialForbid = function(value) {
  const pattern = new RegExp("[`~!@#$^%&*=|{}':;'\\[\\].<>/?~！@#￥……&*|{}【】\\ \\‘；：”“'。、？]")
  value = value.replace(new RegExp(pattern, 'g'), '')
  return value
}
//全局整数
Vue.prototype.integerForbid = function(value) {
  if (value) {
    value = ToCDB(value)
  }
  const number = new RegExp('[^\\d]')
  value = value.replace(new RegExp(number, 'g'), '')
  return value
}
//全局正整数
Vue.prototype.integerNoZeroForbid = function(value) {
  if (value) {
    value = ToCDB(value)
  }
  if (value === '0') {
    value = ''
  }
  const number = new RegExp('[^\\d]')
  value = value.replace(new RegExp(number, 'g'), '')
  return value
}

//整数  最大保留1位小数
Vue.prototype.doubleOneForbid = function(value) {
  if (value) {
    value = ToCDB(value)
  }
  if (value === '0.0') {
    value = ''
  }
  value = value.replace(/[^\d.]/g, '').replace(/\.{2,}/g, '.').replace('.', '$#$').replace(/\./g, '')
    .replace('$#$', '.').replace(/^(\-)*(\d+)\.(\d).*$/, '$1$2.$3').replace(/^\./g, '')
  return value
}
//整数  最大保留2位小数
Vue.prototype.doubleTwoForbid = function(value) {
  if (value) {
    value = ToCDB(value)
  }
  if (value === '0.00') {
    value = ''
  }
  value = value.replace(/[^\d.]/g, '').replace(/\.{2,}/g, '.').replace('.', '$#$').replace(/\./g, '')
    .replace('$#$', '.').replace(/^(\-)*(\d+)\.(\d\d).*$/, '$1$2.$3').replace(/^\./g, '')
  return value
}
//整数  最大保留3位小数
Vue.prototype.doubleMoreForbid = function(value) {
  if (value) {
    value = ToCDB(value)
  }
  if (value === '0.000') {
    value = ''
  }
  value = value.replace(/[^\d.]/g, '').replace(/\.{2,}/g, '.').replace('.', '$#$').replace(/\./g, '')
    .replace('$#$', '.').replace(/^(\-)*(\d+)\.(\d\d\d).*$/, '$1$2.$3').replace(/^\./g, '')
  return value
}

/*//只能输入0-1之间的小数
Vue.prototype.decimalOneForbid = function (value) {
  let decimalnumber = new RegExp("[0\.(?!0{2})\d{2}]");
  value = value.replace(new RegExp(decimalnumber, "g"), "");
  return value;
}*/
//小写字母
Vue.prototype.lowerCaseForbid = function(value) {
  if (value) {
    value = ToCDB(value)
  }
  const lowerCase = new RegExp('[^a-z]')
  value = value.replace(new RegExp(lowerCase, 'g'), '')
  return value
}
//大写字母
Vue.prototype.upperCaseForbid = function(value) {
  if (value) {
    value = ToCDB(value)
  }
  const upperCase = new RegExp('[^A-Z]')
  value = value.replace(new RegExp(upperCase, 'g'), '')
  return value
}
//大小写字母
Vue.prototype.alphabetsForbid = function(value) {
  if (value) {
    value = ToCDB(value)
  }
  const alphabets = new RegExp('[^a-zA-Z]')
  value = value.replace(new RegExp(alphabets, 'g'), '')
  return value
}
//字母和数字
Vue.prototype.numberStringForbid = function(value, label) {
  if (value) {
    value = ToCDB(value)
  }
  let addRex = ''
  if (label) {
    addRex = label
  }
  const rex = '[^a-zA-Z\\d' + addRex + ']'
  const alphabets = new RegExp(rex)
  value = value.replace(new RegExp(alphabets, 'g'), '')
  //保证输入一个
  if (label) {
    value = value.replace(label + label, label)
  }
  return value
}
/**
 * 全角转换
 * @param str
 * @returns {string}
 * @constructor
 */
function ToCDB(str) {
  var tmp = ''
  for (var i = 0; i < str.length; i++) {
    if (str.charCodeAt(i) === 12288) {
      tmp += String.fromCharCode(str.charCodeAt(i) - 12256)
      continue
    }
    if (str.charCodeAt(i) > 65280 && str.charCodeAt(i) < 65375) {
      tmp += String.fromCharCode(str.charCodeAt(i) - 65248)
    } else {
      tmp += String.fromCharCode(str.charCodeAt(i))
    }
  }
  return tmp
}
