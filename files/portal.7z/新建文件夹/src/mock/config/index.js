import Mock from 'mockjs'
const data = Mock.mock({
  // 'data|100': [ //生成100条数据 数组
  // {
  //   'shopId|+1': 1, //生成商品id，自增1
  //   'shopMsg': '@ctitle(10)', //生成商品信息，长度为10个汉字
  //   'shopName': '@cname', //生成商品名 ， 都是中国人的名字
  //   'shopTel': /^1(5|3|7|8)[0-9]{9}$/, //生成随机电话号
  //   'shopAddress': '@county(true)', //随机生成地址
  //   'shopStar|1-5': '★', //随机生成1-5个星星
  //   'salesVolume|30-1000': 30, //随机生成商品价格 在30-1000之间
  //   'shopLogo': "@Image('100x40','#c33', '#ffffff','小北鼻')", //生成随机图片，大小/背景色/字体颜色/文字信息
  //   'food|7': [ //每个商品中再随机生成七个food
  //     {
  //       'foodName': '@cname', //food的名字
  //       'foodPic': "@Image('100x40','#c33', '#ffffff','小可爱')", //生成随机图片，大小/背景色/字体颜色/文字信息
  //       'foodPrice|1-100': 20, //生成1-100的随机数
  //       'aname|14': [
  //         { 
  //           'aname': '@cname', 
  //           'aprice|30-60': 20 
  //         }
  //       ]
  //     }
  //   ]
  //-------------------------------
  // {
  msg: '成功',
  // result: {
  'allotCoList|15': [
    {
      'allotCode': '123',
      'checkQtty': 0,
      'deptName': '事业部1',
      'deptNo': '1',
      'orderqtty': 0,
      'purposeWareHouseName': '目的仓',
      'purposeWareHouseNo': '1',
      'sellerName': '商家1',
      'sellerNo': '1',
      'skuName': 'sku名称',
      'skutNo': '1',
      'startingWareHouseName': '始发仓1',
      'startingWareHouseNo': '1'
    }
  ],
  'data': [],
  'errCode': '',
  'errMessage': '',
  'marketCoList': [
    {
      'delieveredQtty': 0,
      'delieveredTime': '2020-09-15',
      'deliveryTime': '2020-09-15',
      'deptName': '事业部名称',
      'deptNo': '1',
      'orderCode': '123',
      'orderTime': '2020-09-15',
      'orderqtty': 0,
      'reviewPackagingTime': '2020-09-15',
      'sellerName': '商家1',
      'sellerNo': '1',
      'skuName': 'suk名称',
      'skutNo': '1',
      'startingWareHouseName': '始发仓1',
      'startingWareHouseNo': '1',
      'transRegional': true
    }
  ],
  'pageNum': 1,
  'pageSize': 10,
  'pages': 0,
  'size': 0,
  'success': true,
  'total': 1
  // },
  // successFlag: 0
  // }
  // }
  // ]
})
const findOrder = {
  url: '/business/order/findOrder',
  method: /post|get/i,
  data: data
  // {
  //   msg: '成功',
  //   result: {
  //     'allotCoList': [
  //       {
  //         'allotCode': '123',
  //         'checkQtty': 0,
  //         'deptName': '事业部1',
  //         'deptNo': '1',
  //         'orderqtty': 0,
  //         'purposeWareHouseName': '目的仓',
  //         'purposeWareHouseNo': '1',
  //         'sellerName': '商家1',
  //         'sellerNo': '1',
  //         'skuName': 'sku名称',
  //         'skutNo': '1',
  //         'startingWareHouseName': '始发仓1',
  //         'startingWareHouseNo': '1'
  //       }
  //     ],
  //     'data': [],
  //     'errCode': '',
  //     'errMessage': '',
  //     'marketCoList': [
  //       {
  //         'delieveredQtty': 0,
  //         'delieveredTime': '2020-09-15',
  //         'deliveryTime': '2020-09-15',
  //         'deptName': '事业部名称',
  //         'deptNo': '1',
  //         'orderCode': '123',
  //         'orderTime': '2020-09-15',
  //         'orderqtty': 0,
  //         'reviewPackagingTime': '2020-09-15',
  //         'sellerName': '商家1',
  //         'sellerNo': '1',
  //         'skuName': 'suk名称',
  //         'skutNo': '1',
  //         'startingWareHouseName': '始发仓1',
  //         'startingWareHouseNo': '1',
  //         'transRegional': true
  //       }
  //     ],
  //     'pageNum': 1,
  //     'pageSize': 10,
  //     'pages': 0,
  //     'size': 0,
  //     'success': true,
  //     'total': 1
  //   },
  //   successFlag: 0
  // }
}

export default {
  findOrder
}
