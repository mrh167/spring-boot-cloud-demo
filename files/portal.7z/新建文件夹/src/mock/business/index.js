//商家查询
const warehouseFindseller = {
  url: '/business/warehouse/seller',
  method: /post|get/i,
  data: {
    data: [
      {
        'sellerName': '1',
        'sellerNo': '1'

      },
      {
        'sellerName': '2',
        'sellerNo': '2'

      }
    ],
    'errCode': '',
    'errMessage': '',
    'success': true
  }
}
//band
const luckWithFindBand = {
  url: '/business/luckWith/findBand',
  method: /post|get/i,
  data: {
    data: [
      {
        'bandName': '1',
        'bandNo': '1'

      },
      {
        'bandName': '2',
        'bandNo': '2'

      }
    ],
    'list|1-10': [{
      // 属性 id 是一个自增数，起始值为 1，每次增 1
      'id|+1': 1
    }],
    'errCode': '',
    'errMessage': '',
    'success': true
  }
}
export default {
  warehouseFindseller,
  luckWithFindBand
}
