import Utils from '@/utils/utils'

export default {
  unescape: Utils.unescape,
  numberFix: Utils.numberFix,
  formatEmptyStr: Utils.formatEmptyStr,
  ellipse: Utils.ellipse
}
