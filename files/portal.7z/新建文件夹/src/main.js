import Vue from 'vue'
// import ElementUI from 'element-ui'
import LUI from '@lui/lui'
import '@lui/lui/lib/theme-chalk/index.css'
import 'font-awesome/css/font-awesome.min.css'
import App from './App.vue'
import router from './router'
import store from './store'
import filters from './filters'
import Plugins from './plugins'
import VueBus from 'vue-bus'
import 'babel-polyfill'
import promise from 'es6-promise'
import VueDOMPurifyHTML from 'vue-dompurify-html' //解决xss攻击
Vue.use(VueDOMPurifyHTML)
// eslint-disable-next-line no-undef
if (process.env.NODE_ENV === 'mock') {
  // 当环境为mock时， 加载mock模块
  // eslint-disable-next-line no-undef
  require('./mock/index.js')
}
promise.polyfill()
// import elCascaderMulti from 'el-cascader-multi'
import '@/directive/waves'
import '@/utils/validate'
// 图片预览注册全局组件
import 'viewerjs/dist/viewer.css'
import Viewer from 'v-viewer'

Vue.use(Viewer)
// Vue.use(elCascaderMulti)
// Vue.use(ElementUI)
Vue.use(LUI)
Vue.use(Plugins)
Vue.use(VueBus)
// 加载filter
Object.keys(filters).forEach(key => {
  Vue.filter(`${key}`, filters[key])
})
Vue.config.productionTip = false

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')
