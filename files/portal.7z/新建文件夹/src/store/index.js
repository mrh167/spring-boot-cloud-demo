import Vue from 'vue'
import Vuex from 'vuex'
import state from './state'
import getters from './getters'
import mutations from './mutations'
import actions from './actions'
import user from './modules/user'
import menu from './modules/menu'
import isEclp from './modules/isEclp'
import layout from './modules/layout/index'
Vue.use(Vuex)

export default new Vuex.Store({
  state,
  getters,
  mutations,
  actions,
  modules: {
    user,
    menu,
    isEclp,
    layout
  }
})
