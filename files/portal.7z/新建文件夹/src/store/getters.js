
const getters = {
  keepAliveArr: state => state.layout.keepAliveArr,
  isCollapse: state => state.layout.isCollapse,
  uniquerouter: state => state.layout.uniquerouter,
  // tabnavBox: state => state.layout.tabnavBox,
  tabnavBox(state) {
    if (state.layout.tabnavBox.length) { //tabnavBox为空数组为true,所有需要判断length
      return state.layout.tabnavBox
    } else { //刷新页面时tabnavBox为空数组，所以从sessionStorage取。
      // state.layout.tabnavBox = JSON.parse(sessionStorage.getItem('tabnavBox'))
      return JSON.parse(sessionStorage.getItem('tabnavBox'))
    }
  }
}

export default getters
