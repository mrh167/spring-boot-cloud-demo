const state = {
  isEclp: true,
  accountType: '',
  isBookmark: false,
  firstMenuIndex: 100, //100时为都不选中
  isArrow: false, //是否显示侧边栏按钮
  isHelpCenter: false, //是否显示帮助中心搜素框
  isIframe: false, //是否显示顶通/侧边栏
  isEclpForNodeAndSupplier: true,
  userInfo: Object(), //用户信息
  buttonPermission: false //是否显示删除按钮
}
const getters = {
  getButtonPermission(state) {
    return state.buttonPermission || JSON.parse(sessionStorage.getItem('buttonPermission'))
  },
  getUserInfo(state) {
    return state.userInfo || JSON.parse(sessionStorage.getItem('userInfo'))
  },
  getIsEclp(state) {
    console.log(!state.isEclp, 'isEclp')
    return !state.isEclp
    // || !JSON.parse(sessionStorage.getItem('isEclp')) //ECLP为true时隐藏，所以取反。
  },
  getIsEclpForNodeAndSupplier(state) {
    //库节点主数据和供应商主数据使用
    console.log(!state.isEclpForNodeAndSupplier, 'isEclpForNodeAndSupplier')
    return !state.isEclpForNodeAndSupplier
    // || !JSON.parse(sessionStorage.getItem('isEclpForNodeAndSupplier'))
  },
  getAccountType(state) {
    return state.accountType || JSON.parse(sessionStorage.getItem('accountType'))
  },
  getIsBookmark(state) {
    return state.isBookmark || JSON.parse(localStorage.getItem('isBookmark')) //收藏夹显示状态。
  },
  getFirstMenuIndex(state) {
    //菜单高亮显示使用。
    return state.firstMenuIndex
  },
  getIsArrow(state) {
    //判断是否显示侧边栏按钮。
    return state.isArrow
  },
  getIsHelpCenter(state) {
    return state.isHelpCenter || JSON.parse(sessionStorage.getItem('isHelpCenter'))
  },
  getIsIframe(state) {
    return state.isIframe || JSON.parse(sessionStorage.getItem('isIframe'))
  }
}
const mutations = {
  Set_BUTTONPERMISSION(state, buttonPermission) {
    state.buttonPermission = buttonPermission
  },
  Set_USERINFO(state, userInfo) {
    state.userInfo = userInfo
  },
  Set_ISECLP(state, isEclp) {
    state.isEclp = isEclp
  },
  Set_IsEclpForNodeAndSupplier(state, isEclpForNodeAndSupplier) {
    state.isEclpForNodeAndSupplier = isEclpForNodeAndSupplier
  },
  Set_AccountType(state, accountType) {
    state.accountType = accountType
  },
  Set_IsBookmark(state, isBookmark) {
    if (isBookmark) {
      //改为与localStorage一样的值
      state.isBookmark = true
    }
    state.isBookmark = !isBookmark
    window.localStorage.setItem('isBookmark', state.isBookmark)
  },
  Set_FirstMenuIndex(state, fid) {
    state.firstMenuIndex = fid
  },
  Set_isArrow(state, isArrow) {
    state.isArrow = isArrow
  },
  Set_IsHelpCenter(state, isHelpCenter) {
    state.isHelpCenter = isHelpCenter
  },
  isChildren(state, obj) {
    //判断是否有二级菜单，有显示侧边栏按钮，否则不显示，暂时写死将来改成数组是否有children。
    if (obj.path === '/home' || obj.path === '/kaPanel' || obj.path === '/application') {
      state.isArrow = obj.state
    }
  },
  Set_IsIframe(state, isIframe) {
    state.isIframe = isIframe
  }
}
const actions = {
  buttonPermission(context, buttonPermission) {
    context.commit('Set_BUTTONPERMISSION', buttonPermission)
  },
  userInfo(context, userInfo) {
    context.commit('Set_USERINFO', userInfo)
  },
  isEclp(context, isEclp) {
    context.commit('Set_ISECLP', isEclp)
  },
  isEclpForNodeAndSupplier(context, isEclpForNodeAndSupplier) {
    context.commit('Set_IsEclpForNodeAndSupplier', isEclpForNodeAndSupplier)
  },
  accountType(context, isEclp) {
    context.commit('Set_AccountType', isEclp)
  },
  isBookmark(context, isBookmark) {
    context.commit('Set_IsBookmark', isBookmark)
  },
  firstMenuIndex(context, index) {
    context.commit('Set_FirstMenuIndex', index)
  },
  isArrow(context, isArrow) {
    context.commit('Set_isArrow', isArrow)
  },
  isHelpCenter(context, isHelpCenter) {
    context.commit('Set_IsHelpCenter', isHelpCenter)
  },
  isChildren(context, isArrow) {
    context.commit('isChildren', isArrow)
  },
  isIframe(context, isIframe) {
    context.commit('Set_IsIframe', isIframe)
  }
}

export default {
  state,
  actions,
  getters,
  mutations
}
