
export default {
  state: {
    isCollapse: false,
    logoShow: false,
    uniquerouter: true,
    rightNav: {},
    tabnavBox: JSON.parse(window.sessionStorage.getItem('tabnavBox')) || [],
    // [
    //   // {
    //   //   title: '首页',
    //   //   path: '/home'
    //   // }
    // ],
    activeTabnav: JSON.parse(window.sessionStorage.getItem('activeTabnav')) || {},
    keepAliveArr: [] //keep-alive缓存下来的数组，存的是组件名，在添加到tabNav的时候加进来，点叉号的时候移除
  },
  mutations: {
    //添加并存储当前菜单
    addTab(state, arg) {
      state.isActive = arg.path
      state.activeTabnav = arg //存储当前菜单
      window.sessionStorage.setItem('activeTabnav', JSON.stringify(arg))
      const navList = JSON.parse(window.sessionStorage.getItem('tabnavBox')) || []
      state.tabnavBox = navList //必须保持与sessionStorage一致
      for (let i = 0; i < navList.length; i++) {
        if (navList[i].path === arg.path) {
          return false //当path一致时不添加到tabnavBox
        }
      }
      state.tabnavBox.push({
        title: arg.title,
        path: arg.path
      })
      window.sessionStorage.setItem('tabnavBox', JSON.stringify(state.tabnavBox))
      state.keepAliveArr.push(arg)
    },
    //改变iframe传过来的需要跳转的菜单名称
    changeActiveTabnav(state, arg) {
      console.log(state.tabnavBox, state.activeTabnav, '改变tabnav')
      const index = state.tabnavBox.findIndex(item => item.path === state.activeTabnav.path)
      state.tabnavBox[index].title = arg.title
    },
    openMenu(state, arg) {
      state.rightNav = arg
    },
    removeTab(state, arg) {
      //从sessionStorage取一份数据
      // state.tabnavBox = JSON.parse(window.sessionStorage.getItem('tabnavBox'))
      const index = state.tabnavBox.findIndex(function(value, key) {
        return value.path === arg.tabItem.path
      })
      // const keepAliveindex = state.keepAliveArr.findIndex(function(value, key) {
      //   return value.path.toLowerCase() === arg.tabItem.path.toLowerCase()
      // })
      // state.keepAliveArr.splice(keepAliveindex, 1)
      state.tabnavBox.splice(index, 1)
      window.sessionStorage.setItem('tabnavBox', JSON.stringify(state.tabnavBox))
      
      
      if (arg.tabItem.path === arg.fullPath) {
        const tabActive = state.tabnavBox[index] || state.tabnavBox[index - 1]
        
        arg.router.push(tabActive.path)
      }
    },
    removeOtherTab(state, arg) {
      state.tabnavBox = [{
        title: 'Home',
        path: '/home'
      }]
      // if (arg.all) {
      // arg.router.push('/index')
      // return false
      // }
      // state.tabnavBox.push(arg.tabItem)
      // arg.router.push(arg.tabItem.path)
    },
    collapse(state, arg) {
      state.isCollapse = !state.isCollapse
      if (state.logoShow) {
        setTimeout(function() {
          state.logoShow = false
        }, 300)
      } else {
        state.logoShow = true
      }
    }
  },
  actions: {
    addTab({ commit }, arg) {
      commit('addTab', arg)
    },
    changeTab({ commit }, arg) {
      commit('changeActiveTabnav', arg)
    },
    openMenu({ commit }, arg) {
      commit('openMenu', arg)
    },
    removeTab({ commit }, arg) {
      commit('removeTab', arg)
    },
    removeOtherTab({ commit }, arg) {
      commit('removeOtherTab', arg)
    },
    collapse({ commit }, arg) {
      commit('collapse', arg)
    }
  }
}
