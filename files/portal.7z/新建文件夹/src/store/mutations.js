const mutations = {
  SET_UPLOAD: (state, upload) => {
    state.upload = upload
  }
}


export default mutations
