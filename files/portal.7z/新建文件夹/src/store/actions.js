const actions = {
  // 上传标识
  UPLOAD({ commit }, upload) {
    commit('SET_UPLOAD', upload)
  }
}

export default actions
