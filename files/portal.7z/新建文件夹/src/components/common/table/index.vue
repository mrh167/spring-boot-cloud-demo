<template>
  <div class="table">
    <lui-table
      v-loading="loadingShow"
      :data="tableData"
      style="width: 100%"
      border
      :header-cell-style="{background:'#D9F0FE'}"
      :header-row-class-name="tableRowClassName"
      @selection-change="handleSelectionChange"
      @row-click="clickTable">
      <template slot="empty">
        <showEmptyImage></showEmptyImage>
      </template>
      <!--
        id: 判断表格类型  selection==单选多选  text==正常单元格  button==操作按钮=｛ 循环遍历操作数组 size==按钮尺寸 icon==按钮指示图标 handleEdit==根据传入ID判断按钮功能｝
        fixed: 判断单元格固定的位置
        align: 数据的位置不传值默认居中
        width：单元格的宽度 不传值则不限制宽度
        type： 部分单元格使用 如：多选框
        prop: 父组件传参到每个单元格
        label: 各个单元格命名
       -->
      <template v-for="(item, index) of columns">

        <!-- <lui-table-column
          v-if="item.id === 'number'"
          :key="index"
          :fixed="item.fixed ? item.fixed : false"
          :align="item.align ? item.align : 'center'"
          :width="item.width ? item.width : 50"
          :type="item.type"
          show-overflow-tooltip>
        </lui-table-column> -->
        <!-- 序号 -->
        <lui-table-column
          v-if="item.id === 'number'"
          :key="index"
          :prop="item.prop"
          :label="item.label"
          :fixed="item.fixed ? item.fixed : false"
          :align="item.align ? item.align : 'center'"
          :width="item.width ? item.width : 55"
          show-overflow-tooltip>
          <template v-slot="scope">
            <span>{{ (pageNum - 1) * pageSize + scope.$index + 1 }}</span>
          </template>
        </lui-table-column>

        <lui-table-column
          v-else-if="item.id === 'selection'"
          :key="index"
          :fixed="item.fixed ? item.fixed : false"
          :align="item.align ? item.align : 'center'"
          :width="item.width ? item.width : 55"
          :type="item.type"
          show-overflow-tooltip>
        </lui-table-column>
        <!-- 表格正常显示 -->
        <!-- <lui-table-column
          v-else-if="item.id === 'text'"
          :key="index"
          :prop="item.prop"
          :label="item.label"
          :fixed="item.fixed ? item.fixed : false"
          :align="item.align ? item.align : 'left'"
          :min-width="item.width ? item.width : 170"
          show-overflow-tooltip>
        </lui-table-column> -->


        <lui-table-column
          v-else-if="item.id === 'text'"
          :key="index"
          :prop="item.prop"
          :label="item.label"
          :fixed="item.fixed ? item.fixed : false"
          :align="item.align ? item.align : 'left'"
          :min-width="item.width ? item.width : 170"
          show-overflow-tooltip>
          <template v-slot="scope">
            <!-- 自定义内容 -->
            <template v-if="item.formatter">
              <span v-dompurify-html="item.formatter(scope.row, item)"></span>
            </template>
            <!-- switch滑块 -->
            <template v-else-if="item.type === 'switch'">
              <lui-switch
                v-model="scope.row.status"
                style="display: block"
                :active-color="item.activeColor ? item.activeColor : '#13ce66'"
                :inactive-color="item.inactiveCcolor?item.inactiveCcolor : '#ff4949'"
                :active-text="item.activeText ? item.activeText : ''"
                :inactive-text="item.inactiveText ? item.inactiveText : ''">
              </lui-switch>
            </template>
            <!-- 文本输出 -->
            <template v-else>
              <span>{{ scope.row[item.prop] }}</span>
            </template>
          </template>
        </lui-table-column>


        <!-- 按钮操作 -->
        <lui-table-column
          v-else-if="item.id==='button'"
          :key="index"
          :label="item.label"
          :fixed="item.fixed ? item.fixed : false"
          :align="item.align ? item.align : 'center'"
          :width="item.width">
          <template v-slot="{row}">
            <lui-button
              v-for="val in item.list"
              :key="val.id"
              :size="val.size"
              :type="val.type"
              :icon="val.icon"
              @click.native.prevent="handleEdit(row, val.id)">{{ val.name }}</lui-button>
          </template>
        </lui-table-column>
      </template>
    </lui-table>
  </div>
</template>

<script>
import showEmptyImage from '@/components/common/showEmptyImage/index.vue'
export default {
  components: {
    showEmptyImage
  },
  props: {
    tableData: {
      // 表格数据源 默认为空数组
      type: Array,
      default: () => []
    },
    columns: {
      // 表格的字段展示 默认为空数组
      type: Array,
      default: () => []
    },
    loadingShow: {
      type: Boolean,
      default: false
    },
    pageSize: {
      type: Number,
      default: 0
    },
    pageNum: {
      type: Number,
      default: 0
    }
  },

  methods: {
    //表格操作
    handleEdit(index, row) {
      this.$emit('handleEdit', { index: index, row: row })
    },
    // 多选反选正常
    handleSelectionChange(val) {
      this.$emit('handleSelectionChange', { val: val })
    },
    // 点击某一行触发的事件
    clickTable(row, column, event) {
      this.$emit('clickTable', { row: row, column: column, event: event })
    },
    // 正常
    tableRowClassName({ row, rowIndex }) {
      if (rowIndex === 0) {
        return 'warning-row'
      } else if (rowIndex === 1) {
        return 'warning-row'
      }
      return ''
    }
  }
}
</script>

<style lang="scss" scoped>
.table{
  width: 100%;
  background: #fff;
  padding: 0 20px 20px 20px;

  // min-height: 400px;

}
</style>
