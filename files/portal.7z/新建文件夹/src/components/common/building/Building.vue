<template>
  <div class="building">
    <p class="building-txt">敬请期待...</p>
  </div>
</template>

<style lang="scss" rel="stylesheet/scss">
  @import "building.scss";
</style>
<script type="text/babel">
export default {
  name: 'building',
  props: {
  },
  data() {
    return {
    }
  },
  watch: {
  },
  mounted() {
  },
  methods: {
  }
}
</script>
