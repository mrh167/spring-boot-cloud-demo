<template>
  <div>
    <div class="backtop">
      <div
        v-show="backTopShow"
        v-cloak
        class="item top"
        @click="backToTop">
        <i class="iconfont iconfanhuidingbu"></i>
      </div>     
      <div class="item center">
        <img src="@/assets/img/feedback.png">
        <div
          class="feedback"
          @click="openFeedback">问题反馈</div>
      </div>
      <div class="item bottom">
        <img src="@/assets/img/contact-us.png">
        <div class="contact-us">
          <p>联系我们</p>
          <div>
            <div class="title">QQ群</div>
            <div>1039822239</div>
          </div>
          <div>
            <div class="title">邮箱</div>
            <div>jdjinghui@jd.com</div>
          </div>
        </div>
      </div>
      <lui-dialog
        title="问题反馈"
        custom-class="custom-problemfeedback-dialog"
        :append-to-body="true"
        :close-on-click-modal="false"
        :visible.sync="dialogVisible"
        width="650px">
        <div style="padding-bottom:22px">
          我们十分抱歉，给您带来了不佳的体验，恳请您反馈问题，帮助我们改善，谢谢。
        </div>
        <lui-form
          ref="problemFeedback"
          label-position="left"
          :model="problemFeedback"
          :rules="rules"
          label-width="100px">
          <lui-form-item
            label="问题位置："
            prop="position">
            <lui-input v-model="problemFeedback.position" disabled>
              <template slot="prepend">当前菜单位置</template>
            </lui-input>
          </lui-form-item>
          <lui-form-item
            label="您的问题："
            prop="problem">
            <lui-input
              v-model.trim="problemFeedback.problem"
              type="textarea"
              rows="5"
              placeholder="请输入您的问题"
              maxlength="200"
              show-word-limit></lui-input>
          </lui-form-item>
          <lui-form-item
            label="联系方式："
            prop="phone">
            <lui-row class="custom-problem-row">
              <lui-col
                :span="8"
                style="float: left;">
                <lui-input
                  v-model.trim="problemFeedback.phone"
                  maxlength="11"
                  placeholder="请输入您的电话"><template slot="prepend">电话</template></lui-input>
              </lui-col>
              或
              <lui-col
                :span="15"
                style="float: right;">
                <lui-input
                  v-model.trim="problemFeedback.email"
                  placeholder="请输入您的邮箱"><template slot="prepend">邮箱</template></lui-input>
              </lui-col>
            </lui-row>
          </lui-form-item>
        </lui-form>
        <span
          slot="footer"
          class="dialog-footer">
          <lui-button @click="dialogVisible = false">取 消</lui-button>
          <lui-button
            type="primary"
            @click="postAddFeedback">确 定</lui-button>
        </span>
      </lui-dialog>
    </div>
  </div>
</template>
<script type="text/javascript">
export default {
  name: 'floatBar',
  components: {
    //FloatBar
  },
  data() {
    return {

    }
  }
}
</script>

<style lang="scss" scoped>
</style>
