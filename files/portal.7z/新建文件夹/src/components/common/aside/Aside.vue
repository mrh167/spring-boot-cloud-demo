<template>
  <div class="aside" :class="{'active-aside': !getIsBookmark}">
    <!-- 菜单展开按钮 -->
    <div
      v-if="getIsArrow || isCollapse"
      class="menu-right"
      :style="{top:firstMenuHeight/2 - 21 +'px'}"
      @click="changeAside(false)">
      <img v-if="getIsArrow && isCollapse" src="../../../assets/img/open.png">
    </div>
    <!-- 首级菜单 -->
    <div
      ref="aside"
      :class="{'active-lui-menu':!getIsBookmark}"
      class="first-menu">
      <ul>
        <li
          v-for="item in firstMenuList "
          :key="item.id"
          :class="{ 'active' : getFirstMenuIndex == item.id}"
          @click="changeFirstMenu(item)">
          <span class="iconSpan">
            <i :class="[ item.icon[item.iconIndex],{'iconfontActive' : getFirstMenuIndex == item.id}]"></i>
          </span>
          <span>{{ item.label }}</span>
        </li>
      </ul>
    </div>
    <!-- 菜单组件 -->
    <div>
      <lui-menu
        :default-active="activeIndex"
        :class="{'active-lui-menu':!getIsBookmark}"
        class="lui-menu-vertical"
        background-color="rgba(60,63,77,0.1)"
        text-color="#fff"
        :collapse="isCollapse"
        :router="true"
        active-text-color="#1d1e23"
        :unique-opened="true"
        @open="handleOpen"
        @close="handleClose">
        <template v-for="(item) in navlist">
          <!-- 一级  -->
          <lui-submenu
            v-if="item.children !=''&& item.children != null"
            :key="item.id"
            :index="item.id + ''">
            <template slot="title">
              <span>{{ item.label }}</span>
            </template>
            <!-- 二级 -->
            <template v-for="itemChild in item.children">
              <lui-submenu
                v-if="itemChild.children !=''&& itemChild.children != null"
                :key="itemChild.id"
                :index="itemChild.id + ''">
                <template slot="title">
                  <span>{{ itemChild.label }}</span>
                </template>
                <!-- 三级 -->
                <lui-menu-item
                  v-for="(itemChild_child,itemChildIndex) in itemChild.children"
                  :key="itemChild_child.id + itemChildIndex"
                  :index="itemChild_child.path">
                  <template slot="title">
                    <span><span v-if="itemChild_child.iconShow" class="tabSpan"></span> {{ itemChild_child.label }}</span>
                  </template>
                </lui-menu-item>
                <!-- 三级 -->
              </lui-submenu>
              <lui-menu-item v-if="itemChild.children == null" :key="itemChild.id" :index="itemChild.path" popper-class="custom-menuitem">
                <span><span v-if="itemChild.iconShow" class="tabSpan"></span>{{ itemChild.label }} </span>
              </lui-menu-item>
            </template>
            <!-- 二级 -->
          </lui-submenu>
          <lui-menu-item v-if="item.children == null" :key="item.id" :index="item.path" popper-class="custom-menuitem">
            <span><span v-if="item.iconShow" class="tabSpan"></span>{{ item.label }} </span>
          </lui-menu-item>
          <!-- 一级  -->
        </template>
      </lui-menu>
      <!-- 菜单关闭按钮 -->
      <div
        v-if="!isCollapse"
        class="menu-left"
        :style="{top:firstMenuHeight/2 - 21 +'px'}"
        @click="changeAside(true)"><img src="../../../assets/img/close.png">
      </div>
    </div>
    <!-- 商业化入住 -->
    <BussinessDialog 
      v-if="bussinessMaskShow"
      :commercial-account-info="commercialAccountInfo"
      :menu-version-code="menuVersionCode"
      @handleQueryUnit="handleQueryUnit"
      @handleQueryUnitButton="handleQueryUnitButton" />
    <!-- 右下角 商家入驻按钮 -->
    <div v-if="rightTipShow" class="applyBut" @click="handelBusiMask">
      <img src="@/assets/img/applyBut.png" alt="">
    </div>
  </div>
</template>
<script type="text/babel">
const PublicPage = () => import('@/views/PublicPage/PublicPage.vue')
import { mapGetters } from 'vuex'
import BussinessDialog from '@/views/login/BussinessCheckIn'
import Api from '@/api'
import utils from '@/utils/utils'
import VueRouter from 'vue-router' 
import $ from 'jquery'
export default {
  name: 'v-aside',
  components: {
    BussinessDialog
  },
  props: {
    isCollapse: {
      type: Boolean,
      default() {
        return false
      }
    }
  },
  data() {
    return {
      helpCenterTree: '',
      bussinessMaskShow: false, //判断商家是否显示商家入住弹框
      rightTipShow: false,
      menuParentId: [], //帮助中心菜单
      navlist: [], //二级菜单列表
      firstMenuHeight: 0, //菜单高度
      firstMenuList: [], //一级菜单列表
      jurisdiction: {}, //权限管理
      menuList: [], //菜单列表
      currentPath: '', //当前路由
      helpCenterRoutes: [], //帮助中心路由表
      bussinessData: '', //获取商家入住数据
      bussinessDialogShow: false, //商家入住弹框展示隐藏
      commercialAccountInfo: {}, // 客户信息
      sellerNo: '', //商家编码
      checkStatus: '', //审核状态,1 记录不存在 2待审核 3 已拒绝 4 已关闭
      sellerName: '', //商家名称
      approveStatus: '', //账号审核状态,PENDING:待审核,OPEN:开启中,CLOSED:已关闭
      trialExpired: false, //试用期是否已到期,true代码已过期
      trialEnddateStr: '', //试用期 日期
      menuVersionCode: 0, //菜单的版本 1试用版本 2纯配版 3amway版（特殊版）4 dyson 5 volvo版 6专业版 7智能商务仓 8标准版 9长虹版 10纯配试用版
      getMenuList: ['/', '/403', '/defaultPage', '/commitMask', '/accountApplication', '/testPage', '/operations'] //默认公共路由  当是'/'和'/403'时跳转到默认页，defaultPage广告页面 '/commitMask'为替换连页面 'accountApplication' 账号申请页面

    }
  },
  computed: {
    activeIndex() {
      return this.$route.path
    },
    ...mapGetters(['getIsBookmark', 'getFirstMenuIndex', 'getAccountType', 'getPublicPage', 'getIsArrow']) //vuex调用全局属性
  },
  watch: {
    '$route.path': function(val) {
      this.selectmenu(val) //监听浏览器直接输入路由，将此路由添加到tabnavBox
      let path = this.getPublicPage.path
      let url = window.location.href.split('/#/')
      if (!url[1]) {
        this.$router.push(path) //跳默认页面
      }
      this.changeFirstMenuIndex(val)//路由变化时选中高亮显示当前一级菜单
      this.menuList.forEach(item => {
        if (item.path === val) {
          item.iconShow = true
        } else {
          item.iconShow = false
        }
      })
      setTimeout(() => {
        //控制菜单点击选中之后延迟收起
        this.$bus.$emit('changeAside', true)
        this.changeFirstMenuIndex()
      }, 300)
    },
    'isCollapse': function(oldVal, newVal) {
      if (oldVal) {
        for (let i = 0; i < this.firstMenuList.length; i++) {
          this.firstMenuList[i].iconIndex = 0
          if (this.firstMenuList[i].id == this.$route.meta.fid) {
            this.firstMenuList[i].iconIndex = 1
          } else {
            this.firstMenuList[i].iconIndex = 0
          }
        }
      }
    }
  },
  created() {
    this.getSearchHelpNavList()//帮助中心菜单列表
    this.getUserServerSelectStatusByPin()//获取菜单权限
    this.currentPath = location.hash.split('#')[1] //获取当前path
    this.updateSearchHelpNavList() //注册event事件，帮助中心菜单更新时使用。
    this.getButtonPerm() //判断删除按钮是否显示
  },
  mounted() {
    //计算菜单栏高度
    setTimeout(() => {
      this.firstMenuHeight = this.$refs.aside.offsetHeight || 0
      window.addEventListener('resize', () => {
        this.firstMenuHeight = this.$refs.aside.offsetHeight || 0
      })
    }, 300)
  },
  methods: {

    getButtonPerm() { //判断删除按钮是否显示
      Api.Merchants.buttonPermission().then(res => {
        if (res.success) {
          this.$store.dispatch('buttonPermission', res.data)
          sessionStorage.setItem('buttonPermission', JSON.stringify(res.data))
        }
      }).catch((e) => {
        console.log(e)
      })
    },


    handleQueryUnitButton() {
      this.rightTipShow = false //提交审批之后隐藏申请入驻按钮
    },
    handleQueryUnit(val) {
      this.bussinessMaskShow = false
      this.rightTipShow = false //.5期更改
    },
    // 点击右侧打开客户信息弹框
    handelBusiMask() {
      this.bussinessMaskShow = true
      this.rightTipShow = false 
    },
    //注册路由之前先清空所有路由，，解决控制台路由警告
    addRoutesTR(params) {
      this.$router.matcher = new VueRouter({
        mode: 'history'
      }).matcher
      this.$router.addRoutes(params)
    },
    //把菜单树转换成平级
    getTreeToMenu(tree) {
      for (let i = 0; i < tree.length; i++) {
        this.menuList.push(tree[i])
        if (tree[i].children) {
          this.getTreeToMenu(tree[i].children)
        }
      }
    },
    //重新组装帮助中心
    formaterHelpList(tree) {
      for (var i in tree) {
        this.helpCenterRoutes.push(tree[i]) //把树转换成平级，添加进路由表
        const id = tree[i].id
        tree[i].id = id + '' //避免和本地菜单id重复
        tree[i].path = '/helpsearchdetails/' + id
        tree[i].show = false
        tree[i].title = tree[i].label
        if (tree[i].children) {
          this.formaterHelpList(tree[i].children)
        }
      }
      return tree
    },
    //获取帮助中心菜单
    getSearchHelpNavList() {
      Api.HelpCenter.getSearchHelpNavList().then(res => {
        if (res.success) {
          this.helpCenterTree = res.data
          this.getMenu(res.data)
         
        }
      }).catch((e) => { })
    },
    //获取用户菜单
    getMenu(helpCenterTree) {
      this.menuParentId = []
      Api.Home.getMenu().then(res => {
        if (res.success) {
          if (res.data.tip) { //获取菜单是否异常
            this.$showErrorMsg(res.data.tipMsg)
            return
          }
          this.commercialAccountInfo = res.data.commercialAccountInfo
          this.trialExpired = res.data.trialExpired
          this.trialEnddateStr = res.data.trialEnddateStr
          this.menuVersionCode = res.data.menuVersionCode 
          //取出一级菜单
          if (res.data.menuVo !== null) {
            this.firstMenuList = res.data.menuVo.menuList
            let iframeList = res.data.menuVo.iframeList
            let menuList = res.data.menuVo.menuList
            let path = res.data.menuVo.path
            //遍历找出帮助中心，给帮助中心菜单赋值
            this.firstMenuList.forEach(item => {
              if (item.id === 9) {
                item.children = this.formaterHelpList(helpCenterTree)
                this.menuParentId = item.children
              }
            })
            const helpSearch = {
              id: 112,
              show: true,
              level: 1,
              checked: false,
              label: '帮助中心-搜索',
              path: '/helpsearch',
              code: '112',
              fid: 0,
              icon: '',
              pid: 0,
              type: 1,
              url: '',
              children: null
            }
            //帮助中心-搜索页面添加到帮助中心菜单最前面
            this.menuParentId.splice(0, 0, helpSearch)
            sessionStorage.setItem('menuParentId', JSON.stringify(this.menuParentId))
            this.$store.dispatch('menuParentId', this.menuParentId)
            this.$store.dispatch('PublicPage', res.data.menuVo)
            sessionStorage.setItem('PublicPage', JSON.stringify(res.data.menuVo))
            this.getTreeToMenu(this.firstMenuList)
            //当页面刷新高亮icon自动定位
            for (let i = 0; i < this.menuList.length; i++) {
              if (this.menuList[i].path === this.currentPath) {
                this.menuList[i].iconShow = true
              } else {
                this.menuList[i].iconShow = false
              }
            }
            this.addRouter(iframeList, menuList, path)
          } else {
            sessionStorage.setItem('getMenu', JSON.stringify(this.getMenuList))
            this.$router.push('/defaultPage') //跳默认页面
          }
          /*
          frontFlag:
            1===>账号正常展示
            2===>账号不存在且是纯配 正常显示
            3===>账号不存在，非纯配，商家已入住portal
              approveStatus 账号审核状态,
                NOT_FOUND:记录不存在,
                PENDING:待审核,
                OPEN:开启中,
                CLOSED:已关闭
            4===>账号不存在，非纯配，商家未入住portal
              checkStatus:
                1===>记录不存在
                2===>待审核
                3===>已拒绝
                4===>已关闭
          */
          this.frontFlag = res.data.frontFlag //根据商家登录状态弹框提示
          this.checkStatus = res.data.checkStatus
          let approveStatus = res.data.approveStatus//账号审核状态, 
          // let approveStatus = 'PENDING'//账号审核状态, 
          let frontFlag = res.data.frontFlag
          // let frontFlag = 3
          let checkStatus = res.data.checkStatus
          //商家名称
          this.sellerNo = res.data.sellerNo
          sessionStorage.setItem('frontFlag', JSON.stringify(this.frontFlag))
          this.$store.dispatch('frontFlag', this.frontFlag)

          if (this.menuVersionCode === 1) { //如果商家为试用版工作台跳转广告页
            this.$router.push('/defaultPage') //跳广告页面
          }
          if (frontFlag === 2) {
            this.$confirm('为了给您提供更好的服务，【京慧】标准版-纯配数据服务正在全面升级，升级期间系统暂无法访问，对您造成的不便，敬请谅解！', '温馨提示', {
              cancelButtonText: '退出',
              showClose: false,
              showCancelButton: true,
              showConfirmButton: false,
              closeOnClickModal: false,
              customClass: 'message-bg',
              closeOnPressEscape: false
            }).then(() => {
              this.$message({
                type: 'success',
                message: '删除成功!'
              })
            }).catch(() => {
              //清除cookies 退出系统
              this.clearOut() 
            })
          } else if (frontFlag === 3) { //待修改
            /*   
                approveStatus 账号审核状态,
                NOT_FOUND:记录不存在,
                PENDING:待审核,
                OPEN:开启中,
                CLOSED:已关闭
            */  
            if (approveStatus === 'NOT_FOUND') {
              this.$confirm('为了给您提供更好的服务，【京慧】标准版在权限管理上进行了全面升级，目前已限制了您的账号访问权限。烦请您重新提交访问申请，我们会在3个工作日内完成审核。给您带来的不便敬请谅解！', '温馨提示', {
                cancelButtonText: '退出',
                confirmButtonText: '申请',
                showClose: false,
                showCancelButton: true,
                showConfirmButton: true,
                closeOnClickModal: false,
                closeOnPressEscape: false,
                customClass: 'message-bg'
              }).then(() => {
                //申请成功之后弹窗提示
                const params = {}
                params.applyAccount = res.data.accountId
                params.sellerNo = res.data.sellerNo
                params.sellerName = res.data.sellerName

                Api.Merchants.addApplicationRecord(params).then(res => {
                  if (res.success) {
                    this.$confirm('您的账号开通申请已经成功提交，请您通知销售人员进行及时审批！', '温馨提示', {
                      cancelButtonText: '退出',
                      showClose: false,
                      showCancelButton: true,
                      showConfirmButton: false,
                      closeOnClickModal: false,
                      closeOnPressEscape: false,
                      customClass: 'message-bg'
                    }).then(() => {}).catch((e) => {
                      //清除cookies 退出系统
                      this.clearOut() 
                    })
                  }
                }).catch((e) => {
                  this.$showErrorMsg(e)
                })
              }).catch((e) => {
                //清除cookies 退出系统
                this.clearOut() 
              })
            } else if (approveStatus === 'OPEN') {
              this.$confirm('您的账号开通存在异常，请联系销售人员处理！', '温馨提示', {
                cancelButtonText: '退出',
                showClose: false,
                showCancelButton: true,
                showConfirmButton: false,
                closeOnClickModal: false,
                closeOnPressEscape: false,
                customClass: 'message-bg'
              }).then(() => {}).catch((e) => {
                //清除cookies 退出系统
                this.clearOut() 
              })
            } else if (approveStatus === 'PENDING') {
              this.$confirm('您已申请访问京慧的入驻商家，请您耐心等待，销售业务人员会在3个工作日内处理您的申请！', '温馨提示', {
                cancelButtonText: '退出',
                showClose: false,
                showCancelButton: true,
                showConfirmButton: false,
                closeOnClickModal: false,
                closeOnPressEscape: false,
                customClass: 'message-bg'
              }).then(() => {}).catch((e) => {
                //清除cookies 退出系统
                this.clearOut() 
              })
            } else if (approveStatus === 'CLOSED') {
              this.$confirm('您的账号开通申请已被拒绝，请您联系销售人员确认！', '温馨提示', {
                cancelButtonText: '退出',
                showClose: false,
                showCancelButton: true,
                showConfirmButton: false,
                closeOnClickModal: false,
                closeOnPressEscape: false,
                customClass: 'message-bg'
              }).then(() => {}).catch((e) => {
                //清除cookies 退出系统
                this.clearOut() 
              })
            }
            // this.$confirm('非常抱歉，您的账号不能访问【京慧】系统，请您联系销售人员申请开通访问权限！', '温馨提示', {
            //   cancelButtonText: '关闭',
            //   confirmButtonText: '申请',
            //   showClose: false,
            //   showCancelButton: true,
            //   showConfirmButton: true,
            //   closeOnClickModal: false,
            //   closeOnPressEscape: false,
            //   customClass: 'message-bg'
            // }).then(() => {
            //   this.$message({
            //     type: 'success',
            //     message: '删除成功!'
            //   })
            // }).catch((e) => {
            //   this.$showErrorMsg(e)
            // })
          } else if (frontFlag === 4) {
            /*
              checkStatus:
                  1===>记录不存在  弹框展示（第一次访问，开始使用则进入弹框确认商家信息），关闭弹框到试用版
                  2===>待审核  弹框展示（催办的）
                  3===>已拒绝  关闭弹框显示试用版本
                  4===>已关闭  平台审核拒绝了，试用版本也不让用了
            */
            if (checkStatus === 1) {
              this.initplateForm(this.commercialAccountInfo)
            } else if (checkStatus === 2) {
              this.$confirm('您的开通申请暂未审批，请您联系销售人员及时审批！', '温馨提示', {
                cancelButtonText: '关闭',
                confirmButtonText: '催办',
                customClass: 'message-bg',
                showConfirmButton: false,
                closeOnClickModal: false,
                closeOnPressEscape: false,
                type: 'warning'
              }).then(() => {
                //点击调用催办
                this.getUrge(this.sellerNo)
              }).catch(() => {})
            } else if (checkStatus === 3) {
              //一进来是4，3状态，则弹框展示 （确认商家信息）
              this.initplateForm(this.commercialAccountInfo)
            } else if (checkStatus === 4) {
              this.$confirm('您的开通申请已被拒绝，请您联系销售人员确认！', '温馨提示', {
                showConfirmButton: false,
                showCancelButton: true,
                customClass: 'message-bg',
                showClose: false,
                closeOnPressEscape: false,
                cancelButtonText: '关闭'     
              })
            }
          } 
        } else {
          this.$router.push('/defaultPage') //跳默认页面
          this.$showErrorMsg(res.errMessage)
        }
      }).catch((e) => {
        this.$router.push('/defaultPage') //跳默认页面

        this.$confirm(e, '温馨提示', {
          cancelButtonText: '退出',
          showClose: false,
          showCancelButton: true,
          showConfirmButton: false,
          closeOnClickModal: false,
          closeOnPressEscape: false,
          customClass: 'message-bg'
        }).then(() => {}).catch((e) => {
          //清除cookies 退出系统
          this.clearOut() 
        })
      })
    },
    //清除cookies 并且退出系统
    clearOut() {
      sessionStorage.clear()
      if (this.getAccountType === '2') { //商家
        $.getJSON('https://sso.jdl.cn/exit?callback=?', function(data) {
          $.getJSON('https://sso.jd.com/exit?callback=?', function(data) {
            window.location.reload()
          })
        })
      } else if (this.getAccountType === '1') { //运营
        this.clearCookie()
      } 
    },
    //催办接口掉用
    getUrge(params) {
      Api.MerchantLogin.urge(params).then(res => {
        if (res.success) {  
          this.$showSuccessMsg('提交催办成功') 
        } else {
          this.$showErrorMsg(res.errMessage)
        }
      }).catch((e) => {
        this.$showErrorMsg(e) 
      })
    },
    // 试用期是否已到期
    initplateForm(data) {
      let trialExpiredMsg = ''
      if (this.trialExpired) { //试用期是否已到期 切换期后
        trialExpiredMsg = '为了给您提供更好的服务，【京慧】标准版在权限管理上进行了全面升级，您可以继续免费使用，感谢您的大力支持！'
        this.$confirm(trialExpiredMsg, 'Hi,  欢迎您访问京慧数字化供应链管理平台！', {
          distinguishCancelAndClose: true,
          closeOnClickModal: false,
          customClass: 'message-bg',
          showClose: false,
          showCancelButton: false,
          confirmButtonText: '免费使用',
          type: 'warning',
          beforeClose: (action, instance, done) => {
            if (action === 'confirm') {
            //调取接口mcok就是getmenu接口里取commercialAccountInfo
              this.commercialAccountInfo = data
              //0.5期新增
              let userSubmitCmd = {}
              userSubmitCmd.sellerNo = this.sellerNo
              //暂时注释
              Api.MerchantLogin.submitApproval(userSubmitCmd).then(res => {
                //审批成功以后
                if (res.success) {
                  //关闭弹框
                  this.checkStatus = 2   
                  this.$confirm('您的开通申请已经成功提交，请您通知销售人员进行及时审批！', '温馨提示', {
                    cancelButtonText: '关闭',
                    showClose: false,
                    showCancelButton: true,
                    showConfirmButton: false,
                    closeOnClickModal: false,
                    customClass: 'message-bg',
                    closeOnPressEscape: false
                  }).then(() => {
                    this.$message({
                      type: 'success',
                      message: '删除成功!'
                    })
                  }).catch(() => {
                    if (this.menuVersionCode === 1) {
                      this.$router.push('/defaultPage') //跳默认页面
                    }
                    // window.location.reload()
                  })
                 
                }
              }).catch((e) => {
                this.$showErrorMsg(e)
              })
              // this.bussinessMaskShow = true
              done()
            } else {
            //这里区别就是关闭按钮.拒绝按钮去掉了
              this.bussinessMaskShow = false
              // this.rightTipShow = true
              this.rightTipShow = false //.5期更改
            }              
          }
        }).then(action => {
        }).catch(action => { 
        }) 
      } else { //试用期是否已到期 切换期前
        trialExpiredMsg = '为了给您提供更好的服务，【京慧】标准版平台升级，服务将于' + utils.getFomateDateStr(this.trialEnddateStr.toString()) + '对未申请“免费使用“的客户关闭服务，为了不影响您正常使用，请您及时申请，十分感谢！'
        this.$confirm(trialExpiredMsg, 'Hi,  欢迎您访问京慧数字化供应链管理平台！', {
          distinguishCancelAndClose: true,
          closeOnClickModal: false,
          customClass: 'message-bg',
          showClose: false,
          confirmButtonText: '免费使用',
          showCancelButton: false,
          type: 'warning',
          beforeClose: (action, instance, done) => {
            if (action === 'confirm') {
            //调取接口mcok就是getmenu接口里取commercialAccountInfo
              this.commercialAccountInfo = data
              // this.bussinessMaskShow = true
              //0.5期新增
              let userSubmitCmd = {}
              userSubmitCmd.sellerNo = this.sellerNo
              //暂时注释
              Api.MerchantLogin.submitApproval(userSubmitCmd).then(res => {
                //审批成功以后
                if (res.success) {
                  //关闭弹框
                  this.checkStatus = 2
                  this.$confirm('您的开通申请已经成功提交，请您通知销售人员进行及时审批！', '温馨提示', {
                    cancelButtonText: '关闭',
                    showClose: false,
                    showCancelButton: true,
                    showConfirmButton: false,
                    customClass: 'message-bg',
                    closeOnClickModal: false,
                    closeOnPressEscape: false
                  }).then(() => {
                    this.$message({
                      type: 'success',
                      message: '删除成功!'
                    })
                  }).catch(() => {
                    if (this.menuVersionCode === 1) {
                      this.$router.push('/defaultPage') //跳默认页面
                    }
                    // window.location.reload()
                  })
                }
              }).catch((e) => {
                this.$showErrorMsg(e)
              })
              done()
            } else {
            //这里区别就是关闭按钮.拒绝按钮去掉了
              this.bussinessMaskShow = false
              // this.rightTipShow = true
              this.rightTipShow = false //.5期更改
            }              
          }
        }).then(action => {
        }).catch(action => { 
        }) 
      }
    },
    //动态路由管理
    addRouter(iframeRoutes, menuList, path) {
      for (let i = 0; i < iframeRoutes.length; i++) {
        // 给路由绑定模板
        iframeRoutes[i].component = PublicPage
        //对后台返回的特殊字符进行转义
        iframeRoutes[i].meta.position = iframeRoutes[i].meta.position ? utils.htmlDecode(iframeRoutes[i].meta.position) : ''
        iframeRoutes[i].meta.url = iframeRoutes[i].meta.url ? utils.htmlDecode(iframeRoutes[i].meta.url) : ''
        //通过当前路由找到当前页面信息，问题反馈使用
        if (this.$route.path === iframeRoutes[i].path) {
          this.$route.meta.fid = iframeRoutes[i].meta.fid
          this.$route.meta.position = iframeRoutes[i].meta.position
          this.$route.meta.title = iframeRoutes[i].meta.title
          this.$route.meta.url = iframeRoutes[i].meta.url ? iframeRoutes[i].meta.url : ''
        }
      }
      //合并路由，本地路由+外链路由+帮助中心路由
      let localRoutes = this.$router.options.routes
      let newRoute = []
      //判断如果没有返回帮助中心(id为9)则不添加路由
      let menuIds = []
      for (var i in menuList) {
        menuIds.push(menuList[i].id)
      }
      if (menuIds.includes(9)) {
        newRoute = [...iframeRoutes, ...localRoutes, ...this.helpCenterRoutes]
        //是否展示顶通帮助中心快捷菜单
        sessionStorage.setItem('isHelpCenter', true)
        this.$store.dispatch('isHelpCenter', true)
      } else {
        newRoute = [...iframeRoutes, ...localRoutes]
        sessionStorage.setItem('isHelpCenter', false)
        this.$store.dispatch('isHelpCenter', false)
      }
      //把合并后的路由添加进路由表
      this.$router.options.routes = newRoute
      this.addRoutesTR(newRoute)
      //高亮显示当前菜单icon
      this.changeFirstMenuIndex()
      //从平级菜单中取出带有path的菜单列表
      this.menuList.forEach(item => {
        if (item.path !== '') {
          this.getMenuList.push(item.path)
        }
      })
      //存储所有权限菜单的path
      sessionStorage.setItem('getMenu', JSON.stringify(this.getMenuList))
      //下面代码，外部平台直接跳转到需要访问的页面
      let url = window.location.href.split('/#/')
      const newPath = sessionStorage.getItem('newPath')
      //路由为'/'时,url[1]等于空
      if (!url[1]) {
        if (newPath && this.getMenuList.includes(newPath) && newPath !== '/' && newPath !== '/403' && newPath !== '/defaultPage') {
          this.$router.push(newPath)
          return
        }
        this.$router.push(path) //跳默认页面
      } else {
        //如果当前路由403与默认页 且path 默认页面不为空则进入默认页
        if (url[1] === '403' || url[1] === 'defaultPage') {
          if (path) {
            this.$router.push(path) //跳默认页面
          }
        }
      }
    },
    //刷新页面图标背景显示
    changeFirstMenuIndex(path) {
      for (let i = 0; i < this.firstMenuList.length; i++) {
        this.firstMenuList[i].iconIndex = 0
        if (this.firstMenuList[i].id == this.$route.meta.fid) {
          this.firstMenuList[i].iconIndex = 1
        } else {
          this.firstMenuList[i].iconIndex = 0
        }
      }
      //存储当前菜单父id,页面刷新时高亮显示用
      this.$store.dispatch('firstMenuIndex', this.$route.meta.fid)
    },
    //更新帮助中心菜单
    updateSearchHelpNavList() {
      this.$bus.on('updateSearchHelp', () => {
        this.getSearchHelpNavList()
      })
    },
    handleOpen(key, keyPath) { },
    handleClose(key, keyPath) { },
    //用户开通服务情况，待跟进事项使用
    getUserServerSelectStatusByPin() {
      Api.Home.getUserServerSelectStatusByPin().then(res => {
        this.jurisdiction = res.data
        window.sessionStorage.setItem('jurisdiction', JSON.stringify(this.jurisdiction))
      }).catch((e) => { })
    },
    // 点击一级菜单
    changeFirstMenu(firstMenu) {
      // this.getMenu(this.helpCenterTree)
      if (this.menuVersionCode === 1) {
        if (this.checkStatus === 2) {
          //点击催办调接口传参
          //一进来如果是4，2：弹框展示 （有催办按钮）
          this.$confirm('您的京慧平台“使用申请”正在加急审批中，一般会在5个工作日内审核完成，感谢您的支持！', '温馨提示', {
            cancelButtonText: '取消',
            confirmButtonText: '催办',
            customClass: 'message-bg',
            showConfirmButton: false,
            closeOnClickModal: false,
            closeOnPressEscape: false,
            type: 'warning'
          }).then(() => {
            //点击催办调接口传参
            this.getUrge(this.sellerNo)
          }).catch(() => {})
          return
        } else {
          this.initplateForm(this.commercialAccountInfo)
          return
        }
      }
      //判断高亮ICON
      if (firstMenu.children === null) {
        for (let i = 0; i < this.menuList.length; i++) {
          this.menuList[i].iconShow = false
        }
      }
      //一级菜单高亮使用
      this.$store.dispatch('firstMenuIndex', firstMenu.id)
      this.firstMenuList.forEach(item => {
        if (firstMenu.id === item.id) {
          item.iconIndex = 1
          if (item.children) {
            //给一级菜单下二级菜单赋值
            this.navlist = item.children
            this.$bus.$emit('changeAside', false)
            //判断是否有二级菜单，有显示侧边栏按钮，否则不显示。
            this.$store.dispatch(
              'isChildren',
              {
                'path': this.$route.path,
                'state': true
              })
          } else {
            this.$router.push(item.path)
            this.$bus.$emit('changeAside', true)
            //判断是否有二级菜单，有显示侧边栏按钮，否则不显示。
            this.$store.dispatch(
              'isChildren',
              {
                'path': this.$route.path,
                'state': false
              })
          }
        } else {
          item.iconIndex = 0
        }
      })
    },
    //把当前菜单添加进tab签
    selectmenu(key) {
      if (!key) {
        return
      }
      const router = this.$router.options.routes
      let title = ''
      const navTitle = function(path, routerARR) {
        for (let i = 0; i < routerARR.length; i++) {
          if (routerARR[i].path === path) {
            title = routerARR[i].title
          }
        }
        return title
      }
      const navName = navTitle(key, router)
      if (navName) {
        this.$store.dispatch('addTab', {
          title: navName,
          path: key
        })
      }
    },
    changeAside(isCollapse) {
      this.$store.dispatch( //判断是否有二级菜单，有显示侧边栏按钮，否则不显示。
        'isChildren',
        {
          'path': this.$route.path,
          'state': false
        })
      this.$bus.$emit('changeAside', isCollapse)
      this.changeFirstMenuIndex()
    }
  }
}
</script>
<style lang="scss" scoped>
.active-aside{
  top: 60px;
}
.active-lui-menu{
  height: calc(100% - 60px)!important;
  background-color: rgba(60, 63, 77, 0.8)!important;
}
.lui-menu-item.is-active {
    color: #FFFFFF;
    background-color: rgba(60,63,77,0.8);
    background-image: linear-gradient(180deg, #1D1E23 0%, #282A31 8%, #2C2D35 97%, #484C5D 100%);
}
.lui-menu-item:focus, .lui-menu-item:hover {
    outline: 0;
    color: #FFFFFF;
    background-image: linear-gradient(180deg, #1D1E23 0%, #282A31 8%, #2C2D35 97%, #484C5D 100%);
}

.lui-menu-item:focus, .lui-menu-item {
    outline: 0;
    color: #FFFFFF;
}
.lui-menu-vertical.lui-menu{
   backdrop-filter: blur(4px);
    background-color: rgba(60, 63, 77, 0.8)!important;
}
.tabSpan{
  display: inline-block;
  width: 6px;
  height: 6px;
  background: 50%;
  background-image: linear-gradient(180deg, #358DFA 0%, #1854F3 100%);
  box-shadow: 0 1px 3px 0 rgba(0,0,0,0.50);
  border-radius: 50%;
  margin-top: -3px;
  margin-right: 5px;
}
/deep/ .lui-message-box__header{
  background-color: #f00!important;
}
.applyBut{
  position: fixed;
  bottom: 0;
  right: 0;
  width: 100px;
  height: 100px;
  z-index: 1000;
  cursor: pointer;
  img{
    width: 100%;
  }
}
</style>
<style lang="scss" rel="stylesheet/scss">
@import "@/assets/stylus/main.scss";
@import "aside.scss";
.lui-message-box{
  border: none;
}
.lui-message-box.message-bg .lui-message-box__header{
  position: relative;
  background:url('../../../assets/img/applyTitle.png') no-repeat center center $--gl-blue !important;
  background-size: cover;
}
.lui-message-box.message-bg .lui-message-box__header .lui-message-box__title{
  color: #FFFFFF;
}
</style>
