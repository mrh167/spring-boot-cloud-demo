<template>
  <div class="header-box">
    <div class="header-controller">
      <ul class="hd-ct-left">
        <li class="hd-logo-wrp">
          <div class="logo-img-box">
            <img
              src="../../../assets/img/logo.png"
              @click="handelClickPath">
          </div>
        </li>
        <!-- <li @click="changeAside">
          <a v-if="iconRemember ==='left'"
             class="iconfont adSys-outdent"
             href="javascript:;"></a>
          <a v-if="iconRemember ==='right'"
             class="iconfont adSys-indent"
             href="javascript:;"></a>
        </li>
        <li>
          <a class="iconfont adSys-reload"
             href="javascript:;"
             @click="reloadPage()"></a>
        </li> -->
      </ul>
      <ul class="hd-ct-right">
        <!-- 帮助中心 -->
        <li v-if="getIsHelpCenter">
          <a
            class="iconfont keyword-wrap"
            href="javascript:;">
            <input
              v-model="keyword"
              class="search-input"
              type="text"
              placeholder="搜索范围为帮助中心">
            <i
              class="lui-icon-search"
              @click="$router.push({name:'HelpSearch',params:{keyword:keyword}})"></i>
          </a>
          <div
            v-show="keyword"
            ref="search"
            class="search-content">
            <div
              v-for="item of helpList"
              :key="item.id"
              class="search-item"
              @click="handleHelpClick(item)">
              <p v-dompurify-html="item.label"></p>
              <span v-dompurify-html="item.helpText"></span>
            </div>
            <div
              v-show="hasNoData"
              class="search-item">没有找到匹配数据</div>
          </div>
        </li>
        <!-- 收藏夹 -->
        <li>
          <span>
            <a
              style=""
              class="iconfont iconxihuan"
              href="javascript:;"
              @click="handleBookmark">
            </a>
          </span>
        </li>
        <!-- 应用中心 -->
        <li v-if="getVscSellerType===1 ||getVscSellerType===2">
          <span>
            <a
              class="iconfont iconyingyongzhongxin"
              href="javascript:;"
              @click="goAppCenter">
            </a>
          </span>
        </li>
        <!-- 帮助中心 -->
        <li v-if="getIsHelpCenter">
          <span>
            <a
              class="iconfont iconbangzhuzhongxin1"
              href="javascript:;"
              @click="$router.push('/helpsearch')"></a>
          </span>
        </li>
        <!-- 公告 -->
        <li
          v-outside-click="close"
          class="message-li">
          <a
            href="javascript:;"
            @click="drawer=!drawer">
            <lui-badge
              v-if="MsgCount>=1"
              is-dot
              class="mark"><i class="iconfont iconxiaoxizhongxin"></i></lui-badge>
            <lui-badge v-else><i class="iconfont iconxiaoxizhongxin"></i></lui-badge>
          </a>
          <div
            v-if="drawer"
            class="message-box">
            <div class="message-box-header">
              <div><span>全部消息</span></div>
              <div><span
                class="allread"
                @click="allRead">全部标记为已读</span></div>
            </div>
            <div class="message-box-content">
              <div
                v-if="tableData.length>=1"
                class="message-box-content-table">
                <dl
                  v-for="(item,index) in tableData"
                  :key="index"
                  class="tableDls">
                  <dt
                    v-if="item.readFlag===0"
                    class="DliMsgCount"><span></span>【未读消息数】{{ item.msgTitle }}</dt>
                  <dt
                    v-else
                    class="DliMsgCount countMargin">【已读消息数】{{ item.msgTitle }}</dt>
                  <dd class="DlsDdCount">{{ item.msgText }}</dd>
                </dl>
              </div>
              <div
                v-else
                class="message-box-content-img"><img src="@/assets/img/message.png"></div>
            </div>
            <div class="message-box-footer">
              <div @click="messageClick">历史消息&nbsp;<i class="lui-icon-d-arrow-right"></i></div>
            </div>
          </div>
        </li>
        <!-- 下载管理 -->
        <li>
          <span>
            <a
              class="iconfont iconxiazai"
              style="font-size:14px;"
              href="javascript:;"
              @click="$router.push('/downloadCenter')"></a>
          </span>
        </li>
        <!-- 审批中心 -->
        <li>
          <span>
            <a
              class="iconfont iconshenpi"
              href="javascript:;"
              @click="$router.push('/workApproval')"></a>
          </span>
        </li>
        <!-- 商家切换 -->
        <li @click="isDropdown = false">
          <lui-dropdown ref="dropdown" class="dropdown-box" :hide-on-click="false" trigger="click">
            <span class="lui-dropdown-link">
              <a href="javascript:;">
                <img src="../../../assets/img/jd.png" style="width:36px;height: 36px">
              </a>
            </span>
            <lui-dropdown-menu slot="dropdown">
              <div v-if="isDropdown" class="custom-dropdown-select" :style="{'right':dropdownWidth+'px','width':dropdownWidth+'px'}" @mouseleave="isDropdown = true">
                <lui-input
                  v-model="search"
                  class="search-top"
                  placeholder="请输入搜索内容">
                  <i slot="suffix" class="lui-input__icon lui-icon-search" @click="getSellers(1)"></i>
                </lui-input> <!-- -->
                <ul class="search-list">
                  <li
                    v-for="(item,index) in sellerList"
                    :key="index"
                    @click="updateSelectSeller(item)">
                    <lui-tooltip effect="dark" :visible-arrow="false" :content="item.sellerName" placement="left">
                      <span class="text">{{ item.sellerName }}</span>
                    </lui-tooltip>
                    <lui-checkbox
                      v-if="index === 0 && item.sellerNo === userInfo.sellerNo"
                      v-model="isCheckbox"
                      disabled>
                    </lui-checkbox>
                  </li>
                </ul> <!---->
                <div v-if="sellerList.length>=10" class="custom-dropdown-footer">*更多商家请使用关键词搜索</div>
              </div>
              <lui-dropdown-item>
                <div v-show="userInfo.sellerName" @click="getDropdownWidth(true)">
                  <i class="lui-icon-arrow-left"></i>
                  <span>{{ userInfo.sellerName }}</span>
                </div>
              </lui-dropdown-item>
              <!-- <lui-dropdown-item>
                <div class="custom-dropdown-item">
                  <span>{{ userInfo.sellerName }}</span>
                </div>
              </lui-dropdown-item> -->
              <lui-dropdown-item>
                <div class="custom-dropdown-item">
                  <span @click="$router.push('/userprofile')">{{ userInfo.account }}</span>
                </div>
              </lui-dropdown-item>
              <lui-dropdown-item>
                <div class="custom-dropdown-item" @click="logout">
                  登出系统
                </div>
              </lui-dropdown-item>
            </lui-dropdown-menu>
          </lui-dropdown>
        </li>
      </ul>
    </div>
    <!-- <div class="bread-crumb">
      <lui-breadcrumb separator-class="lui-icon-arrow-right">
        <lui-breadcrumb-item :to="{ path: '/' }">首页</lui-breadcrumb-item>
        <lui-breadcrumb-item>{{$route.name}}</lui-breadcrumb-item>
      </lui-breadcrumb>
    </div> -->
  </div>
</template>
<style lang="scss" rel="stylesheet/scss">
@import "./header.scss";
</style>
<script type="text/babel">
import Api from '@/api'
import { mapGetters } from 'vuex'
// import utils from '@/utils/utils'
import $ from 'jquery'
export default {
  //消息模拟弹窗
  directives: {
    'outside-click': {
      bind: function(el, binding, vnode) {
        //定义点击函数
        function clickHandler(e) {
          if (el.contains(e.target)) { //如果点击区域在所在指令元素内部，则直接返回
            return false
          }
          if (binding.expression) { //如果定义了表达式，则执行表达式中的函数
            binding.value(e)
          }
        }
        el.vueOutsideClick = clickHandler
        document.addEventListener('mouseover', clickHandler)//绑定到 document 的点击事件
      },
      unbind: function(el, binding, vnode) {
        document.removeEventListener('mouseover', el.vueOutsideClick)//解绑
        delete el.vueOutsideClick//销毁
      }
    }
  },
  props: {
    isCollapse: {
      type: Boolean,
      default() {
        return false
      }
    }
  },
  data() {
    return {
      iconRemember: 'left',
      passDate: 1,
      drawer: false,
      direction: 'ttb',
      x: 0,
      y: 0,
      pageNum: 1,
      pageSize: 10,
      tableData: [],
      MsgCount: 0,
      keyword: '',
      list: [],
      timer: null,
      helpList: [],
      isShow: false,
      dropdownWidth: '',
      isDropdown: false,
      search: '', //商家搜索
      sellerList: [], //商家列表
      isCheckbox: true,
      userInfo: { sellerName: '', pin: '' }
    }
  },
  computed: {
    hasNoData() {
      return !this.helpList.length
    },
    ...mapGetters(['getIsBookmark', 'getAccountType', 'getVscSellerType', 'getIsHelpCenter', 'getfrontFlag'])
  },
  watch: {
    keyword() {
      if (this.timer) {
        clearTimeout(this.timer)
      }
      if (!this.keyword) {
        this.helpList = []
        return
      }
      this.searchTop()
    }
  },
  mounted() {
    if (this.getIsHelpCenter) {
      this.hide()
    }
    this.msgSidePageList()
    this.unMsgCount()
    this.getUserInfo()
  },
  methods: {
    handelClickPath() {
      const menuList = sessionStorage.getItem('PublicPage') ? JSON.parse(sessionStorage.getItem('PublicPage')) : ''
      this.$router.push({ path: menuList.path })
    },
    //商家切换
    updateSelectSeller(item) {
      if (item.sellerNo === this.userInfo.sellerNo) {
        return
      }
      const params = { sellerNo: item.sellerNo, sellerName: item.sellerName }
      Api.Home.updateSelectSeller(params).then((res) => {
        if (res.success) {
          sessionStorage.clear()
          this.$message({
            message: '成功切换到商家[' + item.sellerName + ']',
            type: 'success'
          })
          setTimeout(() => {
            window.location.reload()
          }, 1000)
        } else {
          this.$showErrorMsg('商家切换失败')
        }
      }).catch((e) => {
        console.log(e)
      })
    },
    //查询账号下绑定的商家
    getSellers(type) {
      const formData = new FormData()
      formData.append('type', type)
      formData.append('content', this.search)
      Api.Home.listSellersByCondition(formData).then((res) => {
        if (res.success) {
          this.sellerList = res.data

        }
      }).catch((e) => {
        console.log(e)
      })
    },
    // 获取下拉菜单宽度
    getDropdownWidth(isShow) {
      this.isDropdown = !this.isDropdown
      if (!this.isDropdown) {
        return
      }
      // if (isShow) {
      this.search = ''
      this.sellerList = []
      this.getSellers(0)
      // this.isDropdown = true
      this.dropdownWidth = this.$refs.dropdown.dropdownElm.offsetWidth + 3
    },
    //打开收藏夹
    handleBookmark() {
      this.$store.dispatch('isBookmark', this.getIsBookmark)
    },
    //打开应用中心
    goAppCenter() {
      this.$router.push('/application')
    },
    //退出登录
    logout() {
      // const getAccountType = '1'
      sessionStorage.clear()
      if (this.getAccountType === '2') { //商家
        $.getJSON('https://sso.jdl.cn/exit?callback=?', function(data) {
          $.getJSON('https://sso.jd.com/exit?callback=?', function(data) {
            window.location.reload()
          })
        })
      } else if (this.getAccountType === '1') { //运营
        this.clearCookie()
      }
    },
    clearCookie() {
      const arr = window.location.hostname.split('.')
      const domain = arr[arr.length - 2] + '.' + arr[arr.length - 1]
      const date = new Date()
      date.setTime(date.getTime() - 10000)
      document.cookie = 'sso.jd.com=0;path=/;domain=' + domain + ';expires=' + date.toUTCString()//清除一级域名下的或指定的，例如 .kevis.com
      window.location.reload()
    },
    Approval() {
      this.$message.error('功能建设中，敬请期待')
    },
    //获取用户信息
    getUserInfo() {
      Api.Home.getUserInfo().then(res => {
        if (res.success) {
          this.userInfo = res.data
          window.sessionStorage.setItem('userInfo', JSON.stringify(res.data))
          this.$store.dispatch('userInfo', res.data)
        }
      }).catch(e => {
        console.log(e)
        this.$showErrorMsg(e)
      })
    },
    hide() {
      // document.addEventListener('click', (e) => {
      //   if (!this.$refs.search.contains(e.target)) {
      //     this.keyword = ''
      //   }
      // })
    },
    //点击跳转到帮助中心
    handleHelpClick(item) {
      item.label = item.label.replace('<font color="#56C1DF">', '').replace('</font>', '')
      this.$router.push({ name: 'HelpSearch', params: { keyword: item.label }})
      this.keyword = ''
    },
    msgSidePageList() { //消息侧边获取
      Api.MessageInfo.msgSidePageList({
        pageNum: this.pageNum,
        pageSize: this.pageSize
      }).then(row => {
        if (row.success) {
          this.tableData = row.data
        }
      }).catch((e) => { })
    },
    allRead() { //全部标记已读
      Api.MessageInfo.allRead({
        pageSize: this.pageSize,
        pageNum: this.pageNum,
        readFlag: this.readFlag
      }).then(row => {
        if (row.success) {
          this.msgSidePageList()
          this.unMsgCount()
        }
      }).catch(e => { this.$showErrorMsg(e) })
    },
    unMsgCount() { //未读消息数
      Api.MessageInfo.unMsgCount().then(row => {
        if (row.success) {
          this.MsgCount = row.data
        }
      }).catch((e) => { })
    },
    changeAside() {
      if (this.iconRemember === 'left') {
        this.iconRemember = 'right'
      } else {
        this.iconRemember = 'left'
      }
      this.$bus.$emit('changeAside')
    },
    reloadPage() {
      // this.reload()
    },
    // logout() {
    //   window.location.href = 'https://passport.jd.com/uc/login?ltype=logout'
    // },
    close(event) { //消息弹窗事件
      this.drawer = false
    },
    messageClick() {
      this.$router.push({ path: '/news' })
    },
    searchTop() {
      Api.Home.postSearchTop({
        'keyword': this.keyword,
        'size': 5
      }).then((res) => {
        if (res.success) {
          this.helpList = res.data
          this.serchKeyword()
        }
      }).catch((e) => {
        console.log(e)
      })
    },
    escape2Html(str) {
      var arrEntities = { 'lt': '<', 'gt': '>', 'nbsp': ' ', 'amp': '&', 'quot': '"' }
      return str.replace(/&(lt|gt|nbsp|amp|quot);/ig, function(all, t) { return arrEntities[t] })
    },
    serchKeyword() {
      this.timer = setTimeout(() => {
        // var result = []
        this.helpList.forEach((item) => {
          item.label = this.escape2Html(item.label)
          item.helpText = this.escape2Html(item.helpText)
        })
        // this.list = result
      }, 100)
    }
  }
}
</script>
<style lang="scss">
@import '@/assets/stylus/main';
  .custom-dropdown-item{
    padding-left: 19px;
  }
  .custom-dropdown-select{
    min-width: 200px;
    max-height: 384px;
    display: flex;
    flex-direction: column;
    position: absolute;
    top: 0;
    right: 127px;
    background: #fff;
    border-radius: 4px;
    box-shadow: 0 2px 12px 0 rgba(0,0,0,.1);
    .lui-icon-search{cursor: pointer;}
    .lui-input__inner{border: 0;}
    .search-top{
      position: absolute;
      top: 0;
    }
    .search-list{
      margin-top: 32px;
      flex: 1;
      overflow-y: auto;
      overflow-x: hidden;
      li{
        &:first-child{
          cursor: default!important
        }
        width: 100%;
        cursor: pointer;
        height: 32px;
        line-height: 32px;
        padding: 0 10px;
        font-size: 14px;
        .text{
          display: inline-block;
          overflow: hidden;
          text-overflow: ellipsis;
          width: calc(100% - 14px);
          white-space: nowrap;
        }
        &:hover{
          background: rgba(13, 108, 162, 0.1);
          color: $--gl-blue;
        }
        .lui-checkbox{
          float: right;
          cursor: default;
          .lui-checkbox__input{
            cursor: default;
          }
          .lui-checkbox__inner{
            background-color: $--gl-blue;
            border-color: $--gl-blue;
          }
        }
      }
    }
    .custom-dropdown-footer{
      height: 32px;
      line-height: 32px;
      padding: 0 10px;
      font-size: 14px;
      text-align: center;
      color:#ccc;
    }
  }
.search-content {
  height: 300px;
  overflow-y: auto;
  width: 395px;
  z-index: 111;
  position: fixed;
  background: #fff;
  margin: 0 8px;
  border-radius: 4px;
  box-shadow: 1px 1px 5px 1px #ccc;
  .search-item {
    padding-left: 10px;
    width: 100%;
    color: #333;
    line-height: 30px;
    z-index: 111;
    font-size: 14px;
    &:hover {
      border-radius: 4px;
      background: #f2f2f2;
    }
  }
}
.lui-dropdown-menu__item:focus, .lui-dropdown-menu__item:not(.is-disabled):hover{
  background-color:#fff!important;
  color:$--gl-blue!important;
}
</style>
