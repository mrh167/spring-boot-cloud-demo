<template>
  <div v-show="transitionShow" class="tabnavBox">
    <div class="wrap" :class="{'is-arrow':showTool}">
      <span
        v-show="showTool"
        class="el-tabs__nav-prev"
        style="z-index: 1000;"
        @click="clickLeft()"><i class="lui-icon-arrow-left"></i></span>
      <span
        v-show="showTool"
        class="el-tabs__nav-next"
        style="z-index: 1000;"
        @click="clickRight()"><i class="lui-icon-arrow-right"></i></span>
      <div class="ul-wrap">
        <transition-group
          ref="tabnavBox"
          name="list"
          tag="ul"
          :style="{transform: 'translateX('+translateX+'px)'}">
          <li
            v-for="(item, index) in tabnavBox"
            :key="item.path"
            ref="tabnav"
            class="tabnav"
            :class="{ active: $route.path === item.path }"
            @contextmenu.prevent="openMenu(item,$event,index)"
          >
            <div @click="openPath">
              <router-link :to="item.path">{{ item.title }}</router-link>
              <i v-if="tabnavBox.length >1" class="lui-icon-close" @click="removeTab(item)"></i>
            </div>
          </li>
        </transition-group>
      </div>
    </div>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
export default {
  name: 'tabNav',
  data() {
    return {
      transitionShow: true, //当页面为403 或 defaultPage 隐藏tba
      allwidthCom: 0,
      showTool: false,
      left: 0,
      top: 0,
      translateX: 0,
      withComput: {
        tabnavBoxWidth: 0,
        allwidth: 0
      }
    }
  },
  computed: {
    ...mapGetters([
      'tabnavBox'
    ])
  },
  watch: {
    tabnavBox(val, oldVal) {
      console.log(this.tabnavBox, 'tabnav')
      this.calcWidth()
    },
    '$route.path': function(val) {
      if (val === '/403' || val === '/defaultPage') {
        this.transitionShow = false
      } else {
        this.transitionShow = true
      }
    }
  },
  mounted() {
    setTimeout(() => {
      this.calcWidth()
      window.addEventListener('resize', () => {
        this.calcWidth()
      })
    }, 300)//确保刷新时获取到tabs长度
  },
  methods: {
    openPath() {
      this.$store.dispatch('isChildren',
        {
          'path': this.$route.path,
          'state': false
        })
    },
    clickLeft() {
      this.translateX = 0
    },
    clickRight() {
      this.translateX = this.$refs.tabnavBox.$el.clientWidth - this.allwidthCom
    },
    calcWidth() {
      this.allwidthCom = 0
      //  setTimeout(()=>{
      if (this.$refs.tabnavBox.children === 'undefined') {
        return
      }
      this.$nextTick(() => {
        this.$refs.tabnavBox.children.forEach(element => {
          this.allwidthCom += element.elm.clientWidth + 5
        })
        if (this.allwidthCom > this.$refs.tabnavBox.$el.clientWidth) {
          this.clickRight()
          this.showTool = true
        } else {
          this.translateX = 0
          this.showTool = false
        }
      })
      //  },200)
    },
    openMenu(item, e, index) {
      if (index === 0) {
        return false
      }
      this.left = e.clientX + 10
      this.top = e.clientY
      this.$store.dispatch('openMenu', item)
    },
    removeTab(tabItem) {
      this.$store.dispatch('removeTab', { tabItem, fullPath: this.$route.path, router: this.$router })
      // this.calcWidth();
    },
    removeOtherTab(tabItem) {
      this.$store.dispatch('removeOtherTab', { tabItem, router: this.$router })
    },
    removeAllTab() {
      this.$store.dispatch('removeOtherTab', { all: true, router: this.$router })
    }
  }
}
</script>
<style>
.tabnav {
  display: inline-block;
  border-radius: 4px 4px 0 0;
}
</style>
<style lang="scss">
  @import "@/assets/stylus/main.scss";
$top: top;
$bottom: bottom;
$left: left;
$right: right;
$leftright: ($left, $right);

%w100 {
  width: 100%;
}

%h100 {
  height: 100%;
}

%cursor {
  cursor: pointer;
}
@mixin set-value($side, $value) {
  @each $prop in $leftright {
    #{$side}-#{$prop}: $value;
  }
}
.tabnavBox {
  .is-arrow{
     padding: 0 20px;
  }
  .wrap{
    position: relative;
    .ul-wrap{
      overflow: hidden;
    }
    .el-tabs__nav-prev{
      cursor: pointer;
      position: absolute;
      top: 0;
      left: 0;
      font-size: 16px;
      line-height: 32px;
      color: $--gl-blue;
    }
    .el-tabs__nav-next{
      cursor: pointer;
      position: absolute;
      top: 0;
      right: 0;
      font-size: 16px;
      line-height: 32px;
      color: $--gl-blue;
    }

  }
  @extend %w100;
  overflow: hidden;
  ul {
    display: flex;
    justify-content: flex-start;
    flex-wrap: nowrap;
    white-space: nowrap;
    transition: transform 0.3s;
    position: relative;
    z-index: 100;
    li {
      min-width: 88px;
      padding: 0 24px;
      height: 32px;
      line-height: 32px;
      font-size: 14px;
      text-align: center;
      @extend %cursor;
      flex-shrink: 0;
      margin-#{$right}: 5px;
      // background: rgba(13, 108, 162, 0.2);
      // border-radius: 4px 4px 0 0;
      background: rgba(255,255,255,0.6);
      border-radius: 8px 8px 0 0;
      overflow: hidden;
      a {
        @include set-value(padding-left, 13px);
        display: inline-block;
        @extend %h100;
        font-size: 14px;
        color: #666666;
      }
      &:nth-child(n + 2) {
        a {
          padding-#{$right}: 0;
        }
      }
      i {
        color: $--gl-blue;
        margin-left: 4px;
        @extend %cursor;
        &:hover {
          color: red;
        }
      }
    }
    li.active {
      background: #ffffff;
      a {
        color: $--gl-blue;
      }
    }
  }
}
</style>
