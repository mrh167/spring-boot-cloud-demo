<template>
  <div class="user-profile">
    <div class="header">
      Hi，上午好！本月您已连续登陆<span style="color:#3C6EF0;">{{ userInfo.lastAccessCount }}</span>天、累计登陆<span style="color:#3C6EF0;">{{ userInfo.maccessTotal }}</span>天了。
    </div>
    <div class="content">
      <lui-row class="custom-row">
        <lui-col :span="4"><img src="../../../assets/img/jd.png" style="width:65px;height: 65px"></lui-col>
        <lui-col :span="8">
          <div>
            <div class="title">账户信息</div>
            <lui-form 
              label-position="left"
              label-width="84px">
              <lui-form-item label="用户名：">
                <span>{{ userInfo.pin }}</span>
              </lui-form-item>
              <lui-form-item label="公司名称：">
                <span>{{ userInfo.sellerName }}</span>
              </lui-form-item>
              <div 
                v-for="(item,index) in userInfo.bwValidContractCos"
                :key="index">
                <lui-form-item label="合同信息：">
                  <span>{{ item.contractTypeCode }}</span>
                </lui-form-item>
                <lui-form-item label="合同状态：">
                  <span>{{ item.contractStatusCode }}</span>
                </lui-form-item>
                <lui-form-item label="到期日期：">
                  <span style="color: #E1251B">{{ item.contractEndDate }}</span>
                  <a 
                    v-if="index == 0"
                    style="color:#3C6EF0;cursor:pointer;margin-left:10px"
                    href="https://lop.jd.com/"
                    target="_blank">续约</a>
                </lui-form-item>
              </div>
            </lui-form>
          </div>
        </lui-col>
        <lui-col :span="10">
          <div class="contact-info">
            <!-- <div>联系手机：+86- <img src="../../../assets/img/icon-edit.png"></div>
            <div>联系邮箱：-<img src="../../../assets/img/icon-edit.png"></div> -->
            <lui-form 
              label-position="left"
              label-width="84px"
              :model="userInfo"
              :rules="rules">
              <lui-form-item label="联系手机：">
                <lui-input 
                  v-if="editPhone"
                  v-model.trim="userInfo.phone"
                  prop="phone"
                  maxlength="11">
                </lui-input>
                <div v-else>
                  <span>{{ userInfo.phone ? userInfo.phone : '--' }}</span>
                  <img src="../../../assets/img/icon-edit.png" @click="editPhone = true">
                </div>
              </lui-form-item>
              <lui-form-item label="联系邮箱：">
                <lui-input
                  v-if="editEmail"
                  v-model.trim="userInfo.email"
                  prop="email">
                </lui-input>
                <div v-else>
                  <span>{{ userInfo.email ? userInfo.email : '--' }}</span>
                  <img src="../../../assets/img/icon-edit.png" @click="editEmail = true">
                </div>
              </lui-form-item>
              <div v-if=" editEmail || editPhone " style="text-align:right">
                <lui-button type="default" @click="editPhone = false; editEmail = false">取消</lui-button>
                <lui-button type="primary" @click="postEditPhoneAndEmail">保存</lui-button>
              </div>
            </lui-form>
          </div>
        </lui-col>
      </lui-row>
      <!-- </lui-col> -->
    </div>
    <!-- </lui-col> -->
    <!-- </lui-row> -->
  </div>
  <!-- </div> -->
</template>

<script>
import Api from '@/api'
export default {
  name: 'UserProfile',
  props: {
    // cities: Object
  },
  data() {
    return {
      userInfo: {
        phone: '',
        email: ''
      },
      editPhone: false,
      editEmail: false,
      rules: {
        phone: [
          { required: true, message: '请输入手机号', trigger: 'blur' }
        ],
        email: [
          { required: true, message: '请输入邮箱', trigger: 'blur' }
        ]
      }
    }
  },
  mounted() {
    this.getUserStat()
  },
  methods: {
    getUserStat() {
      Api.Home.getUserStat('').then(res => {
        this.userInfo = res.data
      }).catch(e => {
        console.error(e)
      })
    },
    postEditPhoneAndEmail() {
      Api.Home.postEditPhoneAndEmail({ id: this.userInfo.id, phone: this.userInfo.phone, email: this.userInfo.email }).then(res => {
        if (res.success) {
          this.editPhone = false
          this.editEmail = false
          this.$message({
            showClose: true,
            message: '提交成功',
            type: 'success'
          })
        }
      }).catch(e => {
        console.error(e)
        this.$message.error(e)
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.user-profile {
  padding-top: 20px;
  background: #fff;
  min-height: 600px;
  .header {
    padding-left: 20px;
    font-size: 18px;
  }
  .custom-row {
    .lui-col{
      height: 150px;
    }
    .lui-form-item {
      margin-bottom: 0;
    }
    margin-top: 50px;
    display: flex;
    align-items: center;
    .title {
      color: #333;
      font-size: 18px;
    }
    .lui-col:nth-of-type(1) {
      text-align: center;
    }
    .lui-col:nth-of-type(2) {
      border-right: 1px solid #ccc;
    }
    .contact-info {
      padding-left: 100px;
      div {
        margin-bottom: 12px;
        font-size: 14px;
        line-height: 32px;
      }
      img {
        cursor: pointer;
        margin-left: 10px;
      }
    }
  }
}
</style>
