<template>
  <div class="bookmark-wrap">
    <div
      class="bookmark"
      @click="showBookmark()">
      <div>
        <i class="iconfont iconxihuan"></i>
        <p>收藏夹配置</p>
      </div>
    </div>
    <div class="line"></div>
    <div class="menu-list-wrap">
      <div style="position: relative;" :class="{'is-arrow':showTool}">
        <span
          v-show="showTool"
          class="el-tabs__nav-prev"
          style="z-index: 1000;"
          @click="clickLeft()"><i class="lui-icon-arrow-left"></i></span>
        <span
          v-show="showTool"
          class="el-tabs__nav-next"
          style="z-index: 1000;"
          @click="clickRight()"><i class="lui-icon-arrow-right"></i></span>
        <div class="menu-list-box">
          <div ref="tabnavBox" class="menu-list" :style=" {transform: 'translateX('+translateX+'px)'}">
            <span
              v-for="(item,index) in menuList"
              :key="item.path +index"
              class="menu-item"
              @click="goPage(item)">{{ item.label }}</span>
          </div>
        </div>
      </div>
    </div>
    <lui-dialog
      title="收藏夹配置"
      custom-class="custom-bookmark-dialog"
      :append-to-body="true"
      :close-on-click-modal="false"
      :visible.sync="dialogVisible"
      width="650px">
      <div class="dialog-div">
        <div class="left">
          <p>待选择</p>
          <div style="overflow-y: auto;height: 380px;padding: 12px;margin-right:2px;">
            <lui-tree
              :data="firstMenuList"
              node-key="code"
              default-expand-all
              :props="defaultProps"
              :expand-on-click-node="false">
              <span
                slot-scope="{ node, data }"
                class="custom-tree-node">
                <span>{{ node.label }}</span>
                <span v-if="data.show">
                  <i
                    :class="!data.checked ? 'iconfont iconshoucang-kongxin' :'iconfont iconshoucang-shixin'"
                    @click="() => select(data)">
                  </i>
                </span>
              </span>
            </lui-tree>
          </div>
        </div>
        <div class="right">
          <p><span style="float:left">已收藏</span><span style="float:right">{{ list.length }}/10</span></p>
          <div style="height: 380px;padding: 0 20px;">
            <span
              v-for="(tag,index) in list"
              :key="index"
              class="tsgSpan"> {{ tag.label }} <i
                class="lui-icon-close"
                @click="handleClose(tag)"></i></span>
          </div>
        </div>
      </div>
      <span
        slot="footer"
        class="dialog-footer">
        <lui-button @click="dialogVisible = false">取 消</lui-button>
        <lui-button
          type="primary"
          :loading="loading"
          @click="postAddFavorites"> {{ loading ? '提交中...' : '确 定' }}</lui-button>
      </span>
    </lui-dialog>
  </div>
</template>

<script>
import Api from '@/api'
import { mapGetters } from 'vuex'

export default {
  components: {
  },
  data() {
    return {
      loading: false,
      showTool: false,
      translateX: 0,
      allwidthCom: 0,
      dialogVisible: false,
      menuList: [],
      firstMenuList: [],
      defaultProps: {
        children: 'children',
        label: 'label'
      },
      list: [],
      arrs: []
    }
  },
  computed: {
    ...mapGetters(['getIsBookmark'])
  },
  watch: {
    menuList(val, oldVal) {
      this.calcWidth()
    }
  },
  mounted() {
    this.getFavorites()
    this.$nextTick(() => {
      this.calcWidth()
      window.addEventListener('resize', () => {
        this.calcWidth()
      })
    })
  },
  methods: {
    recursion(arr) {
      for (let i = 0; i < arr.length; i++) {
        this.arrs.push(arr[i])
        if (arr[i].children && arr[i].children.length > 0) {
          this.recursion(arr[i].children)
        }
      }
    },
    goPage(page) {
      this.$router.push(page.path)
      this.$store.dispatch(
        'isChildren',
        {
          'path': this.$route.path,
          'state': false
        })
    },
    clickLeft() {
      this.translateX = 0
    },
    clickRight() {
      this.translateX = this.$refs.tabnavBox.clientWidth - this.allwidthCom - 30
    },
    calcWidth() {
      this.allwidthCom = 0
      if (this.$refs.tabnavBox.children === 'undefined') {
        return
      }
      this.$nextTick(() => {
        this.$refs.tabnavBox.children.forEach(element => {
          this.allwidthCom += element.clientWidth + 30
        })
        if (this.allwidthCom > this.$refs.tabnavBox.clientWidth) {
          this.clickRight()
          this.showTool = true
        } else {
          this.translateX = 0
          this.showTool = false
        }
      })
    },
    //打开收藏夹
    showBookmark() {
      this.firstMenuList = JSON.parse(sessionStorage.getItem('PublicPage')).menuList
      this.dialogVisible = true
      this.getFavorites()
    },
    //获取收藏列表
    getFavorites() {
      Api.Home.getFavorites().then((res) => {
        this.list = res.data
        this.menuList = JSON.parse(JSON.stringify(this.list))
        this.setNull(this.firstMenuList)
        this.list.forEach(el => {
          this.changeChecked(el.code, this.firstMenuList, true)
        })
      }).catch((e) => {
        console.log(e)
      })
    },
    //添加收藏
    postAddFavorites() {
      this.loading = true
      this.list.forEach(item => {
        item.icon = ''
      })
      Api.Home.postAddFavorites(this.list).then((res) => {
        if (res.success) {
          this.menuList = this.list
          this.dialogVisible = false
          this.$showSuccessMsg('提交成功')
        } else {
          this.$showErrorMsg('提交失败，请稍后重试')
        }
        this.loading = false
      }).catch((e) => {
        console.log(e)
        this.loading = false
      })
    },
    //清空已选中
    setNull(items) {
      for (var i in items) {
        const item = items[i]
        item.checked = false
        if (item.children) {
          this.setNull(item.children)
        }
      }
    },
    //修改收藏夹状态
    changeChecked(code, items, status) {
      for (var i in items) {
        const item = items[i]
        if (item.code === code) {
          item.checked = status
          break
        } else if (item.children) {
          this.changeChecked(code, item.children, status)
        }
      }
    },
    handleClose(tag) {
      this.list.splice(this.list.indexOf(tag), 1)
      this.changeChecked(tag.code, this.firstMenuList, false)
    },
    //选中取消收藏夹
    select(data) {
      if (!data.checked && this.list.length === 10) {
        this.$showWarningMsg('最多收藏10条')
        return
      }
      data.checked = !data.checked
      if (data.checked && this.list.indexOf(data) === -1) {
        this.list.push(data)
      } else {
        const index = this.list.findIndex(item => item.code === data.code)
        this.list.splice(index, 1)
      }
    }
  }
}
</script>
<style lang="scss">
@import "@/assets/stylus/main";
.custom-bookmark-dialog {

  .lui-dialog__body {
    padding: 20px;
  }
  .dialog-div {
    height: 430px;
    .custom-tree-node {
      .iconfont {
        margin-left: 5px;
      }
      .iconshoucang-shixin {
        color: $--gl-blue;
      }
    }
  }
  .left {
    height: 430px;
    float: left;
    width: 66%;
    overflow: hidden;
    border: 1px #e6e6e6 solid;
    border-radius: 4px;
    p {
      background: #fafafa;
      border-bottom: 1px solid #d9d9d9;
      height: 30px;
      line-height: 30px;
      padding: 0 24px;
    }
  }
  .right {
    width: 31%;
    height: 430px;
    min-width: 90px;
    float: right;
    border: 1px #e6e6e6 solid;
    border-radius: 4px;
    p {
      min-width: 160px;
      background: #fafafa;
      border-bottom: 1px solid #d9d9d9;
      height: 30px;
      line-height: 30px;
      padding: 0 24px;
    }
    .tsgSpan:nth-child(1) {
      margin-top: 12px;
    }
    .tsgSpan {
      padding: 5px 30px 5px 8px;
      font-size: 13px;
      display: block;
      border-radius: 4px;
      margin-bottom: 7px;
      border: 1px solid #999;
      color: #999;
      position: relative;
      i {
        position: absolute;
        top: 8px;
        right: 5px;
        color: #999;
        &:hover {
          position: absolute;
          top: 7px;
          right: 5px;
          border: 1px solid red;
          border-radius: 50%;
          background: red;
          padding: 1px;
          color: #ffffff !important;
        }
      }
      &:hover {
        cursor: pointer;
        color: $--gl-blue;
        border: 1px solid $--gl-blue;
        i {
          color: #999;
        }
      }
    }
  }
}
</style>
<style lang="scss" scoped>
@import '@/assets/stylus/main';
.bookmark-wrap {
  height: 50px;
  min-width: 1200px;
  background: #3C3F4D;
  display: flex;
  box-shadow: 0 2px 8px 0 rgba(0, 0, 0, 0.3);
  .bookmark {
    // background: #3C3F4D;
    cursor: pointer;
    width: 64px;
    display: flex;
    text-align: center;
    justify-content: center;
    align-items: center;
    p {
      margin-top: -3px;
      font-size: 12px;
      transform: scale(0.88);
      color: rgba(255,255,255,0.8);
    }
    i{
      color: rgba(255,255,255,0.8);
      font-size: 20px;
    }
    &:hover p {
      transition: all 0.6s;
      color: #FFFFFF;
    }
    &:hover i {
      transition: all 0.6s;
      color: #FFFFFF;
    }
  }
  .line {
    width: 1px;
    height: 20px;
    background: rgba(255,255,255,0.8);
    box-shadow: 0 5px 14px 0 rgba(0, 0, 0, 0.12);
    margin: 15px 0;
  }
  .menu-list-wrap{
    position: relative;
    width: calc(100% - 64px);
    overflow: hidden;
    .is-arrow{
     padding: 0 20px;
    }
    .el-tabs__nav-prev{
      cursor: pointer;
      position: absolute;
      top: 0;
      left: 0;
      font-size: 16px;
      line-height: 50px;
      color: $--gl-blue;
    }
    .el-tabs__nav-next{
      cursor: pointer;
      position: absolute;
      top: 0;
      right: 0;
      font-size: 16px;
      line-height: 50px;
      color: $--gl-blue;
    }
    .menu-list-box{
      overflow: hidden;
      background: #3C3F4D;
    }
  }
  .menu-list {
    display: flex;
    align-items: center;
    line-height: 50px;
  }
  .menu-item {
    cursor: pointer;
    margin-left: 30px;
    white-space: nowrap;
    font-size: 14px;
    color: rgba(255,255,255,0.8);
    &:hover {
      // transition: all 0.6s;
       color: rgba(255,255,255,1);
    }
  }
}
</style>
