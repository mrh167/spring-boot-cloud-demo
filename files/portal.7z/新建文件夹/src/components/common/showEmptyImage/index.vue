<template>
  <div class="table-date">
    <img src="@/assets/img/tableBanner.png" alt="">
  </div>
</template>

<script>
export default {
  name: 'index'
}
</script>

<style scoped lang="scss">
.table-date{
  width: 100%;
  img{
    margin: 80px auto;
  }
}
</style>
