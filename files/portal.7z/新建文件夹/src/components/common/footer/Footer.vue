<template>
  <div class="footer-container">
    <div class="middle-container footer-item-container">
      <div class="footer-logo hidden-xs-only">
        <img src="@/assets/img/logo_jd.png" alt="">
      </div>
      <div class="footer-center">
        <div class="footer-center-first">
          <ul>
            <li class="hidden-xs-only" @click="about">关于我们</li>
            <li class="hidden-xs-only" @click="HelpCenter">帮助中心
            </li>
            <li class="hidden-xs-only" @click="product">使用产品
            </li>
            <li class="hidden-xs-only" @click="Privacy">隐私协议
            </li>
            <li class="hidden-xs-only">
              <a href="//www.jd.com/" target="_blank">京东商城</a>
            </li>
            <li v-if="getVscSellerType!==1 && getVscSellerType !== 2" class="hidden-xs-only">诸葛智享</li>
          </ul>
        </div>
        <div v-if="getVscSellerType===1 || getVscSellerType === 2" class="footer-center-second hidden-xs-only">
          <p>©2004 - 2020 京东物流 版权所有 增值电信业务经营许可证： 京ICP备17005970号-1</p>
          <p><a href="http://www.beian.gov.cn/portal/registerSystemInfo?recordcode=11011502003298" target="_blank"> 京公网安备 11011502003298号</a></p>
        </div>
        <div v-else class="footer-center-second hidden-xs-only">
          <p>©2004 - 2020 京东物流 版权所有 增值电信业务经营许可证： 京ICP备17005970号-1<a href="http://www.beian.gov.cn/portal/registerSystemInfo?recordcode=11011502003298" target="_blank"> 京公网安备 11011502003298号</a></p>
          <p class="only-p">本站技术服务由<span @click="spanClick">诸葛智享</span>提供</p>
        </div>
      </div>
      <div v-if="getVscSellerType===1 || getVscSellerType === 2" class="footer-right">
        <a href="tel:950616" class="hidden-sm-and-up">
          <img src="https://www.jdwl.com/img/phone.0179ab4e.png" alt="" class="phone" style="vertical-align: top;">
        </a>
        <div class="hidden-xs-only">
          <img src="@/assets/img/QrCode.png" alt="" class="code1">
          <div><span>供应链交流<span style="color: #000;font-weight: 700;padding: 0 1px;">QQ</span>群</span></div>
        </div>
      </div>
      <div v-else class="footer-right">
        <div class="hidden-xs-only">
          <img src="@/assets/img/jh_code.png" alt="" class="code1">
          <div><span>产品服务1群</span></div>
        </div>
        <div class="hidden-xs-only">
          <img src="@/assets/img/zhuge.png" alt="" class="code1">
          <div><span>产品服务2群</span></div>
        </div>
      </div>

    </div>
  </div>
</template>
<style lang="scss" rel="stylesheet/scss">
  @import "./footer.scss";
</style>
<script type="text/babel">
import { mapGetters } from 'vuex'
export default {
  name: 'LayoutFooter',
  props: {
    isCollapse: {
      type: Boolean,
      default() {
        return false
      }
    }
  },
  computed: {
    ...mapGetters(['getVscSellerType']) //判断是否是诸葛
  },
  mounted() {
    
  },
  methods: {
    //关于我们
    about() {
      // this.$router.push({ 'path': '/about' })
    },
    HelpCenter() {
      this.$router.push({ 'path': '/helpsearch' })
    },
    // 使用产品
    product() {
      const menuList = sessionStorage.getItem('PublicPage') ? JSON.parse(sessionStorage.getItem('PublicPage')) : ''
      this.$router.push({ path: menuList.path })
    },
    //隐私服务------打开新窗口
    Privacy() {},
    spanClick() {
      window.open('//ysc.jd.com', '_blank')
    }
  }
}
</script>
