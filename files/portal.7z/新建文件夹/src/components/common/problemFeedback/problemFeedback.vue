<template>
  <div class="backtop">
    <div
      v-show="backTopShow"
      v-cloak
      class="item top"
      @click="backToTop">
      <i class="iconfont iconfanhuidingbu"></i>
    </div>
    <div class="item center">
      <img src="@/assets/img/feedback.png">
      <div
        class="feedback"
        @click="openFeedback">问题反馈</div>
    </div>
    <div class="item bottom">
      <img src="@/assets/img/contact-us.png">
      <div class="contact-us">
        <p>联系我们</p>
        <div>
          <div class="title">QQ群</div>
          <div>1039822239</div>
        </div>
        <div>
          <div class="title">邮箱</div>
          <div>jdjinghui@jd.com</div>
        </div>
      </div>
    </div>
    <lui-dialog
      title="问题反馈"
      custom-class="custom-problemfeedback-dialog"
      :append-to-body="true"
      :close-on-click-modal="false"
      :visible.sync="dialogVisible"
      width="650px">
      <div style="padding-bottom:22px">
        我们十分抱歉，给您带来了不佳的体验，恳请您反馈问题，帮助我们改善，谢谢。
      </div>
      <lui-form
        ref="problemFeedback"
        label-position="left"
        :model="problemFeedback"
        :rules="rules"
        label-width="100px">
        <lui-form-item
          label="问题位置："
          prop="position">
          <lui-input v-model="problemFeedback.position" disabled>
            <template slot="prepend">当前菜单位置</template>
          </lui-input>
        </lui-form-item>
        <lui-form-item
          label="您的问题："
          prop="problem">
          <lui-input
            v-model.trim="problemFeedback.problem"
            type="textarea"
            rows="5"
            placeholder="请输入您的问题"
            maxlength="200"
            show-word-limit></lui-input>
        </lui-form-item>
        <lui-form-item
          label="联系方式："
          prop="phone">
          <lui-row class="custom-problem-row">
            <lui-col
              :span="8"
              style="float: left;">
              <lui-input
                v-model.trim="problemFeedback.phone"
                maxlength="11"
                placeholder="请输入您的电话"><template slot="prepend">电话</template></lui-input>
            </lui-col>
            或
            <lui-col
              :span="15"
              style="float: right;">
              <lui-input
                v-model.trim="problemFeedback.email"
                placeholder="请输入您的邮箱"><template slot="prepend">邮箱</template></lui-input>
            </lui-col>
          </lui-row>
        </lui-form-item>
      </lui-form>
      <span
        slot="footer"
        class="dialog-footer">
        <lui-button @click="dialogVisible = false">取 消</lui-button>
        <lui-button
          type="primary"
          @click="postAddFeedback">确 定</lui-button>
      </span>
    </lui-dialog>
  </div>
</template>

<script>
import Api from '@/api'
import echarts from 'echarts'
import utils from '@/utils/utils'
export default {
  name: 'AbnormalAlarm',
  // props: ['showAbnormalAlarm'],
  data() {
    var checkPhoneEmail = (rule, value, callback) => {
      if (!this.problemFeedback.phone && !this.problemFeedback.email) {
        callback(new Error('请输手机号或邮箱'))
      } else if (!this.problemFeedback.phone && this.problemFeedback.email) {
        if (!this.checkEmail(this.problemFeedback.email)) {
          callback(new Error('请输正确的邮箱'))
        }
      }
      callback()
    }
    return {
      problemFeedback: {
        problem: '',
        position: '',
        phone: '',
        email: ''
      },
      rules: {
        problem: [
          { required: true, message: '请输入问题内容', trigger: 'blur' }
        ],
        position: [
          { required: true, message: '请输入问题位置', trigger: 'blur' }
        ],
        phone: [
          { required: true, validator: checkPhoneEmail, trigger: 'blur' },
          { pattern: /^1[3456789]\d{9}$/, message: '请输入正确的手机号', trigger: 'blur' }
        ]
      }
    }
  },
  mounted() {
  
  },
  methods: {
    calcHeight() {
      const box = document.getElementsByClassName('main-wrapper')[0]
      box.addEventListener('scroll', this.backTopShowOperate, true)
    },
    openFeedback() {
      this.problemFeedback.position = this.$route.meta.position
      this.problemFeedback.problem = ''
      this.problemFeedback.email = ''
      this.problemFeedback.phone = ''
      this.dialogVisible = true
      this.$nextTick(() => {
        this.$refs.problemFeedback.clearValidate()
      })
    },
    //回到顶部
    backTopShowOperate: function() {
      if (document.getElementsByClassName('main-wrapper')[0].scrollTop > this.showPx) {
        this.backTopShow = true
      } else {
        this.backTopShow = false
      }
    },
    backToTop: function() {
      document.body.scrollTop = 0
      var step = document.getElementsByClassName('main-wrapper')[0].scrollTop / this.backSeconds
      var backTopInterval = setInterval(function() {
        if (document.getElementsByClassName('main-wrapper')[0].scrollTop > 0) {
          document.getElementsByClassName('main-wrapper')[0].scrollTop -= step
        } else {
          clearInterval(backTopInterval)
        }
      }, 1)
    },
    checkEmail(email) {
      var pattern = /^[a-zA-Z0-9_.-]+@[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)*\.[a-zA-Z0-9]{2,6}$/
      if (email) {
        if (!pattern.test(email)) {
          return false
        }
        return true
      }
    },
    //问题反馈
    postAddFeedback() {
      this.$refs['problemFeedback'].validate((valid) => {
        if (valid) {
          Api.Home.postAddFeedback({
            'contacts': '',
            'content': this.problemFeedback.problem,
            'email': this.problemFeedback.email,
            'location': this.problemFeedback.position,
            'phone': this.problemFeedback.phone,
            'position': 2
          }).then(res => {
            this.dialogVisible = false
            this.$message({
              showClose: true,
              message: '提交成功',
              type: 'success'
            })
          }).catch(e => {
            this.$message.error(e)
          })
        }
      })
    }
  }
}
</script>

<style lang="scss" scoped>
@import '@/assets/stylus/main';
.e-chart {
  height: 100%;
  .wrap {
    float: left;
    width: 60%;
    height: 100%;
    .p1 {
      font-size: 12px;
      color: #333333;
      margin: 20px 0px 10px 15px;
    }
    .p2 {
      font-size: 20px;
      color: #333;
      margin-left: 15px;
        &:hover{
          color: $--gl-blue;
          cursor: pointer;
        }
      span {
        margin-left: 5px;
        font-size: 12px;
        color: #666666;
      }
    }
    .p3 {
      margin-left: 15px;
      font-size: 12px;
      color: #666666;
      .lui-icon-help {
        margin-left: 5px;
        cursor: pointer;
      }
    }
  }
  .details-wrap {
    float: left;
    padding: 20px 12px 0;
    width: 40%;
    height: 100%;
    border-left: 1px solid #e6e6e6;
  }
  .details {
    height: 88px;
    display: flex;
    box-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.1);
    border-radius: 4px;
    margin-bottom: 12px;
    .title {
      width: 135px;
      padding: 12px;
      .p1 {
        width: 108px;
      }
      .p2 {
        font-size: 20px;
        color: #333333;
         &:hover{
          color: $--gl-blue;
          cursor: pointer;
        }
        span {
          margin-left: 5px;
          font-size: 12px;
          color: #666666;
        }
      }
      p {
        font-size: 12px;
        color: #666666;
        i {
          margin-left: 5px;
          cursor: pointer;
        }
        span {
          font-size: 20px;
          color: #333333;
        }
      }
    }
  }
}
</style>
