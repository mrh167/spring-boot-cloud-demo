<template>
  <div class="container">
    <div class="information-nav">
      <!-- 查询条件 -->
      <Search
        :table-search="tableSearch"
        @handleSearch="searchClick"
        @handleQueryUnit="handleQueryUnit">
      </Search>
    </div>
    <div class="container-content">
      <!-- 按钮 -->
      <ButtonList
        :buttons="buttons"
        :configdept-no="deptNo.split('&')[0]"
        :configdept-name="deptNo.split('&')[1]"
        :check-dept-no="checkDeptNo"
        :table-button="tableButton"
        @handelClick="handelClick"
        @uploadSuccess="getList"></ButtonList>
      <!-- 表格列表 -->
      <flight-table
        :loading-show="loadingShow"
        :table-data="tableData"
        :columns="columns"
        :page-size="pageSize"
        :page-num="pageNum"
        @handleSelectionChange="handleSelectionChange"
        @handleEdit="handleEdit" />
      <!-- 翻页 -->
      <pagination
        :page-sizes="pageSizes"
        :total="total"
        :page-size="pageSize"
        @handleSizeChange="handleSizeChange"
        @handleCurrentChange="handleCurrentChange" />
    </div>
    <!-- 新增 -->
    <lui-dialog
      v-if="dialogVisible"
      :visible.sync="dialogVisible"
      width="40%"
      top="10vh"
      :close-on-click-modal="false"
      :title="dialogTitle">
      <lui-form
        ref="ruleForm"
        :model="ruleForm"
        :rules="rules"
        label-width="140px"
        class="demo-ruleForm">
        <div class="ruleForm-title">
          <lui-row>
            <lui-col :span="24">
              <lui-form-item
                label="VSC商家类型编码"
                prop="domain">
                <lui-input
                  v-model.trim="ruleForm.domain"
                  show-word-limit
                  :disabled="detailsShow"
                  onkeyup="value=value.replace(/[^a-zA-Z0-9-_.:]+/g,'')"
                  placeholder="请输入VSC商家类型编码">
                </lui-input>
              </lui-form-item>
            </lui-col>
          </lui-row>
          <lui-row>
            <lui-col :span="24">
              <lui-form-item
                label="VSC商家类型"
                prop="domain1">
                <lui-input
                  v-model.trim="ruleForm.domain"
                  show-word-limit
                  :disabled="editShow"
                  onkeyup="value=value.replace(/[^a-zA-Z0-9-_.:]+/g,'')"
                  placeholder="请输入VSC商家类型">
                </lui-input>
              </lui-form-item>
            </lui-col>
          </lui-row>
        </div>
      </lui-form>
      <!-- 页脚按钮 -->
      <span slot="footer" class="dialog-footer">
        <lui-button @click="dialogVisible=false">取 消</lui-button>
        <lui-button v-if="!details" type="primary" :loading="loadingButton" @click="submitForm('ruleForm')">确 定</lui-button>
      </span>
    </lui-dialog>
  </div>
</template>

<script>
import flightTable from '@/components/common/table'
import Search from '@/components/common/search'
import http from '@/lib/http'
import pagination from '@/components/common/pagination'

import ButtonList from '@/components/common/button'
const buttons = {
  upload: {
    noAsync: true,
    maxM: 10,
    uploadtips: '只能上传xlsx文件，文件大小不超过10M',
    label: '批量解绑',
    uploadConfig: {
      uploadActionUrl: http.baseContextUrl + '上传接口地址'
    },
    templateUrl: http.baseContextUrl + '下载接口地址'
  }
}
export default {
  name: 'index',
  components: {
    Search,
    flightTable,
    ButtonList,
    pagination
  },
  data() {
    return {
      dialogVisible: false,
      dialogTitle: '新增VSC商家分类信息',
      editShow: false,
      detailsShow: false,
      details: false,
      loadingButton: false,
      buttons,
      deptNo: '',
      ruleForm: {},
      rules: {
        domain: [{ required: true, message: '请输入VSC商家类型编码', trigger: ['blur', 'change'] }],
        domain1: [{ required: true, message: '请输入VSC商家类型', trigger: ['blur', 'change'] }]
      },
      loadingShow: false,
      tableData: [{}],
      multipleSelection: [],
      pageSizes: [10, 20, 50, 100],
      total: 0,
      pageNum: 1,
      pageSize: 10,
      checkDeptNo: false, //默认false表示不上传事业部
      tableSearch: [
        {
          label: '审批业务类型',
          type: 'select',
          value: 'billTypeCode',
          children: [],
          code: 'code',
          name: 'name',
          width: '110px',
          inpWidth: 220
        },
        {
          label: '审批业务类型',
          type: 'input',
          value: 'sellerVsc',
          maxlength: 30,
          inpWidth: 220 //输入框长度
        },
        {
          label: '申请时间',
          type: 'date',
          displayType: 'daterange',
          separator: '~',
          value: 'date',
          format: 'yyyy-MM-dd', //显示类型
          valueFormat: 'yyyy-MM-dd HH:mm:ss', //输出类型
          maxlength: false,
          inpWidth: 220,
          startPlaceholder: '开始时间',
          endPlaceholder: '结束时间'
        },
        { //申请时间
          label: '申请时间',
          type: 'date',
          format: 'yyyy-MM-dd', //显示类型
          valueFormat: 'yyyy-MM-dd HH:mm:ss', //输出类型
          value: 'applicantTime',
          maxlength: false,
          inpWidth: 220,
          searchType: '2'
        },
        {
          label: '现货率',
          type: 'temperature',
          value: 'deptName',
          maxlength: 30,
          inpWidth: 220, //输入框长度
          left: {
            inpWidth: 92, //输入框长度
            placeholder: '起始',
            value: 'start',
            onkeyup: "value=value.replace(/[^\d]/g,'')"
          },
          content: {
            value: '~'
          },
          right: {
            inpWidth: 92, //输入框长度
            placeholder: '终止',
            value: 'end'
          }
        }
      ],
      tableButton: [
        {
          label: '账号申请',
          id: 'application',
          type: 'primary',
          genre: 'badge',
          value: 999,
          max: 90,
          dotType: 'danger'
        },
        {
          label: '批量下载',
          id: 'download',
          type: 'primary'
        },
        {
          label: '批量上传',
          id: 'upload',
          type: 'primary'
        },
        {
          label: '手工删除',
          type: 'primary',
          id: 'deleted'
        },
        {
          label: '手工添加',
          id: 'add',
          type: 'primary'
        }

      ],
      columns: [
        {
          id: 'selection',
          type: 'selection',
          label: '',
          fixed: 'left',
          width: '50',
          prop: '',
          align: 'center'
        },
        {
          id: 'text',
          prop: 'title',
          label: '标题',
          align: 'center',
          formatter: (row, column, cellValue) => {
            return `<span style="white-space: nowrap;color: dodgerblue;">${row.title}</span>`
          }
        },
        {
          id: 'text',
          type: 'switch',
          label: '是否VSC运营',
          prop: 'status',
          status: true,
          activeColor: '#13ce66',
          inactiveCcolor: '#ff4949',
          activeText: '开始',
          inactiveText: '结束'
        },
        {
          id: 'text',
          type: 'text',
          label: '审批业务类型',
          fixed: false,
          width: '170',
          prop: 'billTypeName',
          align: 'left'
        },
        {
          id: 'text',
          type: 'text',
          label: '工作台名称',
          fixed: false,
          width: '170',
          prop: 'tabName',
          align: 'left'
        },
        {
          id: 'text',
          type: 'text',
          label: '业务单据',
          fixed: false,
          width: '170',
          prop: 'name',
          align: 'left'
        },
        {
          id: 'text',
          type: 'text',
          label: '说明',
          fixed: false,
          width: '170',
          prop: 'description',
          align: 'left'
        },
        {
          id: 'text',
          type: 'text',
          label: '修改人',
          fixed: false,
          width: '170',
          prop: 'updateUser',
          align: 'left'
        },
        {
          id: 'text',
          type: 'text',
          label: '修改时间',
          fixed: false,
          width: '170',
          prop: 'updateTime',
          align: 'left'
        },
        {
          id: 'text',
          type: 'text',
          label: '创建时间',
          fixed: false,
          width: '170',
          prop: 'createTime',
          align: 'left'
        },
        {
          id: 'button',
          type: 'button',
          label: '操作',
          fixed: 'right',
          width: '100',
          align: 'center',
          list: [
            {
              id: 'details',
              name: '详情',
              type: 'text',
              size: ''
            },
            {
              id: 'edit',
              name: '编辑',
              type: 'text',
              size: ''
            }
          ]
        }
      ]

    }
  },
  methods: {
    //数据列表
    getList() {

    },
    // 数据操作按钮
    handelClick(item) {
      if (item.type === 'add') {
        this.dialogVisible = true
        this.editShow = false
        this.detailsShow = false
      }
      console.log(item, '===---')
    },
    //提交
    submitForm(ruleForm) {
      this.dialogVisible = false
      // this.$refs[ruleForm].validate((valid) => {
      //   if (valid) {} 
      // }) 
    },
    //表格操作子组建返回数据
    handleEdit(row) {
      switch (row.row) {
        case 'edit':
          this.dialogVisible = true
          this.editShow = false
          this.detailsShow = true
          break
      }
      console.log(row, '--===--')
    },
    //查询条件
    searchClick(val) {},
    //多选
    handleSelectionChange(val) {
      this.multipleSelection = val.val
    },
    //页码更改
    handleSizeChange(val) {
      this.pageSize = val
      this.getList()
    },
    //翻页
    handleCurrentChange(val) {
      this.pageNum = val
      this.getList()
    },
    // 表格点击
    handleClickTable(val) {},
    //class 赋值
    handleClassName(val) {},
    //表格模糊下拉
    handleQueryUnit(queryString, cb) {}
  }
}
</script>

<style lang="scss" scoped="scoped">
  .container{
    width: 100%;
    .information-nav{
      box-shadow: 2px 2px 7px 2px #ccc;
      border-radius: 0 0 4px 4px;
      width: 100%;
      background: #ffffff;
      margin-bottom: 20px;
    }
    .container-content{
      background: #fff;
      width: 100%;
      border-radius: 4px;
      box-shadow: 2px 2px 7px 2px #ccc;
      // margin-top: 20px;
      padding: 0 25px 25px 25px;
      /*border: 1px solid red;*/
    }
  }
</style>
