<template>
  <div class="transfer">
    <!-- 左侧穿梭框 -->
    <div class="transfer-panel">
      <p class="transfer-panel-header">
        <span>{{ titleTexts && titleTexts[0] }}</span>
        <span v-if="showPagination">{{ leftSelection.length }}/{{ leftTableData.length }}</span>
      </p>
      <div v-if="showQuery">
        <lui-form :inline="true" :model="leftQueryCondition" class="query-form" label-width="90px">
          <slot name="leftCondition" :scope="leftQueryCondition"></slot>
          <div style="text-align: right;display:block">
            <lui-form-item>
              <lui-button @click="resetLeftSubmit()">重置</lui-button>
              <lui-button type="primary" @click="onLeftQuerySubmit()">{{ queryTexts[0] }}</lui-button>
            </lui-form-item>
          </div>
        </lui-form>
      </div>
      <lui-table
        ref="leftTable"
        size="small"
        :max-height="maxHeight"
        :height="minHeight"
        :data="leftTableData"
        :row-key="tableRowKey"
        :row-style="handleRowStyle"
        border
        stripe
        class="transfertable"
        @row-click="handleLeftRowClick"
        @selection-change="handleLeftSelectionChange">
        <lui-table-column
          width="40px"
          type="selection"
          :selectable="handleSelectable"></lui-table-column>
        <lui-table-column
          v-for="col in leftColumns"
          :key="col.id"
          :prop="col.id"
          :label="col.label"
          :width="col.width"
          show-overflow-tooltip
        >
          <template slot-scope="scope">
            <slot :scope="{row: scope.row, col: col}">
              <span>{{ scope.row[col.id] }}</span>
            </slot>
          </template>
        </lui-table-column>
      </lui-table>
      <lui-pagination
        v-if="showPagination"
        :current-page="pageIndex"
        :page-sizes="[10, 20, 50, 100]"
        :page-size="pageSize"
        :pager-count="5"
        :total="totalSize"
        class="pagepadding"
        layout="total, sizes, prev, pager, next"
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange">
      </lui-pagination>
    </div>
    <!-- 中间穿梭按钮 -->
    <div class="transfer-buttons">
      <lui-button
        type="primary"
        :class="buttonClasses"
        :disabled="disabledLeftButton"
        @click.native="addToRight">
        <span v-if="buttonTexts[0] !== undefined" class="button-text">{{ buttonTexts[0] }}</span>
        <i class="el-icon-arrow-right"></i>
      </lui-button>
      <lui-button
        type="primary"
        :class="buttonClasses"
        :disabled="rightSelection.length === 0"
        @click.native="addToLeft">
        <i class="el-icon-arrow-left"></i>
        <span v-if="buttonTexts[1] !== undefined" class="button-text">{{ buttonTexts[1] }}</span>
      </lui-button>
    </div>
    <!-- 右侧穿梭框 -->
    <div class="transfer-panel">
      <p class="transfer-panel-header">
        <span>{{ titleTexts && titleTexts[1] }}</span>
        <span>{{ rightSelection.length }}/{{ rightTableData.length }}</span>
      </p>
      <!-- 右侧查询条件 -->
      <div v-if="showQuery">
        <lui-form :inline="true" :model="rightQueryCondition" class="query-form" label-width="90px">
          <slot name="rightCondition" :scope="rightQueryCondition"></slot>
          <div style="text-align: right;display:block">
            <lui-form-item>
              <lui-button @click="resetRightSubmit()">重置</lui-button>
              <lui-button type="primary" @click="onRightQuerySubmit()">{{ queryTexts[1] }}</lui-button>
            </lui-form-item>
          </div>
        </lui-form>
      </div>
      <lui-table
        ref="rightTable"
        size="small"
        :max-height="maxHeight"
        :height="minHeight"
        :data="rightchooseList"
        :row-key="tableRowKey"
        class="transfertable"
        border
        stripe
        @row-click="handleRightRowClick"
        @selection-change="handleRightSelectionChange">
        <lui-table-column width="40px" type="selection"></lui-table-column>
        <lui-table-column
          v-for="col in rightColumns || leftColumns"
          :key="col.id"
          :prop="col.id"
          :label="col.label"
          :width="col.width"
          show-overflow-tooltip
        >
          <template slot-scope="scope">
            <slot :scope="{row: scope.row, col: col}">
              <span>{{ scope.row[col.id] }}</span>
            </slot>
          </template>
        </lui-table-column>
      </lui-table>
      <!-- 右侧的分页 -->
      <lui-pagination
        v-if="showPagination"
        :current-page="pageIndex2"
        :page-sizes="[10, 20, 50, 100]"
        :page-size="pageSize2"
        :pager-count="5"
        :total="rightTableTotal"
        layout="slot, sizes, prev, pager, next"
        @size-change="handleSizeChange2"
        @current-change="handleCurrentChange2"
      >
        <span class="lui-pagination__total">共 {{ rightTableTotal }} 条</span>
      </lui-pagination>
    </div>
  </div>
</template>

<script>
export default {
  name: 'EltTransfer',
  props: {
    //右侧全量数据
    value: {
      type: Array,
      default() {
        return []
      }
    },
    //左侧全量
    leftTableDataList: {
      type: Array,
      default() {
        return []
      }
    },
    // 显示条件查询
    showQuery: {
      type: Boolean,
      default: false
    },
    // 显示分页
    showPagination: {
      type: Boolean,
      default: false
    },
    // 左侧分页回调
    paginationCallBack: {
      type: Function,
      default: function() {
        return new Promise((resolve, reject) => {
          try {
            resolve({ total: 0, data: null })
          } catch {
            reject()
          }
        })
      }
    },
    // 右侧分页回调
    paginationCallBack2: {
      type: Function,
      default: function() {
        return new Promise((resolve, reject) => {
          try {
            resolve({ total: 0, data: null })
          } catch {
            reject()
          }
        })
      }
    },
    // 标题文本
    titleTexts: {
      type: Array,
      default() {
        return ['待选项', '已选项']
      }
    },
    // 按钮文本
    buttonTexts: {
      type: Array,
      default() {
        return []
      }
    },
    // 查询按钮文本
    queryTexts: {
      type: Array,
      default() {
        return ['查询', '筛选']
      }
    },
    // 左侧参数
    leftColumns: {
      type: Array,
      default() {
        return []
      }
    },
    // 右侧参数
    rightColumns: {
      type: Array,
      default() {
        return undefined
      }
    },
    // 表格最小高度
    minHeight: {
      type: String,
      default: '300px'
    },
    // 表格最大高度
    maxHeight: {
      type: String,
      default: '500px'
    },
    // 表格行数据的Key
    tableRowKey: {
      type: Function,
      default(row) {
        return row && row.id
      }
    }
  },
  data() {
    return {
      leftTableData: this.leftTableDataList || [], //左侧的全量数据
      rightTableData: this.value || [], //右侧的全量数据
      pageIndex: 1, // 左侧分页
      pageIndex2: 1, //右侧分页
      pageSize: 10,
      pageSize2: 10,
      totalSize: 0,
      totalSize2: 0,
      leftSelection: [],
      rightSelection: [],
      leftQueryCondition: {},
      rightQueryCondition: {},
      rightConditionTemp: undefined,
      rightchooseList: this.value || [],
      rightTableTotal: 0
    }
  },
  computed: {
    hasButtonTexts() {
      return this.buttonTexts.length === 2
    },
    buttonClasses() {
      return ['transfer-button', { 'is-with-texts': this.hasButtonTexts }]
    },
    disabledLeftButton() {
      return !this.leftSelection.some(leftRow => !this.rightTableData.some(rightRow => this.checkObjectIsEqual(leftRow, rightRow)))
    },
    calcRightTableData() {
      // const conditionKeys = Object.keys(this.rightConditionTemp) //拿的筛选条件的key
      // console.log(conditionKeys, '这里') //conditionKeys为sellerNo
      // return this.rightTableData.filter(data => {
      //   return conditionKeys.some(key => {
      //     const rowCellData = data[key] //sellerNO的值
      //     const condVal = this.rightConditionTemp[key].trim() //sellerNO的值
      //     console.log(rowCellData, condVal)
      //     if (rowCellData) {
      //       return String(rowCellData).indexOf(condVal) > -1
      //     }
      //     return true
      //   })
      // })
      this.rightchooseList = this.pagination(this.pageIndex2, this.pageSize2, this.rightTableData)
      return this.rightchooseList
      // return this.rightTableData
    }
  },
  created() {
    //左侧分页的方法
    this.handlePaginationCallBack({ pageIndex: 1, pageSize: 10, sellerNo: '', nodeNo: '', nodeNoOrNameKeyword: '', nodeType: 0 })
    //右侧分页的方法
    this.handlePaginationCallBack2()
  },
  mounted() {
    console.log(this.value, 'runney')
    this.rightTableTotal = this.rightTableData.length
    //console.log(this.value, this.leftTableDataList, 'this.value')
    //console.log(this.leftColumns, '234')
  },
  methods: {
    //勾选左侧数据
    handleLeftSelectionChange(selection) {
      this.leftSelection = selection
    },
    //勾选右侧数据
    handleRightSelectionChange(selection) {
      this.rightSelection = selection
    },
    //获取左侧选中数据
    handleLeftRowClick(row) {
      if (!this.rightTableData.some(rightRow => this.checkObjectIsEqual(rightRow, row))) {
        this.$refs.leftTable.toggleRowSelection(row)
      }
    },
    //获取右侧选中数据
    handleRightRowClick(row) {
      this.$refs.rightTable.toggleRowSelection(row)
    },
    handleSizeChange(val) {
      this.pageSize = val
      this.handlePaginationCallBack()
    },
    handleSizeChange2(val) {
      this.pageSize2 = val
      this.handlePaginationCallBack2()
    },
    // 获取左侧当前分页
    handleCurrentChange(val) {
      this.pageIndex = val
      this.handlePaginationCallBack()
    },
    //获取右侧当前分页
    handleCurrentChange2(val) {
      this.pageIndex2 = val
      this.handlePaginationCallBack2()

    },
    //初始化数据
    handlePaginationCallBack() {
      this.leftQueryCondition.pageIndex = this.pageIndex
      this.leftQueryCondition.pageSize = this.pageSize
      if (this.showPagination && this.paginationCallBack) {
        const condition = {
          pageIndex: this.pageIndex,
          pageSize: this.pageSize,
          sellerNo: '',
          nodeNo: '', 
          // deptNo: '',
          nodeNoOrNameKeyword: '',
          nodeType: '',
          ...this.leftQueryCondition

        }
        // console.log({ ...this.leftQueryCondition }, 8989)
        // console.log(condition, 67667)
        this.paginationCallBack.call(null, condition).then(result => {
          if (result && Array.isArray(result.data)) {
            this.leftTableData = result.data
            this.totalSize = result.total
          }
          this.$nextTick(() => {
            this.leftTableData.forEach(leftRow => {
              const isHave = this.rightTableData.some(rightRow => this.checkObjectIsEqual(rightRow, leftRow))
              this.$refs.leftTable.toggleRowSelection(leftRow, isHave)
            })
          })
        })
      }
    },
    //初始化
    handlePaginationCallBack2() {
      this.onRightQuerySubmit('pagination')
      // this.$emit('choosefuc', this.rightchooseList)
    },
    // 分页处理
    pagination(pageNo, pageSize, array) {
      let offset = (pageNo - 1) * pageSize
      return (offset + pageSize >= array.length) ? array.slice(offset, array.length) : array.slice(offset, offset + pageSize)
    },
    //如果相等，则样式颜色变化
    handleRowStyle({ row }) {
      if (this.rightTableData.some(rightRow => this.checkObjectIsEqual(rightRow, row))) {
        return {
          color: '#0d6ca2'
        }
      }
      return {}
    },
    handleSelectable(row) {
      return !this.rightTableData.some(rightRow => this.checkObjectIsEqual(rightRow, row))
    },
    //添加
    addToRight() {
      for (const item of this.leftSelection) {
        const isHave = this.rightTableData.some(rightRow => this.checkObjectIsEqual(rightRow, item))
        if (!isHave) {
          this.rightTableData.push(item)
        }
      }
      // this.rightTableTotal = this.rightTableData.length
      // this.rightchooseList = this.pagination(this.pageIndex2, this.pageSize2, this.rightTableData)
      this.onRightQuerySubmit()
      console.log('当前右侧的数据：' + JSON.stringify(this.rightTableData))
      //这里将筛选的数据发送
      this.$store.dispatch('depList', this.rightTableData)
      this.$store.dispatch('nodeList', this.rightTableData)
      this.$emit('input', this.rightTableData)
    },
    //删除
    addToLeft() {
      console.log(this.rightSelection, '右侧勾选的数据')
      this.rightSelection.forEach(item => {
        const index = this.rightTableData.findIndex(rightRow => this.checkObjectIsEqual(rightRow, item))
        if (index !== -1) {
          this.rightTableData.splice(index, 1)
          const leftRow = this.leftTableData.find(leftRow => this.checkObjectIsEqual(leftRow, item))
          if (leftRow) {
            this.$refs.leftTable.toggleRowSelection(leftRow, false)
          } 
        }
      })
      this.rightchooseList = this.pagination(this.pageIndex2, this.pageSize2, this.rightTableData)
      if (this.rightchooseList.length === 0 && this.pageIndex2 > 1) {
        this.pageIndex2 = this.pageIndex2 - 1
        this.rightchooseList = this.pagination(this.pageIndex2, this.pageSize2, this.rightTableData)
      }
      // this.rightTableTotal = this.rightTableData.length
      this.onRightQuerySubmit()
      console.log('当前右侧的数据：' + JSON.stringify(this.rightTableData))
      this.$store.dispatch('depList', this.rightTableData)
      this.$store.dispatch('nodeList', this.rightTableData)
      //2.24
      // this.$emit('input', this.rightTableData)
    },
    //左侧查询
    onLeftQuerySubmit() {
      console.log(this.leftQueryCondition, 676767)
      this.handlePaginationCallBack(this.leftQueryCondition)
     
    },
    //右侧查询
    onRightQuerySubmit(type) {
      //返回的是右侧查询条件
      console.log(this.rightQueryCondition, this.rightTableData, '565656555555')
      let temp = this.rightTableData
      if (this.showQuery && this.rightQueryCondition.sellerNo) { //查询商家
        this.rightchooseList = []
        for (let i = 0, size = temp.length; i < size; i++) {
          //console.log(temp[i].sellerNo, this.rightQueryCondition.sellerNo, 777)
          if (temp[i].sellerNo === this.rightQueryCondition.sellerNo) {
            this.rightchooseList.push(temp[i])
          }
        }
        temp = this.rightchooseList
      } else {
        this.rightchooseList = temp
      }
      if (this.showQuery && this.rightQueryCondition.deptNo) { //查询事业部
        this.rightchooseList = []
        for (let i = 0, size = temp.length; i < size; i++) {
          if (temp[i].deptNo === this.rightQueryCondition.deptNo) {
            this.rightchooseList.push(temp[i])
          }
        }
        temp = this.rightchooseList
      } else {
        this.rightchooseList = temp
      }
      if (this.showQuery && this.rightQueryCondition.nodeType) { //查询类型
        this.rightchooseList = []
        for (let i = 0, size = temp.length; i < size; i++) {
          if (temp[i].nodeType === this.rightQueryCondition.nodeType) {
            this.rightchooseList.push(temp[i])
          }
        }
        temp = this.rightchooseList
      } else {
        this.rightchooseList = temp
      }
      if (this.showQuery && this.rightQueryCondition.nodeNoOrNameKeyword) { //查询库节点名称
        this.rightchooseList = []
        for (let i = 0, size = temp.length; i < size; i++) {
          if (temp[i].nodeName.toLowerCase().indexOf(this.rightQueryCondition.nodeNoOrNameKeyword.toLowerCase()) !== -1 ||
          temp[i].nodeNo.toLowerCase().indexOf(this.rightQueryCondition.nodeNoOrNameKeyword.toLowerCase()) !== -1) {
            this.rightchooseList.push(temp[i])
          }
        }
        temp = this.rightchooseList
      } else {
        this.rightchooseList = temp
      }
      this.rightTableTotal = this.rightchooseList.length
      console.log(this.rightchooseList, 4444)
      if (type !== 'pagination') { //当不是点击分页查询时
        this.pageIndex2 = 1
      } else {
        if (this.rightchooseList.length <= 10) {
          this.pageIndex2 = 1
        }
      }
      this.rightchooseList = this.pagination(this.pageIndex2, this.pageSize2, this.rightchooseList)
     
      console.log(this.rightTableData, this.rightchooseList, 123)
    },
    //判断是否相等
    checkObjectIsEqual(rowObj1, rowObj2) {
      // console.log(rowObj1, rowObj2, '对比————')
      return this.tableRowKey(rowObj1) === this.tableRowKey(rowObj2)
    },
    //重置
    resetLeftSubmit() {
      for (const key in this.leftQueryCondition) {
        this.leftQueryCondition[key] = undefined
      }
      this.pageIndex = 1
      this.pageSize = 10
      this.handlePaginationCallBack({ pageIndex: 1, pageSize: 10, sellerNo: '', nodeNo: '', nodeNoOrNameKeyword: '', nodeType: 0 })
      //发送一个事件给父组件，清空关联的事业部的数据this.deptListAllLeft
      this.$emit('handleLeftDeptClear')
    },
    resetRightSubmit() {
      for (const key in this.rightQueryCondition) {
        this.rightQueryCondition[key] = undefined
      }
      this.pageIndex2 = 1
      //发送一个事件给父组件，清空关联的事业部的数据deptListAllRight
      this.onRightQuerySubmit()
      this.$emit('handleRightDeptClear')
    },
    //清空数据
    clear() {
      this.rightTableData = []
      this.$refs.leftTable.clearSelection()
      for (const key in this.leftQueryCondition) {
        this.leftQueryCondition[key] = undefined
      }
      for (const key in this.rightQueryCondition) {
        this.rightQueryCondition[key] = undefined
      }
      this.pageIndex = 1
      this.handlePaginationCallBack()
    }
  }
}
</script>

<style scoped>
  .transfer {
    font-size: 14px;
    display: flex;
    justify-content: center;
    align-items: center;
  }
  .el-icon-arrow-right, .el-icon-arrow-left {
    font-size: 40px;
    cursor: pointer;
  }
  .transfer-panel {
    background: #FFFFFF;
    box-shadow: 0 0 20px 0 rgba(195,205,210,0.40);
    border-radius: 4px;
    border-radius: 4px;
    overflow: hidden;
    display: inline-block;
    /* 让左右两个面板等分 */
    width: calc((100% - 80px) / 2);
    max-height: 100%;
    box-sizing: border-box;
    position: relative
  }
  .transfer-panel .transfer-panel-header {
    height: 40px;
    line-height: 40px;
    background: #ffffff;
    margin: 0;
    padding-left: 20px;
    border-bottom: 1px solid #EBEEF5;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    color: #000;
  }
  .transfer-panel-header span:last-child {
    position: absolute;
    right: 15px;
  }
  .transfer-buttons {
    display: inline-block;
    vertical-align: middle;
    width: 80px;
  }
  .transfer-button {
    /* width: 30px;
    height: 30px; */
    display: block;
    margin: 0 auto;
    padding: 10px;
    border-radius: 4px;
    color: #FFF;
    background-color: #409EFF;
    font-size: 0
  }
  .transfer-button .button-text {
    margin-left: 2px;
    margin-right: 5px;
  }
  .transfer-button.is-with-texts {
    border-radius: 4px
  }
  .transfer-button.is-disabled, .transfer-button.is-disabled:hover {
    border: 1px solid #DCDFE6;
    background-color: #F5F7FA;
    color: #C0C4CC
  }
  .transfer-button:first-child {
    margin-bottom: 10px
  }
  .transfer-button:nth-child(2) {
    margin: 0 auto;
  }
  .transfer-button i, .transfer-button span {
    font-size: 14px
  }
  .query-form {
    margin: 20px 20px 0;
    
  }
  .query-form .lui-form-item{
    margin-bottom: 20px;
  }
  .pagepadding{
    padding:8px
  }
 .query-form .el-form-item {
    margin-bottom: 0;
  }
  /deep/ .lui-table.transfertable thead th{
  background: #D9F0FE!important;
}

</style>
