<template>
  <div class="tinymce-editor">
    <editor
      v-model="myValue"
      :init="init"
      :disabled="disabled"
      @onClick="onClick">
    </editor>
  </div>
</template>

<script>
import tinymce from 'tinymce/tinymce'
import Editor from '@tinymce/tinymce-vue'
import 'tinymce/themes/modern/theme'
import 'tinymce/plugins/image'
import 'tinymce/plugins/media'
import 'tinymce/plugins/link'
import 'tinymce/plugins/code'
import 'tinymce/plugins/table'
import 'tinymce/plugins/lists'
import 'tinymce/plugins/contextmenu'
import 'tinymce/plugins/wordcount'
import 'tinymce/plugins/colorpicker'
import 'tinymce/plugins/textcolor'
// import 'tinymce/plugins/indent2em'

export default {
  components: {
    Editor
  },
  props: {
    // 传入一个value，使组件支持v-model绑定
    value: {
      type: String,
      default: ''
    },
    disabled: {
      type: Boolean,
      default: false
    },
    plugins: {
      type: [String, Array],
      default: 'link lists image code table colorpicker textcolor wordcount contextmenu powerpaste'
    },
    toolbar: {
      type: [String, Array],
      default: 'undo redo | formatselect | bold italic forecolor | fontsizeselect fontselect | lineheightselect | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link unlink image | lists media table | removeformat | pastetext | code fullscreen'
    },
    height: {
      type: Number,
      default: 300
    },
    language: {
      type: String,
      default: 'zh_CN'
    }
  },
  data() {
    return {
      // 初始化配置
      init: {
        language_url: `/assets/tinymce/langs/${this.language}.js`,
        language: this.language,
        skin_url: '/assets/tinymce/skins/lightgray',
        height: this.height,
        plugins: this.plugins,
        toolbar: this.toolbar,
        branding: false,
        menubar: 'edit insert view format table',
        external_plugins: {
          'powerpaste': '/assets/tinymce/plugins/powerpaste/plugin.js',
          'lineheight': '/assets/tinymce/plugins/lineheight/plugin.js'
          // 'indent2em': '/assets/tinymce/plugins/indent2em/plugin.js'
        },
        fontsize_formats: '8pt 10pt 12pt 14pt 18pt 24pt 36pt',
        lineheight_formats: '8pt 9pt 10pt 11pt 12pt 14pt 16pt 18pt 20pt 22pt 24pt 26pt 36pt',
        powerpaste_word_import: 'prompt', // 参数可以是propmt, merge, clear
        powerpaste_html_import: 'prompt', // propmt, merge, clear
        powerpaste_allow_local_images: true, // 允许带图片
        // 此处为图片上传处理函数，这个直接用了base64的图片形式上传图片，
        // 如需ajax上传可参考https://www.tiny.cloud/docs/configure/file-image-upload/#images_upload_handler
        images_upload_handler: (blobInfo, success, failure) => {
          const img = 'data:image/jpeg;base64,' + blobInfo.base64()
          success(img)
        },
        file_browser_callback: function(field_name, url, type, win) {
        }
      },
      myValue: this.value
    }
  },
  watch: {
    value(newValue) {
      this.myValue = newValue
    },
    myValue(newValue) {
      this.$emit('input', newValue)
    }
  },
  mounted() {
    tinymce.init(this.init)
  },
  methods: {
    // 添加相关的事件，可用的事件参照文档=> https://github.com/tinymce/tinymce-vue => All available events
    // 需要什么事件可以自己增加
    onClick(e) {
      this.$emit('onClick', e, tinymce)
    },
    // 可以添加一些自己的自定义事件，如清空内容
    clear() {
      this.myValue = ''
    }
  }
}

</script>
<style scoped>
</style>
