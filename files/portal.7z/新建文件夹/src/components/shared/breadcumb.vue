<template>
  <div class="breadcrumbWrapper">
    <el-breadcrumb class="breadcrumbContent" separator="/">
      <el-breadcrumb-item
        v-for="(item,index) in breadcrumbObj.hrefList"
        :key="index"
        class="title"
        :to="{name:item.href,params:{type:item.type,id:item.id}}"
      >{{ item.title }}</el-breadcrumb-item>
      <el-breadcrumb-item class="currentTitle">{{ breadcrumbObj.currrentTitle }}</el-breadcrumb-item>
    </el-breadcrumb>
  </div>
</template>
<style lang="scss">
    .breadcrumbWrapper {
        line-height: 50px;
        margin-bottom: 15px;
        height: 50px;
        background: #FFFFFF;
        border-radius: 5px;
    }
    .breadcrumbWrapper .breadcrumbContent {
        padding-left: 15px;
    }
    .breadcrumbWrapper .title {
        float: left;
        height: 50px;
        line-height: 50px;
        color: #1295da;
        font-size: 14px;
        font-weight: 300 !important;
    }
    .breadcrumbWrapper .title .el-breadcrumb__inner.is-link {
        font-weight: 300;
    }
    .breadcrumbWrapper .currrentTitle {
        height: 50px;
        line-height: 50px;
    }
    .breadcrumbWrapper .currrentTitle .el-breadcrumb__inner {
        color: #1274da;
    }
    .breadcrumbWrapper .currrentTitle .el-breadcrumb__inner:hover {
        color: #1295da;
    }
    .currentTitle .el-breadcrumb__inner{
      color: #3C6EF0 !important;
      vertical-align: middle !important;
      line-height: 50px;
    }
</style>
<script>
export default {
  props: {
    breadcrumbObj: {
      type: Object
    }
  }
}
</script>
