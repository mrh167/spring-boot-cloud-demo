<template>
  <div ref="lineChart" class="line-chart" :style="style">
  </div>
</template>

<script>
import echarts from 'echarts'
import Utils from '@/utils'
export default {
  name: 'GlLineChart',
  props: {
    // echart宽度
    chartWidth: {
      type: Number,
      default: 0
    },
    // echart高度
    chartHeight: {
      type: Number,
      default: 0
    },
    data: {
      type: Object,
      default: () => {
        return {
          title: '',
          xAxis: [],
          yAxis: [],
          seriesArray: []
        }
      }
    }
  },
  data() {
    return {
      innerData: this.data,
      lineChart: null
    }
  },
  computed: {
    style() {
      return { width: this.chartWidth + 'px', height: this.chartHeight + 'px' }
    }
  },
  watch: {
    data: {
      handler(value) {
        this.innerData = value
        this.drawLine()
      },
      deep: true
    }
  },
  mounted() {
    setTimeout(() => {
      this.drawLine()
    }, 500)
  },
  beforeDestroy() {
    this.lineChart && this.lineChart.dispose()
    this.lineChart = null
  },
  methods: {
    initOption() {
      const chartData = this.innerData
      const option = {
        colors: chartData.colors || [],
        title: Utils.isString(chartData.title) ? {
          text: chartData.title || '',
          left: 'center',
          top: 20,
          textStyle: {
            color: '#000'
          }
        } : chartData.title,
        legend: chartData.legend || {
          x: 'center',
          y: 'bottom',
          data: []
        },
        tooltip: chartData.tooltip || {
          trigger: 'axis'
        },
        grid: chartData.grid || {
          top: 60,
          left: 40,
          right: 40,
          bottom: 40
        },
        xAxis: chartData.xAxis || [],
        yAxis: chartData.yAxis || [],
        series: []
      }

      chartData.seriesArray.forEach(series => {
        const data = {
          name: series.name || '',
          type: 'line',
          data: series.data || []
        }
        if (series.markPoint) {
          data.markPoint = series.markPoint || {} // 标点
        }
        // 颜色设置
        if (series.color) {
          data.color = series.color
        }
        // 其他属性
        if (series.smooth) {
          data.smooth = series.smooth || false
        }
        if (series.symbol) {
          data.symbol = series.symbol || 'circle'
        }
        if (series.symbolSize) {
          data.symbolSize = series.symbolSize || 10
        }
        data.showSymbol = series.showSymbol
        if (series.areaStyle) {
          data.areaStyle = series.areaStyle || {}
        }
        if (series.symbolSize) {
          data.legend = chartData.legend || {
            x: 'center',
            y: 'bottom',
            data: []
          }
        }
        if (series.itemStyle) {
          data.itemStyle = series.itemStyle || {
            normal: {
              color: '#5fbdff',
              lineStyle: {
                width: 3
              }
            }
          }
        }
        if (series.markLine) {
          data.markLine = series.markLine
        }
        if (series.yAxisIndex) {
          data.yAxisIndex = series.yAxisIndex || 0
        }
        option.series.push(data)
      })
      return option
    },
    // 刷新图表
    refreshChart() {
      if (!this.lineChart) return
      const option = this.initOption()
      this.lineChart.setOption(option, true)
    },
    // 绘制折线图
    drawLine() {
      this.lineChart = this.lineChart || echarts.init(this.$refs.lineChart)
      this.refreshChart()
      this.registerEvent()
    },
    // 注册事件
    registerEvent() {
      this.lineChart.on('click', (params) => {
        // 点击tooltip事件
        if (params.componentType === 'series' || params.componentType === 'markLine') {
          this.$emit('on-series-click', { params, seriesArray: this.innerData.seriesArray, xAxis: this.innerData.xAxis, yAxis: this.innerData.yAxis })
          this.refreshChart()
        }
      })
    },
    resize() {
      this.$nextTick(() => {
        this.lineChart && this.lineChart.resize()
      })
    }
  }
}
</script>

<style lang="scss" scoped>
</style>
