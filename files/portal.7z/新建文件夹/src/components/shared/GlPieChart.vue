<template>
  <div ref="pieChart" class="pie-chart" :style="style">
  </div>
</template>

<script>
import echarts from 'echarts'
import utils from '@/utils'
export default {
  name: 'GlPieChart',
  props: {
    // echart宽度
    chartWidth: {
      type: Number,
      default: 0
    },
    // echart高度
    chartHeight: {
      type: Number,
      default: 0
    },
    data: {
      type: Object,
      default: () => {
        return {
          title: {},
          tooltip: {},
          legend: {},
          seriesArray: []
        }
      }
    }
  },
  data() {
    return {
      innerData: this.data,
      pieChart: null
    }
  },
  computed: {
    style() {
      return { width: this.chartWidth + 'px', height: this.chartHeight + 'px' }
    }
  },
  watch: {
    data: {
      handler(newVal, oldVal) {
        if (this.pieChart) {
          this.innerData = newVal
        } else {
          this.innerData = oldVal
        }
        this.drawPie()
      },
      deep: true
    }
  },
  mounted() {
    setTimeout(() => {
      this.drawPie()
    }, 500)
  },
  beforeDestroy() {
    // echarts.dispose(this.$refs.pieChart)
    this.pieChart && this.pieChart.dispose()
    this.pieChart = null
  },
  methods: {
    initOption() {
      const data = this.innerData
      const option = {}
      if (utils.isString(data.title)) {
        option.title = {
          text: data.title,
          subtext: data.subtext,
          x: 'center'
        }
      } else {
        option.title = data.title
      }
      option.tooltip = data.tooltip || {}
      option.legend = data.legend || {}
      if (data.color && utils.isArray(data.color)) {
        option.color = data.color
      } else {
        option.color = ['#3A8FFF', '#F78384', '#2FC25B', '#FFA91D', '#975FE4']
      }
      option.series = []
      data.seriesArray.forEach(series => {
        const data = {
          name: series.name || '',
          type: series.type || 'pie',
          radius: series.radius || '55%',
          data: series.data || [],
          label: series.label || '',
          itemStyle: {
            emphasis: {
              shadowBlur: 10,
              shadowOffsetX: 0,
              shadowColor: 'rgba(0, 0, 0, 0.5)'
            }
          }
        }
        if (series.center) {
          data.center = series.center || ['50%', '50%']
        }
        if (series.roseType) {
          data.roseType = series.roseType || 'radius'
        }
        option.series.push(data)
      })
      return option
    },
    drawPie() {
      if (!this.pieChart) {
        this.pieChart = echarts.init(this.$refs.pieChart)
      }
      const option = this.initOption()
      this.pieChart.setOption(option, true)
    },
    updateChart() {
      const option = this.initOption()
      this.pieChart.setOption(option, true)
    },
    resize() {
      this.pieChart && this.pieChart.resize()
    }
  }
}
</script>

<style scoped>

</style>
