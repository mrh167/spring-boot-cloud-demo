<template>
  <div ref="lineBarChart" class="bar" :style="style">
  </div>
</template>

<script>
import echarts from 'echarts'
import utils from '@/utils'
export default {
  name: 'GlLineBarChart',
  props: {
    // echart宽度
    chartWidth: {
      type: Number,
      default: 0
    },
    // echart高度
    chartHeight: {
      type: Number,
      default: 0
    },
    data: {
      type: Object,
      default: () => {
        return {
          title: '',
          xAxis: [],
          yAxis: [],
          seriesArray: []
        }
      }
    }
  },
  data() {
    return {
      innerChartWidth: this.chartWidth,
      innerChartHeight: this.chartHeight,
      lineBarChart: null,
      options: []
    }
  },
  computed: {
    style() {
      return { width: this.innerChartWidth + '%', height: this.innerChartHeight + 'px' }
    }
  },
  watch: {
    chartWidth(value) {
      this.innerChartWidth = value
      this.resize()
    },
    chartHeight(value) {
      this.innerChartHeight = value
      this.resize()
    },
    data: {
      handler(value) {
        this.initChart()
      },
      deep: true
    }
  },
  mounted() {
    this.initChart()
  },
  beforeDestroy() {
    this.lineBarChart && this.lineBarChart.dispose()
    this.lineBarChart = null
  },
  methods: {
    resize() {
      this.$nextTick(() => {
        this.lineBarChart && this.lineBarChart.resize()
      })
    },
    updateChart() {
      this.lineBarChart.setOption(this.option, true)
    },
    initChart() {
      const that = this
      this.lineBarChart = echarts.init(this.$refs.lineBarChart)
      this.option = {
        colors: this.data.colors || [],
        title: {
          text: that.data.title || '',
          left: 'center',
          top: 20,
          textStyle: {
            color: '#000'
          }
        },
        legend: this.data.legend || {
          x: 'center',
          y: 'bottom',
          data: []
        },
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            type: 'shadow'
          }
        },
        xAxis: this.data.xAxis || [],
        yAxis: this.data.yAxis || [],
        series: []
      }
      this.data.seriesArray.forEach(series => {
        const data = {
          name: series.name || '',
          type: series.type || 'bar', // bar柱状图 line折线图
          barWidth: series.barWidth || '',
          markPoint: series.markPoint || {}, // 标点
          data: series.data || [],
          gradient: series.gradient || true, // 柱状图时，颜色是否需要渐变
          label: series.label || true, // 柱状图时，基本设置
          borderRadius: series.borderRadius || true, // 柱状图时，圆角是否需要渐变
          itemStyle: {
            normal: {
            }
          },
          barGap: series.barGap || 1,
          barCategoryGap: series.barCategoryGap || 1
        }
        if (series.type === 'bar') {
          // 柱状图圆角设置
          if (utils.isArray(series.barBorderRadius) && data.borderRadius) {
            data.itemStyle.normal.barBorderRadius = series.barBorderRadius
            // shadowBlur: [0, 0, 0, 10], // 拼接处
            // shadowColor: '#ebe806',// 拼接处
            // 如果2个柱状图叠加，而且需要圆角时，需要设置
            if (series.shadowBlur) {
              data.itemStyle.normal.shadowBlur = series.shadowBlur
            }
            if (series.shadowColor) {
              data.itemStyle.normal.shadowColor = series.shadowColor
            }
            if (series.shadowOffsetY) {
              data.itemStyle.normal.shadowOffsetY = series.shadowOffsetY
            }
          }
          // 柱状图其他设置
          if (utils.isObject(series.label) && data.label) {
            data.itemStyle.normal.label = series.label
          }
          // z-index设置
          if (series.zIndex) {
            data.z = series.zIndex
          }
          // 颜色设置
          if (series.color) {
            if (utils.isString(series.color) && data.gradient) { // 颜色渐变
              const color = new echarts.graphic.LinearGradient(0, 1, 0, 0, [{
                offset: 0,
                color: series.color // 0% 处的颜色
              }, {
                offset: 1,
                color: utils.hexToRgba(series.color, 0.6) // 100% 处的颜色
              }], false)
              data.itemStyle.normal.color = function(params) {
                return color
              }
            } else if (utils.isObject(series.color) || (utils.isString(series.color) && !data.gradient)) {
              data.itemStyle.normal.color = function() {
                return series.color
              }
            }
          }
        } else if (series.type === 'line') {
          data.color = series.color
        }
        this.option.series.push(data)
      })
      this.updateChart()
    }
  }
}
</script>

<style lang="scss" scoped>
</style>
