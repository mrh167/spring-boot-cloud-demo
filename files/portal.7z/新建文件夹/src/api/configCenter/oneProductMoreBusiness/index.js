
import Http from '@/lib/http'

const API = {
  //删除
  postDeleteGoodsMoreStore: params => Http.postPayload('/goodsMoreStore/delete', params),
  //一品多商列表
  postListPage: params => Http.postPayload('/goodsMoreStore/listPage', params),
  //商品列表
  postBaseGoodsInfo: params => Http.postPayload('/baseGoodsInfo/limitList', params),
  //添加
  saveGoodsMoreStore: params => Http.postPayload('/goodsMoreStore/save', params),
  //查看详情
  getDetails: params => Http.postPayload('/goodsMoreStore/get', params)

}

export default API
