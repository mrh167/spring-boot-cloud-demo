
import Http from '@/lib/http'

const API = {
  //列表
  postListPage: params => Http.postPayload('/warehouseRelation/pageList', params),
  //库节点分配规则
  postConstantRules: params => Http.postPayload('/constant/rules', params),
  //添加
  createWarehouseRelation: params => Http.postPayload('/warehouseRelation/create', params),
  //配出库节点列表
  postParentNodeList: params => Http.postPayload('/warehouseRelation/parentNodeList', params),
  //编辑
  editWarehouseRelation: params => Http.postPayload('/warehouseRelation/edit', params),
  //删除
  deleteWarehouseRelation: params => Http.postPayload('/warehouseRelation/delete', params),
  //查看详情
  getDetails: params => Http.postPayload('/warehouseRelation/details', params)
}

export default API
