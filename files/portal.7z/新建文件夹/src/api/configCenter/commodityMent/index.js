
import Http from '@/lib/http'

const API = {
  listPage: params => Http.postPayload('/nodeConfig/listPage', params), //列表页
  dropDownGoodsCate: params => Http.postPayload('/base/dropDownGoodsCate', params), //商品分类
  getNonConfigNum: params => Http.postPayload('/nodeConfig/getNonConfigNum', params), //校验可视化提示
  addNodeConfig: params => Http.postPayload('/nodeConfig/addNodeConfig', params), //添加舱内设置
  getNodeConfigDetail: params => Http.postPayload('/nodeConfig/getNodeConfigDetail', params), //编辑详情
  editNodeConfig: params => Http.postPayload('/nodeConfig/editNodeConfig', params), //编辑详情 提交
  getByNodeNo: params => Http.postPayload('/nodeConfig/getByNodeNo', params), //查看详情简易
  listDetailPageByNodeNo: params => Http.postPayload('/nodeConfig/listDetailPageByNodeNo', params), //分页查询仓内详情查看
  deleteNodeConfig: params => Http.postPayload('/nodeConfig/deleteNodeConfig', params), //删除
  getDimensionList: params => Http.postPayload('/constant/dim', params), //维度
  getChannelTypeList: params => Http.postPayload('/constant/channelType', params), //销售渠道
  getListNoGoods: params => Http.postPayload('/baseNodeInfo/listNoGoods', params), //未配置商品的节点列表
  

  downloadTemplate: `baseNodeInfo/downloadTemplate`, //模版下载
  download: `nodeConfig/download`, //批量下载
  downloadDetail: `nodeConfig/downloadDetail` //xiangqing下载
}
export default API
