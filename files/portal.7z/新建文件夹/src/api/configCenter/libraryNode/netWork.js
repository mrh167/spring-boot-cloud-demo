
import Http from '@/lib/http'

const API = {
  //商品类目列表
  listPage: params => Http.postPayload('/baseSupplierInfo/listPage', params), //列表获取
  uploadFile: params => Http.postPayload('/baseSupplierInfo/upload', params), //批量上传
  delete: params => Http.postPayload('/baseSupplierInfo/delete', params), //删除
  add: params => Http.postPayload('/baseSupplierInfo/add', params), //添加
  edit: params => Http.postPayload('/baseSupplierInfo/edit', params), //添加
  get: params => Http.postPayload('/baseSupplierInfo/get', params), //获取


  downloadTemplate: `baseSupplierInfo/downloadTemplate`, //模版下载
  download: `baseSupplierInfo/download` //批量下载
}

export default API
