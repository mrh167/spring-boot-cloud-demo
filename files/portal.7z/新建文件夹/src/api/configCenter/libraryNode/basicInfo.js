
import Http from '@/lib/http'

const API = {
  listPage: params => Http.postPayload('/baseNodeInfo/listPage', params), //列表页
  constantNodeType: params => Http.postPayload('/constant/nodeType', params), //库节点类型
  batchUpload: params => Http.postPayload('/baseNodeInfo/batchUpload', params), //批量上传
  delete: params => Http.postPayload('/baseNodeInfo/delete', params), //批量上传
  editShow: params => Http.postPayload('/baseNodeInfo/editShow', params), //是否显示
  infoAdd: params => Http.postPayload('/baseNodeInfo/add', params), //添加
  infoEdit: params => Http.postPayload('/baseNodeInfo/edit', params), //添加
  jdAddress: params => Http.postPayload('/base/jdAddress', params), //省市区获取
  getDetails: params => Http.postPayload('/baseNodeInfo/get', params), //获取详情
  postList: params => Http.postPayload('/baseNodeInfo/list', params), //工厂列表
  getShopLevel: params => Http.postPayload('/constant/getShopLevel', params), //库节点等级
  downloadTemplate: `baseNodeInfo/downloadTemplate`, //模版下载
  download: `baseNodeInfo/download` //模版下载
}
export default API
