
import Http from '@/lib/http'

const API = {
  //删除
  postDeleteDysonStoresStock: params => Http.postPayload('/dysonStoresStock/delete', params),
  //历史库存列表
  postListPage: params => Http.postPayload('/dysonStoresStock/pageList', params),
  //覆盖数据
  postOverlay: params => Http.get('/dysonStoresStock/overlay', params)
}

export default API
