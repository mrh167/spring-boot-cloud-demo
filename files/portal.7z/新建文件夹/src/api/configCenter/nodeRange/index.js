
import Http from '@/lib/http'

const API = {
  //列表
  postListPage: params => Http.postPayload('/baseNodePriority/listPage', params),
  //添加
  saveBaseNodePriority: params => Http.postPayload('/baseNodePriority/save', params),
  //编辑
  editBaseNodePriority: params => Http.postPayload('/baseNodePriority/edit', params),
  //删除
  postDeleteBaseNodePriority: params => Http.postPayload('/baseNodePriority/delete', params),
  //获取所有省市
  getAllAddress: params => Http.get('/address/all', params),
  //获取库节点列表
  postNodeByCityAndType: params => Http.postPayload('/baseNodeInfo/getNodeByCityAndType', params),
  //获取优先级下拉
  postPriority: params => Http.postPayload('baseNodePriority/priority', params),
  //根据事业部获取库节点
  postNodesByDept: params => Http.postPayload('baseNodeInfo/getNodesByDept', params),
  //未配置覆盖库节点
  postNoNodeCity: params => Http.postPayload('baseNodePriority/noNodeCity', params),
  //已配置库节点城市
  postAllCityNoCover: params => Http.postPayload('address/allCityNoCover', params)

}

export default API
