import Http from '@/lib/http'

const API = {
  listPage: params => Http.postPayload('/baseGoodsInfo/listPage', params), //商品主数据
  queryDept: params => Http.postPayload('/base/queryDept', params), //当前用户事业部
  baseGoodsAdd: params => Http.postPayload('/baseGoodsInfo/add', params), //新增
  baseGoodsEdit: params => Http.postPayload('/baseGoodsInfo/edit', params), //编辑
  category: params => Http.postPayload('/baseGoodsCate/list', params), //商品分类
  baseSupplierInfo: params => Http.postPayload('/baseSupplierInfo/list', params), //供应商获取
  upload: params => Http.postPayload('/baseGoodsInfo/upload', params), //批量上传
  delete: params => Http.postPayload('/baseGoodsInfo/delete', params), //批量删除
  channelType: params => Http.postPayload('/constant/channelType', params), //销售渠道
  goodsType: params => Http.postPayload('/constant/goodsType', params), //商品类型
  lifeCycle: params => Http.postPayload('/constant/lifeCycle', params), //生命周期
  season: params => Http.postPayload('/constant/season', params), //季节
  details: params => Http.postPayload('/baseGoodsInfo/get', params), //获取详情
  dangerous: params => Http.get('/baseGoodsInfo/dangerous', params), //运输危险品
  downloadTemplate: `baseGoodsInfo/downloadTemplate`, //模版下载
  download: `baseGoodsInfo/download` //批量下载

}

export default API
