
import Http from '@/lib/http'

const API = {
  //商品类目列表
  postAddBaseGoodsCate: params => Http.postPayload('/baseGoodsCate/add', params),
  postEditBaseGoodsCate: params => Http.postPayload('/baseGoodsCate/edit', params),
  postBaseGoodsCate: params => Http.postPayload('/baseGoodsCate/list', params),
  postDeleteBaseGoodsCate: params => Http.postPayload('/baseGoodsCate/delete', params),
  postListPage: params => Http.postPayload('/baseGoodsCate/listPage', params),
  postListLike: params => Http.postPayload('/baseGoodsCate/listLike', params),
  postKeywords: params => Http.postPayload('/association/keywords', params) //模糊查询
}

export default API
