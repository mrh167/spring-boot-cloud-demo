
import Http from '@/lib/http'

const API = {
  //删除
  postDeleteDysonStoresOrder: params => Http.postPayload('/dysonStoresOrder/delete', params),
  //历史销量列表
  postListPage: params => Http.postPayload('/dysonStoresOrder/pageList', params),
  //覆盖数据
  postOverlay: params => Http.get('/dysonStoresOrder/overlay', params)
}

export default API
