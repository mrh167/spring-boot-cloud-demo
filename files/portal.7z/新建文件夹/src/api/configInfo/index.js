import Http from '@/lib/http'
const API = {
  //获取所有菜单角色
  getRole: params => Http.get('/system/sellerInfo/getAllServerWithMenuRoles', params),
  //根据编号sellNo查询获取账号系统的商家信息
  getSellerBySellerNo: params => Http.get('/system/sellerInfo/getSellerBySellerNo', params),
  //添加的接口
  getUserAdd: params => Http.postPayload('/system/configCenter/add', params),
  //分页查询的方法
  getAccountPageList: params => Http.postPayload('/system/configCenter/pageList', params),
  //修改列表状态
  updateAccountStatus: params => Http.postPayload('/system/configCenter/updateStatusById', params),
  //列表进编辑id主键查询接口地址 /manage/userInfo/getById
  accountGetById: params => Http.postPayload('/system/configCenter/getById', params),
  //修改编辑页
  handleEdit: params => Http.postPayload('/system/configCenter/edit', params),
  //批量删除方法
  deleteUserInfo: params => Http.postPayload('/system/configCenter/deleteByIds', params),
  //批量下载方法
  downloadUserInfo: params => Http.postPayload('/system/configCenter/downloadBatch', params),
  //下载一个连接
  downloadUserInfoUrl: `system/configCenter/downloadBatch`,
  //下载一个空模板(暂时没给)
  downloadTemplate: `system/configCenter/downloadTemplate`,
  //上传地址
  uploadActionUrl: `system/configCenter/uploadBatch`,
  //获取产品及菜单
  getMyServerWithMenuRoles: params => Http.get('/system/configCenter/getMyServerWithMenuRoles', params)
  /* deleteUserInfo: params => Http.post('/user/getUserCountByDept.json', params),
  updateStatusUser: params => Http.post('/user/updateUserStatus.json', params),
  updateUser: params => Http.post('/user/updateUser.json', params)*/
}
export default API

