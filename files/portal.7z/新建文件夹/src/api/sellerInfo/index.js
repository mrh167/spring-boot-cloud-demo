
import Http from '@/lib/http'
// import MockData from './mock'
const API = {
  // 分页查询
  getSellerInfoList: (params) => Http.postPayload('/system/sellerInfo/listPage', params),
  // 查询ECLP商家信息
  getSellerByEclp: (params) => Http.get('/system/sellerInfo/getSellerByEclp', params),
  // 列表点击id编辑
  getSellerInfoById: (params) => Http.get('/system/sellerInfo/getSellerById', params),
  // 添加页面 下一步
  addSellerInfo: (params) => Http.postPayload('/system/sellerInfo/add', params),
  // 状态修改
  updateStatusSellerInfo: (params) => Http.postPayload('/system/sellerInfo/updateStatusById', params),
  // 编辑更新提交
  updateSellerInfo: (params) => Http.postPayload('/system/sellerInfo/updateById', params),
  //获取所有系统服务updateSellerInfo
  getAllSysServer: (params) => Http.get('/system/sellerInfo/getAllServerWithConfigs', params),
  // 获取个性化配置
  getServerConfigByServerCode: (params) => Http.postPayload('/system/sellerInfo/getServerConfigByServerCode', params),
  //批量删除方法
  deleteSellerInfo: params => Http.postPayload('/system/sellerInfo/deleteByIds', params),
  //批量下载方法
  downloadSellerInfo: params => Http.postPayload('/system/sellerInfo/downloadBatch', params),
  //下载一个连接
  downloadSellerInfoUrl: `system/sellerInfo/downloadBatch`,
  //默认获取事业部编码
  getDeptNot: params => Http.get('/system/sellerInfo/genDeptNo', params)

}
export default API
/*if (process.env.NODE_ENV === 'mock') {
  API.getSellerInfoList = (params) => {
    return new Promise((resolve) => {
      debugger
      resolve(MockData.pageList)
    })
  }
}*/

