import Http from '@/lib/http'

const API = {
  listPage: params => Http.postPayload('/approvalConfig/listPage', params), //列表
  dropdownSellers: params => Http.postPayload('/association/dropdownSellers', params), //商家列表
  add: params => Http.postPayload('/approvalConfig/addApprovalConfig', params), //新增
  getDetail: params => Http.postPayload('/approvalConfig/getDetail', params), //获取详情
  editSave: params => Http.postPayload('/approvalConfig/editSave', params), //编辑保存
  deleteBatch: params => Http.postPayload('/approvalConfig/deleteBatch', params) //删除
}
export default API
