import Http from '@/lib/http'

const API = {
  pageList: params => Http.postPayload('/approvalBill/listPage', params), //数据列表
  getDetail: params => Http.postPayload('/approvalBill/getDetail', params) //数据详情
}
export default API
