import Http from '@/lib/http'

const API = {
  dynamicTabs: params => Http.postPayload('/workbench/dynamicTabs', params), //动态菜单
  dynamicFilterBox: params => Http.postPayload('/workbench/dynamicFilterBox', params), //动态条件
  dynamicListPage: params => Http.postPayload('/workbench/dynamicListPage', params), //动态表格
  dynamicTitle: params => Http.postPayload('/workbench/dynamicTitle', params), //动态表头
  submitApproval: params => Http.postPayload('/approvalBill/submitApproval', params), //审批接口
  submitApprovalBatch: params => Http.postPayload('/workbench/submitApprovalBatch', params), //批量
  query: params => Http.postPayload('/doc/query', params)// 筛选接口、


}
export default API
