import Http from '@/lib/http'

const API = {
  save: params => Http.postPayload('/approval/save', params), //新增
  pageList: params => Http.postPayload('/approval/pageList', params), //数据列表
  detail: params => Http.postPayload('/approval/detail', params), //数据详情
  deleteById: params => Http.postPayload('/approval/deleteById', params), //数据删除
  update: params => Http.postPayload('/approval/update', params), //数据删除
  selectFilterType: params => Http.get('/approval/selectFilterType', params), //查询筛选类型
  setDomain: params => Http.get('/approval/selectDomain', params), //系统来源
  selectBillType: params => Http.get('/approval/selectBillType', params) //查询审批业务类型
}
export default API
