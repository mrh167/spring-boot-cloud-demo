import Http from '@/lib/http'

const API = {
  appCenterList: params => Http.postPayload('/manage/appCenter/listPage', params), //列表
  appCenterDelete: params => Http.get('/manage/appCenter/delete', params), //删除
  appCenterEditTop: params => Http.get('/manage/appCenter/editTop', params), //置顶
  appCenterSetIfShow: params => Http.get('/manage/appCenter/setIfShow', params), //是否显示
  appCenterCreate: params => Http.postPayload('/manage/appCenter/create', params), //新增
  appCenterGet: params => Http.get('/manage/appCenter/get', params), //预览
  appCenterEdit: params => Http.postPayload('/manage/appCenter/edit', params), //编辑
  //用户端 appCenter/pageList
  UserAppCenterList: params => Http.postPayload('/appCenter/pageList', params), //列表
  UserAppCenterGet: params => Http.get('/appCenter/findById', params) //列表
}
export default API
