import Http from '@/lib/http'

const API = {
  postChannelList: params => Http.postPayload('/accounttypeApp/list', params)
}
export default API
