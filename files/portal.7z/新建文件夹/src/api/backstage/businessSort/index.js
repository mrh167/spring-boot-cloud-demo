import Http from '@/lib/http'

const API = {
  listPage: params => Http.postPayload('/system/sellerWhitelist/listPage', params), //列表
  delete: params => Http.postPayload('/system/sellerWhitelist/delete', params), //批量删除
  add: params => Http.postPayload('/system/sellerWhitelist/add', params), //新增
  edit: params => Http.postPayload('/system/sellerWhitelist/editSave', params), //编辑
  getDetail: params => Http.postPayload('/system/sellerWhitelist/getDetail', params), //查看
  query: params => Http.postPayload('/enum/query', params), //枚举获取


  download: `system/sellerWhitelist/download`, //批量下载
  downloadTemplate: `system/sellerWhitelist/downloadTemplate` //模版下载
}
export default API
