import Http from '@/lib/http'

const API = {
  tenantList: params => Http.postPayload('/system/customer/pageList', params), //列表
  tenantAdd: params => Http.postPayload('/system/customer/create', params), //添加
  tenantEdit: params => Http.postPayload('/system/customer/edit', params), //编辑
  tenantDel: params => Http.get('/system/customer/deleteById', params) //删除
}
export default API
