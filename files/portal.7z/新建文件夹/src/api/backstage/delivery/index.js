
import Http from '@/lib/http'

const API = {
  deliveryListPage: params => Http.postPayload('/manage/accuratePut/listPage', params), //投放列表
  deliveryAdd: params => Http.post('/manage/accuratePut/addAccuratePutWithPin', params), //添加接口
  deliveryEdit: params => Http.postPayload('/manage/accuratePut/updateAccuratePut', params), //编辑接口
  deliveryDel: params => Http.postPayload('/manage/accuratePut/deleteByIds', params), //删除

  deliveryDownloadPinPackage: `manage/accuratePut/downloadPinPackage`, //下载PIN包
  deliveryDownView: `manage/accuratePut/downloadPinPackageView`, //查看
  deliveryDownloadTemplate: `manage/accuratePut/downloadTemplate` //模版下载
}
export default API
