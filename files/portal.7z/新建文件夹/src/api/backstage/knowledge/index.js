import Http from '@/lib/http'

const API = {
  knowledgeList: params => Http.postPayload('/manage/delpDoc/managePage', params), //列表
  knowledgeCreate: params => Http.postPayload('/manage/delpDoc/create', params), //新增
  knowledgeEdit: params => Http.postPayload('/manage/delpDoc/edit', params), //编辑
  knowledgeByid: params => Http.get('/manage/delpDoc/manageFindById', params), //查看
  knowledgeDele: params => Http.get('/manage/delpDoc/deleteById', params), //删除
  knowledgeTop: params => Http.get('/manage/delpDoc/editCatalogTop', params), //置顶
  knowledgeShow: params => Http.get('/manage/delpDoc/editShow', params), //显示
  knowledgedrefts: params => Http.postPayload('/manage/delpDoc/manageRaftsPageList', params) //草稿箱列表
}
export default API
