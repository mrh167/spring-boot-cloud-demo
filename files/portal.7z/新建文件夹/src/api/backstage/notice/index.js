import Http from '@/lib/http'

const API = {
  manageNoticeList: params => Http.postPayload('/manage/notice/managePage', params), //列表
  manageNoticeAdd: (params) => Http.postPayload('/manage/notice/create', params), //添加
  manageNoticeDel: params => Http.get('/manage/notice/deleteById', params), //删除
  manageNoticeEdit: params => Http.postPayload('/manage/notice/edit', params), //编辑
  manageNoticeGet: params => Http.postPayload('/manageNotice/get', params), //查看
  manageInfoById: params => Http.get('/manage/notice/manageInfoById', params), //查看
  manageNoticePlacement: params => Http.get('/manage/notice/editCatalogTop', params), //是否置顶
  manageNoticeSetIfShow: params => Http.get('/manage/notice/editShow', params) //是否显示/manage/notice/editShow
}
export default API
