import Http from '@/lib/http'

const API = {
  manageBroadcastList: params => Http.postPayload('/manage/broadcast/listPage', params), //列表
  manageBroadcastAdd: params => Http.postPayload('/manage/broadcast/add', params), //add
  manageBroadcastEdit: params => Http.postPayload('/manage/broadcast/edit', params), //edit
  manageBroadcastDelete: params => Http.get('/manage/broadcast/delete', params), //delete
  manageBroadcastSetIfShow: params => Http.get('/manage/broadcast/setIfShow', params) //是否显示
}
export default API
