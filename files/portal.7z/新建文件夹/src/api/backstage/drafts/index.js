import Http from '@/lib/http'

const API = {
  manageRaftsPageList: params => Http.post('/manageHelpDoc/manageRaftsPageList', params), //草稿箱列表
  manageHelpDocEdit: params => Http.post('/manageHelpDoc/edit', params) //草稿箱编辑
}
export default API
