import Http from '@/lib/http'

const API = {
  bannerListPage: params => Http.postPayload('/manage/show/listPage', params), //轮播列表
  bannerDelete: params => Http.get('/manage/show/delete', params), //轮播删除
  bannerGet: params => Http.postPayload('/manage/show/get', params), //轮播详情
  bannerAdd: params => Http.postPayload('/manage/show/add', params), //轮播添加
  bannerSetIfShow: params => Http.get('/manage/show/setIfShow', params), //是否显示
  bannerEdit: params => Http.postPayload('/manage/show/edit', params), //修改
  imgUpload: (params) => Http.post('/img/upload', params) //图片上传
}
export default API
