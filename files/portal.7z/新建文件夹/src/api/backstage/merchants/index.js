import Http from '@/lib/http'

const API = {
  listPage: params => Http.postPayload('/sellerSettledLogInfo/listPage', params), //列表
  editSave: params => Http.postPayload('/sellerSettledLogInfo/editSave', params), //行内保存
  enableBatch: params => Http.postPayload('/sellerSettledLogInfo/enableBatch', params), //开启/关闭
  getSettledDept: params => Http.postPayload('/sellerSettledLogInfo/getSettledDept', params), //事业部查询
  getSettledContract: params => Http.postPayload('/sellerSettledLogInfo/getSettledContract', params), //点击合同查询
  deleteBatch: params => Http.postPayload('/sellerSettledLogInfo/deleteBatch', params), //删除
  setDeptBusiness: params => Http.postPayload('/sellerSettledLogInfo/setDeptBusinessClass', params), //是否智能商务仓
  regionEnum: params => Http.get('/sellerSettled/listRegisterRegionEnum', params), //获取签约区域枚举
  menuVersionEnum: params => Http.get('/sellerSettled/listMenuVersionEnum', params), //获取所有菜单版本枚举
  StatusEnum: params => Http.get('/sellerSettled/listOpenStatusEnum', params), //获取所有开通状态枚举
  ChannelEnum: params => Http.get('/sellerSettled/listOpenChannelEnum', params), //获取所有开通渠道枚举
  getAccountAuth: params => Http.get('/sellerSettled/getAccountAuth', params), //获取账号对应的操作权限
  SettledSeller: params => Http.postPayload('/sellerSettledLogInfo/clickBindingSettledSeller', params), //点击商家切换

  downloadBatch: `sellerSettledLogInfo/downloadBatch`, //批量下载
  //账号申请弹窗接口
  listAll: params => Http.postPayload('/SellerSettledUserInfo/listPage', params), //列表
  addApplicationRecord: params => Http.postPayload('/SellerSettledUserInfo/addApplicationRecord', params), //申请
  enable: params => Http.postPayload('/SellerSettledUserInfo/enableBatch', params), //开启
  enableBatchClose: params => Http.postPayload('/SellerSettledUserInfo/enableBatchClose', params), //关闭
  buttonPermission: params => Http.postPayload('/SellerSettledUserInfo/getButtonPermission', params), //删除按钮是否显示
  delete: params => Http.postPayload('/SellerSettledUserInfo/deleteBatch', params), //删除
  listOpenChannelEnum: params => Http.get('/SellerSettledUserInfo/listOpenChannelEnum', params), //状态
  countByBubble: params => Http.get('/SellerSettledUserInfo/countByBubble', params), //气泡
  //商家运营接口
  sellerList: params => Http.postPayload('/sellerOperation/pageList', params), //数据列表
  sellerdownload: `sellerOperation/downloadBatch` //批量下载
}
export default API
