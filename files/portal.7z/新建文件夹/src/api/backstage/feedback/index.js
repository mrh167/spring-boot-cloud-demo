import Http from '@/lib/http'

const API = {
  feedbackList: params => Http.postPayload('/manage/feedback/listPage', params), //列表
  feedbackDownload: params => Http.postPayload('/manage/feedback/download', params), //下载
  feedbackDownloadNew: `manage/feedback/download` //查看
}
export default API
