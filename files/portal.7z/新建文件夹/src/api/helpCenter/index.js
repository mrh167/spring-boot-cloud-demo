
import Http from '@/lib/http'

const API = {
  //顶通搜索
  postSearchTop: params => Http.postPayload('/portalHelpDoc/searchTop', params),
  //搜索中心
  postSearchHelp: params => Http.postPayload('/portalHelpDoc/searchHelp', params),
  //帮助中心导航栏
  getSearchHelpNavList: params => Http.get('/portalHelpDoc/catalogList', params),
  //帮助中心详情
  getSearchHelpDetails: params => Http.get('/portalHelpDoc/findById', params)
}

export default API
