//BOD商品配置
import Http from '@/lib/http'

const API = {
  listPage: params => Http.postPayload('/bodGoods/bodByGoodsListPage', params), // 商品配置列表
  category: params => Http.postPayload('/baseGoodsCate/list', params), //商品分类
  deleteBodGoods: params => Http.postPayload('/bodGoods/deleteBodGoods', params), //列表数据删除
  queryDept: params => Http.postPayload('/base/queryDept', params), //当前用户事业部
  unbindUpload: params => Http.postPayload('/bodGoods/unbindUpload', params), //批量解绑
  upload: params => Http.postPayload('/bodGoods/upload', params), //批量上传
  baseSupplierInfo: params => Http.postPayload('/baseSupplierInfo/list', params), //供应商获取
  letList: params => Http.postPayload('/baseGoodsInfo/listPage', params), //批量删除
  batchSaveBodGoods: params => Http.postPayload('/bodGoods/batchSaveBodGoods', params), //手工添加(批量保存分配商品)
  defaultBod: params => Http.postPayload('/bodBase/defaultBod', params), //默认BOD设置列表
  editBodGoods: params => Http.postPayload('/bodGoods/editBodGoods', params), //编辑保存
  settingDefaultBod: params => Http.postPayload('/bodBase/settingDefaultBod', params), //默认BOD添加
  // deleteBodNodes: params => Http.postPayload('/manage/bodNodes/deleteBodNodes', params), //默认BOD删除
  cancelDefaultBod: params => Http.postPayload('/bodBase/cancelDefaultBod', params), //默认BOD删除
  bodGoodDetailPage: params => Http.postPayload('/bodGoods/bodGoodDetailPage', params), //BOD分配详情
  bodGoodDetailPagetree: params => Http.postPayload('/bodGoods/bodGoodDetailPage', params), //BOD分配详情树形结构
  getBodGoodsByBodNo: params => Http.postPayload('/bodGoods/getBodGoodsByBodNo', params), //BOD编辑详情
  batchEditBodGoods: params => Http.postPayload('/bodGoods/batchEditBodGoods', params), //修改(批量编辑分配商品)

  downloadTemplate: `bodGoods/templateDownload`, //模版下载
  unbindTemplateDownload: `bodGoods/unbindTemplateDownload`, // 商品配置解绑模板下载
  download: `bodGoods/download` //批量下载
}

export default API
