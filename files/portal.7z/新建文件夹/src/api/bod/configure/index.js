//BOD配置
import Http from '@/lib/http'

const API = {
  listPage: params => Http.postPayload('/bodBase/listPage', params), //bod配置列表
  getBaseByBodNo: params => Http.postPayload('/bodBase/getBaseByBodNo', params), //bod配置列表====下拉模糊搜索
  upload: params => Http.postPayload('/bodNodes/upload', params), //批量上传
  deleteBodNodes: params => Http.postPayload('/bodNodes/deleteBodNodes', params), //批量删除
  getNodesByBodNo: params => Http.postPayload('/bodNodes/getNodesByBodNo', params), // 详情
  getNodeNameByBodNo: params => Http.postPayload('/baseNodeInfo/getNodeNameByBodNo', params), //入口仓
  baseNodeInfo: params => Http.postPayload('/baseNodeInfo/list', params), //库节点
  distributionRules: params => Http.postPayload('/constant/distributionRules', params), //分配规则
  transportMode: params => Http.postPayload('/constant/transportMode', params), //运输方式
  saveBodBaseInfo: params => Http.postPayload('/bodNodes/saveBodBaseInfo', params), //新增保存
  editBodNodes: params => Http.postPayload('bodNodes/editBodNodes', params), //编辑保存

  downloadTemplate: `bodNodes/templateDownload`, //模版下载
  download: `bodNodes/download` //批量下载

}

export default API
