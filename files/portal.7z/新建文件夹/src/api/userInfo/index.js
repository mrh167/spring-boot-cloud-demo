import Http from '@/lib/http'
const API = {
  //获取所有菜单角色
  getRole: params => Http.get('/system/sellerInfo/getAllServerWithMenuRoles', params),
  //根据编号sellNo查询获取账号系统的商家信息
  getSellerBySellerNo: params => Http.get('/system/sellerInfo/getSellerBySellerNo', params),
  //添加
  getUserAdd: params => Http.postPayload('/system/userInfo/add', params),
  //修改
  editUserInfo: params => Http.postPayload('/system/userInfo/edit', params),
  //分页查询的方法
  getAccountPageList: params => Http.postPayload('/system/userInfo/pageList', params),
  //修改列表状态
  updateAccountStatus: params => Http.postPayload('/system/userInfo/updateStatusById', params),
  //列表进编辑id主键查询接口地址 /manage/userInfo/getById
  accountGetById: params => Http.postPayload('/system/userInfo/getById', params),
  //批量删除方法
  deleteUserInfo: params => Http.postPayload('/system/userInfo/deleteByIds', params),
  //批量下载方法
  downloadUserInfo: params => Http.postPayload('/system/userInfo/downloadBatch', params),
  //查询商家列表
  getSellerList: params => Http.get('/system/sellerInfo/listAll', params),
  //根据账号调用eclp jsf接口获取商家
  getEclpSellerByAccount: params => Http.postPayload('/system/accountInfo/getEclpSellerByAccount', params),
  //根据多个商家获取产品并集
  getMenuRolesBySellerNoList: params => Http.postPayload('system/sellerInfo/getMenuRolesBySellerNoList', params),
  //下载一个连接
  downloadUserInfoUrl: `system/userInfo/downloadBatch`,
  //下载一个空模板
  downloadTemplate: `system/userInfo/downloadTemplate`,
  //上传地址
  uploadActionUrl: `system/userInfo/uploadBatch`,
  //是否有配置数据权限
  hasDataPermission: params => Http.get('system/user/permission/hasDataPermission', params),
  //获取数据权限详情
  getPermissionByUser: params => Http.postPayload('system/user/permission/getPermissionByUser', params),
  //根据账户下拉商家
  dropDownSellerByAccount: params => Http.postPayload('system/user/permission/dropDownSellerByAccount', params),
  //根据分页查询库节点数据
  listPageBaseNodeBySeller: params => Http.postPayload('system/user/permission/listPageBaseNodeBySeller', params),
  //根据分页查询商家下事业部
  listPageDeptBySeller: params => Http.postPayload('system/user/permission/listPageDeptBySeller', params),
  //根据商家下拉事业部
  dropDownDeptBySeller: params => Http.postPayload('system/user/permission/dropDownDeptBySeller', params),
  //回显事业部数据（全量）
  getDeptPermissionByAccount: params => Http.postPayload('system/user/permission/getDeptPermissionByAccount', params),
  //回显事业部数据（分页）
  pageListDeptPermissionByAccount: params => Http.postPayload('system/user/permission/pageListDeptPermissionByAccount', params),
  //回显库节点数据（全量）
  getUserNodePermissionByAccount: params => Http.postPayload('system/user/permission/getUserNodePermissionByAccount', params),
  //回显库节点数据（分页）
  pageListUserNodePermissionByAccount: params => Http.postPayload('system/user/permission/pageListUserNodePermissionByAccount', params),
  //提交事业部数据
  submitDeptPermission: params => Http.postPayload('system/user/permission/submitDeptPermission', params),
  //提交库节点数据
  submitUserNodePermission: params => Http.postPayload('system/user/permission/submitUserNodePermission', params),
  //提交配置数据
  submitUserPermission: params => Http.postPayload('system/user/permission/getDeptPermissionByAccount', params),
  baseNodeInfo: params => Http.postPayload('constant/nodeType', params), //库节点/api/system/user/permission/toggleAlwaysAllPermission
  //切换是否全部数据
  toggleAlwaysAllPermission: params => Http.postPayload('system/user/permission/toggleAlwaysAllPermission', params), //库节点/api/
  //库节点-根据商家下拉已配置的事业部
  dropDownUserDeptBySeller: params => Http.postPayload('system/user/permission/dropDownUserDeptBySeller', params),
  // 事业部-确认移除事业部及事业下部库节点数据
  confirmSubmitUserDeptPermission: params => Http.postPayload('system/user/permission/confirmSubmitUserDeptPermission', params) 

}
export default API
