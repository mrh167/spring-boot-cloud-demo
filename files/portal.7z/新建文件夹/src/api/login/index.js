import Http from '@/lib/http'

const API = {
  //拒绝使用
  rejectUse: params => Http.postPayload('/sellerSettledLogInfo/reject', params), 
  //提交审批
  submitApproval: params => Http.postPayload('/sellerSettledLogInfo/submit', params), 
  //账号所属商家已入驻portal,但账号首次访问portal
  userFirstVisit: params => Http.postPayload('/sellerSettledLogInfo/userFirstVisit', params),
  //催办
  urge: params => Http.postPayload('/sellerSettledLogInfo/urge', params)
}
export default API
