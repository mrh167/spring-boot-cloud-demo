import ConfigInfo from './configInfo'
import SellerInfo from './sellerInfo'
import UserInfo from './userInfo'
import Home from './home'
import HelpCenter from './helpCenter'
import BackStageDeafts from './backstage/drafts'
import BackStageRotation from './backstage/rotation'
import BackStageNotice from './backstage/notice'
import BackStageBroadcast from './backstage/broadcast'
import BackStageFeedback from './backstage/feedback'
import BackStageDelivery from './backstage/delivery'
import BackStageKnowledge from './backstage/knowledge'
import BackStageTenant from './backstage/tenant'
import BackStageChannel from './backstage/channel'
import BackStageAppContent from './backstage/appContent'
import MessageInfo from './messageCenter'
import ConfigCenter from './configCenter'
import BaseGoodsInfo from './configCenter/masterData'
import oneProductMoreBusiness from './configCenter/oneProductMoreBusiness'
import BasicInfo from './configCenter/libraryNode/basicInfo'
import ConfigNetWork from './configCenter/libraryNode/netWork'
import NodeNetwork from './configCenter/nodeNetwork'
import NodeRange from './configCenter/nodeRange'
import BodConfig from './bod/configure'
import BodCommodity from './bod/commodity'
import Business from './business'
import CommodityMent from './configCenter/commodityMent/'
import ChainCommodity from './chain/commodity'
import BusinessSort from './backstage/businessSort'
import StartApproval from './backstage/approval/startApproval'
import DeployApproval from './backstage/approval/deployApproval'
import ManageApproval from './backstage/approval/manageApproval'
import WorkApproval from './backstage/approval/workApproval'
import Common from './common'
import InventoryData from './configCenter/inventoryData'
import SalesData from './configCenter/salesData'
import Merchants from './backstage/merchants'
import MerchantLogin from './login'


export default {
  ConfigInfo: {
    ...ConfigInfo
  },
  SellerInfo: {
    ...SellerInfo
  },
  UserInfo: {
    ...UserInfo
  },
  Home: {
    ...Home
  },
  HelpCenter: {
    ...HelpCenter
  },
  MessageInfo: {
    ...MessageInfo
  },
  BackStageDeafts: {
    ...BackStageDeafts
  },
  BackStageRotation: {
    ...BackStageRotation
  },
  BackStageNotice: {
    ...BackStageNotice
  },
  BackStageBroadcast: {
    ...BackStageBroadcast
  },
  BackStageFeedback: {
    ...BackStageFeedback
  },
  BackStageDelivery: {
    ...BackStageDelivery
  },
  BackStageKnowledge: {
    ...BackStageKnowledge
  },
  BackStageAppContent: {
    ...BackStageAppContent
  },
  BackStageTenant: {
    ...BackStageTenant
  },
  BackStageChannel: {
    ...BackStageChannel
  },
  ConfigCenter: {
    ...ConfigCenter
  },
  oneProductMoreBusiness: {
    ...oneProductMoreBusiness
  },
  BaseGoodsInfo: {
    ...BaseGoodsInfo
  },
  BasicInfo: {
    ...BasicInfo
  },
  ConfigNetWork: {
    ...ConfigNetWork
  },
  NodeNetwork: {
    ...NodeNetwork
  },
  NodeRange: {
    ...NodeRange
  },
  BodConfig: {
    ...BodConfig
  },
  BodCommodity: {
    ...BodCommodity
  },
  CommodityMent: {
    ...CommodityMent
  },
  Business: {
    ...Business
  },
  ChainCommodity: {
    ...ChainCommodity
  },
  StartApproval: {
    ...StartApproval
  },
  DeployApproval: {
    ...DeployApproval
  },
  BusinessSort: {
    ...BusinessSort
  },
  Common: {
    ...Common
  },
  ManageApproval: {
    ...ManageApproval
  },
  WorkApproval: {
    ...WorkApproval
  },
  InventoryData: {
    ...InventoryData
  },
  SalesData: {
    ...SalesData
  },
  Merchants: {
    ...Merchants
  },
  MerchantLogin: {
    ...MerchantLogin
  }
}
