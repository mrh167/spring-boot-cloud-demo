
import Http from '@/lib/http'

const API = {
  //运营动态
  getWithDefaultDetail: params => Http.get('/homePage/getWithDefaultDetail', params),
  //顶通搜索
  postSearchTop: params => Http.postPayload('/portalHelpDoc/searchTop', params),
  //系统公告详情
  getFindById: params => Http.get('/notice/findById', params),
  //待办事项-预测任务进行
  getTaskItem: params => Http.get('/followUp/getTaskItem', params),
  //待跟进事项-补调待办
  getPendingProcessingItem: params => Http.get('/followUp/getPendingProcessingItem', params),
  //待跟进事项-补调待审批
  getPendingApprovalItem: params => Http.get('/followUp/getPendingApprovalItem', params),
  //通知列表
  postPageList: params => Http.postPayload('/notice/pageList', params),
  //确认精准投放
  getConfirmaAcuratePut: params => Http.get('/accuratePut/confirm', params),
  //添加收藏夹
  postAddFavorites: params => Http.postPayload('/favorites/add', params),
  //获取收藏列表
  getFavorites: params => Http.get('/favorites/list', params),
  //获取精准投放
  getFirstAccuratePut: params => Http.get('/accuratePut/first', params),
  //小广播
  getBroadcastList: params => Http.get('/broadcast/list', params),
  //轮播图
  getBannerList: params => Http.get('/show/list', params),
  //个人信息
  getUserInfo: params => Http.get('/sellerAccessRecord/userInfo', params),
  //合同信息
  getUserStat: params => Http.get('/sellerAccessRecord/userStat', params),
  //修改手机号邮箱
  postEditPhoneAndEmail: params => Http.postPayload('/sellerAccessRecord/editPhoneAndEmail', params),
  //用户类型
  getHomePageUserType: params => Http.get('/homePage/userType', params),
  //添加问题反馈
  postAddFeedback: params => Http.postPayload('/feedback/add', params),
  //用户开通服务情况
  getUserServerSelectStatusByPin: params => Http.get('/operationDynamic/getUserServerSelectStatusByPin', params),
  //本地订单满足率
  getEnoughRateView: params => Http.get('/serviceLevel/get/enoughRateView', params),
  //妥投时长 && 物流跟踪
  getProperlyTimeAndLogisticsTrack: params => Http.get('/serviceLevel/get/properlyTimeAndLogisticsTrack', params),
  //异常报警-大指标
  getAbnormalWarn: params => Http.get('/abnormalWarn/get', params),
  //库存健康-大指标
  getInventoryHealth: params => Http.get('/inventoryHealth/getInventoryHealth', params),
  //服务水平-大指标
  getServiceLevel: params => Http.get('/serviceLevel/get/overview', params),
  //库存健康-库存诊断、在库
  getDiagnosis: params => Http.get('/inventoryHealth/getDiagnosis', params),
  //库存健康-出库、入库
  getInventoryStockCo: params => Http.get('/inventoryHealth/getInventoryStockCo', params),
  //库存健康-库存周转
  getTurnover: params => Http.get('/inventoryHealth/getTurnover', params),
  //异常报警 ehcarts 图
  abnormalWarngetAbnormalWarn: params => Http.get('/abnormalWarn/getTrendRangeQtyAll', params),
  //异常单量
  abnormalWarngetAbnormalView: params => Http.get('/abnormalWarn/getAbnormalView', params),
  //运营动态-揽收量
  getFlowDirection: params => Http.get('/operationDynamic/getFlowDirection', params),
  //运营动态-今日昨日订单量折线
  getBrokenLine: params => Http.get('/operationDynamic/getBrokenLine', params),
  //运营动态-今日监控中部指标
  getTodayMonitor: params => Http.get('/operationDynamic/getTodayMonitor', params),
  //运营动态-历史销量、本周预测
  getWeekPredictionView: params => Http.get('/operationDynamic/getWeekPredictionView', params),
  //判断是否eclp用户
  jurisdiction: params => Http.postPayload('/base/isEclp', params),
  //判断是否eclp用户，库节点主数据和供应商主数据使用
  isEclpForNodeAndSupplier: params => Http.postPayload('/base/isEclpForNodeAndSupplier', params),
  //商家切换-查询账号下绑定商家
  listSellersByCondition: params => Http.postPayload('/system/accountInfo/listSellersByCondition', params),
  //商家切换-更新选中商家
  updateSelectSeller: params => Http.postPayload('/system/accountInfo/updateAccountSelectSeller', params),
  //登出渠道类型 1运营 2商家
  getCurrentLoginAccountType: params => Http.get('/system/accountInfo/getCurrentLoginAccountType', params),
  //是否登录
  postIsLogin: params => Http.postPayload('/official/isLogin', params),
  //判断当前是否为isVolvo
  isVolvo: params => Http.get('/menu/isVolvo', params),

  //获取菜单列表
  getMenu: params => Http.get('/menu/getMenu', params),
  //获取账号权限 /、
  getVscSellerType: params => Http.postPayload('/sellerWhitelist/getVscSellerType', params)

}

export default API
