//公共接口
import Http from '@/lib/http'

const Api = {
  queryDept: params => Http.postPayload('/base/queryDept', params), // 事业部
  enumQuery: params => Http.postPayload('/enum/query', params) //枚举接口
}


export default Api
