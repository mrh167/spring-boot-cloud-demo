
import Http from '@/lib/http'

const API = {
  /**仓库数据查询页面
   *
   * @param params
   * @returns {Promise}
   */
  //事业部查询
  warehouseDeptSearch: params => Http.postPayload('/business/warehouse/dept', params),
  //仓库查询
  findWarehouse: params => Http.postPayload('/business/warehouse/findWarehouse', params),
  //下载部分
  warehouseDownload: params => Http.postPayload('/business/warehouse/download', params),
  //下载全部
  warehouseDownloadAll: params => Http.postPayload('/business/warehouse/downloadAll', params),
  //band查询
  warehouseFindBand: params => Http.postPayload('/business/warehouse/findBand', params),
  //分页查询
  findWarehouseMessage: params => Http.postPayload('/business/warehouse/page', params),
  //商家查询
  warehouseFindseller: params => Http.postPayload('/business/warehouse/seller', params),

  /**单据查询页面
   *
   */
  //事业部查询
  orderDeptSearch: params => Http.postPayload('/business/order/dept', params),
  //始发仓查询
  orderStaringWareHouse: params => Http.postPayload('/business/order/staringWareHouse', params),
  //下载部分-调拨单
  orderDownloadAllot: params => Http.postPayload('/business/order/downloadAllot', params),
  //下载部分-销售单
  orderDownloadMarket: params => Http.postPayload('/business/order/downloadMarket', params),
  //下载全部
  orderDownloadAll: params => Http.postPayload('/business/order/downloadAll', params),
  //分页查询
  findOrder: params => Http.postPayload('/business/order/findOrder', params),
  //商家查询
  orderFindseller: params => Http.postPayload('/business/order/seller', params),

  /**数商家看板页面
   *
   */
  //近7日各仓平均库存量
  findAvgOnWhQtty: params => Http.postPayload('/business/sellerBoard/findAvgOnWhQtty', params),
  //自然月时效订单
  findMongthAging: params => Http.postPayload('/business/sellerBoard/findMongthAging', params),
  //近7日各仓销售出库量
  findOutWhQtty: params => Http.postPayload('/business/sellerBoard/findOutWhQtty', params),
  //近7日时效订单占比
  findWeekAging: params => Http.postPayload('/business/sellerBoard/findWeekAging', params),
  //近7日库存与出库量
  findWhQtty: params => Http.postPayload('/business/sellerBoard/findWhQtty', params),

  /**运配数据查询页面
   *
   */
  //事业部查询
  luckWithDeptSearch: params => Http.postPayload('/business/shipping/dept', params),
  //仓库查询
  luckWithFindWarehouse: params => Http.postPayload('/business/shipping/findWarehouse', params),
  //下载部分
  luckWithDownload: `business/shipping/download`,
  //下载全部
  luckWithDownloadAll: `business/shipping/downloadAll`,
  //band查询
  luckWithFindBand: params => Http.postPayload('/business/shipping/findBand', params),
  //分页查询
  findLuckWith: params => Http.postPayload('/business/shipping/page', params),
  //商家查询
  luckWithFindseller: params => Http.postPayload('/business/shipping/seller', params)
}

export default API
