//商品替换
import Http from '@/lib/http'

const Api = {
  listPage: params => Http.postPayload('/replaceRelation/listPage', params), // 商品配置列表
  listDelete: params => Http.postPayload('/replaceRelation/deleteReplaceRelation', params), //列表删除
  keywords: params => Http.postPayload('/association/keywords', params), //和覆盖范围相关地址列表
  dropDownReplaceName: params => Http.postPayload('/replaceRelation/dropDownReplaceName', params), //名称
  addReplaceRelation: params => Http.postPayload('/replaceRelation/addReplaceRelation', params), //数据添加
  editSave: params => Http.postPayload('/replaceRelation/editSave', params), //数据编辑保存
  preview: params => Http.postPayload('/replaceRelation/previewReplaceRelation', params), //预览商品关系链
  detailReplaceRelationList: params => Http.postPayload('/replaceRelation/detailReplaceRelationList', params), //详情-列表数据与补货比例
  replaceHistory: params => Http.postPayload('/replaceRelation/replaceHistory', params), //详情-替换链历史版本
  detailReplaceRelationTree: params => Http.postPayload('/replaceRelation/detailReplaceRelationTree', params), //详情-树形数据
  dropdownGoods: params => Http.postPayload('/association/dropdownGoods', params), //新增商品下拉

  download: `replaceRelation/download` //批量下载
}


export default Api
