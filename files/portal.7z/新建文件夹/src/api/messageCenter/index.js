import Http from '@/lib/http'

const API = {
  msgSidePageList: params => Http.postPayload('/portalSysMsg/msgSidePageList', params), //消息侧边
  allRead: params => Http.get('/portalSysMsg/allRead', params), //全部已读
  deleteByIds: params => Http.postPayload('/portalSysMsg/deleteByIds', params), //批量删除
  msgPageList: params => Http.postPayload('/portalSysMsg/msgPageList', params), //消息列表
  partRead: params => Http.postPayload('/portalSysMsg/partRead', params), //批量已读
  unMsgCount: params => Http.get('/portalSysMsg/unMsgCount', params), //未读消息数
  noticePageList: params => Http.postPayload('/notice/pageList', params), //公告列表
  findById: params => Http.get('/notice/findById', params) //公告详情

}
export default API
