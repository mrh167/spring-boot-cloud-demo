const Home = () => import('@/views/index/home.vue')
// const PublicPage = () => import('@/views/PublicPage/PublicPage.vue')

export default [

  {
    path: '/home',
    name: 'Home',
    title: '首页',
    meta: {
      fid: '0',
      title: '首页',
      position: '首页'
    },
    component: Home
  },
  {
    path: '/userprofile',
    name: 'UserProfile',
    title: '个人概况',
    meta: {
      fid: 7,
      title: '个人概况',
      position: '管理中心 > 个人概况'
    },
    component: () => import('@/components/common/header/UserProfile')
  }
  // {
  //   path: '/login',
  //   name: 'Login',
  //   title: '登录',
  //   meta: {
  //     fid: 7,
  //     title: '登录',
  //     position: ''
  //   },
  //   component: () => import('@/views/login/Login.vue')
  // }
]
