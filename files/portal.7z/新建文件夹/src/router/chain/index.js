//商品替换
const Chain = () => import('@/views/chain/index.vue')
const CommitMask = () => import('@/views/chain/commodity/commitMask.vue')

export default [
  {
    path: '/chain',
    name: 'chain',
    title: '商品替换',
    meta: {
      fid: '8',
      title: '商品替换',
      position: '配置中心 > 参数配置 > 商品替换'
    },
    component: Chain
  },
  {
    path: '/commitMask',
    name: 'commitMask',
    title: '历史版本',
    meta: {
      fid: '8',
      title: '历史版本',
      position: '配置中心 > 参数配置 > 历史版本'
    },
    component: CommitMask
  }
]
