//管理后台
const Bod = () => import('@/views/bod/index.vue')
// const Test = () => import('@/views/bod/test.vue')

export default [
  {
    path: '/bod',
    name: 'Bod',
    title: 'BOD',
    meta: {
      title: 'Bod',
      position: '配置中心 > 参数配置 > BOD',
      fid: 8
    },
    component: Bod
  }
  // {
  //   path: '/test',
  //   name: 'Test',
  //   title: 'Test',
  //   meta: {
  //     title: 'Test',
  //     position: '管理中心 > 管理后台 > Test'
  //   },
  //   component: Test
  // }
]
