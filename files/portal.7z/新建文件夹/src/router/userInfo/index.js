const userInfo = () => import('@/views/userInfo/index.vue')

export default [
  {
    path: '/userInfo',
    name: 'userInfo',
    title: '账号配置',
    meta: {
      fid: 7,
      title: '账号配置',
      position: '管理中心 > 管理后台 > 权限管理'
    },
    component: userInfo
  }
  // {
  //   path: '/userInfo/addAccount',
  //   name: 'addAccount',
  //   meta: {
  //     title: '账号配置',
  //     position: '管理中心 > 管理后台 > 权限管理'
  //   },
  //   component: () => import('@/views/userInfo/AddAccount')
  // },
  // {
  //   path: '/userInfo/updateAccount',
  //   name: 'UpdateAccount',
  //   meta: {
  //     title: '账号配置',
  //     position: '管理中心 > 管理后台 > 权限管理'
  //   },
  //   component: () => import('@/views/userInfo/UpdateAccount')
  // },
  // {
  //   path: '/userInfo/viewAccount',
  //   name: 'viewAccount',
  //   meta: {
  //     title: '账号配置',
  //     position: '管理中心 > 管理后台 > 权限管理'
  //   },
  //   component: () => import('@/views/userInfo/ViewAccount')
  // }

]
