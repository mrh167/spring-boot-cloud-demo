const commodityCategory = () => import('@/views/configCenter/commodityCategory.vue')

export default [
  {
    path: '/goodsCate',
    name: 'GoodsCate',
    title: '商品类目',
    meta: {
      fid: 8,
      title: '商品类目',
      position: '配置中心 > 主数据 > 商品类目'
    },
    component: commodityCategory
  },
  {
    path: '/goodsMoreSupplier',
    name: 'GoodsMoreSupplier',
    title: '供应商网络配置',
    meta: {
      fid: 8,
      title: '供应商网络配置',
      position: '配置中心 > 主数据 > 供应商网络配置'
    },
    component: () => import('@/views/configCenter/oneProductMoreBusiness')
  },
  {
    path: '/goods',
    name: 'Goods',
    title: '商品主数据',
    meta: {
      fid: 8,
      title: '商品主数据',
      position: '配置中心 > 主数据 > 商品主数据'
    },
    component: () => import('@/views/configCenter/MasterData.vue')
  },
  {
    path: '/node',
    name: 'Node',
    title: '库节点基础信息',
    meta: {
      fid: 8,
      title: '库节点基础信息',
      position: '配置中心 > 主数据 > 库节点基础信息'
    },
    component: () => import('@/views/configCenter/LibrayData.vue')
  },
  {
    path: '/supplier',
    name: 'Supplier',
    title: '供应商主数据',
    meta: {
      fid: 8,
      title: '供应商主数据',
      position: '配置中心 > 主数据 > 供应商主数据'
    },
    component: () => import('@/views/configCenter/SupplierMasterData.vue')
  },
  {
    path: '/configCenter/nodeNetwork',
    name: 'NodeNetwork',
    title: '库节点网络结构',
    meta: {
      fid: 8,
      title: '库节点网络结构',
      position: '配置中心 > 主数据 > 库节点网络结构'
    },
    component: () => import('@/views/configCenter/NodeNetwork.vue')
  },
  {
    path: '/configCenter/nodeRange',
    name: 'NodeRange',
    title: '库节点仓覆盖范围',
    meta: {
      fid: 8,
      title: '库节点仓覆盖范围',
      position: '配置中心 > 库节点配置管理 > 库节点仓覆盖范围'
    },
    component: () => import('@/views/configCenter/NodeRange.vue')
  },
  {
    path: '/configCenter/commodityMent',
    name: 'commodityMent',
    title: '库节点商品管理',
    meta: {
      fid: 8,
      title: '库节点商品管理',
      position: '配置中心 > 库节点配置管理 > 库节点商品管理'
    },
    component: () => import('@/views/configCenter/commodityMent.vue')
  },
  {
    path: '/configCenter/goodsConfig',
    name: 'GoodsConfig',
    title: '库节点商品配置',
    meta: {
      fid: 8,
      title: '库节点商品配置',
      position: '配置中心 > 库节点商品配置'
    },
    component: () => import('@/views/configCenter/GoodsConfig.vue')
  },
  {
    path: '/configCenter/inventoryData',
    name: 'inventoryData',
    title: '门店历史库存数据',
    meta: {
      fid: 8,
      title: '门店历史库存数据',
      position: '配置中心 > 历史数据 > 门店历史库存数据'
    },
    component: () => import('@/views/configCenter/inventoryData.vue')
  },
  {
    path: '/configCenter/salesData',
    name: 'salesData',
    title: '门店历史销量数据',
    meta: {
      fid: 8,
      title: '门店历史销量数据',
      position: '配置中心 > 历史数据 > 门店历史销量数据'
    },
    component: () => import('@/views/configCenter/SalesData.vue')
  },
  {
    path: '/configCenter/test',
    name: 'test',
    title: '门店历史销量数据',
    meta: {
      fid: 8,
      title: '门店历史销量数据',
      position: '配置中心 > 历史数据 > 门店历史销量数据'
    },
    component: () => import('@/views/configCenter/test.vue')
  }
]
