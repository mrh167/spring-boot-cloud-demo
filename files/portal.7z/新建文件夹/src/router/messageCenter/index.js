const News = () => import('@/views/messageCenter/news/index.vue')
const Notice = () => import('@/views/messageCenter/Notice/index.vue')
// const About = () => import('@/views/messageCenter/about/index.vue')

export default [
  {
    path: '/news',
    name: 'News',
    title: '系统消息',
    meta: {
      fid: 7,
      title: '系统消息',
      position: '管理中心 > 消息管理 > 系统消息'
    },
    component: News
  },
  {
    path: '/notice',
    name: 'Notice',
    title: '系统公示',
    meta: {
      fid: 7,
      title: '系统公示',
      position: '管理中心 > 消息管理 > 系统公示'
    },
    component: Notice
  }
  // {
  //   path: '/about',
  //   name: 'About',
  //   title: '关于我们',
  //   meta: {
  //     title: '关于我们',
  //     position: '关于我们'
  //   },
  //   component: About
  // }
]
