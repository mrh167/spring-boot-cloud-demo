const configInfo = () => import('@/views/configInfo/index.vue')

export default [
  {
    path: '/configInfo',
    name: 'configInfo',
    title: '权限管理',
    meta: {
      fid: 7,
      title: '权限管理',
      position: '管理中心 > 权限管理'
    },
    component: configInfo
  }
  // {
  //   path: '/configInfo/addConfig',
  //   name: 'addConfig',
  //   meta: {
  //     title: '权限管理',
  //     position: '管理中心 > 权限管理'
  //   },
  //   component: () => import('@/views/configInfo/AddConfig')
  // },
  // {
  //   path: '/configInfo/updateConfig',
  //   name: 'updateConfig',
  //   meta: {
  //     title: '权限管理',
  //     position: '管理中心 > 权限管理'
  //   },
  //   component: () => import('@/views/configInfo/UpdateConfig')
  // },
  // {
  //   path: '/configInfo/viewConfig',
  //   name: 'viewConfig',
  //   meta: {
  //     title: '权限管理',
  //     position: '管理中心 > 权限管理'
  //   },
  //   component: () => import('@/views/configInfo/ViewConfig')
  // }

]
