import Vue from 'vue'
import VueRouter from 'vue-router'
// import Home from '../views/index/home.vue'
import SellerInfo from './sellerInfo'
import UserInfo from './userInfo'
import ConfigInfo from './configInfo'
// import Msite from './msite/index'
import messageCenter from './messageCenter'
// import PublicPage from './PublicPage'
import backstage from './backstage'
import Home from './home'
import HelpCenter from './helpCenter'
import Test from './test'
import permission from './permission'
import configCenter from './configCenter'
import NProgress from 'nprogress'
import Bod from './bod'
import Chain from './chain'
import Business from './business'
import '@/assets/stylus/nprogress/nprogress.css'

Vue.use(VueRouter)

const routes = [...SellerInfo, ...UserInfo, ...ConfigInfo, ...messageCenter, ...backstage, ...Home, ...HelpCenter, ...permission, ...configCenter, ...Test, ...Bod, ...Chain, ...Business]

const router = new VueRouter({
  // mode: 'history',
  //base: process.env.BASE_URL,
  routes
})
const originalPush = VueRouter.prototype.push
VueRouter.prototype.push = function push(location) {
  return originalPush.call(this, location).catch(err => err)
}

router.beforeEach((to, from, next) => {
  const menuList = sessionStorage.getItem('getMenu') ? JSON.parse(sessionStorage.getItem('getMenu')) : ''

  const wearp = document.getElementsByClassName('main-wrapper')[0]
  if (wearp) wearp.scrollTop = 0

  // if (wearp) {
  //   //��·�ɷ����仯��ҳ���ö�
  //   const step = document.getElementsByClassName('main-wrapper')[0].scrollTop / 100
  //   const backTopInterval = setInterval(function() {
  //     if (document.getElementsByClassName('main-wrapper')[0].scrollTop > 0) {
  //       document.getElementsByClassName('main-wrapper')[0].scrollTop -= step
  //     } else {
  //       clearInterval(backTopInterval)
  //     }
  //   }, 1)
  // }
  if (menuList) {
    if (menuList.includes(to.path)) {
      NProgress.start()
      next()
    } else {
      next({
        path: '/403'
      })
    }
  } else {
    NProgress.start()
    next()
  }
})
router.afterEach((to, from) => {
  NProgress.done()
})

export default router
