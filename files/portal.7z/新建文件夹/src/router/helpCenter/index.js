const HelpSearch = () => import('@/views/helpCenter/HelpSearch.vue')

export default [
  {
    path: '/helpsearch',
    name: 'HelpSearch',
    title: '帮助中心-搜索',
    meta: {
      fid: 9,
      title: '帮助中心-搜索',
      position: '帮助中心 > 搜索'
    },
    component: HelpSearch
  },
  {
    path: '/helpsearchdetails/:id',
    name: 'helpsearchdetails',
    title: '帮助中心-搜索',
    meta: {
      fid: 9,
      title: '帮助中心',
      position: '帮助中心'
    },
    component: () => import('@/views/helpCenter/HelpSearchDetails.vue')
  }
]
