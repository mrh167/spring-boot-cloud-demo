const SellerInfo = () => import('@/views/sellerInfo/index.vue')

export default [
  {
    path: '/sellerInfo',
    name: 'sellerInfo',
    title: '商家信息配置',
    meta: {
      fid: 7,
      title: '商家信息配置',
      position: '管理中心 > 管理后台 > 商家信息配置'
    },
    component: SellerInfo
  }
  // {
  //   path: '/sellerInfo/addSeller',
  //   name: 'addSeller',
  //   component: () => import('@/views/sellerInfo/AddSeller')
  // },
  // {
  //   path: '/sellerInfo/updateSeller',
  //   name: 'updateSeller',
  //   component: () => import('@/views/sellerInfo/UpdateSeller')
  // },
  // {
  //   path: '/sellerInfo/addUser',
  //   name: 'addUser',
  //   component: () => import('@/views/sellerInfo/AddUser')
  // }

]
