const Msite = () => import('../../views/msite/Msite.vue')

export default [
  {
    path: '/msite',
    name: 'Msite',
    component: Msite
  }
]
