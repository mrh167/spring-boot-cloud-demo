const WarehouseData = () => import('@/views/business/warehouseData.vue')
const Distribution = () => import('@/views/business/distribution.vue')
const Bill = () => import('@/views/business/bill.vue')
const BusinessBoard = () => import('@/views/business/businessBoard.vue')
export default [
  {
    path: '/business/warehouseData',
    name: 'WarehouseData',
    title: '仓库数据看板',
    meta: {
      fid: 11,
      title: '仓库数据看板',
      position: '智能商务仓 > 运营数据看板 > 仓库数据看板'
    },
    component: WarehouseData
  },
  {
    path: '/business/distribution',
    name: 'Distribution',
    title: '运配数据看板',
    meta: {
      fid: 11,
      title: '运配数据看板',
      position: '智能商务仓 > 运营数据看板 > 运配数据看板'
    },
    component: Distribution
  },
  {
    path: '/business/bill',
    name: 'Bill',
    title: '单据数据看板',
    meta: {
      fid: 11,
      title: '单据数据看板',
      position: '智能商务仓 > 运营数据看板 > 单据数据看板'
    },
    component: Bill
  },
  {
    path: '/business/businessBoard',
    name: 'BusinessBoard',
    title: '商家数据看板',
    meta: {
      fid: 11,
      title: '商家数据看板',
      position: '智能商务仓 > 商家数据看板'
    },
    component: BusinessBoard
  }
]
