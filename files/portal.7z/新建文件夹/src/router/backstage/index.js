//管理后台
const Tenant = () => import('@/views/backstage/tenant/index.vue') //租户管理

export default [
  {
    path: '/information',
    name: 'information',
    title: '信息管理',
    meta: {
      title: '信息管理',
      position: '管理中心 > 管理后台 > 信息管理',
      fid: 7
    },
    component: () => import('@/views/backstage/information')
  },
  {
    path: '/tenant',
    name: 'Tenant',
    title: '租户管理',
    meta: {
      title: '租户管理',
      position: '管理中心 > 管理后台 > 租户管理',
      fid: 7
    },
    component: Tenant
  },
  {
    path: '/channel',
    name: 'Channel',
    title: '应用渠道配置',
    meta: {
      title: '应用渠道配置',
      position: '管理中心 > 应用渠道配置',
      fid: 7
    },
    component: () => import('@/views/channel/channel.vue')
  },
  {
    //应用中心
    path: '/application',
    name: 'application',
    title: '应用中心',
    meta: {
      title: '应用中心',
      position: '应用中心',
      fid: 10
    },
    component: () => import('@/views/backstage/information/productDetails.vue')
  },
  {
    //商家分类管理
    path: '/businessSort',
    name: 'BusinessSort',
    title: '商家分类管理',
    meta: {
      title: '商家分类管理',
      position: '管理中心 > 商家分类管理',
      fid: 7
    },
    component: () => import('@/views/backstage/businessSort')
  },
  // {
  //   path: '/approval',
  //   name: 'Approval',
  //   title: '审批中心',
  //   meta: {
  //     title: '审批中心',
  //     position: '配置中心 > 参数配置 > 审批中心',
  //     fid: 7
  //   },
  //   component: () => import('@/views/backstage/approval/approval.vue')
  // },
  {
    path: '/startApproval',
    name: 'StartApproval',
    title: '审批接入配置',
    meta: {
      title: '审批接入配置',
      position: '管理中心 > 审批中心 > 审批接入配置',
      fid: 7
    },
    component: () => import('@/views/backstage/approval/startApproval.vue')
  },
  {
    path: '/deployApproval',
    name: 'DeployApproval',
    title: '审批流配置',
    meta: {
      title: '审批流配置',
      position: '管理中心 > 审批中心 > 审批流配置',
      fid: 7
    },
    component: () => import('@/views/backstage/approval/deployApproval.vue')
  },
  {
    path: '/manageApproval',
    name: 'ManageApproval',
    title: '审批单管理',
    meta: {
      title: '审批单管理',
      position: '管理中心 > 审批中心 > 审批单管理',
      fid: 7
    },
    component: () => import('@/views/backstage/approval/manageApproval.vue')
  },
  {
    path: '/workApproval',
    name: 'WorkApproval',
    title: '审批工作台',
    meta: {
      title: '审批工作台',
      position: '管理中心 > 审批中心 > 审批工作台',
      fid: 7
    },
    component: () => import('@/views/backstage/approval/workApproval.vue')
  },
  {
    path: '/merchants',
    name: 'merchants',
    title: '商家开通管理',
    meta: {
      title: '商家管理后台',
      position: '管理中心 > 管理后台 > 商家开通管理',
      fid: 7
    },
    component: () => import('@/views/backstage/merchants/merchants.vue')
  },
  {
    path: '/accountApplication',
    name: 'AccountApplication',
    title: '账号申请',
    meta: {
      title: '商家管理后台',
      position: '管理中心 > 管理后台 > 账号申请',
      fid: 7
    },
    component: () => import('@/views/backstage/merchants/accountApplication.vue')
  },
  {
    path: '/testPage',
    name: 'TestPage',
    title: '数据上传',
    meta: {
      title: '数据上传',
      position: '管理中心 > 管理后台 > 数据上传',
      fid: 7
    },
    component: () => import('@/views/backstage/merchants/testPage.vue')
  },
  {
    path: '/operations',
    name: 'Operations',
    title: '商家运营管理',
    meta: {
      title: '商家运营管理',
      position: '管理中心 > 管理后台 > 商家运营管理',
      fid: 7
    },
    component: () => import('@/views/backstage/merchants/operations.vue')
  }
]
//
