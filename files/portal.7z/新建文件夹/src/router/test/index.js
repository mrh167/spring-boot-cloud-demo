
const MyBarChartTest = () => import('@/views/test/MyBarChartTest')
const MyLineChartTest = () => import('@/views/test/MyLineChartTest')
const MyPieChartTest = () => import('@/views/test/MyPieChartTest')
const inputtest = () => import('@/views/test/inputtest')


export default [
  {
    path: '/inputtest',
    name: 'inputtest',
    component: inputtest
  },
  {
    path: '/barChart',
    name: 'BarChart',
    component: MyBarChartTest
  },
  {
    path: '/lineChart',
    name: 'LineChart',
    component: MyLineChartTest
  },
  {
    path: '/pieChart',
    name: 'PieChart',
    component: MyPieChartTest
  }
  
]
