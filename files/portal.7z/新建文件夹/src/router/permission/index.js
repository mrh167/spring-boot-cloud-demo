const permission403 = () => import('@/views/permission/403.vue')
const defaultPage = () => import('@/views/permission/default.vue')

export default [
  {
    path: '/403',
    name: '403',
    title: '',
    meta: {
      title: '403',
      position: '403'
    },
    component: permission403
  },
  {
    path: '/defaultPage',
    name: 'defaultPage',
    title: '',
    meta: {
      title: 'defaultPage',
      position: 'defaultPage'
    },
    component: defaultPage
  }

  // {
  //   path: '/helpsearchdetails',
  //   name: 'HelpsearchDetails',
  //   title: '帮助中心-搜索',
  //   component: () => import('@/views/helpCenter/HelpSearchDetails.vue')
  // }
]
